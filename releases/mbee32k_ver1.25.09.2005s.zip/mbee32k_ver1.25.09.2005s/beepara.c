
#include "fakealeg.h"
#include <stdio.h>
#include <stdlib.h>
#include "z80pio.h"
#include "beepara.h"
#include "u_dtype.h"
#include "beelowpc.h"
#include "configer.h"
#include "debmaloc.h"

/*
   beepara_state - (applicable to modes 1-2,5)
                   0 = output mode- waiting for data from pio
                   1 = output mode- data received, waiting to respond
                   2 = output mode- responded, waiting to end strobe
                   (applicable to modes 3-4)
                   0 = input mode- waiting for pio to give the all clear
                   1 = input mode- all clear received, waiting to start
                   2 = input mode- data given->pio, strobe low, wait to end

   beepara_length_to_response = number of clock cycles to start of responce
   beepara_length_of_strobe   = length of strobe signal sent 15-40 cycles

   beepara_counter - clock cycle counter

   beepara_dest_fp - file output is to be sent to.
   beepara_src_fp  - file input is to be taken from.
*/

void beepara_close_output_stream(void);
void beepara_close_input_stream(void);

int beepara_open_output_stream(const char *filename);
int beepara_open_input_stream(const char *filename);

void beepara_update_menu_marks(void);

void beepara_finish_current(void);
int beepara_get_mode(void);

int beepara_set_mode0(void);
int beepara_set_mode1(const char *filename);
int beepara_set_mode2(void);
int beepara_set_mode3(const char *filename);
int beepara_set_mode4(void);
int beepara_set_mode5(void);

int beepara_set_parallel_0(void);
int beepara_set_parallel_1(void);
int beepara_set_parallel_2(void);
int beepara_set_parallel_3(void);
int beepara_set_parallel_4(void);
int beepara_set_parallel_5(void);

UINT_16 *beepara_cycle_bus;

char beepara_filename_paradest[1800] = "\0";
char beepara_filename_parasrc[1800]  = "\0";

char beepara_menu_optiona[] = "- Output to pc &parallel port (direct)";
char beepara_menu_optionb[] = "- Output to pc parallel port (&via os)";
char beepara_menu_optionc[] = "- Output to &file";
char beepara_menu_optiond[] = "- Output to &NULL";
char beepara_menu_optione[] = "- &Input from &file";
char beepara_menu_optionf[] = "- &Unconnected";

#ifdef PARALLEL_ACCESSABLE_ALL
MENU beepara_menu[] =
{
    { beepara_menu_optiona, beepara_set_parallel_0, NULL, 0, NULL },
    { beepara_menu_optionb, beepara_set_parallel_5, NULL, 0, NULL },
    { beepara_menu_optionc, beepara_set_parallel_1, NULL, 0, NULL },
    { beepara_menu_optiond, beepara_set_parallel_2, NULL, 0, NULL },
    { beepara_menu_optione, beepara_set_parallel_3, NULL, 0, NULL },
    { beepara_menu_optionf, beepara_set_parallel_4, NULL, 0, NULL },
    { NULL,                NULL,                    NULL, 0, NULL }
};
#endif

#ifdef PARALLEL_ACCESSABLE_BIOS_ONLY
MENU beepara_menu[] =
{
    { beepara_menu_optiona, beepara_set_parallel_0, NULL, 0,          NULL },
    { beepara_menu_optionb, beepara_set_parallel_5, NULL, D_DISABLED, NULL },
    { beepara_menu_optionc, beepara_set_parallel_1, NULL, 0,          NULL },
    { beepara_menu_optiond, beepara_set_parallel_2, NULL, 0,          NULL },
    { beepara_menu_optione, beepara_set_parallel_3, NULL, 0,          NULL },
    { beepara_menu_optionf, beepara_set_parallel_4, NULL, 0,          NULL },
    { NULL,                 NULL,                   NULL, 0,          NULL }
};
#endif

#ifdef PARALLEL_ACCESSABLE_HW_ONLY
MENU beepara_menu[] =
{
    { beepara_menu_optiona, beepara_set_parallel_0, NULL, D_DISABLED, NULL },
    { beepara_menu_optionb, beepara_set_parallel_5, NULL, 0,          NULL },
    { beepara_menu_optionc, beepara_set_parallel_1, NULL, 0,          NULL },
    { beepara_menu_optiond, beepara_set_parallel_2, NULL, 0,          NULL },
    { beepara_menu_optione, beepara_set_parallel_3, NULL, 0,          NULL },
    { beepara_menu_optionf, beepara_set_parallel_4, NULL, 0,          NULL },
    { NULL,                 NULL,                   NULL, 0,          NULL }
};
#endif

#ifdef PARALLEL_HIDDEN
MENU beepara_menu[] =
{
    { beepara_menu_optiona, beepara_set_parallel_0, NULL, D_DISABLED, NULL },
    { beepara_menu_optionb, beepara_set_parallel_5, NULL, D_DISABLED, NULL },
    { beepara_menu_optionc, beepara_set_parallel_1, NULL, 0,          NULL },
    { beepara_menu_optiond, beepara_set_parallel_2, NULL, 0,          NULL },
    { beepara_menu_optione, beepara_set_parallel_3, NULL, 0,          NULL },
    { beepara_menu_optionf, beepara_set_parallel_4, NULL, 0,          NULL },
    { NULL,                 NULL,                   NULL, 0,          NULL }
};
#endif



#define DEFAULT_RESPONSE_TIME_OUTPUT    5
#define DEFAULT_RESPONSE_TIME_INPUT     500000
#define DEFAULT_STROBE_TIME             15
#define DEFAULT_READ_GRANULARITY        50

UINT_32 beepara_length_to_response_output;
UINT_32 beepara_length_to_response_input;
UINT_32 beepara_length_of_strobe;
UINT_32 beepara_read_granularity;


int beepara_mode;
int beepara_state;

UINT_32 beepara_counter;
UINT_8  beepara_upstatcnt;

FILE *beepara_dest_fp;
FILE *beepara_src_fp;


#define BEEPARA_SET_DEFAULT_MODE beepara_set_mode4()


UINT_8 *beepara_strobe_bus;
UINT_8 *beepara_ready_bus;
UINT_8 *beepara_data_bus;

weird_pointer_jive beepara_strober;


z80pio_state *beepara_pio_state;



SetupData beepara_setdat[] =
{
   { "Parallel_response_time_out", &beepara_length_to_response_output, 2 },
   { "Parallel_response_time_in",  &beepara_length_to_response_input,  2 },
   { "Parallel_strobe_time",       &beepara_length_of_strobe,          2 },
   { "Parallel_read_granularity",  &beepara_read_granularity,          2 },
   { "",                           NULL,                               0 }
};


SetupData *beepara_setup(void)
{
    beepara_length_to_response_output = DEFAULT_RESPONSE_TIME_OUTPUT;
    beepara_length_to_response_input  = DEFAULT_RESPONSE_TIME_INPUT;
    beepara_length_of_strobe          = DEFAULT_STROBE_TIME;
    beepara_read_granularity          = DEFAULT_READ_GRANULARITY;

    return beepara_setdat;
}

int beepara_init(UINT_8 *_beepara_data_bus,
                 UINT_8 *_beepara_strobe_bus,
                 UINT_8 *_beepara_ready_bus,
                 weird_pointer_jive _beepara_strober,
                 UINT_16 *_beepara_cycle_bus)
{
    beepara_data_bus   = _beepara_data_bus;
    beepara_strobe_bus = _beepara_strobe_bus;
    beepara_ready_bus  = _beepara_ready_bus;
    beepara_strober    = _beepara_strober;
    beepara_cycle_bus  = _beepara_cycle_bus;

    beepara_upstatcnt = 0;

    beepara_dest_fp = NULL;
    beepara_src_fp  = NULL;

    BEEPARA_SET_DEFAULT_MODE;

    return 1;
}

MENU *beepara_getmenu(void)
{
    beepara_update_menu_marks();

    return beepara_menu;
}

void beepara_remove(void)
{
    beepara_close_output_stream();
    beepara_close_input_stream();

    return;
}

int beepara_get_mode(void)
{
    return beepara_mode;
}

int beepara_set_mode0(void)
{
    beepara_finish_current();

    beepara_mode  = 0;
    beepara_state = 0;

    beepara_counter = 0;

    beepara_close_output_stream();
    beepara_close_input_stream();

    if ( init_parallel_state() )
    {
        BEEPARA_SET_DEFAULT_MODE;

        return 1;
    }

    if ( write_parallel_state(0,0) )
    {
        BEEPARA_SET_DEFAULT_MODE;

        return 1;
    }

    return 0;
}

int beepara_set_mode1(const char *filename)
{
    beepara_finish_current();

    beepara_mode  = 1;
    beepara_state = *beepara_ready_bus;

    beepara_counter = 0;

    beepara_close_output_stream();
    beepara_close_input_stream();

    if ( beepara_open_output_stream(filename) )
    {
        BEEPARA_SET_DEFAULT_MODE;

        return 1;
    }

    return 0;
}

int beepara_set_mode2(void)
{
    beepara_finish_current();

    beepara_mode  = 2;
    beepara_state = *beepara_ready_bus;

    beepara_counter = 0;

    beepara_close_output_stream();
    beepara_close_input_stream();

    return 0;
}

int beepara_set_mode3(const char *filename)
{
    beepara_finish_current();

    if ( *beepara_ready_bus )
    {
        beepara_mode  = 3;
        beepara_state = 0;
    }

    else
    {
        beepara_mode  = 3;
        beepara_state = 1;
    }

    beepara_counter = 0;

    beepara_close_output_stream();
    beepara_close_input_stream();

    if ( beepara_open_input_stream(filename) )
    {
        BEEPARA_SET_DEFAULT_MODE;

        return 1;
    }

    return 0;
}

int beepara_set_mode4(void)
{
    beepara_finish_current();

    beepara_mode  = 4;
    beepara_state = 0;

    beepara_counter = 0;

    beepara_close_output_stream();
    beepara_close_input_stream();

    return 0;
}

int beepara_set_mode5(void)
{
    beepara_finish_current();

    beepara_mode  = 5;
    beepara_state = *beepara_ready_bus;

    beepara_counter = 0;

    beepara_close_output_stream();
    beepara_close_input_stream();

    if ( init_parallel_state_bios() )
    {
        BEEPARA_SET_DEFAULT_MODE;

        return 1;
    }

    return 0;
}

int beepara_data_written(void)
{
    switch ( beepara_mode )
    {
        case 0:
        {
            /* Output to PC parallel port */

            if ( write_parallel_state(*beepara_data_bus,*beepara_ready_bus) )
            {
                BEEPARA_SET_DEFAULT_MODE;

                return 1;
            }

            break;
        }

        case 1:
        {
            /* output to file */

            if ( ( beepara_state == 0 ) && ( *beepara_ready_bus == 1 ) )
            {
                if ( fputc(*beepara_data_bus,beepara_dest_fp) == *beepara_data_bus )
                {
                    beepara_counter = 0;
                    beepara_state   = 1;
                }

                else
                {
                    BEEPARA_SET_DEFAULT_MODE;

                    return 1;
                }
            }

            break;
        }

        case 2:
        {
            /* NULL output with handshaking */

            if ( ( beepara_state == 0 ) && ( *beepara_ready_bus == 1 ) )
            {
                beepara_counter = 0;
                beepara_state   = 1;
            }

            break;
        }

        case 3:
        {
            /* input from file */

            if ( ( beepara_state == 0 ) && ( *beepara_ready_bus == 0 ) )
            {
                if ( !feof(beepara_src_fp) )
                {
                    beepara_counter = 0;
                    beepara_state   = 1;
                }

                else
                {
                    BEEPARA_SET_DEFAULT_MODE;
                }
            }

            break;
        }

        case 5:
        {
            /* output to bios */

            if ( ( beepara_state == 0 ) && ( *beepara_ready_bus == 1 ) )
            {
                if ( print_parallel_bios(*beepara_data_bus) )
                {
                    BEEPARA_SET_DEFAULT_MODE;

                    return 1;
                }

                else
                {
                    beepara_counter = 0;
                    beepara_state   = 1;
                }
            }

            break;
        }

        default:
        {
            /* unconnected */

            break;
        }
    }

    return 0;
}

int beepara_cycle(void)
{
    switch ( beepara_mode )
    {
        case 0:
        {
            /* output direct to pc parallel port */

            beepara_upstatcnt++;

            if ( beepara_upstatcnt >= beepara_read_granularity )
            {
                beepara_upstatcnt = 0;

                if ( read_parallel_state(beepara_data_bus,beepara_strobe_bus) )
                {
                    BEEPARA_SET_DEFAULT_MODE;

                    return 1;
                }
            }

            (beepara_strober)();

            break;
        }

        case 1:
        case 2:
        case 5:
        {
            /* output to file, NULL(handshaking), bios */

            switch ( beepara_state )
            {
                case 1:
                {
                    beepara_counter += *beepara_cycle_bus;

                    if ( beepara_counter >= beepara_length_to_response_output )
                    {
                        *beepara_strobe_bus = 0;

                        (beepara_strober)();

                        beepara_counter = 0;
                        beepara_state   = 2;
                    }

                    break;
                }

                case 2:
                {
                    beepara_counter += *beepara_cycle_bus;

                    if ( beepara_counter >= beepara_length_of_strobe )
                    {
                        *beepara_strobe_bus = 1;

                        (beepara_strober)();

                        beepara_counter = 0;
                        beepara_state   = 0;
                    }

                    break;
                }

                default:
                {
                    break;
                }
            }

            break;
        }

        case 3:
        {
            /* input from file */

            switch ( beepara_state )
            {
                case 1:
                {
                    beepara_counter += *beepara_cycle_bus;

                    if ( beepara_counter >= beepara_length_to_response_input )
                    {
                        *beepara_strobe_bus = 0;

                        if ( feof(beepara_src_fp) )
                        {
                            BEEPARA_SET_DEFAULT_MODE;

                            *beepara_data_bus = 0;
                        }

                        else
                        {
                            *beepara_data_bus = fgetc(beepara_src_fp);
                        }

                        (beepara_strober)();

                        beepara_counter = 0;
                        beepara_state   = 2;
                    }

                    break;
                }

                case 2:
                {
                    beepara_counter += *beepara_cycle_bus;

                    if ( beepara_counter >= beepara_length_of_strobe )
                    {
                        *beepara_strobe_bus = 1;

                        (beepara_strober)();

                        beepara_counter = 0;
                        beepara_state   = 0;
                    }

                    break;
                }

                default:
                {
                    break;
                }
            }

            break;
        }

        default:
        {
            break;
        }
    }

    return 0;
}

void beepara_close_output_stream(void)
{
    if ( beepara_dest_fp != NULL )
    {
        fclose(beepara_dest_fp);
    }

    beepara_dest_fp = NULL;

    return;
}

void beepara_close_input_stream(void)
{
    if ( beepara_src_fp != NULL )
    {
        fclose(beepara_src_fp);
    }

    beepara_src_fp = NULL;

    return;
}

int beepara_open_output_stream(const char *filename)
{
    beepara_close_output_stream();

    beepara_dest_fp = fopen(filename,"wb");

    if ( beepara_dest_fp == NULL )
    {
        return 1;
    }

    return 0;
}

int beepara_open_input_stream(const char *filename)
{
    beepara_close_input_stream();

    beepara_src_fp = fopen(filename,"rb");

    if ( beepara_src_fp == NULL )
    {
        return 1;
    }

    return 0;
}

void beepara_finish_current(void)
{
    switch ( beepara_mode )
    {
        case 1:
        case 2:
        case 3:
        case 5:
        {
            switch ( beepara_state )
            {
                case 1:
                {
                    beepara_state   = 0;
                    beepara_counter = 0;

                    break;
                }

                case 2:
                {
                    beepara_state   = 0;
                    beepara_counter = 0;

                    *beepara_strobe_bus = 1;
                    (beepara_strober)();

                    break;
                }

                default:
                {
                    break;
                }
            }

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}


void beepara_update_menu_marks(void)
{
    beepara_menu_optiona[0] = ' ';
    beepara_menu_optionb[0] = ' ';
    beepara_menu_optionc[0] = ' ';
    beepara_menu_optiond[0] = ' ';
    beepara_menu_optione[0] = ' ';
    beepara_menu_optionf[0] = ' ';

    switch ( beepara_get_mode() )
    {
        case 0:  { beepara_menu_optiona[0] = '-'; break; }
        case 5:  { beepara_menu_optionb[0] = '-'; break; }
        case 1:  { beepara_menu_optionc[0] = '-'; break; }
        case 2:  { beepara_menu_optiond[0] = '-'; break; }
        case 3:  { beepara_menu_optione[0] = '-'; break; }
        default: { beepara_menu_optionf[0] = '-'; break; }
    }

    return;
}



int beepara_set_parallel_0(void)
{
    if ( beepara_set_mode0() )
    {
        alert("Error:","Parallel port access blocked.","Reverting to unconnected.","&OK",NULL,'o',0);
    }

    beepara_update_menu_marks();

    return D_O_K;
}

int beepara_set_parallel_1(void)
{
    FILE *tempfp;

    if ( file_select_ex("Parallel Port Destination file",beepara_filename_paradest,NULL,300,0,0) )
    {
        if ( ( tempfp = fopen(beepara_filename_paradest,"rt") ) != NULL )
        {
            fclose(tempfp);

            if ( alert("File already exists.","Overwrite anyhow?","","&OK","&Cancel",'o','c') == 2 )
            {
                BEEPARA_SET_DEFAULT_MODE;

                goto exit_point;
            }
        }

        if ( beepara_set_mode1(beepara_filename_paradest) )
        {
            alert("Error:","Couldn't open file.","Reverting to unconnected.","&OK",NULL,'o',0);
        }
    }

    exit_point:

    beepara_update_menu_marks();

    return D_O_K;
}

int beepara_set_parallel_2(void)
{
    if ( beepara_set_mode2() )
    {
        alert("Error:","Unknown parallel port error.","Reverting to unconnected.","&OK",NULL,'o',0);
    }

    beepara_update_menu_marks();

    return D_O_K;
}

int beepara_set_parallel_3(void)
{
    if ( file_select_ex("Parallel Port Source File",beepara_filename_parasrc,NULL,300,0,0) )
    {
        z80pio_data_rd_A(beepara_pio_state); /*this seems to be necessary*/

        if ( beepara_set_mode3(beepara_filename_parasrc) )
        {
            alert("Error:","Couldn't open file.","Reverting to unconnected.","&OK",NULL,'o',0);
        }
    }

    beepara_update_menu_marks();

    return D_O_K;
}

int beepara_set_parallel_4(void)
{
    if ( beepara_set_mode4() )
    {
        alert("Wow!","An impossible error has occured.","Hmmmmmmmmm.","&OK",NULL,'o',0);
    }

    beepara_update_menu_marks();

    return D_O_K;
}

int beepara_set_parallel_5(void)
{
    if ( beepara_set_mode5() )
    {
        alert("Error:","Unable to access BIOS.","Reverting to unconnected.","&OK",NULL,'o',0);
    }

    beepara_update_menu_marks();

    return D_O_K;
}

