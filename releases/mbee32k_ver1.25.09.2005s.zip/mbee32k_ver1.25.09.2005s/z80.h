

#include "u_dtype.h"

#ifndef _z80_h
#define _z80_h

#ifndef BUS_PREFIX
#define BUS_PREFIX extern
#endif

#ifndef FN_BUS_PREFIX
#define FN_BUS_PREFIX extern
#endif



/*

       \\\              ///
      /~~~~~~~~~\      ///
      \______   /     ///
         \\\/  ####  /####
          \/  #    # #//  #
          /  /#    #/#/   #   VZ80 - Virtual Z80 for PC
         /  /\ #### /#    #   32-bit z80 emulator
        /  /\\#    #/#    #   Coding: Alistair Shilton
       /  /  \#\  /#/#    #           apsh@ecr.mu.oz.au
      /   ~~~~~####/  ####            http://
      \_________////
               \\//
                \/


Introduction
============

The z80 is started by calling the function z80_enter().  This passes control
to the z80 emulator, which will then call call back when external data/stuff
is required.  The following functions must be provided to the emulator:


z80_ack_reset()  - acknowledge receipt of reset.
z80_ack_busrq()  - acknowledge receipt of bus request.  The caller can now
                   do operation and put wait states on z80_wait_bus (clock
                   cycles).
z80_ack_halt()   - acknowledge excecution of HALT opcode.
z80_ack_NMI()    - acknowledge NMI.  The contents of the PC are put on the
                   z80_addr_bus, and R on the z80_rfsh_bus.
z80_ack_INT()    - acknowledge INT.  The contents of the PC are put on the
                   z80_addr_bus, and the responce data can be put on the
                   z80_data_bus.  Wait states can also be inserted using the
                   z80_wait_bus.
z80_opfetch()    - call to fetch opcode.  The contents of the PC are put on
                   the z80_addr_bus, and R on z80_rfsh_bus.  The responce
                   data must be put on the z80_data_bus and wait states can
                   be inserted using the z80_wait_bus.
z80_sync_clock() - call to delay to align clock cycles with elapsed time.
                   The number of accumulated clock cycles is put on the
                   z80_clk_bus.  The function may only wait for some, and
                   put the difference on the z80_clk_bus before returning,
                   or otherwise put 0 on the z80_clock_bus otherwise.
z80_wr_mem()     - call to write to memory.  Data on z80_data_bus, address
                   on z80_addr_bus.  Wait states may be inserted in the
                   usual manner.
z80_rd_mem()     - call to read from memory.  Addr on z80_addr_bus, data
                   must be loaded onto z80_data_bus.  Wait states may be
                   inserted in the usual manner.
z80_wr_io()      - write value to memory.  Same as z80_wr_mem(), but io.
z80_rd_io()      - read value from memory.  Same as z80_rd_mem(), but io.


During any of these calls functions are available to control the state of
the emulator.  These functions can be split into internal state control
functions (which should only be called during a reset acknowledge cycle)
and signal functions, which roughly correspond to the pins available on
the z80 and can be called at any time (including during an interupt when
the emulator still has control).

The internal state control functions have the general form z80_set_reg() or
z80_get_reg().  In all cases, reg is 8-bit and is passed to/from using the
z80_reg_bus.  z80_set_reg() sets the register, z80_get_reg() gets the current
value of the register.  reg may be any one of the following:


A    - accumulator
F    - flag register
B    - B register
C    - C register
D    - D register
E    - E register
H    - H register
L    - L register
Ax   - accumulator, secondary register set
Fx   - flag register, secondary register set
Bx   - B register, secondary register set
Cx   - C register, secondary register set
Dx   - D register, secondary register set
Ex   - E register, secondary register set
Hx   - H register, secondary register set
Lx   - L register, secondary register set
IXh  - IX index register, high order byte
IXl  - IX index register, low order byte
IYh  - IY index register, high order byte
IYl  - IY index register, low order byte
PCh  - program counter, high order byte
PCl  - program counter, low order byte
SPh  - stack pointer, high order byte
SPl  - stack pointer, low order byte
I    - interupt register
R    - regresh register
st1_ - first cpu state byte
st2_ - second cpu state byte
doff - 8-bit memory offset register (used by DDCB opcodes to store d)


The signal functions are:


z80_set_power() - turn off power.  This function instructs the emulator
                  to clean up and leave by returning from z80_enter.
z80_set_reset() - reset the CPU.  Once the current operation is completed,
                  the emulator will call z80_ack_reset and the following
                  values are written to the registers:

                  A,F,B,C,D,E,H,L,Ax,Fx,Bx,Cx,Dx,Ex,Hx,Lx - 0x0ff
                  IX,IY,SP                                - 0x0ffff
                  PC                                      - 0x00000
                  I,R                                     - 0x000
                  st1_,st2_                               - 0x000
                  doff                                    - 0x000

z80_set_busrq() - initiate bus request sequence.  Once the current operation
                  is complete, the emulator will call z80_ack_busrq.
z80_set_NMI()   - initiate NMI sequence.  Emulator will complete the current
                  operation and call z80_ack_NMI.
z80_set_INT()   - set INT pin.  This pin will remain set until either the
                  interupt is processed (resulting in a call from the
                  emulator to z80_ack_INT) or z80_res_INT is called to
                  remove the interupting signal (recall the the INT pin
                  on z80's is level sensitive, and the z80 will ignore
                  it unless interupts are enabled, and even then a long
                  sequence of DDFD type stuff can hold back processing of
                  the instruction indefinitely).
z80_res_INT()   - reset INT pin.
z80_set_wait()  - this function can be called (with the number of wait
                  states being inserted placed on the z80_wait_bus) at
                  any time to insert wait states in the operation.  It is
                  equivalent to the WAIT pin on the z80.
z80_set_fast()  - put z80 in fast mode.  In this mode, no clock timing is
                  done.
z80_set_slow()  - put the z80 in slow mode, so a count of clock cycles is
                  kept and z80_sync_clock called periodically to make sure
                  emulation timing is correct.


Emulator Buses
==============

All data transfer to and from the emulator is done using the following
buses:


z80_wait_bus - wait state bus
z80_rfsh_bus - refresh byte bus
z80_data_bus - data bus
z80_addr_bus - address bus
z80_reg_bus  - register control bus
z80_clk_bus  - clock state bus


The low order part of the address bus is also available on it's own (for
IO systems that use only this) as z80_addr_bus_l.  This points to the same
memory as the z80_addr_bus, but has the data-type of a UINT_8 rather than
UINT_16.


The Emulator State Bytes
========================

The emulator state bytes are as follows:

st1_: 7 - mode bit 2
      6 - mode bit 1
      5 - mode bit 0
      4 - IM1
      3 - IM0
      2 - IFF2
      1 - IFF1
      0 - DI - set if last opcode was EI,DI or a prefix (CB,DD,FD,ED).
               If this bit is set then both NMI and INT signals will be
               ignored.

The mode control bits indicate which part of an opcode is being processed.
Specifically, they indicate whether the opcode is standard, prefixed or
double prefixed, and what prefix (if any) it is.  The mode is:

Mode (210): 000 = normal (no prefix)
            001 = DD prefix
            010 = FD prefix
            100 = CB prefix
            111 = ED prefix
            101 = DDCB double prefix
            110 = FDCB double prefix

st2_: 7 - power  - set by z80_set_power, causes emulator to exit.
      6 - reset  - set by z80_set_reset, causes reset & z80_ack_reset call.
      5 - busrq  - set by z80_set_busrq, causes z80_ack_busrq call.
      4 - NMI    - set by z80_set_NMI, may cause z80_ack_NMI call.
      3 - INT    - set by z80_set_INT, may cause z80_ack_INT call.
      2 - speed  - set by call to z80_set_fast, reset by z80_set_slow.
                   If this bit is set then all timing stuff will be ignored.
      1 - halted - set by HALT opcode, reset by interupts.
      0 - INTOP  - set to indicate presence of an interupt, which can
                   modify read operations.  eg.  a LB A,n op in the correct
                   interupt mode must not increment PC, even though this
                   read is indistinguishable from a standard opcode data
                   read.

Note that bits 7,6,5,4,3,2 are set by signal functions.  Bits 7,6,5,4,3
are transient (will be reset sometime near when the relevant operation is
performed - but AFTER the reset operation, which is important).


Memory operation control data
=============================

Memory is divided into 256 pages (ie. the upper 8 bytes of the address
bus select the table).  For each page, read, write and opread modes may
be set using the following functions:

void z80_set_mem_write_none()
void z80_set_mem_write_direct()
void z80_set_mem_write_indirect()

void z80_set_mem_read_none()
void z80_set_mem_read_direct()
void z80_set_mem_read_indirect()

void z80_set_mem_opread_none()
void z80_set_mem_opread_direct()
void z80_set_mem_opread_indirect()

void z80_set_mem_write_none_naw()
void z80_set_mem_write_direct_naw()
void z80_set_mem_write_indirect_naw()

void z80_set_mem_read_none_naw()
void z80_set_mem_read_direct_naw()
void z80_set_mem_read_indirect_naw()

void z80_set_mem_opread_none_naw()
void z80_set_mem_opread_direct_naw()
void z80_set_mem_opread_indirect_naw()

The methods are: none     - write nothing, read 0
                 direct   - read/write memory directly, using the page of 256
                            packed bytes for the relevant page.  This is set
                            by putting the address of the page on the
                            z80_tab_addr_bus when calling the function to set
                            direct memory access mode
                 indirect - call the relevant z80 function (provided to the
                            z80 emulator).
                 naw      - "no auto wait".  Does not automatically insert
                            wait states (but waits put on the wait bus during
                            indirect will be inserted).

When any of these functions are called, the following buses are used:

UINT_8  z80_tab_num_bus     - number page to be modified.
UINT_8 *z80_tab_addr_bus    - page address to use for direct access.
UINT_16 z80_tab_wr_wait_bus - number of wait states for mem write this page.
UINT_16 z80_tab_rd_wait_bus - number of wait states for mem/op rd this page.

NB. Memory reads from PC when dealing with IM0 will all call external
    read function, regardless of setting here.  Also, wait states here
    will be ignored in this case.

DIRECT ACCESS: An alternative method is direct access.  This will not
               actually change the mode, but it does let you change the
               addresses and waits quickly.  There are 4 arrays:

UINT_16  mem_wtwr_table[0x100];
UINT_16  mem_wtrd_table[0x100];
UINT_8  *mem_addr_table[0x100];


External architecture support
=============================

The PIO (and possibly other devices) need to be able to detect the
processing of the RETI instruction to operate correctly. The z80_reti_counter
counter allows this.  It is incremented whenever the RETI instruction is
encountered, allowing the z80 pio to detect the op (by detecting the change
in the counter).



****************************************************************************/



/* z80 buses */

BUS_PREFIX UINT_8  z80_wait_bus;
BUS_PREFIX UINT_8  z80_rfsh_bus;
BUS_PREFIX UINT_8  z80_data_bus;
BUS_PREFIX UINT_16 z80_addr_bus;
BUS_PREFIX UINT_8  z80_addr_bus_l;
BUS_PREFIX UINT_8  z80_reg_bus;
BUS_PREFIX UINT_16 z80_clk_bus;

/* z80 mem access tables */

BUS_PREFIX UINT_16  z80_mem_wtwr_table[0x100];
BUS_PREFIX UINT_16  z80_mem_wtrd_table[0x100];
BUS_PREFIX UINT_8  *z80_mem_addr_table[0x100];

/* z80 mem/io stuff */

BUS_PREFIX UINT_8  z80_tab_num_bus;
BUS_PREFIX UINT_8 *z80_tab_addr_bus;
BUS_PREFIX UINT_16 z80_tab_wr_wait_bus;
BUS_PREFIX UINT_16 z80_tab_rd_wait_bus;

void z80_set_mem_write_none();
void z80_set_mem_write_direct();
void z80_set_mem_write_indirect();

void z80_set_mem_read_none();
void z80_set_mem_read_direct();
void z80_set_mem_read_indirect();

void z80_set_mem_opread_none();
void z80_set_mem_opread_direct();
void z80_set_mem_opread_indirect();

void z80_set_mem_write_none_naw();
void z80_set_mem_write_direct_naw();
void z80_set_mem_write_indirect_naw();

void z80_set_mem_read_none_naw();
void z80_set_mem_read_direct_naw();
void z80_set_mem_read_indirect_naw();

void z80_set_mem_opread_none_naw();
void z80_set_mem_opread_direct_naw();
void z80_set_mem_opread_indirect_naw();


/* RETI counter */

BUS_PREFIX UINT_32 z80_reti_count;


/* Emulator functions */

void z80_enter();

void z80_set_power();
void z80_set_reset();
void z80_set_busrq();
void z80_set_NMI();
void z80_set_INT();
void z80_res_INT();
void z80_set_fast();
void z80_set_slow();
void z80_set_wait();

void z80_set_A();
void z80_set_F();
void z80_set_B();
void z80_set_C();
void z80_set_D();
void z80_set_E();
void z80_set_H();
void z80_set_L();
void z80_set_Ax();
void z80_set_Fx();
void z80_set_Bx();
void z80_set_Cx();
void z80_set_Dx();
void z80_set_Ex();
void z80_set_Hx();
void z80_set_Lx();
void z80_set_IXh();
void z80_set_IXl();
void z80_set_IYh();
void z80_set_IYl();
void z80_set_PCh();
void z80_set_PCl();
void z80_set_SPh();
void z80_set_SPl();
void z80_set_I();
void z80_set_R();
void z80_set_st1_();
void z80_set_st2_();
void z80_set_doff();

void z80_get_A();
void z80_get_F();
void z80_get_B();
void z80_get_C();
void z80_get_D();
void z80_get_E();
void z80_get_H();
void z80_get_L();
void z80_get_Ax();
void z80_get_Fx();
void z80_get_Bx();
void z80_get_Cx();
void z80_get_Dx();
void z80_get_Ex();
void z80_get_Hx();
void z80_get_Lx();
void z80_get_IXh();
void z80_get_IXl();
void z80_get_IYh();
void z80_get_IYl();
void z80_get_PCh();
void z80_get_PCl();
void z80_get_SPh();
void z80_get_SPl();
void z80_get_I();
void z80_get_R();
void z80_get_st1_();
void z80_get_st2_();
void z80_get_doff();


FN_BUS_PREFIX void z80_ack_reset(void);
FN_BUS_PREFIX void z80_ack_busrq(void);
FN_BUS_PREFIX void z80_ack_halt(void);
FN_BUS_PREFIX void z80_ack_NMI(void);
FN_BUS_PREFIX void z80_ack_INT(void);
FN_BUS_PREFIX void z80_opfetch(void);
FN_BUS_PREFIX void z80_sync_clock(void);
FN_BUS_PREFIX void z80_wr_mem(void);
FN_BUS_PREFIX void z80_rd_mem(void);
FN_BUS_PREFIX void z80_wr_io(void);
FN_BUS_PREFIX void z80_rd_io(void);



#endif

