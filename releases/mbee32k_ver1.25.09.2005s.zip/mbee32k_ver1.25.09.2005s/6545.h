
#include "u_dtype.h"

#ifndef _6545_h
#define _6545_h

/*

   +-------+
  -|       |-            +-----------------------------------------+
  -|       |-            |+----+----+----+----+----+----+----+----+|
  -|       |-            ||0000|0001|0002|....|....|004D|004E|004F||
  -|       |-      \\    |+----+----+----+----+----+----+----+----+|
  -|       | ====== \\   ||0050|0051|0052|....|....|009D|009E|009F||
  -|                 \\  |+----+----+----+-       -+----+----+----+|
  -|                  \\ ||00A0|00A1|00A             0ED|00EE|00EF||
  -| 6545 Emulator     \ |+----+----+--       _       --+----+----+|
  -|                     ||....|....|..      / \      ..|....|....||
  -| Alistair Shilton    |+----+----+-       \ /       -+----+----+|
  -| apsh@ecr.mu.oz.au   ||....|....|.     >{|||}      .|....|....||
  -| http://           / |+----+----+--      / \      --+----+----+|
  -|                  // ||....|....|..      \_/      ..|....|....||
  -|                 //  |+----+----+---             ---+----+----+|
  -|       | ====== //   ||06E0|06E1|06E2|.       .|072D|072E|072F||
  -|       |-      //    |+----+----+----+----+----+----+----+----+|
  -|       |-            ||0730|0731|0732|....|....|077D|077E|077F||
  -|       |-            |+----+----+----+----+----+----+----+----+|
  -|       |-            +-----------------------------------------+
  -|       |-
   +-------+



                        6545 CRTC Emulation
                        ===================

The following code emulates the functionality of the Synertek 6545 CRT
controller (CRTC).  In the MicroBee, in addition to controlling the video
display, the 6545 also acts as an interface to the keyboard.



Installation, Removal and Resetting
===================================

The following function:

c6545_state *c6545_init(UINT_16  c6545_lpen_alias,
                        UINT_8  *c6545_comms_data_bus,
                        UINT_32 *c6545_lpen_call_mask_bus,
                        UINT_16 *c6545_geometry_bus,
                        UINT_16 *c6545_video_mem_addr_bus,
                        UINT_16 *c6545_video_data_bus,
                        UINT_8  *c6545_video_char_line_bus,
                        UINT_16 *c6545_xpos_bus,
                        UINT_16 *c6545_ypos_bus,
                        UINT_8  *c6545_is_fore_bus,
                        UINT_8  *c6545_fore_colour_bus,
                        UINT_8  *c6545_back_colour_bus,
                        UINT_8  *c6545_inv__colour_bus,
                        UINT_32 *c6545_lpen_reset_counter_bus,
                        UINT_32 *c6545_update_reset_counter_bus,
                        UINT_8  **c6545_pole_lpen_table,
                        UINT_8  **c6545_pole_lpen_clow_table,
                        UINT_8  **c6545_lpen_feedback_table,
                        UINT_8  **c6545_lpen_feedback_clow_table,
                        UINT_8  **c6545_lpen_feedrfsh_table,
                        UINT_8  **c6545_lpen_feedrfsh_clow_table,
                        weird_pointer_jive c6545_change_left_margin,
                        weird_pointer_jive c6545_change_screen_width,
                        weird_pointer_jive c6545_change_right_margin,
                        weird_pointer_jive c6545_change_top_margin,
                        weird_pointer_jive c6545_change_screen_height,
                        weird_pointer_jive c6545_change_bottom_margin,
                        weird_pointer_jive c6545_pixel_drawer);

sets up an instance of the 6545 emulator using the arguments/functions
given.  Will return NULL on failure, or otherwise a pointer to the
allocated object.  Arguments are:

Variables: c6545_lpen_alias - ANDed with any lookup of c6545_pole_lpen_table
                              or c6545_pole_lpen_clow_table.

Buses: c6545_comms_data_bus           - data bus used for port read/write.
       c6545_lpen_call_mask_bus       - lightpen call mask (see below).
       c6545_geometry_bus             - use to pass screen geometry data to
                                        the functions change_*_margin,
                                        change_screen_width and
                                        change_screen_height.
       c6545_video_mem_addr_bus       - addr bus used for c6545_write_* fns.
       c6545_video_data_bus           - data bus used for c6545_write_* fns.
       c6545_video_char_line_bus      - char line bus " " c6545_write_* fns.
       c6545_xpos_bus                 - pixel position bus (x), pixel_drawer.
       c6545_ypos_bus                 - pixel position bus (y), pixel_drawer.
       c6545_is_fore_bus              - used to communicate pixel info to the
                                        function pixel_drawer.  Each bit is a
                                        single pixel, leftmost is MSB, 1 
                                        implies foreground, zero background.
       c6545_fore_colour_bus          - foregrnd colour bus for pixel_drawer.
       c6545_back_colour_bus          - backgrnd colour bus for pixel_drawer.
       c6545_inv__colour_bus          - if non-zero, colour is inverted (but
                                        note that colour buses have already
                                        allowed for this - for use in
                                        monochrome emulation only).
       c6545_lpen_reset_counter_bus   - lightpen reset counter bus.  This bus
                                        will be incremented by the 6545 
                                        module whenever port 16 or 17 is
                                        read.
       c6545_update_reset_counter_bus - update counter bus.  This bus will be
                                        incremented by the 6545 module when
                                        port 31 is read.

tables: c6545_pole_lpen_table          - table containing state of the
                                         lightpen matrix (clock high).  All
                                         references to this table will be
                                         aliased (ANDed) with
                                         c6545_lpen_alias, so the size of
                                         the table must match this.
        c6545_lpen_feedback_table      - an element will be incremented if
                                         the same element in the
                                         pole_lpen_table is found high,
                                         triggering a successful strobing of
                                         this element when the clock
                                         is high, and this occurs due to
                                         random screen scan, not a specific
                                         refresh driven test event.  The
                                         size of this table should match the
                                         size of the c6545_pole_lpen table.
        c6545_lpen_feedrfsh_table      - incremented in a similar manner to
                                         the lpen_feedback_table, except that
                                         in this case the increment will ONLY
                                         occur if the event was refresh
                                         driven, rather than the other way
                                         around.  Same size note applicable.
        c6545_pole_lpen_clow_table     - low clock state version of above.
        c6545_lpen_feedback_clow_table - low clock state version of above.
        c6545_lpen_feedrfsh_clow_table - low clock state version of above.

functions: c6545_change_left_margin    - called when the left margin is
                                         changed.  The new width of the left
                                         margin (in pixels) will be placed
                                         on the geometry_bus.
           c6545_change_screen_width   - screen width "
           c6545_change_right_margin   - screen width "
           c6545_change_top_margin     - screen width "
           c6545_change_screen_height  - screen width "
           c6545_change_bottom_margin  - screen width "
           c6545_pixel_drawer          - called to draw pixels onto the
                                         screen.  The xpos_bus and ypos_bus
                                         positions start at zero and are
                                         relative to the margins set by the
                                         above functions (that is, point 0,0
                                         will lie at position
                                         left_margin,top_margin).  Also
                                         passes the 8 pixels on and
                                         immediately right of this position
                                         on is_fore_bus, starting at the
                                         MSB, where a 1 should be drawn in
                                         colour fore_colour_bus and a zero in
                                         colour back_colour_bus.


Misc control functions
======================

In all the following, what is of type c6545_state * (and defines the
instances being referred to) and i is of type int.

void c6545_reset(what)   - called to reset the 6545 instance.
void c6545_refresh(what) - called to tell the 6545 to redraw the screen.
void c6545_remove(what)  - called to delete the 6545 instance.

void c6545_alwaysredraw_on(what)      - turn continuous redraw mode on.
void c6545_alwaysredraw_off(what)     - turn continuous redraw mode off.
void c6545_set_frame_multiply(what,i) - set the number of frames counted
                                        per actual frame drawn (used to
                                        compensate if the clock rate is
                                        slowed down, preventing a similar
                                        slowdown in the cursor rate).
void c6545_redraw_next_n(what,i)      - tell the 6545 to redraw the next
                                        i frames completely.

Timing and emulation
====================

During operation, the function:

void c6545_do_cycles(c6545_state *what, UINT_16 num_cycles)

should be called (with the relevant number of clock cycles placed on the
c6545_cycle_counter bus before calling) to take the 6545 emulation through
the relevant number of virtual clock cycles, updating the screen and testing
the lightpen as it goes.  This is also necessary to ensure the the status
byte is correct w.r.t. syncing and lightpen status.



Port io functions
=================

The following functions (which communicate on c6545_comms_data_bus as given
to the init functions) are provided for port io routines direct to the 6545:

void c6545_addr_wr(c6545_state *what);
void c6545_data_wr(c6545_state *what);

void c6545_addr_rd(c6545_state *what);
void c6545_data_rd(c6545_state *what);



Internal Memory Map
===================


The 6545 CRTC emulator maintains an internal version of VDU, character and
colour RAM, which are write-only from a user perspective.  This enables the
emulator to update screen refresh operations.  Each character displayed is
specified by 3 characteristics, namely foreground colour (used to draw the
"set" dots), background colour (the non-set dots) and the character number.
Each character is defined by 32 bytes (8-bit) thusly:

byte 0: defines the top row.
byte 1: defines the 2nd row.
...
byte 31: defines the bottom row.

For each byte, each bit is a pixel, with the leftmost being the MSB and the
rightmost the LSB, where 1 means a foreground pixel and 0 a background pixel.
If the height of the character is less than defined here then rows will be
cut from the base of the character.

The following functions are used to write to this memory:

void c6545_write_char_mem(c6545_state *what)    - write char memory.
void c6545_write_vdu_mem(c6545_state *what)     - write VDU memory.
void c6545_write_fore_colour(c6545_state *what) - write fore colour memory.
void c6545_write_back_colour(c6545_state *what) - write back colour memory.

The following busses are used to communicate with these functions:

c6545_video_mem_addr_bus  - address bus (16 bit) as seen by 6545.
c6545_video_data_bus      - data bus (8 bit).
c6545_video_char_line_bus - line bus (8 bit - used when writing to char
                            memory to indicate which line is being changed).



External Functionality - the Lightpen
=====================================

In an atual 6545, if a 0-1 transition is detected on the lightpen, ie.:

   1: IS_LPEN(previous) = 0 and IS_LPEN_clow = 1
   2: IS_LPEN_clow = 0 and IS_LPEN = 1

then the value stored that would be on the MA_bus in the next cycle (but
not, apparently, the update address, if relevant) is stored in the lpen
registers (R16_17_, R16_ra and R17_ca) and LPEN_REGISTER_FULL is set to 1.

To emulate this functionality, the 6545 CRTC emulator needs to obtain the
state of the lpen form both the lower and high part of the clock cycle.  It
does this in two steps.

Firstly, for each half-cycle, it examines the c6545_lpen_call_mask_bus (32
bit).  In particular, it will look at one bit of this mask based on the
following table:

+-----+----------------------------------------+
|     |  6545 signal combination to test bit   |
|     +------+--------+-------+-------+--------+
| bit | CR4* | DISPEN | HSYNC | VSYNC | CURSOR |
+-----+------+--------+-------+-------+--------+
|  0  |  0   |   0    |   0   |   0   |   0    |
|  1  |  0   |   0    |   0   |   0   |   1    |
|  2  |  0   |   0    |   0   |   1   |   0    |
|  3  |  0   |   0    |   0   |   1   |   1    |
|  4  |  0   |   0    |   1   |   0   |   0    |
|  5  |  0   |   0    |   1   |   0   |   1    |
|  6  |  0   |   0    |   1   |   1   |   0    |
|  7  |  0   |   0    |   1   |   1   |   1    |
|  8  |  0   |   1    |   0   |   0   |   0    |
|  9  |  0   |   1    |   0   |   0   |   1    |
| 10  |  0   |   1    |   0   |   1   |   0    |
| 11  |  0   |   1    |   0   |   1   |   1    |
| 12  |  0   |   1    |   1   |   0   |   0    |
| 13  |  0   |   1    |   1   |   0   |   1    |
| 14  |  0   |   1    |   1   |   1   |   0    |
| 15  |  0   |   1    |   1   |   1   |   1    |
| 16  |  1   |   0    |   0   |   0   |   0    |
| 17  |  1   |   0    |   0   |   0   |   1    |
| 18  |  1   |   0    |   0   |   1   |   0    |
| 19  |  1   |   0    |   0   |   1   |   1    |
| 20  |  1   |   0    |   1   |   0   |   0    |
| 21  |  1   |   0    |   1   |   0   |   1    |
| 22  |  1   |   0    |   1   |   1   |   0    |
| 23  |  1   |   0    |   1   |   1   |   1    |
| 24  |  1   |   1    |   0   |   0   |   0    |
| 25  |  1   |   1    |   0   |   0   |   1    |
| 26  |  1   |   1    |   0   |   1   |   0    |
| 27  |  1   |   1    |   0   |   1   |   1    |
| 28  |  1   |   1    |   1   |   0   |   0    |
| 29  |  1   |   1    |   1   |   0   |   1    |
| 30  |  1   |   1    |   1   |   1   |   0    |
| 31  |  1   |   1    |   1   |   1   |   1    |
+-----+------+--------+-------+-------+--------+

NB: * CR4 is what is physically on pin CR4 of the 6545, which may of may
      not be bit 5 of the CR bus (it can be programmed to be the update
      strobe).

If this bit is set, then the process may continue.  Otherwise, lpen is
assumed to be low for the relevant half cycle.  In the former case, the
emulator will use the contents of MA_bus (or MA_bus_clow for the relevant
half-cycle) as an index to lookup one of the tables:

UINT_8 *c6545_pole_lpen_table;
UINT_8 *c6545_pole_lpen_clow_table;

The result of this lookup is the state of the lpen pin for this half-cycle.


Known Unknowns
==============

- In row/column mode (R8_adm = 1), MA0-7 gives the column address and MA8-13
  the row address.  MA0-7 is offset by R13_ca, and MA8-13 by R13_ra.  I have
  assumed that this is equivalent to offsetting MA_bus by R12_13_.  A
  possible bug with this interpretation is that, under the scheme used here,
  carry from the MSB of MA0-7 to the LSB of MA8-13 is possible during
  offsetting.  None of the docs seem to say if this carry should be masked
  or not, so this may cause issues in some cases (possibly games that rely
  on roll-over?).

- Documentation on the lightpen, update addressing and memory address modes
  (and there interactions) of the 6545 is sparse to say the least.  This
  emulator is based to a large degree on the Synertec datasheet and a
  document I found on the web which covering many of these issues in some
  detail.  Unfortunately, I have no idea who actually wrote the latter
  document, as I failed to record this information - sorry :(.

- Cursor wrap disabled (search for IS_CURSOR = 0 when it should be 1) - this
  is a quick hack.  I known cursor wrap works on the bee, but I need to
  double check to see how exactly, because what I had here wasn't working
  at all.

*/



#define C6545_VDU_MEM_SIZE      0x04000 /* VDU memory size == 2^14   */
#define C6545_CHAR_MEM_SIZE     0x10000 /* char memory size = 2^16   */
#define C6545_MAX_CHR_HEIGHT    0x020   /* max scanlines / char = 32 */
#define C6545_DEFAULT_CHAR      0x000   /* default fill character    */
#define C6545_MAX_SCN_HEIGHT    0x100   /* max screen width (chars)  */
#define C6545_MAX_SCN_WIDTH     0x100   /* max screen height (chars) */


/*
   Screen Information struct
   =========================
*/

typedef struct
{
    /*
       Screen definition data
       ======================

       dim_horiz: horizontal (displayed) char count
       dim_vert:  vertical (displayed) char count
    */

    UINT_8 dim_horiz;
    UINT_8 dim_vert;

    /*
       Screen size data
       ================

       size_width:  total screen width (pixels)
       size_height: total screen height (pixels)
    */

    UINT_16 screen_width;
    UINT_16 screen_height;

    /*
       Margin definitions
       ==================

       margin_left: left blank margin width (pixels)
       margin_top:  top blank margin width (pixels)
    */

    UINT_16 margin_left;
    UINT_16 margin_top;

    /*
       Character definition data
       =========================

       char_height: height of individual chars -1 (pixels)
       char_loopb:  if nonzero, and char_height > 16, then character rows
                    greater than 16 should be repeats of the first 16
                    rows (ie. bit 5 of the RA bus is masked for use as
                    an update strobe).
    */

    UINT_8 char_height;
    int char_loopb;

    /*
       Cursor definition data
       ======================

       cursor_mode:   0 = solid (non-blinking) cursor.
                      1 = no cursor.
                      2 = blinking cursor - 1/16 of field rate.
                      3 = blinking cursor - 1/32 of field rate.
       cursor_offscn: 0 = cursor is located on scn_map.
                      1 = cursor is not located on scn_map (ie. offscreen,
                          so don't draw regardless of given position).

       cursor_startline: scanline where cursor begins (pixels, start at 0).
       cursor_endline:   scanline where cursor ends (pixels, start at 0).

       cursor_x_pos: x position of cursor (chars, start at 0)
       cursor_y_pos: y position of cursor (chars, start at 0)
    */

    int cursor_mode;
    int cursor_offscn;

    UINT_8 cursor_startline;
    UINT_8 cursor_endline;

    UINT_8 cursor_x_pos;
    UINT_8 cursor_y_pos;

    /*
       Screen display data
       ===================

       pcg_map: defines the character map.  pcg_map[i] points to an
                array defining character i (0 start).  pcg_map[i][j]
                is scanline j of this character (0 start).
                array size: C6545_CHAR_MEM_SIZE*C6545_MAX_CHR_HEIGHT
       scn_map: defines the content of the screen.  scn_map[i][j] gives
                the char at position i,j on the screen (0 start).
                array size: C6545_MAX_SCN_WIDTH*C6545_MAX_SCN_HEIGHT
       col_map: defines the fore and background colour content of the
                screen.  col_map[i][j][0] is the foreground colour for
                the char at position i,j on the screen (0 start),
                col_map[i][j][1] the background colour of same.
                array size: C6545_MAX_SCN_WIDTH*C6545_MAX_SCN_HEIGHT*2
    */

    UINT_8 **pcg_map;
    UINT_8 **scn_map;
    UINT_8 ***col_map;
}
C6545_screen;

/*
   Video character struct (INTERNAL)
   =================================

   The following struct defines the relevant information for a contents of
   a particular character position on the 6545 screen.
*/

typedef struct c6545_vdu_point
{
    /*
       Character number
       ================

       char_num: defines the character number displayed here.
    */

    UINT_16 char_num;

    /*
       Colour attributes
       =================

       fore_colour[0] = foreground colour
       back_colour[1] = foreground colour
       fore_colour[1] = background colour
       back_colour[0] = background colour
    */

    UINT_8 fore_colour[2];
    UINT_8 back_colour[2];

    /*
       Character modification mask
       ===========================

       line_change_mask: each bit of this mask refers to a line in the
                         character (the LSB being the uppermost).  If a bit
                         is set then the relevant row has changed since the
                         last time it was drawn, and so must be redrawn at
                         some point.
    */

    UINT_32 line_change_mask;

    /*
       Character linking
       =================

       Characters with the same char_num are arranged into a linked list
       using the following pointers (which point to the next element in the
       list and the previous one, respectively).  In this way, if a character
       is changed then the line_change_masks relevant to this change can be
       quickly updated by following the linked list for the char_num in
       question.
    */

    struct c6545_vdu_point *prev_same_char;
    struct c6545_vdu_point *next_same_char;

    /*
       Position information
       ====================

       char_x_coord,char_y_coord define the position of the character on
       the screen.  If the character is offscreen the value stored here is
       undefined.
    */

    UINT_8 char_x_coord;
    UINT_8 char_y_coord;

    /*
       Screen Information struct pointers
       ==================================

       These point to the relevant elements of the screen informatinos struct
       pointers to allow for quick updating of these structs when the
       contents of the screen are changed.  If NULL then the character is
       not onscreen.
    */

    UINT_8 *char_pointer; /* NULL if char is not onscreen */
    UINT_8 *fore_pointer; /* NULL if char is not onscreen */
    UINT_8 *back_pointer; /* NULL if char is not onscreen */
}
C6545_vdu_point;

/*
   PCG definition struct (INTERNAL)
   ================================

   This struct defines a programmable character.
*/

typedef struct
{
    /*
       Character lines
       ===============

       Best illustrated by example:

                                       +--------+
       lines[0x000] =  10011100        |x..xxx..|
       lines[0x001] =  10110010        |x.xx..x.|
       lines[0x002] =  10110010        |x.xx..x.|
       lines[0x003] =  01100111        |.xx..xxx|
       lines[0x004] =  00100101        |..x..x.x|
       lines[0x005] =  00100101        |..x..x.x|
       lines[0x006] =  00111101        |..xxxx.x|
       lines[0x007] =  00011001        |...xx..x|
       lines[0x008] =  00011000        |...xx...|
       lines[0x009] =  01100110        |.xx..xx.|
       lines[0x00A] =  01100110        |.xx..xx.|
       lines[0x00B] =  01000010        |.x....x.|
       lines[0x00C] =  10000001        |x......x|
       lines[0x00D] =  11100111        |xxx..xxx|
       lines[0x00E] =  10100101        |x.x..x.x|
       lines[0x00F] =  10100101        |x.x..x.x|
                                       |        |
             :            :            |   :    |
             :            :            |   :    |
                                       +--------+
    */

    UINT_8 lines[C6545_MAX_CHR_HEIGHT];

    /*
       Helper pointer
       ==============

       first_occur: points to the first occurrence of this character in
                    VDU ram.  Thus if the character is changed, you can
                    follow this link to the first occurance on the screen,
                    and thereby the linked list of *all* occurences of this
                    character on the screen, to update the line update
                    masks quickly, without searching.
    */

    struct c6545_vdu_point *first_occur;
}
C6545_char;







/*
   6545 Object Instance (nominally read only)
   ==========================================
*/

typedef struct
{
    /*
       Raw 6545 data section (register contents).
       ==========================================
    */

    UINT_8  reg_Raddr;
    UINT_8  reg_R0_;
    UINT_8  reg_R1_;
    UINT_8  reg_R2_;
    UINT_8  reg_R3_h;
    UINT_8  reg_R3_v;
    UINT_8  reg_R4_;
    UINT_8  reg_R5_;
    UINT_8  reg_R6_;
    UINT_8  reg_R7_;
    UINT_8  reg_R8_;
    UINT_8  reg_R8_adm;
    UINT_8  reg_R8_csk;
    UINT_8  reg_R9_;
    UINT_8  reg_R10_bb;
    UINT_8  reg_R10_cs;
    UINT_8  reg_R11_;
    UINT_16 reg_R12_13_;
    UINT_8  reg_R12_ra;
    UINT_8  reg_R13_ca;
    UINT_16 reg_R14_15_;
    UINT_8  reg_R14_ra;
    UINT_8  reg_R15_ca;
    UINT_16 reg_R16_17_;
    UINT_8  reg_R16_ra;
    UINT_8  reg_R17_ca;
    UINT_16 reg_R18_19_;
    UINT_8  reg_R18_ra;
    UINT_8  reg_R19_ca;

    /*
       VDU RAM, character RAM and tables
       =================================

       vdu_memory  - arranged in the order seen by the 6545 memory bus.
       char_memory - character RAM.
       vdu_detail  - description of the screen in alternative format used
                     when communicating with the following functions:

       pole_lpen_table      - external lightpen lookup table (clock high).
       pole_lpen_clow_table - external lightpen lookup table (clock low).
    */

    C6545_vdu_point *vdu_memory;
    C6545_char      *char_memory;
    C6545_screen    vdu_detail;

    UINT_8 **pole_lpen_table;
    UINT_8 **pole_lpen_clow_table;

    /*
       6545 data section
       =================
    */

    UINT_16 horiz_char_count;    /* horizontal character counter */
    UINT_16 vert_char_count;     /* vertical character counter   */
    UINT_16 vert_scan_count;     /* vertical scanline counter    */
    UINT_8  vert_sync_count;     /* vertical oddity counter      */
    UINT_8  frame_count;         /* frame counter                */

    UINT_8  vblank;              /* 0x020 if in vertical blanking      */
    UINT_8  hblank;              /* 0x001 if in vertical blanking      */
    UINT_8  lpen_register_full;  /* 0x040 if lightpen register is full */
    UINT_8  update_ready;        /* 0x080 if update blah               */

    UINT_16 left_margin;         /* left margin on screen  */
    UINT_16 screen_width;        /* visible screen width   */
    UINT_16 right_margin;        /* right margin on screen */

    UINT_16 top_margin;          /* top margin on screen    */
    UINT_16 screen_height;       /* visible screen height   */
    UINT_16 bottom_margin;       /* bottom margin on screen */

    UINT_16 lpen_alias;          /* lightpen alias (see previous) */

    UINT_16 MA_bus_no_update;    /* MA bus contents (raw form)   */
    UINT_16 MA_bus_clow;         /* MA bus contents (clock low)  */
    UINT_16 MA_bus;              /* MA bus contents (clock high) */
    UINT_8  CR_bus_clow;         /* CR bus contents (clock low)  */
    UINT_8  CR_bus;              /* CR bus contents (clock high) */

    UINT_8  is_cursor;           /* CURSOR signal (00h/01h) */
    UINT_8  is_vsync;            /* VSYNC  signal (00h/02h) */
    UINT_8  is_hsync;            /* HSYNC  signal (00h/04h) */
    UINT_8  dispen;              /* DISPEN signal (00h/08h) */

    UINT_8  update_dispen_count; /* internal counter (update cycle)  */
    UINT_32 line_up_mask;        /* modded internal line update mask */

    /*
       Lightpen stuff
       ==============

       is_lpen_clow:       used to store the lightpen state (low)
       is_lpen:            used to store the lightpen state (high)
       previous_lpen_clow: previous state of is_lpen_clow
       previous_lpen:      previous state of is_lpen
       latch_lpen:         set makes llpen latch on next cycle (must be
                           the next cycle, not this one, to put the correct
                           address into the update register etc.

       lpen_feedback_addr:           temp store of lpen feedback address
       lpen_feedback_addr_type:      set if addr is refresh addr
       lpen_feedback_addr_type_clow: set if addr is refresh addr
    */

    UINT_8  is_lpen_clow;
    UINT_8  is_lpen;
    UINT_8  previous_lpen_clow;
    UINT_8  previous_lpen;
    UINT_8  latch_lpen;

    UINT_16 lpen_feedback_addr;
    UINT_8  lpen_feedback_addr_type;
    UINT_8  lpen_feedback_addr_type_clow;

    /*
       Temporary variables
       ===================
    */

    UINT_8 temp_8;
    C6545_vdu_point *temp_vdu;
    UINT_32 i_32;

    /*
       Communication buses
       ===================

       (see descriptions given previously).
    */

    UINT_8  *comms_data_bus;
    UINT_16 *xpos_bus;
    UINT_16 *ypos_bus;
    UINT_8  *is_fore_bus;
    UINT_8  *fore_colour_bus;
    UINT_8  *back_colour_bus;
    UINT_8  *inv__colour_bus;

    UINT_32 *lpen_call_mask_bus;
    UINT_16 *cycle_counter_bus;
    UINT_16 *geometry_bus;
    UINT_16 *video_mem_addr_bus;
    UINT_16 *video_data_bus;
    UINT_8  *video_char_line_bus;

    UINT_32 *lpen_reset_counter_bus;
    UINT_32 *update_reset_counter_bus;

    UINT_8  redraw_bus;

    /*
       Communication tables
       ====================

       (see descriptions given previously).
    */

    UINT_8  **lpen_feedback_table_sel;
    UINT_8  **lpen_feedback_table;
    UINT_8  **lpen_feedback_clow_table;
    UINT_8  **lpen_feedrfsh_table;
    UINT_8  **lpen_feedrfsh_clow_table;

    /*
       External control functions
       ==========================

       (see descriptions given previously).
    */

    weird_pointer_jive change_left_margin;
    weird_pointer_jive change_screen_width;
    weird_pointer_jive change_right_margin;
    weird_pointer_jive change_top_margin;
    weird_pointer_jive change_screen_height;
    weird_pointer_jive change_bottom_margin;
    weird_pointer_jive pixel_drawer;
}
c6545_state;



c6545_state *c6545_init(UINT_16  _c6545_lpen_alias,
                        UINT_8  *_c6545_comms_data_bus,
                        UINT_32 *_c6545_lpen_call_mask_bus,
                        UINT_16 *_c6545_geometry_bus,
                        UINT_16 *_c6545_video_mem_addr_bus,
                        UINT_16 *_c6545_video_data_bus,
                        UINT_8  *_c6545_video_char_line_bus,
                        UINT_16 *_c6545_xpos_bus,
                        UINT_16 *_c6545_ypos_bus,
                        UINT_8  *_c6545_is_fore_bus,
                        UINT_8  *_c6545_fore_colour_bus,
                        UINT_8  *_c6545_back_colour_bus,
                        UINT_8  *_c6545_inv__colour_bus,
                        UINT_32 *_c6545_lpen_reset_counter_bus,
                        UINT_32 *_c6545_update_reset_counter_bus,
                        UINT_8  **_c6545_pole_lpen_table,
                        UINT_8  **_c6545_pole_lpen_clow_table,
                        UINT_8  **_c6545_lpen_feedback_table,
                        UINT_8  **_c6545_lpen_feedback_clow_table,
                        UINT_8  **_c6545_lpen_feedrfsh_table,
                        UINT_8  **_c6545_lpen_feedrfsh_clow_table,
                        weird_pointer_jive _c6545_change_left_margin,
                        weird_pointer_jive _c6545_change_screen_width,
                        weird_pointer_jive _c6545_change_right_margin,
                        weird_pointer_jive _c6545_change_top_margin,
                        weird_pointer_jive _c6545_change_screen_height,
                        weird_pointer_jive _c6545_change_bottom_margin,
                        weird_pointer_jive _c6545_pixel_drawer);

void c6545_reset(c6545_state *what);
void c6545_refresh(c6545_state *what);
void c6545_remove(c6545_state *what);

void c6545_do_cycles(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);

void c6545_addr_wr(c6545_state *what);
void c6545_data_wr(c6545_state *what);

void c6545_addr_rd(c6545_state *what);
void c6545_data_rd(c6545_state *what);

void c6545_write_char_mem(c6545_state *what);
void c6545_write_vdu_mem(c6545_state *what);
void c6545_write_fore_colour(c6545_state *what);
void c6545_write_back_colour(c6545_state *what);

#endif
