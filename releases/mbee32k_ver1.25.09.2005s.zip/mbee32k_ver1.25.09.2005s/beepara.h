
#include "u_dtype.h"
#include "configer.h"
#include "z80pio.h"

#ifndef _beepara_h
#define _beepara_h

/*
   MicroBee parallel port module
   =============================

   Emulates the operation of the microbee parallel port.  This is not the
   PIO emulation module - it emulates what happens on the other (non-z80)
   side of the PIO.

   Operation modes: 0 = output to physical parallel port (see beelowpc.h).
                    1 = output to file.
                    2 = NULL output with handshaking (default).
                    3 = input from file.
                    4 = unconnected.
                    5 = output to lptx port via bios (see beelowpc.h).


   Functions
   =========

   beepara_setup()     - usual setup function
   beepara_init(...)   - initialisation function.  Will return NULL upon
                         failure.  Arguments are:
                         data_bus   = pointer to data bus of PIO.
                         strobe_bus = pointer to strobe bus of PIO.
                         ready_bus  = pointer to ready bus of PIO.
                         strober    = function called to indicate that the
                                      state of a bus may have changed,
                                      indicating an input or acknowledgement.
   beepara_remove(...) - remove module.  Will return non-zero on failure.

   beepara_get_mode(...) - get the operating mode.

   The following functions all return 0 upon success, non-zero upon failure.
   If a mode is not accessible or an error occurs then the fallback mode is
   mode 4.

   beepara_cycle(cycles,...) - run the module through cycles clock cycles.
   beepara_data_written(...) - called to inform the emulator of change.

   beepara_set_mode0(...)          - set mode 0.
   beepara_set_mode1(filename,...) - set mode 1, output file filename.
   beepara_set_mode2(...)          - set mode 2.
   beepara_set_mode3(filename,...) - set mode 3, input file filename.
   beepara_set_mode4(...)          - set mode 4.
   beepara_set_mode5(...)          - set mode 5.
*/


SetupData *beepara_setup(void);
int beepara_init(UINT_8 *data_bus, UINT_8 *strobe_bus, UINT_8 *ready_bus, weird_pointer_jive strober, UINT_16 *_beepara_cycle_bus);
MENU *beepara_getmenu(void);
void beepara_remove(void);

int beepara_data_written(void);
int beepara_cycle(void);

#endif
