
#include "fakealeg.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "beelowpc.h"
#ifndef IS_CYGWIN
#include <conio.h>
#endif
#ifdef PARALLEL_ACCESSABLE_ALL
#include <pc.h>
#include <sys/movedata.h>
#include <bios.h>
#endif
#ifndef PARALLEL_ACCESSABLE_ALL
#ifdef PARALLEL_ACCESSABLE_HW_ONLY
#include <pc.h>
#include <sys/movedata.h>
#endif
#ifdef PARALLEL_ACCESSABLE_BIOS_ONLY
#include <bios.h>
#endif
#endif
#include "u_dtype.h"
#include "configer.h"

/*
   Close to hardware stuff, or potentially os dependent.
*/

void gen_initsound(void);
void gen_removesound(void);

char **splash_screen_gen(int what);

int beelowpc_havepulsed;
int beelowpc_havestrobed;
int beelowpc_lpt_loc;
int beelowpc_simulate_lpt_pulse;
int beelowpc_trigger_pulse_start;

SetupData beelowpc_setdat[] =
{
   { "pc_lpt_num",         &beelowpc_lpt_loc,             6 },
   { "pc_lpt_port",        &beelowpc_lpt_port,            6 },
   { "simulate_lpt_pulse", &beelowpc_simulate_lpt_pulse,  6 },
   { "pc_lpt_pulse_len",   &beelowpc_trigger_pulse_start, 6 },
   { "",                   NULL,                          0 }
};

SetupData *beelowpc_setup(void)
{
    beelowpc_lpt_loc             = 1;
    beelowpc_lpt_port            = 0;
    beelowpc_simulate_lpt_pulse  = 1;
    beelowpc_trigger_pulse_start = 2;

    return beelowpc_setdat;
}

int beelowpc_init(void)
{
    /*
       Parallel port init
    */

    #ifndef PARALLEL_HIDDEN
    #ifndef PARALLEL_ACCESSABLE_BIOS_ONLY
    if ( beelowpc_lpt_port == 0 )
    {
        switch ( beelowpc_lpt_loc )
        {
            case 1:
            {
                dosmemget(0x0408,2,&beelowpc_lpt_port);

                break;
            }

            case 2:
            {
                dosmemget(0x040A,2,&beelowpc_lpt_port);

                break;
            }

            case 3:
            {
                dosmemget(0x040C,2,&beelowpc_lpt_port);

                break;
            }

            case 4:
            {
                dosmemget(0x040E,2,&beelowpc_lpt_port);

                break;
            }

            default:
            {
                break;
            }
        }
    }
    #endif
    #endif

    beelowpc_trigger_pulse = 0;
    beelowpc_havepulsed    = 0;
    beelowpc_havestrobed   = 0;

    gen_initsound();

    return 0;
}

int beelowpc_remove(void)
{
    gen_removesound();

    return 0;
}






#ifdef USE_SOUNDCARD
/* SAMPLE_RATE          byte rate in Hz         */
/* BASE_FREQ_*          frequency at 10000      */
/* CYCLELEN_*           no. cycles in a sample  */
/* CYCLE_LENGTH_*       no. bytes in 1 cycle    */
/* BUFF_SIZE_*          buffer size             */
/* CLICKCYCLES          no cycles/click         */
/* CLICKBUFF_SIZE       click buffer size       */

#define SAMPLE_RATE     44100
#define STRETCH         1
#define SHRINK          2
#define MAXSTRETCH      1
#define MINFREQ         20
#define BASE_FREQ_A     200
#define BASE_FREQ_B     2000
#define BASE_FREQ_C     20000
#define CYCLELEN_A      100
#define CYCLELEN_B      1000
#define CYCLELEN_C      10000
#define CYCLE_LENGTH_A  ((STRETCH*SAMPLE_RATE)/BASE_FREQ_A)
#define CYCLE_LENGTH_B  ((STRETCH*SAMPLE_RATE)/BASE_FREQ_B)
#define CYCLE_LENGTH_C  ((STRETCH*SAMPLE_RATE)/BASE_FREQ_C)
#define BUFF_SIZE_A     (CYCLELEN_A*CYCLE_LENGTH_A)
#define BUFF_SIZE_B     (CYCLELEN_B*CYCLE_LENGTH_B)
#define BUFF_SIZE_C     (CYCLELEN_C*CYCLE_LENGTH_C)
#define CLICKCYCLES     1
#define CLICKBUFF_SIZE  (CLICKCYCLES*CYCLE_LENGTH_A)

int sndcardbad = 0;
int sound_on_a = 0;
int sound_on_b = 0;
int sound_on_c = 0;
SAMPLE *snd_sample_a;
SAMPLE *snd_sample_b;
SAMPLE *snd_sample_c;
SAMPLE *click_sample;
int freq_a;
int freq_b;
int freq_c;
#endif

void gen_initsound(void)
{
    #ifdef USE_SOUNDCARD
    int i,j;

    sndcardbad = install_sound(DIGI_AUTODETECT,MIDI_AUTODETECT,NULL);

    if ( ( snd_sample_a = create_sample(8,0,SAMPLE_RATE,BUFF_SIZE_A) ) == NULL )
    {
        sndcardbad = 1;
    }

    if ( ( snd_sample_b = create_sample(8,0,SAMPLE_RATE,BUFF_SIZE_B) ) == NULL )
    {
        sndcardbad = 1;
    }

    if ( ( snd_sample_c = create_sample(8,0,SAMPLE_RATE,BUFF_SIZE_C) ) == NULL )
    {
        sndcardbad = 1;
    }

    if ( ( click_sample = create_sample(8,0,SAMPLE_RATE,CLICKBUFF_SIZE) ) == NULL )
    {
        sndcardbad = 1;
    }

    if ( !sndcardbad )
    {
        {
            j = 1;

            ((UINT_8 *) (snd_sample_a->data))[0] = 0;

            for ( i = 1 ; i < BUFF_SIZE_A ; i++ )
            {
                ((UINT_8 *) (snd_sample_a->data))[i] = ((UINT_8 *) (snd_sample_a->data))[i-1];

                if ( j >= CYCLE_LENGTH_A/2 )
                {
                    ((UINT_8 *) (snd_sample_a->data))[i] = ~(((UINT_8 *) (snd_sample_a->data))[i-1]);

                    j = 0;
                }

                j++;
            }
        }

        {
            j = 1;

            ((UINT_8 *) (snd_sample_b->data))[0] = 0;

            for ( i = 1 ; i < BUFF_SIZE_B ; i++ )
            {
                ((UINT_8 *) (snd_sample_b->data))[i] = ((UINT_8 *) (snd_sample_b->data))[i-1];

                if ( j >= CYCLE_LENGTH_B/2 )
                {
                    ((UINT_8 *) (snd_sample_b->data))[i] = ~(((UINT_8 *) (snd_sample_b->data))[i-1]);

                    j = 0;
                }

                j++;
            }
        }

        {
            j = 1;

            ((UINT_8 *) (snd_sample_c->data))[0] = 0;

            for ( i = 1 ; i < BUFF_SIZE_C ; i++ )
            {
                ((UINT_8 *) (snd_sample_c->data))[i] = ((UINT_8 *) (snd_sample_c->data))[i-1];

                if ( j >= CYCLE_LENGTH_C/2 )
                {
                    ((UINT_8 *) (snd_sample_c->data))[i] = ~(((UINT_8 *) (snd_sample_c->data))[i-1]);

                    j = 0;
                }

                j++;
            }
        }

        {
            j = 1;

            ((UINT_8 *) (click_sample->data))[0] = 0;

            for ( i = 1 ; i < CLICKBUFF_SIZE ; i++ )
            {
                ((UINT_8 *) (click_sample->data))[i] = ((UINT_8 *) (click_sample->data))[i-1];

                if ( j >= CYCLE_LENGTH_A/2 )
                {
                    ((UINT_8 *) (click_sample->data))[i] = ~(((UINT_8 *) (click_sample->data))[i-1]);

                    j = 0;
                }

                j++;
            }
        }
    }
    #endif

    return;
}

void gen_removesound(void)
{
    #ifdef USE_PC_SPEAKER
    gen_nosound();
    #endif

    #ifdef USE_SOUNDCARD
    if ( !sndcardbad )
    {
        destroy_sample(snd_sample_a);
        destroy_sample(snd_sample_b);
        destroy_sample(snd_sample_c);
        destroy_sample(click_sample);
    }
    #endif

    return;
}

void gen_nosound(void)
{
    #ifdef USE_PC_SPEAKER
    nosound();
    #endif

    #ifdef USE_SOUNDCARD
    if ( !sndcardbad )
    {
        if ( sound_on_a )
        {
            stop_sample(snd_sample_a);

            sound_on_a = 0;
        }

        if ( sound_on_b )
        {
            stop_sample(snd_sample_b);

            sound_on_b = 0;
        }

        if ( sound_on_c )
        {
            stop_sample(snd_sample_c);

            sound_on_c = 0;
        }
    }
    #endif

    return;
}

void gen_sound(int freq)
{
    #ifdef USE_PC_SPEAKER
    sound(freq);
    #endif

    #ifdef USE_SOUNDCARD
    if ( !sndcardbad )
    {
        freq_a = (1000*STRETCH*freq)/BASE_FREQ_A;
        freq_b = (1000*STRETCH*freq)/BASE_FREQ_B;
        freq_c = (1000*STRETCH*freq)/BASE_FREQ_C;

        if ( !sound_on_a && !sound_on_b && !sound_on_c )
        {
            freq_start:

            if ( freq_a <= (1000*STRETCH)/SHRINK )
            {
                play_sample(snd_sample_a,255,128,freq_a,1);

                sound_on_a = 1;
            }

            else if ( freq_b <= (1000*STRETCH)/SHRINK )
            {
                play_sample(snd_sample_b,255,128,freq_b,1);

                sound_on_b = 1;
            }

            else
            {
                play_sample(snd_sample_c,255,128,freq_c,1);
                      
                sound_on_c = 1;
            }
        }

        else
        {
            if ( sound_on_a )
            {
                if (  ( freq_a > MAXSTRETCH*1000 ) || ( freq_a < MINFREQ ) )
                {
                    stop_sample(snd_sample_a);

                    goto freq_start;
                }

                adjust_sample(snd_sample_a,255,128,freq_a,1);
            }

            else if ( sound_on_b )
            {
                if ( ( freq_b > MAXSTRETCH*1000 ) || ( freq_b < MINFREQ ) )
                {
                    stop_sample(snd_sample_b);

                    goto freq_start;
                }

                adjust_sample(snd_sample_b,255,128,freq_b,1);
            }

            else
            {
                if ( ( freq_c > MAXSTRETCH*1000 ) || ( freq_c < MINFREQ ) )
                {
                    stop_sample(snd_sample_c);

                    goto freq_start;
                }

                adjust_sample(snd_sample_c,255,128,freq_c,1);
            }           
        }
    }
    #endif

    return;

    freq = 0;
}

void gen_soundclick(void)
{
    #ifdef USE_PC_SPEAKER
    gen_sound(1);
    #endif

    #ifdef USE_SOUNDCARD
    play_sample(click_sample,255,128,1000,0);
    #endif

    return;
}











int init_parallel_state(void)
{
    #ifndef PARALLEL_HIDDEN
    #ifndef PARALLEL_ACCESSABLE_BIOS_ONLY
    outportb(beelowpc_lpt_port+2,0x008);
    outportb(beelowpc_lpt_port+2,0x00C);

    return 0;
    #endif
    #endif

    return 1;
}

int write_parallel_state(UINT_8 data, UINT_8 ready)
{
    #ifndef PARALLEL_HIDDEN
    #ifndef PARALLEL_ACCESSABLE_BIOS_ONLY
    outportb(beelowpc_lpt_port,data);

    if ( beelowpc_simulate_lpt_pulse )
    {
        if ( ready )
        {
            if ( !beelowpc_havepulsed )
            {
                outportb(beelowpc_lpt_port+2,0x00D);

                beelowpc_havepulsed = 1;

                beelowpc_trigger_pulse = beelowpc_trigger_pulse_start;
            }

            else
            {
                outportb(beelowpc_lpt_port+2,0x00C);
            }
        }

        else
        {
            outportb(beelowpc_lpt_port+2,0x00C);

            beelowpc_havepulsed = 0;
        }
    }

    else
    {
        if ( ready )
        {
            outportb(beelowpc_lpt_port+2,0x00D);
        }

        else
        {
            outportb(beelowpc_lpt_port+2,0x00C);
        }
    }

    return 0;
    #endif
    #endif

    return 1;

    data = ready;
}

int read_parallel_state(UINT_8 *data, UINT_8 *strobe)
{
    #ifndef PARALLEL_HIDDEN
    #ifndef PARALLEL_ACCESSABLE_BIOS_ONLY
    *data = inportb(beelowpc_lpt_port);

    *strobe = inportb(beelowpc_lpt_port+1);

    if ( beelowpc_simulate_lpt_pulse )
    {
        /*
           The ack strobe has most likely been missed, so also check the
           busy line, and if it's high the printer isn't busy so whatever
           happened must have finished.
        */

        if ( !( *strobe & 0x040 ) || ( *strobe & 0x080 ) )
        {
            /*
               The printer is ready - either it's just printed the last char
               or nothing at all.  If beelowpc_havepulsed is set then it's
               the former.  If this is the case, then generate a *pulse* -
               that's what the beelowpc_havestrobed does - it lets strobe
               be set low for precisely one thingy, then it goes high again
               until the next char is sent.
            */

            if ( beelowpc_havepulsed && !beelowpc_havestrobed )
            {
                *strobe = 0;

                beelowpc_havestrobed = 1;
            }

            else
            {
                *strobe = 1;
            }
        }

        else
        {
            *strobe = 1;

            beelowpc_havestrobed = 0;
        }
    }

    else
    {
        if ( !( *strobe & 0x040 ) )
        {
            *strobe = 0;
        }

        else
        {
            *strobe = 1;
        }
    }

    return 0;
    #endif
    #endif

    return 1;

    data = strobe;
}

int init_parallel_state_bios(void)
{
    #ifndef PARALLEL_HIDDEN
    #ifndef PARALLEL_ACCESSABLE_HW_ONLY
    _bios_printer(_PRINTER_INIT,beelowpc_lpt_loc-1,0);

    return 0;
    #endif
    #endif

    return 1;
}

int print_parallel_bios(UINT_8 data)
{
    #ifndef PARALLEL_HIDDEN
    #ifndef PARALLEL_ACCESSABLE_HW_ONLY
    _bios_printer(_PRINTER_WRITE,beelowpc_lpt_loc-1,data);

    return 0;
    #endif
    #endif

    return 1;

    data = 0;
}

char **splash_screen_green(void)
{
    return splash_screen_gen(0);
}

char **splash_screen_colour(void)
{
    return splash_screen_gen(1);
}


char picosplasha[] = "PicoMozzy  GREEN  - a Microbee 32k Emulator v1.19.06.2005 (beta)";
char picosplashb[] = "================================================================";
char picosplashc[] = "                                                                ";
char picosplashd[] = "             By Alistair Shilton (apsh@ecr.mu.oz.au)            ";
char picosplashe[] = "    http://www.ee.mu.oz.au/pgrad/apsh/microbee/microbee.html    ";
char picosplashf[] = "                                                                ";
char picosplashg[] = "Key mapping: PAGE UP is the reset key.                          ";
char picosplashh[] = "             RIGHT ALT is the linefeed key.                     ";
char picosplashi[] = "             RIGHT CTRL is the break key.                       ";
char picosplashj[] = "                                                                ";
char picosplashk[] = "Control keys: PAGE DOWN      - emulation control menu.          ";
char picosplashl[] = "              NUM LOCK       - toggle sound on/off.             ";
char picosplashm[] = "              SCROLL LOCK    - toggle speed emulation on/off.   ";
char picosplashn[] = "              SHIFT+PRTSCR   - Save screenshot in screen.bmp.   ";
char picosplasho[] = "                                                                ";
char picosplashp[] = "LED meanings: NUM LOCK    - lit if sound emulation is on.       ";
char picosplashq[] = "              SCROLL LOCK - lit if speed emulation is on.       ";
char picosplashr[] = "              CAPS LOCK   - lit if colour emulation is on.      ";
char picosplashs[] = "              (note: may not work on all machines)              ";
char picosplasht[] = "                                                                ";
char picosplashu[] = "                                                                ";
char picosplashv[] = "         Press any key to begin.                                ";
char picosplashw[] = "";

char *picosplash[] = { picosplasha,
                       picosplashb,
                       picosplashc,
                       picosplashd,
                       picosplashe,
                       picosplashf,
                       picosplashg,
                       picosplashh,
                       picosplashi,
                       picosplashj,
                       picosplashk,
                       picosplashl,
                       picosplashm,
                       picosplashn,
                       picosplasho,
                       picosplashp,
                       picosplashq,
                       picosplashr,
                       picosplashs,
                       picosplasht,
                       picosplashu,
                       picosplashv,
                       picosplashw,
                       NULL         };

char **splash_screen_gen(int what)
{
    #ifdef IS_CYGWIN
    if ( what )
    {
        picosplash[0][10] = 'C';
        picosplash[0][11] = 'O';
        picosplash[0][12] = 'L';
        picosplash[0][13] = 'O';
        picosplash[0][14] = 'U';
        picosplash[0][15] = 'R';
    }

    return picosplash;
    #endif

    #ifndef IS_CYGWIN
    int top_leave;
    int left_leave;

    clrscr();
    gotoxy(1,1);

    left_leave = (ScreenCols()-64)/2;
    top_leave  = (ScreenRows()-25)/2;

    textcolor(LIGHTGRAY);

    gotoxy(left_leave,top_leave+1); cprintf("PicoMozzy ");

    if ( what )
    {
        textcolor(0x080 | LIGHTBLUE);       cprintf("C");
        textcolor(0x080 | LIGHTGREEN);      cprintf("O");
        textcolor(0x080 | LIGHTCYAN);       cprintf("L");
        textcolor(0x080 | LIGHTRED);        cprintf("O");
        textcolor(0x080 | LIGHTMAGENTA);    cprintf("U");
        textcolor(0x080 | YELLOW);          cprintf("R");
    }

    else
    {
        textcolor(GREEN);   cprintf(" ");
        textcolor(GREEN);   cprintf("G");
        textcolor(GREEN);   cprintf("R");
        textcolor(GREEN);   cprintf("E");
        textcolor(GREEN);   cprintf("E");
        textcolor(GREEN);   cprintf("N");
    }

    textcolor(LIGHTGRAY);

                                     cprintf(              "  - a Microbee 32k Emulator v1.19.06.2005 (beta)  ");
    gotoxy(left_leave,top_leave+ 2); cprintf("================================================================");
    gotoxy(left_leave,top_leave+ 3); cprintf("                                                                ");
    gotoxy(left_leave,top_leave+ 4); cprintf("             By Alistair Shilton (apsh@ecr.mu.oz.au)            ");
    gotoxy(left_leave,top_leave+ 5); cprintf("    http://www.ee.mu.oz.au/pgrad/apsh/microbee/microbee.html    ");
    gotoxy(left_leave,top_leave+ 6); cprintf("                                                                ");
    gotoxy(left_leave,top_leave+ 7); cprintf("Key mapping: PAGE UP is the reset key.                          ");
    gotoxy(left_leave,top_leave+ 8); cprintf("             RIGHT ALT is the linefeed key.                     ");
    gotoxy(left_leave,top_leave+ 9); cprintf("             RIGHT CTRL is the break key.                       ");
    gotoxy(left_leave,top_leave+10); cprintf("                                                                ");
    gotoxy(left_leave,top_leave+11); cprintf("Control keys: PAGE DOWN      - emulation control menu.          ");
    gotoxy(left_leave,top_leave+12); cprintf("              NUM LOCK       - toggle sound on/off.             ");
    gotoxy(left_leave,top_leave+13); cprintf("              SCROLL LOCK    - toggle speed emulation on/off.   ");
    gotoxy(left_leave,top_leave+14); cprintf("              SHIFT+PRTSCR   - Save screenshot in screen.bmp.   ");
    gotoxy(left_leave,top_leave+15); cprintf("                                                                ");
    gotoxy(left_leave,top_leave+16); cprintf("LED meanings: NUM LOCK    - lit if sound emulation is on.       ");
    gotoxy(left_leave,top_leave+17); cprintf("              SCROLL LOCK - lit if speed emulation is on.       ");
    gotoxy(left_leave,top_leave+18); cprintf("              CAPS LOCK   - lit if colour emulation is on.      ");
    gotoxy(left_leave,top_leave+19); cprintf("              (note: may not work on all machines)              ");
    gotoxy(left_leave,top_leave+20); cprintf("                                                                ");
    gotoxy(left_leave,top_leave+21); cprintf("                                                                ");

    textcolor(0x080 | LIGHTRED);

    gotoxy(left_leave,top_leave+22); cprintf("WARNING: DISABLE ANY SCREENSAVERS AND GO TO FULLSCREEN MODE     ");
    gotoxy(left_leave,top_leave+23); cprintf("         (ALT+ENTER IF NEEDED) BEFORE CONTINUING.               ");

    textcolor(LIGHTGRAY);

    gotoxy(left_leave,top_leave+24); cprintf("                                                                ");
    gotoxy(left_leave,top_leave+25); cprintf("         Press any key to begin.                                ");

    _setcursortype(_NOCURSOR);
    getch();
    _setcursortype(_NORMALCURSOR);
    #endif

    what = 0;

    return NULL;
}

#define SPLASH_CHAR_HEIGHT 9
#define SPLASH_BOUNDARY 2

int splash_graphic(char **whatsplash)
{
    #ifdef IS_CYGWIN
    int w,h;
    int cw,ch;
    int i;
    RGB black = { 0,  0,  0,  0 };
    RGB green = { 0,  63, 0,  0 };

    cw = strlen(whatsplash[0]);
    ch = 0;

    while ( whatsplash[ch] != NULL )
    {
        ch++;
    }

    w = SPLASH_CHAR_HEIGHT*(SPLASH_BOUNDARY+SPLASH_BOUNDARY+cw);
    h = SPLASH_CHAR_HEIGHT*(SPLASH_BOUNDARY+SPLASH_BOUNDARY+ch);

    set_color_depth(8);

    if ( set_gfx_mode(GFX_SAFE,w,h,w,h) )
    {
        return 1;
    }

    set_palette(default_palette);

    set_color(1,&black);
    set_color(2,&green);

    set_clip(screen,0,0,w-1,h-1);
    rectfill(screen,0,0,w-1,h-1,1);

    for ( i = 0 ; i < ch ; i++ )
    {
        textout(screen,font,whatsplash[i],(SPLASH_CHAR_HEIGHT*SPLASH_BOUNDARY)+1,SPLASH_CHAR_HEIGHT*(SPLASH_BOUNDARY+i)+1,2);
    }

    clear_keybuf();
    readkey();

    set_gfx_mode(GFX_TEXT,0,0,0,0);
    #endif

    return 0;

    whatsplash = NULL;
}

