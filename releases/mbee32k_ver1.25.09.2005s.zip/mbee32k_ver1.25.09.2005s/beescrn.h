
#include "fakealeg.h"
#include "u_dtype.h"
#include "configer.h"

#ifndef _beescrn_h
#define _beescrn_h

/*
   Microbee screen emulation module
   ================================


*/

SetupData *beescrn_setup(void);
int beescrn_init(int                *_beescrn_in_step_mode,
                 UINT_16            *_beescrn_geometry_bus,
                 int                *_beescrn_do_colour,
                 UINT_16            *_beescrn_xpos,
                 UINT_16            *_beescrn_ypos,
                 UINT_8             *_beescrn_is_fore,
                 UINT_8             *_beescrn_fore_colour,
                 UINT_8             *_beescrn_back_colour,
                 UINT_8             *_beescrn_inv__colour,
                 weird_pointer_jive  _beescrn_scrngrab);
MENU *beescrn_getmenu(void);
void beescrn_remove(void);

void beescrn_change_left_margin(void);
void beescrn_change_screen_width(void);
void beescrn_change_right_margin(void);

void beescrn_change_top_margin(void);
void beescrn_change_screen_height(void);
void beescrn_change_bottom_margin(void);

void beescrn_blank_screen(void);
void beescrn_blank_physical_screen(void);
void beescrn_refresh_bee_screen(void);

int   beescrn_screenshot(const char shotname[]);
void *beescrn_get_beescreen_copy(void); /* actually BITMAP * */

UINT_16  beescrn_get_beescreen_width(void);
UINT_16  beescrn_get_beescreen_height(void);
void    *beescrn_get_beescreen_palette(void); /* actually PALETTE * */

int beescrn_revert_gfx_mode(void);
int beescrn_menu_gfx_mode(void);
int beescrn_is_in_menu_gfx_mode(void);

UINT_8 beescrn_trans_colour(UINT_8 bee_colour);

UINT_8 beescrn_get_bright(void);
UINT_8 beescrn_get_contrast(void);

void beescrn_set_bright(UINT_8 what);
void beescrn_set_contrast(UINT_8 what);

void beescrn_draw_on(void);
void beescrn_draw_off(void);

void beescrn_pixel_drawer(void);

#endif
