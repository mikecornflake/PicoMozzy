
#include <stdio.h>
#include <string.h>
#include "configer.h"
#include "u_dtype.h"



int load_config_file(const char configfile[], SetupData **info)
{
    FILE *gp;
    char buffera[CONFIG_BUFFER_LEN+1];
    char bufferb[CONFIG_BUFFER_LEN+1];
    int i,j,k,l;
    unsigned long m;
    long n;
    char c;

    if ( ( gp = fopen(configfile,"rt") ) == NULL )
    {
        return 1;
    }

    while ( !feof(gp) )
    {
        if ( fgets(buffera,CONFIG_BUFFER_LEN,gp) == NULL )
        {
            fclose(gp);

            return 2;
        }

        i = 1;

        while ( info[i-1] != NULL )
        {
            j = 1;

            while ( (info[i-1][j-1]).data_addr != NULL )
            {
                if ( buffera[0] != '%' )
                {
                    if ( buffera[strlen((info[i-1][j-1]).data_name)] == ' ' )
                    {
                        if ( strncmp(buffera,(info[i-1][j-1]).data_name,strlen((info[i-1][j-1]).data_name)) == 0 )
                        {
                            switch ( (info[i-1][j-1]).data_type )
                            {
                                case 0:
                                {
                                    sscanf(buffera,"%s %c %lu",bufferb,&c,&m);

                                    *((UINT_8 *) (info[i-1][j-1]).data_addr) = (UINT_8) m;

                                    break;
                                }

                                case 1:
                                {
                                    sscanf(buffera,"%s %c %lu",bufferb,&c,&m);

                                    *((UINT_16 *) (info[i-1][j-1]).data_addr) = (UINT_16) m;

                                    break;
                                }

                                case 2:
                                {
                                    sscanf(buffera,"%s %c %lu",bufferb,&c,&m);

                                    *((UINT_32 *) (info[i-1][j-1]).data_addr) = (UINT_32) m;

                                    break;
                                }

                                case 3:
                                {
                                    sscanf(buffera,"%s %c %ld",bufferb,&c,&n);

                                    *((SINT_8 *) (info[i-1][j-1]).data_addr) = (SINT_8) n;

                                    break;
                                }

                                case 4:
                                {
                                    sscanf(buffera,"%s %c %ld",bufferb,&c,&n);

                                    *((SINT_16 *) (info[i-1][j-1]).data_addr) = (SINT_16) n;

                                    break;
                                }

                                case 5:
                                {
                                    sscanf(buffera,"%s %c %ld",bufferb,&c,&n);

                                    *((SINT_32 *) (info[i-1][j-1]).data_addr) = (SINT_32) n;

                                    break;
                                }

                                case 6:
                                {
                                    sscanf(buffera,"%s %c %d",bufferb,&c,(int *) ((info[i-1][j-1]).data_addr));

                                    break;
                                }

                                case 7:
                                {
                                    l = -1;

                                    ((char *) (info[i-1][j-1]).data_addr)[0] = '\0';

                                    if ( strlen((info[i-1][j-1]).data_name)+1 < strlen(buffera) )
                                    {
                                        for ( k = strlen((info[i-1][j-1]).data_name)+1 ; ((unsigned int) k) < strlen(buffera) ; k++ )
                                        {
                                            switch ( l )
                                            {
                                                case -1:
                                                {
                                                    if ( buffera[k-1] == '=' )
                                                    {
                                                        l = 0;
                                                    }

                                                    break;
                                                }

                                                case 0:
                                                {
                                                    if ( ( buffera[k-1] != ' '  ) &&
                                                         ( buffera[k-1] != '\t' )    )
                                                    {
                                                        l = 1;

                                                        goto default_proceed;
                                                    }

                                                    break;
                                                }

                                                default:
                                                {
                                                    default_proceed:

                                                    if ( l < CONFIG_BUFFER_LEN )
                                                    {
                                                        ((char *) (info[i-1][j-1]).data_addr)[l-1] = buffera[k-1];
                                                        ((char *) (info[i-1][j-1]).data_addr)[l]   = '\0';
                                                    }

                                                    l++;

                                                    break;
                                                }
                                            }
                                        }
                                    }

                                    break;
                                }

                                case 8:
                                {
                                    sscanf(buffera,"%s %c %ld",bufferb,&c,(long *) ((info[i-1][j-1]).data_addr));

                                    break;
                                }

                                case 9:
                                {
                                    sscanf(buffera,"%s %c %Lux",bufferb,&c,(UINT_64 *) ((info[i-1][j-1]).data_addr));

                                    break;
                                }

                                case 10:
                                {
                                    sscanf(buffera,"%s %c %Ldx",bufferb,&c,(SINT_64 *) ((info[i-1][j-1]).data_addr));

                                    break;
                                }

                                default:
                                {
                                    fclose(gp);

                                    return 4;

                                    break;
                                }
                            }
                        }
                    }
                }

                j++;
            }

            i++;
        }
    }

    fclose(gp);

    return 0;
}
