
#include "fakealeg.h"
#include <stdio.h>
#include "beekey.h"
#include "u_dtype.h"
#include "configer.h"
#include "debmaloc.h"

/*
                        The Microbee Keyboard
                        =====================

   The microbee keyboard circuitry is connected directly to the 6545 CRTC
   controller and, in particular, the light pen circuitry.  In the microbee
   circuit, the keys are arranged in a grid whose edges are selected by
   MA7,8,9 and MA4,5,6.  The grid is enabled as discussed below.  When the
   grid is enabled, a high goes on the column of the grid selected by
   MA7,8,9. A row is selected by MA4,5,6, and if the key at the intersection
   of these two is selected then the lightpen will be triggered, storing the
   contents of the MA bus in the lightpen register (and updating the
   relevant bits are switched to signal that the read has occured - namely
   LPEN_REGISTER_FULL and UPDATE_READY).

   The grid is set up as follows:



                            +------------------------------------+
    MA7,8,9 ================|                                    |
                            | 74ls156 based open collector demux |
                            | (ie. output pulled low if selected |
                            | by MA7,8,9 and grid_en* = 0).      |
    grid_en* --------------O|                                    |
                            +------------------------------------+
                             O    O    O    O    O    O    O    O
                             |0   |1   |2   |3   |4   |5   |6   |7
      (outputs pulled high)  |    |    |    |    |    |    |    |
                             |    |    |    |    |    |    |    | 
                 +-----+     |    |    |    |    |    |    |    | 
                 |     |---- @`-- H -- P -- X -- 0 -- 8(--ESC   |
                 |     |0    |    |    |    |    |    |    |    |
                 |     |     |    |    |    |    |    |    |    |
                 |     |---- A -- I -- Q -- Y -- 1!-- 9)-- BS--CTRL
    MA4,5,6 =====|     |1    |    |    |    |    |    |    |    |
              sel|     |     |    |    |    |    |    |    |    |
                 |     |---- B -- J -- R -- Z -- 2"-- :*--TAB   |
                 |     |2    |    |    |    |    |    |    |    |
                 |     |     |    |    |    |    |    |    |    |
                 |     |---- C -- K -- S -- [{-- 3#-- ;+-- LF   |
                 | mux |3    |    |    |    |    |    |    |    |
                 |     |     |    |    |    |    |    |    |    |
                 |     |---- D -- L -- T -- \|-- 4$-- ,<-- CR   |
                 |     |4    |    |    |    |    |    |    |    |
    lpen -------O|     |     |    |    |    |    |    |    |    |
          output*|     |---- E -- M -- U -- ]}-- 5%-- -=--LOCK  |
                 |     |5    |    |    |    |    |    |    |    |
                 |     |     |    |    |    |    |    |    |    |
                 |     |---- F -- N -- V -- ^~-- 6&-- .>--BRK   |
                 |     |6    |    |    |    |    |    |    |    |
                 |     |     |    |    |    |    |    |    |    |
                 |     |---- G -- O -- W --DEL-- 7'-- /?--SPC--SHIFT
                 |     |7
                 +-----+

   Grid enabling is controlled by three signals:

    ROMREAD*:  This signal comes from bit 1 of port 0B, and is also used to
               veiw character ROM.  This is just romread.
    DISPEN:    Comes from the 6545.  It is high during the visible display,
               low during the blanking interval.
    CR4(USTB): The update strobe comes from the 6545.  It will either occur
               when showing char scanlines >= 11h (doesn't happen on the
               microbee under normal conditions) or to initiate an update
               strobe, as a result of an accress to R31 when the state of
               the 6545 is correct.

   These are combined in the following circuit:

                                         +-----+
    CR4(UPDATE STROBE 6545) -------------|     |
                                         |     |        a low here enables
                                         | NOR |------- the grid, which puts
                                         |     |        a high on the column
    DISPEN(6545) -----/\/\/-----+--------|     |        selected by MA7,8,9
                                |        +-----+
                                |
    ROMREAD* ---------|<|-------+

   which has the following truth table:

       ROMREAD* CR4  DISPEN   grid_en*   enabled?
          0      0     0         1         no
          0      0     1         1         no
          0      1     0         0         yes
          0      1     1         0         yes
          1      0     0         1         no
          1      0     1         0         yes
          1      1     0         0         yes
          1      1     1         0         yes

   or, correcting the inverted romread signal:

       ROMREAD  CR4  DISPEN   grid_en    enabled?
          0      0     0         0         no
          0      0     1         1         yes
          0      1     0         1         yes
          0      1     1         1         yes
          1      0     0         0         no
          1      0     1         0         no
          1      1     0         1         yes
          1      1     1         1         yes

   For speed reasons, the calling of the keyboard function is controlled by
   the 6545 emulator.  This relies on the mask c6545_lpen_call_mask, which
   has bits assigned thusly:

   +-----+---------------------------------------+
   |     | 6545 signal combination to test bit   |  Mask given romread state
   |     +-----+--------+-------+-------+--------+
   | bit | CR4 | DISPEN | HSYNC | VSYNC | CURSOR |    ROMREAD0   ROMREAD1
   +-----+-----+--------+-------+-------+--------+
   |  0  |  0  |   0    |   0   |   0   |   0    |       0          0
   |  1  |  0  |   0    |   0   |   0   |   1    |       0          0
   |  2  |  0  |   0    |   0   |   1   |   0    |       0          0
   |  3  |  0  |   0    |   0   |   1   |   1    |       0          0
   |  4  |  0  |   0    |   1   |   0   |   0    |       0          0
   |  5  |  0  |   0    |   1   |   0   |   1    |       0          0
   |  6  |  0  |   0    |   1   |   1   |   0    |       0          0
   |  7  |  0  |   0    |   1   |   1   |   1    |       0          0
   |  8  |  0  |   1    |   0   |   0   |   0    |       1          0
   |  9  |  0  |   1    |   0   |   0   |   1    |       1          0
   | 10  |  0  |   1    |   0   |   1   |   0    |       1          0
   | 11  |  0  |   1    |   0   |   1   |   1    |       1          0
   | 12  |  0  |   1    |   1   |   0   |   0    |       1          0
   | 13  |  0  |   1    |   1   |   0   |   1    |       1          0
   | 14  |  0  |   1    |   1   |   1   |   0    |       1          0
   | 15  |  0  |   1    |   1   |   1   |   1    |       1          0
   | 16  |  1  |   0    |   0   |   0   |   0    |       1          1
   | 17  |  1  |   0    |   0   |   0   |   1    |       1          1
   | 18  |  1  |   0    |   0   |   1   |   0    |       1          1
   | 19  |  1  |   0    |   0   |   1   |   1    |       1          1
   | 20  |  1  |   0    |   1   |   0   |   0    |       1          1
   | 21  |  1  |   0    |   1   |   0   |   1    |       1          1
   | 22  |  1  |   0    |   1   |   1   |   0    |       1          1
   | 23  |  1  |   0    |   1   |   1   |   1    |       1          1
   | 24  |  1  |   1    |   0   |   0   |   0    |       1          1
   | 25  |  1  |   1    |   0   |   0   |   1    |       1          1
   | 26  |  1  |   1    |   0   |   1   |   0    |       1          1
   | 27  |  1  |   1    |   0   |   1   |   1    |       1          1
   | 28  |  1  |   1    |   1   |   0   |   0    |       1          1
   | 29  |  1  |   1    |   1   |   0   |   1    |       1          1
   | 30  |  1  |   1    |   1   |   1   |   0    |       1          1
   | 31  |  1  |   1    |   1   |   1   |   1    |       1          1
   +-----+-----+--------+-------+-------+--------+

    ROMREAD = 0: 11111111111111111111111100000000 = 0x0ffffff00
    ROMREAD = 1: 11111111111111110000000000000000 = 0x0ffff0000

   If the relevant bit for the signals is 1 then the keyboard polling
   function will be called, otherwise not.


   Interpretting the microbee keyboard cct
   =======================================

   If ROMREAD* is low (ie. character ROM is visible) then keyboard operation
   is "normal" (ie. entirely controlled by the 6545).  A value is written to
   the update registers, a strobe is initiated by writing to R31, and if the
   key is down the lightpen is hit and the value stored.  If ROMREAD* is
   high, however, the keyboard is effectively polled continuously (or at
   least at all whenever the display is not blanked).  If any keys are down
   they will repeatedly trigger the lightpen.  So the contents of the
   lightpen register will be unpredictable, but a keypress will be instantly
   visible.

   My guess is this: when input is needed by the bee, ROMREAD* is set (or
   more likely, already is) high.  Then cpu then waits, polling the 6545
   until the lightpen is triggered, indicating a keypress.  ROMREAD* is then
   set low, and the update register / update strobe process is used to find
   what key(s) have actually been pressed).


   Microbee key matrix
   ===================

   The rightmost columns of the microbee keyboard matrix are dedicated to
   special function keys, namely:

   [ ESC  ][ unused ]
   [  BS  ][ CTRL   ]
   [ TAB  ][ unused ]
   [  LF  ][ unused ]
   [  CR  ][ unused ]
   [ LOCK ][ unused ]
   [ BRK  ][ unused ]
   [ SPC  ][ SHIFT  ]

   These are assigned to the IBM keyboard as follows:

   ESC   =   key[KEY_ESC]       & KB_NORMAL
   BS    =   key[KEY_BACKSPACE] & KB_NORMAL
   TAB   =   key[KEY_TAB]       & KB_NORMAL
   LF    =   key[KEY_ALTGR]     & KB_NORMAL
   CR    =   key[KEY_ENTER]     & KB_NORMAL
   LOCK  =   key[KEY_CAPSLOCK]  & KB_NORMAL
   BRK   =   key[KEY_RCONROL]   & KB_NORMAL
   SPC   =   key[KEY_SPACE]     & KB_NORMAL
   CTRL  =   key[KEY_LCONROL]   & KB_NORMAL
   SHIFT = ( key[KEY_LSHIFT]    & KB_NORMAL ) || ( key[KEY_RSHIFT] & KB_NORMAL )

   The rest of the matrix depends on whether the shift key is down or not.
   If the (bee) shift key is not down, the matrix is seen by the microbee
   should be:

   [ @ ][ H ][ P ][ X ][ 0 ][ 8 ]
   [ A ][ I ][ Q ][ Y ][ 1 ][ 9 ]
   [ B ][ J ][ R ][ Z ][ 2 ][ : ]
   [ C ][ K ][ S ][ [ ][ 3 ][ ; ]
   [ D ][ L ][ T ][ \ ][ 4 ][ , ]
   [ E ][ M ][ U ][ ] ][ 5 ][ - ]
   [ F ][ N ][ V ][ ^ ][ 6 ][ . ]
   [ G ][ O ][ W ][DEL][ 7 ][ / ]

   corresponding pc keyboard combination to test (default shift up):

   [ shift+2@ ][ H ][ P ][ X        ][ 0) ][ 8*       ]
   [ A        ][ I ][ Q ][ Y        ][ 1! ][ 9(       ]
   [ B        ][ J ][ R ][ Z        ][ 2@ ][ shift+;: ]
   [ C        ][ K ][ S ][ [{       ][ 3# ][ ;:       ]
   [ D        ][ L ][ T ][ \|       ][ 4$ ][ ,<       ]
   [ E        ][ M ][ U ][ ]}       ][ 5% ][ -_       ]
   [ F        ][ N ][ V ][ shift+6^ ][ 6^ ][ .>       ]
   [ G        ][ O ][ W ][ DEL      ][ 7& ][ /?       ]

   If the shift is down, the microbee should see:

   [ ` ][ H ][ P ][ X ][ 0 ][ ( ]
   [ A ][ I ][ Q ][ Y ][ ! ][ ) ]
   [ B ][ J ][ R ][ Z ][ " ][ * ]
   [ C ][ K ][ S ][ { ][ # ][ + ]
   [ D ][ L ][ T ][ | ][ $ ][ < ]
   [ E ][ M ][ U ][ } ][ % ][ = ]
   [ F ][ N ][ V ][ ~ ][ & ][ > ]
   [ G ][ O ][ W ][DEL][ ' ][ ? ]

   corresponding pc keyboard combination to test (default shift down)

   [ noshift+`~ ][ H ][ P ][ X   ][ noshift+0) ][ 9(         ]
   [ A          ][ I ][ Q ][ Y   ][ 1!         ][ 0)         ]
   [ B          ][ J ][ R ][ Z   ][ '"         ][ 8*         ]
   [ C          ][ K ][ S ][ [{  ][ 3#         ][ =+         ]
   [ D          ][ L ][ T ][ \|  ][ 4$         ][ ,<         ]
   [ E          ][ M ][ U ][ ]}  ][ 5%         ][ noshift+=+ ]
   [ F          ][ N ][ V ][ `~  ][ 7&         ][ .>         ]
   [ G          ][ O ][ W ][ DEL ][ noshift+'" ][ /?         ]

   So, the matrix (as read by the microbee scanner to corresponding keys on
   the IBM keyboard) is (if the pc shift is not down):

   [ `~ ][ H ][ P ][ X   ][ 0)       ][ 8*       ]
   [ A  ][ I ][ Q ][ Y   ][ 1!       ][ 9(       ]
   [ B  ][ J ][ R ][ Z   ][ 2@       ][          ]
   [ C  ][ K ][ S ][ [{  ][ 3#       ][ ;:       ]
   [ D  ][ L ][ T ][ \|  ][ 4$       ][ ,<       ]
   [ E  ][ M ][ U ][ ]}  ][ 5%       ][ -_ OR =+ ]
   [ F  ][ N ][ V ][     ][ 6^       ][ .>       ]
   [ G  ][ O ][ W ][ DEL ][ 7& OR '" ][ /?       ]

   If the shift on pc is down:

   [ 2@ ][ H ][ P ][ X        ][    ][ 9(       ]
   [ A  ][ I ][ Q ][ Y        ][ 1! ][ 0)       ]
   [ B  ][ J ][ R ][ Z        ][ '" ][ 8* OR ;: ]
   [ C  ][ K ][ S ][ [{       ][ 3# ][ =+       ]
   [ D  ][ L ][ T ][ \|       ][ 4$ ][ ,<       ]
   [ E  ][ M ][ U ][ ]}       ][ 5% ][          ]
   [ F  ][ N ][ V ][ `~ OR 6^ ][ 7& ][ .>       ]
   [ G  ][ O ][ W ][ DEL      ][    ][ /?       ]

   Usually, the shift intersection of the matrix is just the state of the
   shift key on the pc keyboard.  However, the following combinations of
   shift + another key can cause this to be inverted (ie the intersection
   is the inverse of the shift key on the pc keyboard):

    shift down | shift up
   ------------+----------
       2@      |   `~
       6^      |   '"
       ;:      |   =+
               |   0)


   How the emulation works
   =======================

   It used to work as follows:

>    When a key is pressed, the callback function key_lowlevel_function is
>    called with the scancode.  If the scancode passed on relates to the
>    microbee key then this will refresh the lightpen table which tells the
>    6545 what addresses (ie. keys) will cause a strobe.  If the key has
>    just been pressed after been up then the relevant lpen bit
>    beekey_pole_lpen_table[i] will be set as well as
>    beekey_pole_lpen_table_worktable[i+1].  Furthermore, the counter in
>    beekey_pole_lpen_table_worktable[i+2] will be set to beekey_count_start.
>    If the key has been released, otoh, beekey_pole_lpen_table_worktable[i+1]
>    will be reset (ie. made 0), but neither of the other data bits will be
>    changed.

>    Now, every beekey_refresh_cycles emulated z80 cycles any non-zero key
>    counters beekey_pole_lpen_table_worktable[i+2] will be decremented.
>    If any counters are zero, beekey_pole_lpen_table[i] is set (so the
>    6545 sees the the key down), but beekey_pole_lpen_table_worktable[i+1] is
>    not (ie. the key is actually not down any more), then
>    beekey_pole_lpen_table[i] will be reset.

>    In this way, if the key is down for an appreciable length of emulated
>    time (beekey_count_start*beekey_refresh_cycles emulated z80 cycles) then
>    the emulated key will effectively go down when up at the same time as the
>    real key.  However, if the key is down for a very short emulated time
>    (less than beekey_count_start*beekey_refresh_cycles emulated z80 cycles)
>    then the emulated keypress will be "stretched" to ensure it lasts at least
>    this long.

   It still does, kinda, except that the callback function now just sets a
   flag and the rest is done by the cycle functon.  The old "key stretch"
   method is now used as a fallback only.  Instead, the 6545 has been
   modified to provide feedback.  Once the key has been hit with an update
   strobe, it can be turned off.


   Keyboard Data
   =============

   ROMREAD0_LPEN_MASK: value of LPEN call mask for 6545 when romread = 0.
   ROMREAD0_LPEN_MASK: value of LPEN call mask for 6545 when romread = 1.

   keyboard_pole_mode: Usually 0, this will be set to 1 if the keyboard
                       cannot be operated asynchronously and must be poled.
                       If set to 1 then the keyboard polling function will
                       be called for every z80 opcode.

   beekey_key_down: 1 if any microbee key is currently down.  This will
                      remain in this state for at least beekey_count_start
                      keyboard "refreshes".

   beekey_pole_lpen_table_worktable: Stolen from the 6545.  See above.

   beekey_count_start:    Starting value for key counters.
   beekey_refresh_cycles: Number of z80 cycles between keyboard refreshes.
   beekey_cycle_counter:  Cycle counter.

   Keyboard Functions
   ==================

   key_lowlevel_stuff(scancode): See above.


   Notes
   =====

   - I've observed that for most alphanumeric keys (but not shift, ret etc)
     basic will use "refresh" once (and only once) to test which key has
     been pressed for a single keypress.
   - If you hold down one key, it will block all others.  That is, if a
     press (and hold down) 'a', and then also press 'b' while 'a' is held
     down then there is no effect - it is just like 'a' was being held down
     on its own.  From this I *guess* that the keyboard (in basic, at least)
     operates thusly:

     - the 6545 lpen bit is monitored.  When it is tripped, a key is
       presumed to have been pressed.
     - The 6545 update feature is then used to run through the keyboard to
       see which key has been pressed, and also assess the state of the
       modifiers (shift, ctrl etc.).
     - Once the key is assertained, the lpen bit is reset periodically.  If
       it goes back high within some given period of time then it is assumed
       that the same key is being held down and causing this.
*/

#define MAX_REFRESH_CYCLES              2048

#define DEFAULT_KEY_COUNT_START         15
#define DEFAULT_KEY_REFRESH_CYCLES      200
#define DEFAULT_KEY_RATE                40

#define BEEKEY_RESPONSE_COUNT           0
#define BEEKEY_RESPONSE_COUNT_RFSH      1
#define BEEKEY_RELEASE_UPDATES          1
#define BEEKEY_RELEASE_LPENS            100
#define BEEKEY_RELEASE_LPENS_MIN        90

int  beekey_setfile(const char *filename_keysrc);
void beekey_closefile(void);


UINT_8  beekey_count_start;
UINT_32 beekey_refresh_cycles;

volatile UINT_8  beekey_lowcall_flag;
UINT_64 beekey_cycle_counter;

FILE *beekey_src_fp;
int   beekey_keyfileupdn;

int *beekey_key_down;

UINT_8 *beekey_lpen_table;
UINT_8 *beekey_lpen_worktable;
UINT_8 *beekey_lpen_feedback;
UINT_8 *beekey_lpen_feedrfsh;

UINT_32 *beekey_lpen_reset_counter;
UINT_32 *beekey_update_reset_counter;

UINT_16 *beekey_cycle_bus;

UINT_16 beekey_i16;

UINT_8 beekey_unshift_0;
UINT_8 beekey_unshift_2;
UINT_8 beekey_unshift_6;
UINT_8 beekey_unshift_7;
UINT_8 beekey_unshift_8;
UINT_8 beekey_unshift_9;
UINT_8 beekey_unshift_tilde;
UINT_8 beekey_unshift_quote;
UINT_8 beekey_unshift_colon;
UINT_8 beekey_unshift_equals;
UINT_8 beekey_unshift_minus;

UINT_8 beekey_shift_0;
UINT_8 beekey_shift_2;
UINT_8 beekey_shift_6;
UINT_8 beekey_shift_7;
UINT_8 beekey_shift_8;
UINT_8 beekey_shift_9;
UINT_8 beekey_shift_tilde;
UINT_8 beekey_shift_quote;
UINT_8 beekey_shift_colon;
UINT_8 beekey_shift_equals;
UINT_8 beekey_shift_minus;

UINT_8 beekey_effdown_0;
UINT_8 beekey_effdown_2;
UINT_8 beekey_effdown_6;
UINT_8 beekey_effdown_7;
UINT_8 beekey_effdown_8;
UINT_8 beekey_effdown_9;
UINT_8 beekey_effdown_tilde;
UINT_8 beekey_effdown_quote;
UINT_8 beekey_effdown_colon;
UINT_8 beekey_effdown_equals;
UINT_8 beekey_effdown_minus;


SetupData beekey_setdat[] =
{
   { "key_count_start",    &beekey_count_start,    0 },
   { "key_refresh_cycles", &beekey_refresh_cycles, 2 },
   { "", NULL, 0 }
};


void beekey_update_state(void)
{
    beekey_lowcall_flag = 1;

    return;
}
END_OF_FUNCTION(beekey_update_state)

SetupData *beekey_setup(void)
{
    beekey_count_start    = DEFAULT_KEY_COUNT_START;
    beekey_refresh_cycles = DEFAULT_KEY_REFRESH_CYCLES;

    return beekey_setdat;
}

int beekey_init(UINT_8 *_beekey_lpen_table, UINT_8 *_beekey_lpen_feedback, UINT_8 *_beekey_lpen_feedrfsh, UINT_32 *_beekey_lpen_reset_counter, UINT_32 *_beekey_update_reset_counter, int *_beekey_key_down, UINT_16 *_beekey_cycle_bus)
{
    LOCK_FUNCTION(beekey_update_state);

    LOCK_VARIABLE(beekey_lowcall_flag);
    LOCK_VARIABLE(beekey_src_fp);

    beekey_cycle_bus = _beekey_cycle_bus;

    if ( ( beekey_lpen_worktable = (UINT_8 *) DEBMALLOC(0x04003*sizeof(UINT_8)) ) == NULL )
    {
        return 1;
    }

    for ( beekey_i16 = 0 ; beekey_i16 < 0x04003 ; beekey_i16++ )
    {
        DEBDEREF(beekey_lpen_worktable,beekey_i16) = 0;
    }

    beekey_lpen_table    = _beekey_lpen_table;
    beekey_lpen_feedback = _beekey_lpen_feedback;
    beekey_lpen_feedrfsh = _beekey_lpen_feedrfsh;
    beekey_key_down      = _beekey_key_down;

    beekey_lpen_reset_counter   = _beekey_lpen_reset_counter;
    beekey_update_reset_counter = _beekey_update_reset_counter;

    if ( beekey_refresh_cycles < 2 )
    {
        beekey_refresh_cycles = 2;
    }

    if ( beekey_refresh_cycles > MAX_REFRESH_CYCLES )
    {
        beekey_refresh_cycles = MAX_REFRESH_CYCLES;
    }

    if ( beekey_count_start < 1 )
    {
        beekey_count_start = 1;
    }

    *beekey_key_down     = 0;
    beekey_lowcall_flag  = 0;
    beekey_cycle_counter = 0;

    for ( beekey_i16 = 0x00000 ; beekey_i16 <= 0x003F0 ; beekey_i16 += 0x00010 )
    {
        DEBDEREF(beekey_lpen_worktable,beekey_i16)   = 0x000;
        DEBDEREF(beekey_lpen_worktable,beekey_i16+1) = 0x000;
        DEBDEREF(beekey_lpen_worktable,beekey_i16+2) = 0x000;
    }

    beekey_src_fp      = NULL;
    beekey_keyfileupdn = 0;

    beekey_unshift_0      = 0;
    beekey_unshift_2      = 0;
    beekey_unshift_6      = 0;
    beekey_unshift_7      = 0;
    beekey_unshift_8      = 0;
    beekey_unshift_9      = 0;
    beekey_unshift_tilde  = 0;
    beekey_unshift_quote  = 0;
    beekey_unshift_colon  = 0;
    beekey_unshift_equals = 0;
    beekey_unshift_minus  = 0;

    beekey_shift_0      = 0;
    beekey_shift_2      = 0;
    beekey_shift_6      = 0;
    beekey_shift_7      = 0;
    beekey_shift_8      = 0;
    beekey_shift_9      = 0;
    beekey_shift_tilde  = 0;
    beekey_shift_quote  = 0;
    beekey_shift_colon  = 0;
    beekey_shift_equals = 0;
    beekey_shift_minus  = 0;

    beekey_effdown_0      = 0;
    beekey_effdown_2      = 0;
    beekey_effdown_6      = 0;
    beekey_effdown_7      = 0;
    beekey_effdown_8      = 0;
    beekey_effdown_9      = 0;
    beekey_effdown_tilde  = 0;
    beekey_effdown_quote  = 0;
    beekey_effdown_colon  = 0;
    beekey_effdown_equals = 0;
    beekey_effdown_minus  = 0;

    return 1;
}

void beekey_remove(void)
{
    if ( beekey_lpen_worktable != NULL )
    {
        DEBFREE(beekey_lpen_worktable);
    }

    beekey_lpen_worktable = NULL;

    return;
}

void beekey_cycle(void)
{
    if ( beekey_src_fp == NULL )
    {
        /*
           First off, if a key has been pressed need to update the state
           of the microbee internal key map.
        */

        if ( beekey_lowcall_flag )
        {
            beekey_lowcall_flag = 0;

            /*
               The following keys are the same shiftwise between the
               microbee and the pc keyboards - for example, SHIFT-5 will
               give % on either keyboard.  Hence there is no need for any
               fancy stuff with these keys.

               KEY ASSUMPTION: KB_NORMAL = 0x001
            */

                                        /* 0x001 */
            DEBDEREF(beekey_lpen_worktable,0x011) = key[KEY_A]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x021) = key[KEY_B]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x031) = key[KEY_C]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x041) = key[KEY_D]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x051) = key[KEY_E]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x061) = key[KEY_F]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x071) = key[KEY_G]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x081) = key[KEY_H]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x091) = key[KEY_I]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x0A1) = key[KEY_J]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x0B1) = key[KEY_K]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x0C1) = key[KEY_L]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x0D1) = key[KEY_M]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x0E1) = key[KEY_N]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x0F1) = key[KEY_O]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x101) = key[KEY_P]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x111) = key[KEY_Q]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x121) = key[KEY_R]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x131) = key[KEY_S]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x141) = key[KEY_T]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x151) = key[KEY_U]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x161) = key[KEY_V]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x171) = key[KEY_W]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x181) = key[KEY_X]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x191) = key[KEY_Y]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x1A1) = key[KEY_Z]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x1B1) = key[KEY_OPENBRACE]  & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x1C1) = key[KEY_BACKSLASH]  & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x1D1) = key[KEY_CLOSEBRACE] & KB_NORMAL;
                                        /* 0x1E1 */
            DEBDEREF(beekey_lpen_worktable,0x1F1) = key[KEY_DEL]        & KB_NORMAL;
                                        /* 0x201 */
            DEBDEREF(beekey_lpen_worktable,0x211) = key[KEY_1]          & KB_NORMAL;
                                        /* 0x221 */
            DEBDEREF(beekey_lpen_worktable,0x231) = key[KEY_3]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x241) = key[KEY_4]          & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x251) = key[KEY_5]          & KB_NORMAL;
                                        /* 0x261 */
                                        /* 0x271 */
                                        /* 0x281 */
                                        /* 0x291 */
                                        /* 0x2A1 */
                                        /* 0x2B1 */
            DEBDEREF(beekey_lpen_worktable,0x2C1) = key[KEY_COMMA]      & KB_NORMAL;
                                        /* 0x2D1 */
            DEBDEREF(beekey_lpen_worktable,0x2E1) = key[KEY_STOP]       & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x2F1) = key[KEY_SLASH]      & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x301) = key[KEY_ESC]        & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x311) = key[KEY_BACKSPACE]  & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x321) = key[KEY_TAB]        & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x331) = key[KEY_ALTGR]      & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x341) = key[KEY_ENTER]      & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x351) = key[KEY_CAPSLOCK]   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x361) = key[KEY_RCONTROL]   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x371) = key[KEY_SPACE]      & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x381) = 0                   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x391) = key[KEY_LCONTROL]   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x3A1) = 0                   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x3B1) = 0                   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x3C1) = 0                   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x3D1) = 0                   & KB_NORMAL;
            DEBDEREF(beekey_lpen_worktable,0x3E1) = 0                   & KB_NORMAL;
                                        /* 0x3F1 */

            /*
               The rest of the keys, however, need shift inversion, which
               has been described earlier.  However, consider the following
               chain of events at the pc keyboard:

               1. press SHIFT
               2. press 2@
               3. release SHIFT
               4. release 2@

               Now, this *should* give @ and nothing else.  But if we just
               naively implement the shift inversion scheme outlined earlier,
               it won't.  The problem is that, while 2 and @ are the same key
               on the pc keyboard, they are not the same key on the microbee
               keyboard.

               What the emulated microbee sees using the naive scheme is

               1. SHIFT goes down.
               2. SHIFT goes up due to shift inversion...
                  ...at the same time as @` goes down.
               3. @' goes up...
                  ...at the same time as 2" goes down...
               4. 2" goes up.

               which will result in the string @2 being printed.  What
               *should* happen is the following:

               1. SHIFT goes down
               2. SHIFT goes up due to shift inversion...
                  ...at the same time as @` goes down.
               3. nothing happens
               4. @' goes up.

               which will result in the character @ being printed, as should
               be (to be consistent with other basic strings).

               To achieve this end, it is necessary to make the pc SHIFT key
               sticky - that is, when one of

                KEY_0
                KEY_2
                KEY_6
                KEY_7
                KEY_9
                KEY_8
                KEY_TILDE
                KEY_QUOTE
                KEY_COLON
                KEY_EQUALS

               is pressed when the pc SHIFT key is down, the pc SHIFT key
               must remain (virtually) held down until that key is released.
               Similarly, when one of

                KEY_TILDE
                KEY_0
                KEY_2
                KEY_6
                KEY_7
                KEY_8
                KEY_9
                KEY_QUOTE
                KEY_COLON
                KEY_MINUS
                KEY_EQUALS

               is pressed whilst the pc SHIFT key is NOT held down then pc
               SHIFT key must remain (virtually) NOT held down until the key
               is released.
            */

            /*
               Clear any sticky responses
            */

            if ( !( key[KEY_0]      & KB_NORMAL ) ) { beekey_effdown_0      = 0; beekey_unshift_0      = 0; beekey_shift_0      = 0; }
            if ( !( key[KEY_2]      & KB_NORMAL ) ) { beekey_effdown_2      = 0; beekey_unshift_2      = 0; beekey_shift_2      = 0; }
            if ( !( key[KEY_6]      & KB_NORMAL ) ) { beekey_effdown_6      = 0; beekey_unshift_6      = 0; beekey_shift_6      = 0; }
            if ( !( key[KEY_7]      & KB_NORMAL ) ) { beekey_effdown_7      = 0; beekey_unshift_7      = 0; beekey_shift_7      = 0; }
            if ( !( key[KEY_8]      & KB_NORMAL ) ) { beekey_effdown_8      = 0; beekey_unshift_8      = 0; beekey_shift_8      = 0; }
            if ( !( key[KEY_9]      & KB_NORMAL ) ) { beekey_effdown_9      = 0; beekey_unshift_9      = 0; beekey_shift_9      = 0; }
            if ( !( key[KEY_TILDE]  & KB_NORMAL ) ) { beekey_effdown_tilde  = 0; beekey_unshift_tilde  = 0; beekey_shift_tilde  = 0; }
            if ( !( key[KEY_QUOTE]  & KB_NORMAL ) ) { beekey_effdown_quote  = 0; beekey_unshift_quote  = 0; beekey_shift_quote  = 0; }
            if ( !( key[KEY_COLON]  & KB_NORMAL ) ) { beekey_effdown_colon  = 0; beekey_unshift_colon  = 0; beekey_shift_colon  = 0; }
            if ( !( key[KEY_EQUALS] & KB_NORMAL ) ) { beekey_effdown_equals = 0; beekey_unshift_equals = 0; beekey_shift_equals = 0; }
            if ( !( key[KEY_MINUS]  & KB_NORMAL ) ) { beekey_effdown_minus  = 0; beekey_unshift_minus  = 0; beekey_shift_minus  = 0; }

            if ( key[KEY_LSHIFT] || key[KEY_RSHIFT] )
            {
                /*
                   Set the effective key states, allowing for stickiness.
                */

                if ( ( key[KEY_0]      & KB_NORMAL ) && !beekey_unshift_0      ) { beekey_shift_0      = 1; beekey_effdown_0      = 1; } else { beekey_shift_0      = 0; beekey_effdown_0      = 0; }
                if ( ( key[KEY_2]      & KB_NORMAL ) && !beekey_unshift_2      ) { beekey_shift_2      = 1; beekey_effdown_2      = 1; } else { beekey_shift_2      = 0; beekey_effdown_2      = 0; }
                if ( ( key[KEY_6]      & KB_NORMAL ) && !beekey_unshift_6      ) { beekey_shift_6      = 1; beekey_effdown_6      = 1; } else { beekey_shift_6      = 0; beekey_effdown_6      = 0; }
                if ( ( key[KEY_7]      & KB_NORMAL ) && !beekey_unshift_7      ) { beekey_shift_7      = 1; beekey_effdown_7      = 1; } else { beekey_shift_7      = 0; beekey_effdown_7      = 0; }
                if ( ( key[KEY_8]      & KB_NORMAL ) && !beekey_unshift_8      ) { beekey_shift_8      = 1; beekey_effdown_8      = 1; } else { beekey_shift_8      = 0; beekey_effdown_8      = 0; }
                if ( ( key[KEY_9]      & KB_NORMAL ) && !beekey_unshift_9      ) { beekey_shift_9      = 1; beekey_effdown_9      = 1; } else { beekey_shift_9      = 0; beekey_effdown_9      = 0; }
                if ( ( key[KEY_TILDE]  & KB_NORMAL ) && !beekey_unshift_tilde  ) { beekey_shift_tilde  = 1; beekey_effdown_tilde  = 1; } else { beekey_shift_tilde  = 0; beekey_effdown_tilde  = 0; }
                if ( ( key[KEY_QUOTE]  & KB_NORMAL ) && !beekey_unshift_quote  ) { beekey_shift_quote  = 1; beekey_effdown_quote  = 1; } else { beekey_shift_quote  = 0; beekey_effdown_quote  = 0; }
                if ( ( key[KEY_COLON]  & KB_NORMAL ) && !beekey_unshift_colon  ) { beekey_shift_colon  = 1; beekey_effdown_colon  = 1; } else { beekey_shift_colon  = 0; beekey_effdown_colon  = 0; }
                if ( ( key[KEY_EQUALS] & KB_NORMAL ) && !beekey_unshift_equals ) { beekey_shift_equals = 1; beekey_effdown_equals = 1; } else { beekey_shift_equals = 0; beekey_effdown_equals = 0; }
                if ( ( key[KEY_MINUS]  & KB_NORMAL ) && !beekey_unshift_minus  ) { beekey_shift_minus  = 1; beekey_effdown_minus  = 1; } else { beekey_shift_minus  = 0; beekey_effdown_minus  = 0; }

                /*
                   set the microbee keyboard state, using restuck key states.
                */

                DEBDEREF(beekey_lpen_worktable,0x001) = beekey_effdown_2                             | beekey_unshift_tilde;
                DEBDEREF(beekey_lpen_worktable,0x1E1) = beekey_effdown_tilde | beekey_effdown_6      | 0;
                DEBDEREF(beekey_lpen_worktable,0x201) = 0                                            | beekey_unshift_0;
                DEBDEREF(beekey_lpen_worktable,0x221) = beekey_effdown_quote                         | beekey_unshift_2;
                DEBDEREF(beekey_lpen_worktable,0x261) = beekey_effdown_7                             | beekey_unshift_6;
                DEBDEREF(beekey_lpen_worktable,0x271) = 0                                            | beekey_unshift_7 | beekey_unshift_quote;
                DEBDEREF(beekey_lpen_worktable,0x281) = beekey_effdown_9                             | beekey_unshift_8;
                DEBDEREF(beekey_lpen_worktable,0x291) = beekey_effdown_0                             | beekey_unshift_9;
                DEBDEREF(beekey_lpen_worktable,0x2A1) = beekey_effdown_8 | beekey_effdown_colon      | 0;
                DEBDEREF(beekey_lpen_worktable,0x2B1) = beekey_effdown_equals                        | beekey_unshift_colon;
                DEBDEREF(beekey_lpen_worktable,0x2D1) = 0                                            | beekey_unshift_minus | beekey_unshift_equals;

                DEBDEREF(beekey_lpen_worktable,0x3F1) = ( ( key[KEY_2] | key[KEY_6] | key[KEY_COLON] ) & KB_NORMAL ) ^ KB_NORMAL;
            }                                                                   
                                                                        
            else
            {                                                                   
                /*
                   Set the effective key states, allowing for stickiness.
                */

                if ( ( key[KEY_0]      & KB_NORMAL ) && !beekey_shift_0      ) { beekey_unshift_0      = 1; beekey_effdown_0      = 1; } else { beekey_unshift_0      = 0; beekey_effdown_0      = 0; }
                if ( ( key[KEY_2]      & KB_NORMAL ) && !beekey_shift_2      ) { beekey_unshift_2      = 1; beekey_effdown_2      = 1; } else { beekey_unshift_2      = 0; beekey_effdown_2      = 0; }
                if ( ( key[KEY_6]      & KB_NORMAL ) && !beekey_shift_6      ) { beekey_unshift_6      = 1; beekey_effdown_6      = 1; } else { beekey_unshift_6      = 0; beekey_effdown_6      = 0; }
                if ( ( key[KEY_7]      & KB_NORMAL ) && !beekey_shift_7      ) { beekey_unshift_7      = 1; beekey_effdown_7      = 1; } else { beekey_unshift_7      = 0; beekey_effdown_7      = 0; }
                if ( ( key[KEY_8]      & KB_NORMAL ) && !beekey_shift_8      ) { beekey_unshift_8      = 1; beekey_effdown_8      = 1; } else { beekey_unshift_8      = 0; beekey_effdown_8      = 0; }
                if ( ( key[KEY_9]      & KB_NORMAL ) && !beekey_shift_9      ) { beekey_unshift_9      = 1; beekey_effdown_9      = 1; } else { beekey_unshift_9      = 0; beekey_effdown_9      = 0; }
                if ( ( key[KEY_TILDE]  & KB_NORMAL ) && !beekey_shift_tilde  ) { beekey_unshift_tilde  = 1; beekey_effdown_tilde  = 1; } else { beekey_unshift_tilde  = 0; beekey_effdown_tilde  = 0; }
                if ( ( key[KEY_QUOTE]  & KB_NORMAL ) && !beekey_shift_quote  ) { beekey_unshift_quote  = 1; beekey_effdown_quote  = 1; } else { beekey_unshift_quote  = 0; beekey_effdown_quote  = 0; }
                if ( ( key[KEY_COLON]  & KB_NORMAL ) && !beekey_shift_colon  ) { beekey_unshift_colon  = 1; beekey_effdown_colon  = 1; } else { beekey_unshift_colon  = 0; beekey_effdown_colon  = 0; }
                if ( ( key[KEY_EQUALS] & KB_NORMAL ) && !beekey_shift_equals ) { beekey_unshift_equals = 1; beekey_effdown_equals = 1; } else { beekey_unshift_equals = 0; beekey_effdown_equals = 0; }
                if ( ( key[KEY_MINUS]  & KB_NORMAL ) && !beekey_shift_minus  ) { beekey_unshift_minus  = 1; beekey_effdown_minus  = 1; } else { beekey_unshift_minus  = 0; beekey_effdown_minus  = 0; }

                /*
                   set the microbee keyboard state, using restuck key states
                   and the unshift states.
                */

                DEBDEREF(beekey_lpen_worktable,0x001) = beekey_effdown_tilde                         | beekey_shift_2;
                DEBDEREF(beekey_lpen_worktable,0x1E1) = 0                                            | beekey_shift_tilde | beekey_shift_6;
                DEBDEREF(beekey_lpen_worktable,0x201) = beekey_effdown_0                             | 0;
                DEBDEREF(beekey_lpen_worktable,0x221) = beekey_effdown_2                             | beekey_shift_quote;
                DEBDEREF(beekey_lpen_worktable,0x261) = beekey_effdown_6                             | beekey_shift_7;
                DEBDEREF(beekey_lpen_worktable,0x271) = beekey_effdown_7 | beekey_effdown_quote      | 0;
                DEBDEREF(beekey_lpen_worktable,0x281) = beekey_effdown_8                             | beekey_shift_9;
                DEBDEREF(beekey_lpen_worktable,0x291) = beekey_effdown_9                             | beekey_shift_0;
                DEBDEREF(beekey_lpen_worktable,0x2A1) = 0                                            | beekey_shift_8 | beekey_shift_colon;
                DEBDEREF(beekey_lpen_worktable,0x2B1) = beekey_effdown_colon                         | beekey_shift_equals;
                DEBDEREF(beekey_lpen_worktable,0x2D1) = beekey_effdown_minus | beekey_effdown_equals | 0;
                                                                    
                DEBDEREF(beekey_lpen_worktable,0x3F1) = ( key[KEY_TILDE] | key[KEY_QUOTE] | key[KEY_EQUALS] | key[KEY_0] ) & KB_NORMAL;
            }

            *beekey_key_down = 0;

            for ( beekey_i16 = 0x00000 ; beekey_i16 <= 0x003F0 ; beekey_i16 += 0x00010 )
            {
                if ( DEBDEREF(beekey_lpen_worktable,beekey_i16+1) & !DEBDEREF(beekey_lpen_table,beekey_i16) )
                {
                    /* Key has just been pressed. */
                    /* -= start the counter =- */

                    DEBDEREF(beekey_lpen_table,beekey_i16)       = 1;
                    DEBDEREF(beekey_lpen_worktable,beekey_i16+2) = beekey_count_start;

                    DEBDEREF(beekey_lpen_feedback,beekey_i16) = 0;
                    DEBDEREF(beekey_lpen_feedrfsh,beekey_i16) = 0;
                }

                *beekey_key_down |= DEBDEREF(beekey_lpen_table,beekey_i16);
            }
        }

        /*
           Then do rest of this stuff.
        */

        beekey_cycle_counter += *beekey_cycle_bus;

        if ( beekey_cycle_counter > beekey_refresh_cycles )
        {
            beekey_cycle_counter -= beekey_refresh_cycles;

            if ( *beekey_key_down )
            {
                *beekey_key_down = 0;

                for ( beekey_i16 = 0x00000 ; beekey_i16 <= 0x003F0 ; beekey_i16 += 0x00010 )
                {
                    if ( DEBDEREF(beekey_lpen_table,beekey_i16) )
                    {
                        if ( ( DEBDEREF(beekey_lpen_feedback,beekey_i16) >= BEEKEY_RESPONSE_COUNT      ) &&
                             ( DEBDEREF(beekey_lpen_feedrfsh,beekey_i16) >= BEEKEY_RESPONSE_COUNT_RFSH )    )
                        {
                            /*
                               Key has been read, so we can safely short-
                               circuit the countdown process.
                            */

                            DEBDEREF(beekey_lpen_worktable,beekey_i16+2) = 0;
                        }

                        if ( DEBDEREF(beekey_lpen_worktable,beekey_i16+2) == 0 )
                        {
                            /*
                               Key has been down long enough to be read (and
                               may have been read - see previous if
                               statement), so no need to hold the key down
                               any longer.  Instead, just make the key state
                               correspond to reality.
                            */

                            DEBDEREF(beekey_lpen_table,beekey_i16) = DEBDEREF(beekey_lpen_worktable,beekey_i16+1);
                        }

                        else
                        {
                            /*
                               Continue the countdown, keep key state const.
                            */

                            DEBDEREF(beekey_lpen_worktable,beekey_i16+2)--;
                        }

                        *beekey_key_down |= DEBDEREF(beekey_lpen_table,beekey_i16);
                    }
                }
            }

            if ( !(*beekey_key_down) )
            {
                (*beekey_lpen_reset_counter)   = 0;
                (*beekey_update_reset_counter) = 0;
            }
        }
    }

    else
    {
        beekey_lowcall_flag = 0;

        if ( !beekey_keyfileupdn )
        {
            if ( ( ( (*beekey_update_reset_counter) >= BEEKEY_RELEASE_UPDATES ) || ( (*beekey_lpen_reset_counter) >= BEEKEY_RELEASE_LPENS ) ) && ( (*beekey_lpen_reset_counter) >= BEEKEY_RELEASE_LPENS_MIN ) )
            {
                *beekey_key_down   = 0;
                beekey_keyfileupdn = 1;

                switch ( fgetc(beekey_src_fp) )
                {
                    case '@':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x000) = 1; DEBDEREF(beekey_lpen_feedback,0x000) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x000) = 0; break; }
                    case 'a':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x010) = 1; DEBDEREF(beekey_lpen_feedback,0x010) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x010) = 0; break; }
                    case 'b':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x020) = 1; DEBDEREF(beekey_lpen_feedback,0x020) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x020) = 0; break; }
                    case 'c':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x030) = 1; DEBDEREF(beekey_lpen_feedback,0x030) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x030) = 0; break; }
                    case 'd':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x040) = 1; DEBDEREF(beekey_lpen_feedback,0x040) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x040) = 0; break; }
                    case 'e':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x050) = 1; DEBDEREF(beekey_lpen_feedback,0x050) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x050) = 0; break; }
                    case 'f':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x060) = 1; DEBDEREF(beekey_lpen_feedback,0x060) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x060) = 0; break; }
                    case 'g':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x070) = 1; DEBDEREF(beekey_lpen_feedback,0x070) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x070) = 0; break; }
                    case 'h':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x080) = 1; DEBDEREF(beekey_lpen_feedback,0x080) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x080) = 0; break; }
                    case 'i':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x090) = 1; DEBDEREF(beekey_lpen_feedback,0x090) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x090) = 0; break; }
                    case 'j':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0a0) = 1; DEBDEREF(beekey_lpen_feedback,0x0a0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0a0) = 0; break; }
                    case 'k':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0b0) = 1; DEBDEREF(beekey_lpen_feedback,0x0b0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0b0) = 0; break; }
                    case 'l':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0c0) = 1; DEBDEREF(beekey_lpen_feedback,0x0c0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0c0) = 0; break; }
                    case 'm':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0d0) = 1; DEBDEREF(beekey_lpen_feedback,0x0d0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0d0) = 0; break; }
                    case 'n':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0e0) = 1; DEBDEREF(beekey_lpen_feedback,0x0e0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0e0) = 0; break; }
                    case 'o':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0f0) = 1; DEBDEREF(beekey_lpen_feedback,0x0f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0f0) = 0; break; }
                    case 'p':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x100) = 1; DEBDEREF(beekey_lpen_feedback,0x100) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x100) = 0; break; }
                    case 'q':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x110) = 1; DEBDEREF(beekey_lpen_feedback,0x110) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x110) = 0; break; }
                    case 'r':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x120) = 1; DEBDEREF(beekey_lpen_feedback,0x120) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x120) = 0; break; }
                    case 's':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x130) = 1; DEBDEREF(beekey_lpen_feedback,0x130) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x130) = 0; break; }
                    case 't':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x140) = 1; DEBDEREF(beekey_lpen_feedback,0x140) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x140) = 0; break; }
                    case 'u':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x150) = 1; DEBDEREF(beekey_lpen_feedback,0x150) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x150) = 0; break; }
                    case 'v':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x160) = 1; DEBDEREF(beekey_lpen_feedback,0x160) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x160) = 0; break; }
                    case 'w':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x170) = 1; DEBDEREF(beekey_lpen_feedback,0x170) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x170) = 0; break; }
                    case 'x':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x180) = 1; DEBDEREF(beekey_lpen_feedback,0x180) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x180) = 0; break; }
                    case 'y':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x190) = 1; DEBDEREF(beekey_lpen_feedback,0x190) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x190) = 0; break; }
                    case 'z':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1a0) = 1; DEBDEREF(beekey_lpen_feedback,0x1a0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1a0) = 0; break; }
                    case '[':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1b0) = 1; DEBDEREF(beekey_lpen_feedback,0x1b0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1b0) = 0; break; }
                    case '\\': { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1c0) = 1; DEBDEREF(beekey_lpen_feedback,0x1c0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1c0) = 0; break; }
                    case ']':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1d0) = 1; DEBDEREF(beekey_lpen_feedback,0x1d0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1d0) = 0; break; }
                    case '^':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1e0) = 1; DEBDEREF(beekey_lpen_feedback,0x1e0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1e0) = 0; break; }

                    case '0':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x200) = 1; DEBDEREF(beekey_lpen_feedback,0x200) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x200) = 0; break; }
                    case '1':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x210) = 1; DEBDEREF(beekey_lpen_feedback,0x210) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x210) = 0; break; }
                    case '2':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x220) = 1; DEBDEREF(beekey_lpen_feedback,0x220) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x220) = 0; break; }
                    case '3':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x230) = 1; DEBDEREF(beekey_lpen_feedback,0x230) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x230) = 0; break; }
                    case '4':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x240) = 1; DEBDEREF(beekey_lpen_feedback,0x240) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x240) = 0; break; }
                    case '5':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x250) = 1; DEBDEREF(beekey_lpen_feedback,0x250) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x250) = 0; break; }
                    case '6':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x260) = 1; DEBDEREF(beekey_lpen_feedback,0x260) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x260) = 0; break; }
                    case '7':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x270) = 1; DEBDEREF(beekey_lpen_feedback,0x270) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x270) = 0; break; }
                    case '8':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x280) = 1; DEBDEREF(beekey_lpen_feedback,0x280) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x280) = 0; break; }
                    case '9':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x290) = 1; DEBDEREF(beekey_lpen_feedback,0x290) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x290) = 0; break; }
                    case ':':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2a0) = 1; DEBDEREF(beekey_lpen_feedback,0x2a0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2a0) = 0; break; }
                    case ';':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2b0) = 1; DEBDEREF(beekey_lpen_feedback,0x2b0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2b0) = 0; break; }
                    case ',':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2c0) = 1; DEBDEREF(beekey_lpen_feedback,0x2c0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2c0) = 0; break; }
                    case '-':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2d0) = 1; DEBDEREF(beekey_lpen_feedback,0x2d0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2d0) = 0; break; }
                    case '.':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2e0) = 1; DEBDEREF(beekey_lpen_feedback,0x2e0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2e0) = 0; break; }
                    case '/':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2f0) = 1; DEBDEREF(beekey_lpen_feedback,0x2f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2f0) = 0; break; }



                    case '`':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x000) = 1; DEBDEREF(beekey_lpen_feedback,0x000) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x000) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'A':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x010) = 1; DEBDEREF(beekey_lpen_feedback,0x010) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x010) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'B':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x020) = 1; DEBDEREF(beekey_lpen_feedback,0x020) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x020) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'C':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x030) = 1; DEBDEREF(beekey_lpen_feedback,0x030) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x030) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'D':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x040) = 1; DEBDEREF(beekey_lpen_feedback,0x040) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x040) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'E':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x050) = 1; DEBDEREF(beekey_lpen_feedback,0x050) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x050) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'F':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x060) = 1; DEBDEREF(beekey_lpen_feedback,0x060) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x060) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'G':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x070) = 1; DEBDEREF(beekey_lpen_feedback,0x070) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x070) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'H':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x080) = 1; DEBDEREF(beekey_lpen_feedback,0x080) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x080) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'I':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x090) = 1; DEBDEREF(beekey_lpen_feedback,0x090) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x090) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'J':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0a0) = 1; DEBDEREF(beekey_lpen_feedback,0x0a0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0a0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'K':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0b0) = 1; DEBDEREF(beekey_lpen_feedback,0x0b0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0b0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'L':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0c0) = 1; DEBDEREF(beekey_lpen_feedback,0x0c0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0c0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'M':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0d0) = 1; DEBDEREF(beekey_lpen_feedback,0x0d0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0d0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'N':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0e0) = 1; DEBDEREF(beekey_lpen_feedback,0x0e0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0e0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'O':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x0f0) = 1; DEBDEREF(beekey_lpen_feedback,0x0f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x0f0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'P':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x100) = 1; DEBDEREF(beekey_lpen_feedback,0x100) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x100) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'Q':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x110) = 1; DEBDEREF(beekey_lpen_feedback,0x110) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x110) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'R':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x120) = 1; DEBDEREF(beekey_lpen_feedback,0x120) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x120) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'S':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x130) = 1; DEBDEREF(beekey_lpen_feedback,0x130) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x130) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'T':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x140) = 1; DEBDEREF(beekey_lpen_feedback,0x140) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x140) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'U':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x150) = 1; DEBDEREF(beekey_lpen_feedback,0x150) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x150) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'V':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x160) = 1; DEBDEREF(beekey_lpen_feedback,0x160) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x160) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'W':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x170) = 1; DEBDEREF(beekey_lpen_feedback,0x170) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x170) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'X':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x180) = 1; DEBDEREF(beekey_lpen_feedback,0x180) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x180) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'Y':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x190) = 1; DEBDEREF(beekey_lpen_feedback,0x190) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x190) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case 'Z':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1a0) = 1; DEBDEREF(beekey_lpen_feedback,0x1a0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1a0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '{':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1b0) = 1; DEBDEREF(beekey_lpen_feedback,0x1b0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1b0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '|':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1c0) = 1; DEBDEREF(beekey_lpen_feedback,0x1c0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1c0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '}':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1d0) = 1; DEBDEREF(beekey_lpen_feedback,0x1d0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1d0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '~':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x1e0) = 1; DEBDEREF(beekey_lpen_feedback,0x1e0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x1e0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }


                    case '!':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x210) = 1; DEBDEREF(beekey_lpen_feedback,0x210) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x210) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '\"': { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x220) = 1; DEBDEREF(beekey_lpen_feedback,0x220) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x220) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '#':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x230) = 1; DEBDEREF(beekey_lpen_feedback,0x230) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x230) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '$':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x240) = 1; DEBDEREF(beekey_lpen_feedback,0x240) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x240) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '%':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x250) = 1; DEBDEREF(beekey_lpen_feedback,0x250) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x250) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '&':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x260) = 1; DEBDEREF(beekey_lpen_feedback,0x260) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x260) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '\'': { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x270) = 1; DEBDEREF(beekey_lpen_feedback,0x270) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x270) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '(':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x280) = 1; DEBDEREF(beekey_lpen_feedback,0x280) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x280) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case ')':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x290) = 1; DEBDEREF(beekey_lpen_feedback,0x290) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x290) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '*':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2a0) = 1; DEBDEREF(beekey_lpen_feedback,0x2a0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2a0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '+':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2b0) = 1; DEBDEREF(beekey_lpen_feedback,0x2b0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2b0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '<':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2c0) = 1; DEBDEREF(beekey_lpen_feedback,0x2c0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2c0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '=':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2d0) = 1; DEBDEREF(beekey_lpen_feedback,0x2d0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2d0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '>':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2e0) = 1; DEBDEREF(beekey_lpen_feedback,0x2e0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2e0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }
                    case '\?': { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x2f0) = 1; DEBDEREF(beekey_lpen_feedback,0x2f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x2f0) = 0; DEBDEREF(beekey_lpen_table,0x3f0) = 1; DEBDEREF(beekey_lpen_feedback,0x3f0) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x3f0) = 0; break; }




                    case '\t': { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x320) = 1; DEBDEREF(beekey_lpen_feedback,0x320) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x320) = 0; break; }
                    case '\n': { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x340) = 1; DEBDEREF(beekey_lpen_feedback,0x340) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x340) = 0; break; }
                    case ' ':  { *beekey_key_down = 1; DEBDEREF(beekey_lpen_table,0x370) = 1; DEBDEREF(beekey_lpen_feedback,0x370) = 0; DEBDEREF(beekey_lpen_feedrfsh,0x370) = 0; break; }


                    default: { break; }
                }
            }
        }

        else
        {
            /*
               Wait for keypresses to register.
            */

            for ( beekey_i16 = 0x00000 ; beekey_i16 <= 0x003F0 ; beekey_i16 += 0x00010 )
            {
                if ( DEBDEREF(beekey_lpen_table,beekey_i16) )
                {
                    if ( ( DEBDEREF(beekey_lpen_feedback,beekey_i16) < BEEKEY_RESPONSE_COUNT      ) ||
                         ( DEBDEREF(beekey_lpen_feedrfsh,beekey_i16) < BEEKEY_RESPONSE_COUNT_RFSH )    )
                    {
                        return;
                    }

                    DEBDEREF(beekey_lpen_table,beekey_i16) = 0;
                }
            }

            (*beekey_lpen_reset_counter)   = 0;
            (*beekey_update_reset_counter) = 0;

            *beekey_key_down = 0;

            beekey_keyfileupdn = 0;

            if ( feof(beekey_src_fp) )
            {
                beekey_closefile();
            }
        }
    }

    return;
}

int beekey_setfile(const char *filename_keysrc)
{
    beekey_closefile();

    beekey_keyfileupdn = 0;

    for ( beekey_i16 = 0x00000 ; beekey_i16 <= 0x003F0 ; beekey_i16 += 0x00010 )
    {
        DEBDEREF(beekey_lpen_table,beekey_i16) = 0;
    }

    if ( ( beekey_src_fp = fopen(filename_keysrc,"rb") ) == NULL )
    {
        return 1;
    }

    return 0;
}

void beekey_closefile(void)
{
    if ( beekey_src_fp != NULL )
    {
        fclose(beekey_src_fp);

        beekey_src_fp = NULL;
    }

    *beekey_key_down = 0;
    beekey_keyfileupdn = 0;

    for ( beekey_i16 = 0x00000 ; beekey_i16 <= 0x003F0 ; beekey_i16 += 0x00010 )
    {
        DEBDEREF(beekey_lpen_table,beekey_i16)       = 0;
        DEBDEREF(beekey_lpen_worktable,beekey_i16)   = 0;
        DEBDEREF(beekey_lpen_worktable,beekey_i16+1) = 0;
        DEBDEREF(beekey_lpen_worktable,beekey_i16+2) = 0;
    }

    return;
}









int set_keyboard_normal(void);
int set_keyboard_sourced(void);
void beekey_update_menu_marks(void);

char keyboard_menu_optiona[] = "- &Normal";
char keyboard_menu_optionb[] = "- &Redirect from file";

char filename_keysrc[1800] = "\0";

MENU keyboard_menu[] =
{
    { keyboard_menu_optiona, set_keyboard_normal,  NULL, 0, NULL },
    { keyboard_menu_optionb, set_keyboard_sourced, NULL, 0, NULL },
    { NULL,                  NULL,                 NULL, 0, NULL }
};

MENU *beekey_getmenu(void)
{
    beekey_update_menu_marks();

    return keyboard_menu;
}

int set_keyboard_sourced(void)
{
    if ( file_select_ex("Keystroke Source file",filename_keysrc,NULL,300,0,0) )
    {
        if ( beekey_setfile(filename_keysrc) )
        {
            alert("Error:","Unable to open file.",".","&OK",NULL,'o',0);
        }
    }

    beekey_update_menu_marks();

    return D_O_K;
}

int set_keyboard_normal(void)
{
    beekey_closefile();

    beekey_update_menu_marks();

    return D_O_K;
}

void beekey_update_menu_marks(void)
{
    keyboard_menu_optiona[0] = ' ';
    keyboard_menu_optionb[0] = ' ';

    if ( beekey_src_fp == NULL ) { keyboard_menu_optiona[0] = '-'; }
    else                         { keyboard_menu_optionb[0] = '-'; }

    return;
}


