
#ifndef FAKEALEG_H
#define FAKEALEG_H


#ifndef FAKE_ALLEGRO
#include <allegro.h>
#endif

#ifdef FAKE_ALLEGRO

#define END_OF_FUNCTION(someargorother)
#define LOCK_FUNCTION(someargorother)
#define LOCK_VARIABLE(someargorother)


/*
   Menuing functions and datatypes.
*/

typedef struct MENU
{
   char *text;                   /* menu item text                  */
   int (*proc)(void);            /* callback function               */
   struct MENU *child;           /* to allow nested menus           */
   int flags;                    /* flags about the menu state      */
   void *dp;                     /* any data the menu might require */
} MENU;

struct DIALOG;

typedef struct DIALOG
{
   int (*proc)(int, struct DIALOG *, int);
                                    /* dialog procedure (message handler) */
   int x;                           /* position and size of the object    */
   int y;
   int w;
   int h;
   int fg;                          /* foreground and background colors   */
   int bg;
   int key;                         /* ASCII keyboard shortcut            */
   int flags;                       /* flags about the status of          */
                                    /* the object                         */
   int d1;                          /* whatever you want to use them for  */
   int d2;
   void *dp;                        /* pointers to more                   */
   void *dp2;                       /* object-specific data               */
   void *dp3;
} DIALOG;

#define D_O_K   0

#define D_EXIT          1        /* object makes the dialog exit */
#define D_SELECTED      2        /* object is selected */
#define D_GOTFOCUS      4        /* object has the input focus */
#define D_GOTMOUSE      8        /* mouse is on top of object */
#define D_HIDDEN        16       /* object is not visible */
#define D_DISABLED      32       /* object is visible but inactive */
#define D_DIRTY         64       /* object needs to be redrawn */
#define D_INTERNAL      128      /* reserved for internal use */
#define D_USER          256      /* from here on is free for your own use */

int d_shadow_box_proc(int msg, DIALOG *d, int c);
int d_button_proc(int msg, DIALOG *d, int c);
int d_ctext_proc(int msg, DIALOG *d, int c);
int d_text_proc(int msg, DIALOG *d, int c);
int d_edit_proc(int msg, DIALOG *d, int c);
int d_check_proc(int msg, DIALOG *d, int c);
int d_yield_proc(int msg, DIALOG *d, int c);
int popup_dialog(DIALOG *dialog, int focus_obj);

char *replace_filename(char *dest, const char *path, const char *filename, int size);
char *replace_extension(char *dest, const char *filename, const char *ext, int size);
char *get_filename(const char *path);
char *get_extension(const char *filename);

int alert(const char *s1, const char *s2, const char *s3, const char *b1, const char *b2, int c1, int c2);

/*
   Displays a popup alert box, containing three lines of text (s1-s3), and
   with either one or two buttons. The text for these buttons is passed in 
   b1 and b2 (b2 may be NULL), and the keyboard shortcuts in c1 and c2. 
   Returns 1 or 2 depending on which button was clicked. If the alert is 
   dismissed by pressing ESC when ESC is not one of the keyboard shortcuts, 
   it treats it as a click on the second button (this is consistent with the 
   common "Ok", "Cancel" alert).
*/

int file_select_ex(const char *message, char *path, const char *ext,int size, int w, int h);

/*
   Displays the Allegro file selector, with the message as caption. The path
   parameter contains the initial filename to display (this can be used to 
   set the starting directory, or to provide a default filename for a 
   save-as operation). The user selection is returned by altering the path 
   buffer, whose maximum capacity in bytes is specified by the size parameter.
   Note that it should have room for at least 80 characters (not bytes),
   so you should reserve 6x that amount, just to be sure. The list of files
   is filtered according to the file extensions in the ext parameter.
   Passing NULL includes all files; "PCX;BMP" includes only files with
   .PCX or .BMP extensions. If you wish to control files by their attributes,
   one of the fields in the extension list can begin with a slash, followed
   by a set of attribute characters. Any attributes written on their own,
   or with a + before them, indicate to include only files which have
   that attribute set. Any attributes with a '-' before them indicate to
   leave out any files with that attribute. The flag characters are
   'r' (read-only), 'h' (hidden), 's' (system), 'd' (directory),
   and 'a' (archive). For example, an extension string of "PCX;BMP;/+r-d"
   will display only PCX or BMP files that are read-only, and no
   directories. The file selector is stretched to the width and height
   specified in the w and h parameters, and to the size of the standard
   Allegro font. If either the width or height argument is set to zero, it is
   stretched to the corresponding screen dimension. This function returns
   zero if it was closed with the Cancel button or non-zero if it was OK'd.
*/


/*
   Keyboard control.
*/

#define KEY_MAX         59
#define KB_NORMAL       1

#define KEY_A           0
#define KEY_B           1
#define KEY_C           2
#define KEY_D           3
#define KEY_E           4
#define KEY_F           5
#define KEY_G           6
#define KEY_H           7
#define KEY_I           8
#define KEY_J           9
#define KEY_K           10
#define KEY_L           11
#define KEY_M           12
#define KEY_N           13
#define KEY_O           14
#define KEY_P           15
#define KEY_Q           16
#define KEY_R           17
#define KEY_S           18
#define KEY_T           19
#define KEY_U           20
#define KEY_V           21
#define KEY_W           22
#define KEY_X           23
#define KEY_Y           24
#define KEY_Z           25
#define KEY_0           26
#define KEY_1           27
#define KEY_2           28
#define KEY_3           29
#define KEY_4           30
#define KEY_5           31
#define KEY_6           32
#define KEY_7           33
#define KEY_8           34
#define KEY_9           35
#define KEY_ALTGR       36
#define KEY_BACKSLASH   37
#define KEY_BACKSPACE   38
#define KEY_CAPSLOCK    39
#define KEY_CLOSEBRACE  40
#define KEY_COLON       41
#define KEY_COMMA       42
#define KEY_DEL         43
#define KEY_ENTER       44
#define KEY_EQUALS      45
#define KEY_ESC         46
#define KEY_LCONTROL    47
#define KEY_LSHIFT      48
#define KEY_MINUS       49
#define KEY_OPENBRACE   50
#define KEY_QUOTE       51
#define KEY_RCONTROL    52
#define KEY_RSHIFT      53
#define KEY_STOP        54
#define KEY_SLASH       55
#define KEY_SPACE       56
#define KEY_TAB         57
#define KEY_TILDE       58

char key[KEY_MAX];

#endif


#endif
