
#include "u_dtype.h"
#include "6545.h"
#include "debmaloc.h"






/*

   +-------+
  -|       |-            +-----------------------------------------+
  -|       |-            |+----+----+----+----+----+----+----+----+|
  -|       |-            ||0000|0001|0002|....|....|004D|004E|004F||
  -|       |-      \\    |+----+----+----+----+----+----+----+----+|
  -|       | ====== \\   ||0050|0051|0052|....|....|009D|009E|009F||
  -|                 \\  |+----+----+----+-       -+----+----+----+|
  -|                  \\ ||00A0|00A1|00A             0ED|00EE|00EF||
  -| 6545 Emulator     \ |+----+----+--       _       --+----+----+|
  -|                     ||....|....|..      / \      ..|....|....||
  -| Alistair Shilton    |+----+----+-       \ /       -+----+----+|
  -| apsh@ecr.mu.oz.au   ||....|....|.     >{|||}      .|....|....||
  -| http://           / |+----+----+--      / \      --+----+----+|
  -|                  // ||....|....|..      \_/      ..|....|....||
  -|                 //  |+----+----+---             ---+----+----+|
  -|       | ====== //   ||06E0|06E1|06E2|.       .|072D|072E|072F||
  -|       |-      //    |+----+----+----+----+----+----+----+----+|
  -|       |-            ||0730|0731|0732|....|....|077D|077E|077F||
  -|       |-            |+----+----+----+----+----+----+----+----+|
  -|       |-            +-----------------------------------------+
  -|       |-
   +-------+


                      6545 detailed internal operation
                      ================================

The 6545 has two ports, namely data and address.  The address port controls
what is present at the data port (when written), but may also be read to
obtain information about the status of the 6545 and what attached stuff
is doing (vertical blanking and lpen).  The data register may be read only,
read write or write only depending on what address is being used.



The address port
================

Write     +-+-+-+-+-+-+-+-+
          |7|6|5|4|3|2|1|0|
          +-+-+-+-+-+-+-+-+
           | | | | | | | |
           | | | +-+-+-+-+-- Address appearing on the data port.
           | | |
           +-+-+------------ Ignored.

Read:     +-+-+-+-+-+-+-+-+
          |7|6|5|4|3|2|1|0|
          +-+-+-+-+-+-+-+-+
           | | | | | | | |
           | | | +-+-+-+-+-- Not used.
           | | |
           | | +------------ VERTICAL BLANKING
           | |               0 = Scan currently not in vert blanking time.
           | |               1 = Scan currently in vertical blanking time.
           | |
           | +-------------- LPEN_REGISTER_FULL
           |                 0 = Goes 0 when either R16 or R17 is read.
           |                 1 = Goes 1 when an LPEN strobe occurs.
           |
           +---------------- UPDATE_READY
                             0 = Goes 0 when R31 is read or written.
                             1 = Goes 1 when an update strobe occurs.



The data port
=============

 w R0     ________ Horizontal total chars (-1).
 w R1     ________ Horizontal display chars.
 w R2     ________ Horizontal sync position.
 w R3     vvvvhhhh Vertical and horizontal sync widths:
                   bits 0-3: horiz sync width in char times (0-15).
                   bits 4-7: vert sync width in rasterlines (0-15).
                             0 translates to 16 rasterlines.
 w R4     x_______ Vertical total character rows (-1).
 w R5     xxx_____ Vertical total adjust rasterlines.
 w R6     x_______ Vertical displayed character lines.
 w R7     x_______ Vertical sync position.
 w R8     ________ Mode: bit 0,1: ignore for simplicity (interlace control).
                         bit 2: Addressing mode:
                                0 = straight binary addressing.
                                1 = row/column addressing.
                         bit 3: Refresh RAM access:
                                0 = shared memory access.
                                1 = transparent memory access.
                         bit 4,5: Skew control (simplified version):
                                0,0 = no skew.
                                0,1 = cursor effectively 1 char right.
                                1,0 = cursor effectively 1 char left.
                                1,1 = no effective skew.
                         bit 6: Update strobe (transparent mode):
                                0 = pin 34 acts as scanline address RA4.
                                1 = pin 34 acts as update strobe.
                         bit 7: Update/Read mode:
                                0 = update occurs during horiz/vert blank.
                                1 = update interleaves during Phi2 clock.
 w R9     xxx_____ Number of rasterlines per character row (-1).
 w R10    xBB_____ Cursor start rasterline (low 5 bits).
                   BB: +---------+-----------------------------+
                       |   BIT   |                             |
                       +----+----+ CURSOR MODE                 |
                       |  6 |  5 |                             |
                       +----+----+-----------------------------+
                       |  0 |  0 | No blinking                 |
                       |  0 |  1 | No cursor                   |
                       |  1 |  0 | Blink at 1/16 field rate    |
                       |  1 |  1 | Blink at 1/32 field rate    |
                       +----+----+-----------------------------+
 w R11    xxx_____ Cursor end rasterline (if < start, wrap and invert).
 w R12    xx______ Display start address high.
 w R13    ________ Display start address low.
rw R14    xx______ Cursor address high.
rw R15    ________ Cursor address low.
r  R16    xx______ Lightpen address high.
r  R17    ________ Lightpen address low.
 w R18    xx______ Update address high.
 w R19    ________ Update address low.
rw R20-30 xxxxxxxx Nonexistant (read 0, write to nowhere).
rw R31    xxxxxxxx Read or write this port to tell the 6545 to perform an
                   update cycle (if enabled) at the soonest possible
                   oportunity, and make UPDATE READY go to 0.  After this
                   update cycle is completed, the value in the update
                   register will be incremented and UPDATE READY set to 1.

Reading from x gives 0's.  Writing to x has no affect.






What gets displayed where
=========================

Consider an 80 * 24 example.  If R8_adm == 0, the CRTC sees the screen as
follows:

              +----------------- Horizontal total R0 = 59h ----------------+
              |                                                            |
              +------- Horiz displayed R1 = 50h ------+                    |
              |                                       |                    |
                00   01   02  .... ....  4D   4E   4F    50   51  ....  59
             +-----------------------------------------+
 +----+----- |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  00h ||0000|0001|0002|....|....|004D|004E|004F||0050|0051|....|0059|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  01h ||0050|0051|0052|....|....|009D|009E|009F||00A0|00A1|....|00A9|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  02h ||00A0|00A1|00A2|....|....|00ED|00EE|00EF||00F0|00F1|....|00F9|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  ..  ||....|....|....|....|....|....|....|....||....|....|....|....|
 | Vertical  |+----+----+----+----+----+----+----+----+|----+----+----+----+
 | displayed ||....|....|....|....|....|....|....|....||....|....|....|....|
 | R6 = 18h  |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  ..  ||....|....|....|....|....|....|....|....||....|....|....|....|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  16h ||06E0|06E1|06E2|....|....|072D|072E|072F||0730|0731|....|0739|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  17h ||0730|0731|0732|....|....|077D|077E|077F||0780|0781|....|0789|
 |    +----- |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |           +-----------------------------------------+
 |       18h  |0780|0781|0782|....|....|07CD|07CE|07CF| 07D0|07D1|....|07D9|
Vertical      +----+----+----+----+----+----+----+----+ ----+----+----+----+
total    19h  |07D0|07D1|07D2|....|....|081D|081E|081F| 0820|0821|....|0829|
R4 = 21h      +----+----+----+----+----+----+----+----+ ----+----+----+----+
 |       ..   |....|....|....|....|....|....|....|....| ....|....|....|....|
 |            +----+----+----+----+----+----+----+----+ ----+----+----+----+
 |       21h  |0A50|0A51|0A52|....|....|0A9D|0A9E|0A9F| 0AA0|0AA1|....|0AA9|
 +----------  +----+----+----+----+----+----+----+----+ ----+----+----+----+
   R5_ blank  ========================================= ====================
   scanlines  ========================================= ====================

The number given inside the grid gives the offset from the display start
address R12_13_ which is displayed in that part of the grid.  Thus the
character in the upper left corner is at address R12_13_ + 00h in memory (as
seen by the CRTC).  R12_13_ + offset is what appears on the MA bus.  Each
character is R9_+1 rasterlines high by 8 pixels wide.


For each character on the screen:

                                        76543210
                                       +--------+
                                       |********| 00h
   +----+                              |********| 01h
   |0052|    ---- expands to ----->    |********| 02h 
   +----+                              |********| 03h
                                       |  ....  | ...
                                       |********| R9_
                                       +--------+

Where: The *'s represent the pixel pattern of the char at memory 0052.  For
       example:


 Char memory address        Byte            Binary          Character shape
                                                            +--------+
(c6545_char_memory[0052]).lines[0x000]    10011100        |x..xxx..|
(c6545_char_memory[0052]).lines[0x001]    10110010        |x.xx..x.|
(c6545_char_memory[0052]).lines[0x002]    10110010        |x.xx..x.|
(c6545_char_memory[0052]).lines[0x003]    01100111        |.xx..xxx|
(c6545_char_memory[0052]).lines[0x004]    00100101        |..x..x.x|
(c6545_char_memory[0052]).lines[0x005]    00100101        |..x..x.x|
(c6545_char_memory[0052]).lines[0x006]    00111101        |..xxxx.x|
(c6545_char_memory[0052]).lines[0x007]    00011001        |...xx..x|
(c6545_char_memory[0052]).lines[0x008]    00011000        |...xx...|
(c6545_char_memory[0052]).lines[0x009]    01100110        |.xx..xx.|
(c6545_char_memory[0052]).lines[0x00A]    01100110        |.xx..xx.|
(c6545_char_memory[0052]).lines[0x00B]    01000010        |.x....x.|
(c6545_char_memory[0052]).lines[0x00C]    10000001        |x......x|
(c6545_char_memory[0052]).lines[0x00D]    11100111        |xxx..xxx|
(c6545_char_memory[0052]).lines[0x00E]    10100101        |x.x..x.x|
(c6545_char_memory[0052]).lines[0x00F]    10100101        |x.x..x.x|
                                                             |        |
                                   :            :            |   :    |
                                   :            :            |   :    |
                                                             +--------+

In this diagram, x has color ((c6545_char_memory[0052]).fore_colour)[0]
while . has color ((c6545_char_memory[0052]).back_colour)[0].

If R8_adm = 1 then things are different.  The above diagram becomes:

              +----------------- Horizontal total R0 = 59h ----------------+
              |                                                            |
              +------- Horiz displayed R1 = 50h ------+                    |
              |                                       |                    |
                00   01   02  .... ....  4D   4E   4F    50   51  ....  59
             +-----------------------------------------+
 +----+----- |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  00h ||0000|0001|0002|....|....|004D|004E|004F||0050|0051|....|0059|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  01h ||0100|0101|0102|....|....|014D|014E|014F||0150|0151|....|0159|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  02h ||0200|0201|0202|....|....|024D|024E|024F||0250|0251|....|0259|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  ..  ||....|....|....|....|....|....|....|....||....|....|....|....|
 | Vertical  |+----+----+----+----+----+----+----+----+|----+----+----+----+
 | displayed ||....|....|....|....|....|....|....|....||....|....|....|....|
 | R6 = 18h  |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  ..  ||....|....|....|....|....|....|....|....||....|....|....|....|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  16h ||1600|1601|1602|....|....|164D|164E|164F||1650|1651|....|1659|
 |    |      |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |    |  17h ||1700|1701|1702|....|....|174D|174E|174F||1750|1751|....|1759|
 |    +----- |+----+----+----+----+----+----+----+----+|----+----+----+----+
 |           +-----------------------------------------+
 |       18h  |1800|1801|1802|....|....|184D|184E|184F| 1850|1851|....|1859|
Vertical      +----+----+----+----+----+----+----+----+ ----+----+----+----+
total    19h  |1900|1901|1902|....|....|194D|194E|194F| 1950|1951|....|1959|
R4 = 21h      +----+----+----+----+----+----+----+----+ ----+----+----+----+
 |       ..   |....|....|....|....|....|....|....|....| ....|....|....|....|
 |            +----+----+----+----+----+----+----+----+ ----+----+----+----+
 |       21h  |2100|2101|2102|....|....|214D|214E|214F| 2150|2151|....|2159|
 +----------  +----+----+----+----+----+----+----+----+ ----+----+----+----+
   R5_ blank  ========================================= ====================
   scanlines  ========================================= ====================

So, MA0-7 is the column address, and MA8-13 the row address.  Note that the
address on MA0-7 is offset by R13_ca, and the address on MA8-13 is offset by
R13_ra.  Equivalently (and I *think* this is what actually happens), the
MA_bus just has R12_13_ added to it, which is identical to the other mode of
operation.  The only difference between the two is how carry from MA0-7 to
MA8-13 is treated.  In the first scheme, it is prevented, whereas the second
(used here) allows carry.  This may be incorrect.


Horizontal syncing begins at character R2_ and continues until character
R2_+R3_h-1, inclusive (*may be zero width*).  Therefore, at the start of
each scanline, there will be a visible blank area of width (chars):

c6545_left_margin = R0_-(R2_+R3_h-1)
                     = R0_-R2_-R3_h+1


Likewise, vertical syncing occurs on the R7_'th character, and will go for
R3_v+1 scanlines.  Thus there will be a blank area at the top of the screen
of height (scanlines):

c6545_top_margin = R5_+((R4_-R7_+1)*(R9_+1))-R3_v






The Cursor
==========

The cursor is displayed at whatever position the MA bus gives the same
address as written to R14_15_ and DISPEN == 1 (but allow for skew).  The
MA_bus address where the cursor is shown is:

   +--------+--------------------------+------------------------+
   | R8_csk | MA_bus when cursor shown | Additional conditions  |
   +--------+--------------------------+------------------------+
   | 00xxxx | R14_15_                  | none                   |
   | 01xxxx | R14_15_-1                | HORIZ_CHAR_COUNT > 0   |
   | 10xxxx | R14_15_+1                | HORIZ_CHAR_COUNT < R0_ |
   | 11xxxx | R14_15_                  | none                   |
   +--------+--------+-----------------+------------------------+

The cursor begins at scanline R10_cs and finishes at R11_.  If
R10_cs > R11_ then the cursor rolls over, so covering all starting from
R10_cs, going to the end of the char, re-starting at the top and finishing
at R11_.  For a given character and scanline, the following conditions must
hold for the cursor signal to be activated:

1. CURSOR_ON_OFF == 1
2. DISPEN == 1
3. Conditions in above table met
4. Either:
   a. ( R11_ >= R10_cs ) and (     ( VERT_SCAN_COUNT-1 >= R10_cs )
                             ( and ( VERT_SCAN_COUNT-1 <= R11_   ) )
   b. ( R11_ <  R10_cs ) and (     ( VERT_SCAN_COUNT-1 <= R11_   )
                                or ( VERT_SCAN_COUNT-1 >= R10_cs ) )

CURSOR_ON_OFF is set as follows

   +--------+-----------------------------------------------------------+
   | R10_bb | CURSOR_ON_OFF = 1 if:                                     |
   +--------+-----------------------------------------------------------+
   |   00   | always                                                    |
   |   01   | never                                                     |
   |   10   | ( 0 <= FRAME_COUNT <= 15 ) or ( 32 <= FRAME_COUNT <= 47 ) |
   |   11   | ( 0 <= FRAME_COUNT <= 31 )                                |
   +--------+-----------------------------------------------------------+

The following internal variables are used:

HORIZ_CHAR_COUNT: horizontal position on screen (characters, start at 0).
VERT_SCAN_COUNT:  scanline of current char being drawn (pixels, start at 0).
DISPEN:           1 during visible display, 0 otherwise.
FRAME_COUNT:      Counts frames, starts at 0, rolls over at 63.




Update Strobing (source: Synertek datasheet SY6545)
===================================================

The contents of MA_bus and CR_bus (and in particular, CR4_state) are not
necessarily just screen positions.  First, note that the MSB of the CR_bus
may be used for an "update strobe" by setting R8_us = 1.  Thus:

if R8_us = 0 then CR_bus = ( VERT_SCAN_COUNT & 0x01F )
if R8_us = 1 then CR_bus = ( VERT_SCAN_COUNT & 0x00F ) + ( UP_STB * 0x010 )

From a source I have but can't recall where I found (largely corroborated
by the Synertek SY6545 datasheet, which is the best datasheet I can find,
although it is not complete):


   Shared and Transparent Addressing (Rockwell 6545 only)
   ------------------------------------------------------

   This mode is set with R8 bit 3.  Writing a 0 sets the shared adressing
   mode.  In this mode the CRTC assumes that the CPU has an independent means
   of accessing the video memory - sharing the memory.  A very common method
   is to switch the memory addresses from CRTC during Phi2/E low to CPU
   during Phi2/E high.

   More interesting is the transparent mode that is set with R8, bit 3=1.
   In this case the CPU cannot directly access the video RAM.  The CRTC has
   to generate the address for the CPU.  This is done via the write-only
   registers

   R18     Update Register high (6 bit)
   R19     Update Register low (8 bit)

   When R8 bit 7=1 then the CRTC puts the display memory address on MA0-13
   during Phi2/E low (first), and the update address from R18/R19 during
   Phi2/E high, mimicking interleaved CPU access [I would assume this to be
   quite difficult if CCLK is not connected to Phi2/E].  In this mode it can
   be assumed that the CPU hardware knows when to access the memory.  When R8
   bit 7=0, then the CRTC waits for the horizontal and vertical retrace
   times to put the update address from R18/R19 on the address lines MA0-13.
   With R8 bit 6=1 pin 34 can be programmed to give a high pulse when the
   update address is valid.  External latches might be necessary to store
   the data between initiating the access and receiving it.

   The CRTC docs do not say anything about the read/write control, so this
   has to be set up with external hardware.

   After each update access the address in the update register is
   incremented by 1.  How does the CRTC know when an update has to be done?
   Status register bit 7 gives the answer.  Reading or writing the -
   otherwise nonexisting - register R31 tells the CRTC to perform an update.


The update strobes UP_STB(_clow) and MA_bus(_clow) are both dependant on
the update mode, and in particular R8_rma, R8_smde, R18_19_, R18_ra, R19_ca
and R31_pnd.




                        Local data:
                        ===========

Raddr   - last value written to the address port (5 bits).
R0_     - horizontal total (-1) (8 bits).
R1_     - horizontal displayed (8 bits).
R2_     - horizontal sync pos (8 bits).
R3_h    - horizontal sync width (can be zero?) (4 bits).
R3_v    - vertical sync width (-1) (4 bits).
R4_     - vertical total (-1) (7 bits).
R5_     - vertical total adjust (5 bits).
R6_     - vertical displayed (7 bits).
R7_     - vertical sync pos (7 bits).
R8_     - masked version of R8 (adm,rma,csk,us and smde are left).
R8_adm  - addressing mode (1 bit). (0x004 by default)
R8_rma  - refresh memory access mode (1 bit).
R8_csk  - cursor skew mode (2 bits). (bbxxxx, where bb are skew)
R8_us   - update strobe mode (1 bit).
R8_smde - update strobe mode (1 bit).
R9_     - rasterlines per character row (-1) (5 bits).
R10_bb  - cursor mode (2 bits).
R10_cs  - cursor start rasterline (5 bits).
R11_    - cursor end rasterline (5 bits).
R12_13_ - display start address (14 bits).
R12_ra  - display start row (6 bits).
R13_ca  - display start column (8 bits).
R14_15_ - cursor address (14 bits).
R14_ra  - cursor row (6 bits).
R15_ca  - cursor column (8 bits).
R16_17_ - lightpen address (14 bits).
R16_ra  - lightpen row (6 bits).
R17_ca  - lightpen column (8 bits).
R18_19_ - update address (14 bits).
R18_ra  - update row (6 bits).
R19_ca  - update column (8 bits).

Note: - R3_v is obtained by subtracting 1 from the value written to the
        MSB of R3 (unless 0, in which case R3_ = 15).





                        Local derived data
                        ==================

UINT_16 c6545_left_margin = 8*(R0_-R2_-R3_h+1)               (pixels)
UINT_16 c6545_top_margin  = R5_+((R4_-R7_+1)*(R9_+1))-R3_v   (pixels)

UINT_16 c6545_screen_width  = 8*R1_                          (pixels)
UINT_16 c6545_screen_height = R6_*(R9_+1)                    (pixels)

UINT_16 c6545_right_margin  = 8*(R2_-R1_)                    (pixels)
UINT_16 c6545_bottom_margin = (R7_-R6_)*(R9_+1)              (pixels)





                        Local counters
                        ==============

The following counters are used, in the ranges given:

HORIZ_CHAR_COUNT: x position in characters (>= 0, <= R0_)
VERT_CHAR_COUNT:  y position in characters (>= 0, <= R4_+1)
VERT_SCAN_COUNT:  in character scanline counter (>= 0, <= R9_)
                  (if VERT_CHAR_COUNT == R4_+1, VERT_SCAN_COUNT <= R5_-1
                  this introduces some complexity if R5_ == 0)
VERT_SYNC_COUNT:  counter for vertical sync width (>= 0, <= R3_v)
FRAME_COUNT:      frame counter (>= 0, <= 63)

Scan goes left to right, top to bottom.  Hence HORIZ_CHAR_COUNT will loop
first, then VERT_SCAN_COUNT, then VERT_CHAR_COUNT and finally FRAME_COUNT.
VERT_SYNC_COUNT only starts being inced when VERT_CHAR_COUNT == R7_ (and
VERT_SCAN_COUNT == 0 to ensure that it only loops once), and keeps going
until it reaches R3_v, where it goes back to zero and stays until the next
vertical sync starts.




                        Local signals and global buses
                        ==============================

The following bus signals are 0 by default, 1 if condition met:

DISPEN:      ( HORIZ_CHAR_COUNT <  R1_      ) and
             ( VERT_CHAR_COUNT  <  R6_      )
IS_HSYNC:    ( HORIZ_CHAR_COUNT >= R2_      ) and
             ( HORIZ_CHAR_COUNT <  R2_+R3_h )
IS_VSYNC:  ( ( VERT_CHAR_COUNT  == R7_      ) and
             ( VERT_SCAN_COUNT  == 0        )     ) or
             ( VERT_SYNC_COUNT  >  0        )
IS_CURSOR: see later.

Likewise, local data is 0 by default, 1 if relevant condition met:

VBLANK:             ( VERT_CHAR_COUNT  >= R6_ )   (0x020 == 1)
HBLANK:             ( HORIZ_CHAR_COUNT >= R1_ )
LPEN_REGISTER_FULL: Goes 0x000 when either R16 or R17 is read.
                    Goes 0x040 when an LPEN strobe occurs.
UPDATE_READY:       Goes 0x000 when R31 is read or written.
                    Goes 0x080 when an update strobe occurs.





                Screen memory and character RAM organisation
                ============================================

The 6545 can address 2^14 bytes of VDU RAM.  Each memory address specifies
a character number (out of 2^16 possible character, each 8*32 pixels in
size), background colour (8 bits) and foreground colour (8 bits).




                        6545 Character storage structure
                        ================================

Defines a 8*32 pixel character.  The character is specified by the contents
of the lines array.  The top line of the character is given by lines[0],
the next by lines[1], etc.  For example:

Byte            Binary          Character shape
                                +--------+
lines[0x000]    10011100        |x  xxx  |
lines[0x001]    10110010        |x xx  x |
lines[0x002]    10110010        |x xx  x |
lines[0x003]    01100111        | xx  xxx|
lines[0x004]    00100101        |  x  x x|
lines[0x005]    00100101        |  x  x x|
lines[0x006]    00111101        |  xxxx x|
lines[0x007]    00011001        |   xx  x|
lines[0x008]    00011000        |   xx   |
lines[0x009]    01100110        | xx  xx |
lines[0x00A]    01100110        | xx  xx |
lines[0x00B]    01000010        | x    x |
lines[0x00C]    10000001        |x      x|
lines[0x00D]    11100111        |xxx  xxx|
lines[0x00E]    10100101        |x x  x x|
lines[0x00F]    10100101        |x x  x x|
                                |        |
      :            :            |   :    |
      :            :            |   :    |
                                +--------+

first_occur points to the first occurrence of the character on the current
screen.  If there are no occurences of this character onscreen then this
will be NULL.




                6545 Screen location storage structure
                ======================================

As well as information specified previously, each bit of vdu must specify
it's position in a character chain (bidirectionally linked list of chars
of the same type, so when this char is changed all occurrences can be
located and changed quickly), as well as a map of all lines that have
changed in this char since it was last drawn.  Thus if the relevant bit
is on, the scanline of the relevant char will be updated and the bit set
to zero once more.


                      Clock Division and Timing
                      =========================

For speed reasons, it may be desirable to run the 6545 CRTC emulator
through less cycles than would happen in reality.  If this is done, it may
be noted that the cursor will flash proportionally slower than normal.  This
is controlled by the data pointed to be c6545_frame_multiply, which contains
this clock division factor.  The emulator then increments the frame counter
by this, thereby speeding up the cursor rate sufficiently to exactly
compensate for the slowing that may otherwise be seen.

*/


/*
   Macro section
*/

#define DEFAULT_Raddr   0x000
#define DEFAULT_R0_     0x06B
#define DEFAULT_R1_     0x040
#define DEFAULT_R2_     0x051
#define DEFAULT_R3_h    0x007
#define DEFAULT_R3_v    0x002
#define DEFAULT_R4_     0x012
#define DEFAULT_R5_     0x009
#define DEFAULT_R6_     0x010
#define DEFAULT_R7_     0x012
#define DEFAULT_R8_     0x0c8
#define DEFAULT_R8_adm  0x000
#define DEFAULT_R8_csk  0x000
#define DEFAULT_R9_     0x00F
#define DEFAULT_R10_bb  0x001
#define DEFAULT_R10_cs  0x00F
#define DEFAULT_R11_    0x00F
#define DEFAULT_R12_13_ 0x00000
#define DEFAULT_R12_ra  0x000
#define DEFAULT_R13_ca  0x000
#define DEFAULT_R14_15_ 0x00000
#define DEFAULT_R14_ra  0x000
#define DEFAULT_R15_ca  0x000
#define DEFAULT_R16_17_ 0x00000
#define DEFAULT_R16_ra  0x000
#define DEFAULT_R17_ca  0x000
#define DEFAULT_R18_19_ 0x00000
#define DEFAULT_R18_ra  0x000
#define DEFAULT_R19_ca  0x000


#define DEFAULT_FORE_COLOUR 255
#define DEFAULT_BACK_COLOUR 0


#define RADDR(what)                             (what->reg_Raddr)
#define R0_(what)                               (what->reg_R0_)
#define R1_(what)                               (what->reg_R1_)
#define R2_(what)                               (what->reg_R2_)
#define R3_H(what)                              (what->reg_R3_h)
#define R3_V(what)                              (what->reg_R3_v)
#define R4_(what)                               (what->reg_R4_)
#define R5_(what)                               (what->reg_R5_)
#define R6_(what)                               (what->reg_R6_)
#define R7_(what)                               (what->reg_R7_)
#define R8_(what)                               (what->reg_R8_)
#define R8_ADM(what)                            (what->reg_R8_adm)
#define R8_CSK(what)                            (what->reg_R8_csk)
#define R9_(what)                               (what->reg_R9_)
#define R10_BB(what)                            (what->reg_R10_bb)
#define R10_CS(what)                            (what->reg_R10_cs)
#define R11_(what)                              (what->reg_R11_)
#define R12_13_(what)                           (what->reg_R12_13_)
#define R12_RA(what)                            (what->reg_R12_ra)
#define R13_CA(what)                            (what->reg_R13_ca)
#define R14_15_(what)                           (what->reg_R14_15_)
#define R14_RA(what)                            (what->reg_R14_ra)
#define R15_CA(what)                            (what->reg_R15_ca)
#define R16_17_(what)                           (what->reg_R16_17_)
#define R16_RA(what)                            (what->reg_R16_ra)
#define R17_CA(what)                            (what->reg_R17_ca)
#define R18_19_(what)                           (what->reg_R18_19_)
#define R18_RA(what)                            (what->reg_R18_ra)
#define R19_CA(what)                            (what->reg_R19_ca)

#define c6545_VDU_MEMORY(what)                  (what->vdu_memory)
#define c6545_CHAR_MEMORY(what)                 (what->char_memory)
#define c6545_VDU_DETAIL(what)                  (what->vdu_detail)

#define c6545_POLE_LPEN_TABLE(what)             (what->pole_lpen_table)
#define c6545_POLE_LPEN_CLOW_TABLE(what)        (what->pole_lpen_clow_table)

#define c6545_HORIZ_CHAR_COUNT(what)            (what->horiz_char_count)
#define c6545_VERT_CHAR_COUNT(what)             (what->vert_char_count)
#define c6545_VERT_SCAN_COUNT(what)             (what->vert_scan_count)
#define c6545_VERT_SYNC_COUNT(what)             (what->vert_sync_count)
#define c6545_FRAME_COUNT(what)                 (what->frame_count)

#define c6545_VBLANK(what)                      (what->vblank)
#define c6545_HBLANK(what)                      (what->hblank)
#define c6545_LPEN_REGISTER_FULL(what)          (what->lpen_register_full)
#define c6545_UPDATE_READY(what)                (what->update_ready)

#define c6545_LEFT_MARGIN(what)                 (what->left_margin)
#define c6545_SCREEN_WIDTH(what)                (what->screen_width)
#define c6545_RIGHT_MARGIN(what)                (what->right_margin)

#define c6545_TOP_MARGIN(what)                  (what->top_margin)
#define c6545_SCREEN_HEIGHT(what)               (what->screen_height)
#define c6545_BOTTOM_MARGIN(what)               (what->bottom_margin)

#define c6545_LPEN_ALIAS(what)                  (what->lpen_alias)

#define c6545_MA_BUS_CLOW(what)                 (what->MA_bus_clow)
#define c6545_MA_BUS(what)                      (what->MA_bus)
#define c6545_CR_BUS_CLOW(what)                 (what->CR_bus_clow)
#define c6545_CR_BUS(what)                      (what->CR_bus)

#define c6545_REDRAW_BUS(what)                  (what->redraw_bus)





#define c6545_TEMP_8(what)                      (what->temp_8)
#define c6545_TEMP_VDU(what)                    (what->temp_vdu)
#define c6545_I_32(what)                        (what->i_32)

#define c6545_LATCH_LPEN(what)                  (what->latch_lpen)
#define c6545_MA_BUS_NO_UPDATE(what)            (what->MA_bus_no_update)
#define c6545_UPDATE_DISPEN_COUNT(what)         (what->update_dispen_count)
#define c6545_LINE_UP_MASK(what)                (what->line_up_mask)
#define c6545_IS_CURSOR(what)                   (what->is_cursor)
#define c6545_DISPEN(what)                      (what->dispen)
#define c6545_IS_HSYNC(what)                    (what->is_hsync)
#define c6545_IS_VSYNC(what)                    (what->is_vsync)
#define c6545_IS_LPEN_CLOW(what)                (what->is_lpen_clow)
#define c6545_IS_LPEN(what)                     (what->is_lpen)
#define c6545_PREVIOUS_LPEN_CLOW(what)          (what->previous_lpen_clow)
#define c6545_PREVIOUS_LPEN(what)               (what->previous_lpen)

#define c6545_COMMS_DATA_BUS(what)              (what->comms_data_bus)
#define c6545_XPOS_BUS(what)                    (what->xpos_bus)
#define c6545_YPOS_BUS(what)                    (what->ypos_bus)
#define c6545_IS_FORE_BUS(what)                 (what->is_fore_bus)
#define c6545_FORE_COLOUR_BUS(what)             (what->fore_colour_bus)
#define c6545_BACK_COLOUR_BUS(what)             (what->back_colour_bus)
#define c6545_INV__COLOUR_BUS(what)             (what->inv__colour_bus)

#define c6545_LPEN_CALL_MASK_BUS(what)          (what->lpen_call_mask_bus)

#define c6545_GEOMETRY_BUS(what)                (what->geometry_bus)
#define c6545_VIDEO_MEM_ADDR_BUS(what)          (what->video_mem_addr_bus)
#define c6545_VIDEO_DATA_BUS(what)              (what->video_data_bus)
#define c6545_VIDEO_CHAR_LINE_BUS(what)         (what->video_char_line_bus)

#define c6545_CHANGE_LEFT_MARGIN(what)          (what->change_left_margin)
#define c6545_CHANGE_SCREEN_WIDTH(what)         (what->change_screen_width)
#define c6545_CHANGE_RIGHT_MARGIN(what)         (what->change_right_margin)
#define c6545_CHANGE_TOP_MARGIN(what)           (what->change_top_margin)
#define c6545_CHANGE_SCREEN_HEIGHT(what)        (what->change_screen_height)
#define c6545_CHANGE_BOTTOM_MARGIN(what)        (what->change_bottom_margin)
#define c6545_PIXEL_DRAWER(what)                (what->pixel_drawer)











#define c6545_LPEN_FEEDBACK_ADDR(what)          (what->lpen_feedback_addr)
#define c6545_LPEN_FEEDBACK_ADDR_TYPE(what)     (what->lpen_feedback_addr_type)
#define c6545_LPEN_FEEDBACK_ADDR_TYPE_CLW(what) (what->lpen_feedback_addr_type_clow)
#define c6545_LPEN_FEEDBACK_TABLE_SEL(what)     (what->lpen_feedback_table_sel)
#define c6545_LPEN_FEEDBACK_TABLE(what)         (what->lpen_feedback_table)
#define c6545_LPEN_FEEDBACK_CLOW_TABLE(what)    (what->lpen_feedback_clow_table)
#define c6545_LPEN_FEEDRFSH_TABLE(what)         (what->lpen_feedrfsh_table)
#define c6545_LPEN_FEEDRFSH_CLOW_TABLE(what)    (what->lpen_feedrfsh_clow_table)

#define c6545_LPEN_RESET_COUNTER_BUS(what)      (what->lpen_reset_counter_bus)
#define c6545_UPDATE_RESET_COUNTER_BUS(what)    (what->update_reset_counter_bus)


#define SET_C6545_SCREEN_WIDTH(what)    c6545_SCREEN_WIDTH(what)    = 8*((UINT_16) R1_(what));
#define SET_C6545_SCREEN_HEIGHT(what)   c6545_SCREEN_HEIGHT(what)   = ((UINT_16) (R6_(what)))*((((UINT_16) R9_(what))+1));

#define SET_C6545_LEFT_MARGIN(what)     c6545_LEFT_MARGIN(what)     = 8*((((UINT_16) R0_(what))-((UINT_16) R2_(what))-((UINT_16) R3_H(what))+1));
#define SET_C6545_TOP_MARGIN(what)      c6545_TOP_MARGIN(what)      = (((UINT_16) (R5_(what)))+(((UINT_16) (((UINT_16) R4_(what))-((UINT_16) R7_(what))+1))*((UINT_16) (((UINT_16) R9_(what))+1)))-((UINT_16) R3_V(what)));

#define SET_C6545_RIGHT_MARGIN(what)    c6545_RIGHT_MARGIN(what)    = 8*((UINT_16) (R2_(what)-R1_(what)));
#define SET_C6545_BOTTOM_MARGIN(what)   c6545_BOTTOM_MARGIN(what)   = ( ((UINT_16) (R7_(what)-R6_(what))) * ((UINT_16) (((UINT_16) R9_(what))+1)) );


#define FIX_VDU_DIM(what)                                               \
{                                                                       \
    (c6545_VDU_DETAIL(what)).dim_horiz = R1_(what);                     \
    (c6545_VDU_DETAIL(what)).dim_vert  = R6_(what);                     \
}

#define FIX_VDU_SIZE(what)                                              \
{                                                                       \
    (c6545_VDU_DETAIL(what)).screen_width  = c6545_LEFT_MARGIN(what) + c6545_SCREEN_WIDTH(what)  + c6545_RIGHT_MARGIN(what);  \
    (c6545_VDU_DETAIL(what)).screen_height = c6545_TOP_MARGIN(what)  + c6545_SCREEN_HEIGHT(what) + c6545_BOTTOM_MARGIN(what); \
}

#define FIX_VDU_MARGIN(what)                                            \
{                                                                       \
    (c6545_VDU_DETAIL(what)).margin_left = c6545_LEFT_MARGIN(what);     \
    (c6545_VDU_DETAIL(what)).margin_top  = c6545_TOP_MARGIN(what);      \
}

#define FIX_VDU_CHAR(what)                                              \
{                                                                       \
    (c6545_VDU_DETAIL(what)).char_height = R9_(what);                   \
    (c6545_VDU_DETAIL(what)).char_loopb  = R8_(what) & 0x040;           \
}

#define FIX_VDU_CURSOR(what)                                            \
{                                                                       \
    (c6545_VDU_DETAIL(what)).cursor_mode = R10_BB(what);                \
                                                                        \
    if ( (DEBDEREF(c6545_VDU_MEMORY(what),R14_15_(what))).char_pointer == NULL ) \
    {                                                                   \
        (c6545_VDU_DETAIL(what)).cursor_offscn = 1;                     \
    }                                                                   \
                                                                        \
    else                                                                \
    {                                                                   \
        (c6545_VDU_DETAIL(what)).cursor_offscn = 0;                     \
    }                                                                   \
                                                                        \
    (c6545_VDU_DETAIL(what)).cursor_startline = R10_CS(what);           \
    (c6545_VDU_DETAIL(what)).cursor_endline   = R11_(what);             \
                                                                        \
    (c6545_VDU_DETAIL(what)).cursor_x_pos = (DEBDEREF(c6545_VDU_MEMORY(what),R14_15_(what))).char_x_coord; \
    (c6545_VDU_DETAIL(what)).cursor_y_pos = (DEBDEREF(c6545_VDU_MEMORY(what),R14_15_(what))).char_y_coord; \
}






void c6545_fix_coordspoint(c6545_state *what);





























/*
Function: c6545_init(...)
Operation: Initialises local data and sets non-local function pointers.
*/

c6545_state *c6545_init(UINT_16  _c6545_lpen_alias,
                        UINT_8  *_c6545_comms_data_bus,
                        UINT_32 *_c6545_lpen_call_mask_bus,
                        UINT_16 *_c6545_geometry_bus,
                        UINT_16 *_c6545_video_mem_addr_bus,
                        UINT_16 *_c6545_video_data_bus,
                        UINT_8  *_c6545_video_char_line_bus,
                        UINT_16 *_c6545_xpos_bus,
                        UINT_16 *_c6545_ypos_bus,
                        UINT_8  *_c6545_is_fore_bus,
                        UINT_8  *_c6545_fore_colour_bus,
                        UINT_8  *_c6545_back_colour_bus,
                        UINT_8  *_c6545_inv__colour_bus,
                        UINT_32 *_c6545_lpen_reset_counter_bus,
                        UINT_32 *_c6545_update_reset_counter_bus,
                        UINT_8  **_c6545_pole_lpen_table,
                        UINT_8  **_c6545_pole_lpen_clow_table,
                        UINT_8  **_c6545_lpen_feedback_table,
                        UINT_8  **_c6545_lpen_feedback_clow_table,
                        UINT_8  **_c6545_lpen_feedrfsh_table,
                        UINT_8  **_c6545_lpen_feedrfsh_clow_table,
                        weird_pointer_jive _c6545_change_left_margin,
                        weird_pointer_jive _c6545_change_screen_width,
                        weird_pointer_jive _c6545_change_right_margin,
                        weird_pointer_jive _c6545_change_top_margin,
                        weird_pointer_jive _c6545_change_screen_height,
                        weird_pointer_jive _c6545_change_bottom_margin,
                        weird_pointer_jive _c6545_pixel_drawer)
{
    UINT_32 i,j;

    c6545_state *what;

    if ( ( what = (c6545_state *) malloc(sizeof(c6545_state)) ) != NULL )
    {
        #ifdef DEBUGMODE
        fprintf(stderr,"aligning buses\n");
        #endif

        c6545_LPEN_ALIAS(what) = _c6545_lpen_alias;

        c6545_COMMS_DATA_BUS(what)     = _c6545_comms_data_bus;
        c6545_LPEN_CALL_MASK_BUS(what) = _c6545_lpen_call_mask_bus;

        c6545_GEOMETRY_BUS(what)        = _c6545_geometry_bus;
        c6545_VIDEO_MEM_ADDR_BUS(what)  = _c6545_video_mem_addr_bus;
        c6545_VIDEO_DATA_BUS(what)      = _c6545_video_data_bus;
        c6545_VIDEO_CHAR_LINE_BUS(what) = _c6545_video_char_line_bus;
        c6545_XPOS_BUS(what)            = _c6545_xpos_bus;
        c6545_YPOS_BUS(what)            = _c6545_ypos_bus;
        c6545_IS_FORE_BUS(what)         = _c6545_is_fore_bus;
        c6545_FORE_COLOUR_BUS(what)     = _c6545_fore_colour_bus;
        c6545_BACK_COLOUR_BUS(what)     = _c6545_back_colour_bus;
        c6545_INV__COLOUR_BUS(what)     = _c6545_inv__colour_bus;

        c6545_LPEN_RESET_COUNTER_BUS(what)   = _c6545_lpen_reset_counter_bus;
        c6545_UPDATE_RESET_COUNTER_BUS(what) = _c6545_update_reset_counter_bus;

        c6545_POLE_LPEN_TABLE(what)          = _c6545_pole_lpen_table;
        c6545_POLE_LPEN_CLOW_TABLE(what)     = _c6545_pole_lpen_clow_table;
        c6545_LPEN_FEEDBACK_TABLE(what)      = _c6545_lpen_feedback_table;
        c6545_LPEN_FEEDBACK_CLOW_TABLE(what) = _c6545_lpen_feedback_clow_table;
        c6545_LPEN_FEEDRFSH_TABLE(what)      = _c6545_lpen_feedrfsh_table;
        c6545_LPEN_FEEDRFSH_CLOW_TABLE(what) = _c6545_lpen_feedrfsh_clow_table;

        c6545_CHANGE_LEFT_MARGIN(what)    = _c6545_change_left_margin;
        c6545_CHANGE_SCREEN_WIDTH(what)   = _c6545_change_screen_width;
        c6545_CHANGE_RIGHT_MARGIN(what)   = _c6545_change_right_margin;
        c6545_CHANGE_TOP_MARGIN(what)     = _c6545_change_top_margin;
        c6545_CHANGE_SCREEN_HEIGHT(what)  = _c6545_change_screen_height;
        c6545_CHANGE_BOTTOM_MARGIN(what)  = _c6545_change_bottom_margin;
        c6545_PIXEL_DRAWER(what)          = _c6545_pixel_drawer;

        /*
           Allocate video memory maps and clear.
        */

        #ifdef DEBUGMODE
        fprintf(stderr,"allocate vdu_detail\n");
        #endif

        if ( ( (c6545_VDU_DETAIL(what)).pcg_map = (UINT_8 **) malloc(C6545_CHAR_MEM_SIZE*sizeof(UINT_8 *)) ) == NULL )
        {
            return NULL;
        }

        for ( i = 0 ; i < C6545_CHAR_MEM_SIZE ; i++ )
        {
            if ( ( ((c6545_VDU_DETAIL(what)).pcg_map)[i] = (UINT_8 *) malloc(C6545_MAX_CHR_HEIGHT*sizeof(UINT_8)) ) == NULL )
            {
                return NULL;
            }

            for ( j = 1 ; j < C6545_MAX_CHR_HEIGHT ; j++ )
            {
                ((c6545_VDU_DETAIL(what)).pcg_map)[i][j] = 0;
            }
        }

        if ( ( (c6545_VDU_DETAIL(what)).scn_map = (UINT_8 **) malloc(C6545_MAX_SCN_WIDTH*sizeof(UINT_8 *)) ) == NULL )
        {
            return NULL;
        }

        for ( i = 0 ; i < C6545_MAX_SCN_WIDTH ; i++ )
        {
            if ( ( ((c6545_VDU_DETAIL(what)).scn_map)[i] = (UINT_8 *) malloc(C6545_MAX_SCN_HEIGHT*sizeof(UINT_8)) ) == NULL )
            {
                return NULL;
            }

            for ( j = 1 ; j < C6545_MAX_SCN_HEIGHT ; j++ )
            {
                ((c6545_VDU_DETAIL(what)).scn_map)[i][j] = 0;
            }
        }

        if ( ( (c6545_VDU_DETAIL(what)).col_map = (UINT_8 ***) malloc(C6545_MAX_SCN_WIDTH*sizeof(UINT_8 **)) ) == NULL )
        {
            return NULL;
        }

        for ( i = 0 ; i < C6545_MAX_SCN_WIDTH ; i++ )
        {
            if ( ( ((c6545_VDU_DETAIL(what)).col_map)[i] = (UINT_8 **) malloc(C6545_MAX_SCN_HEIGHT*sizeof(UINT_8 *)) ) == NULL )
            {
                return NULL;
            }

            for ( j = 0 ; j < C6545_MAX_SCN_HEIGHT ; j++ )
            {
                if ( ( ((c6545_VDU_DETAIL(what)).col_map)[i][j] = (UINT_8 *) malloc(2*sizeof(UINT_8)) ) == NULL )
                {
                    return NULL;
                }

                ((c6545_VDU_DETAIL(what)).col_map)[i][j][0] = 0;
                ((c6545_VDU_DETAIL(what)).col_map)[i][j][1] = 0;
            }
        }

        #ifdef DEBUGMODE
        fprintf(stderr,"allocate video memory\n");
        #endif

        if ( ( c6545_VDU_MEMORY(what) = (C6545_vdu_point *) DEBMALLOC(C6545_VDU_MEM_SIZE*sizeof(C6545_vdu_point)) ) == NULL )
        {
            return NULL;
        }

        if ( ( c6545_CHAR_MEMORY(what) = (C6545_char *) DEBMALLOC(C6545_CHAR_MEM_SIZE*sizeof(C6545_char)) ) == NULL )
        {
            return NULL;
        }

        for ( i = 0 ; i < C6545_CHAR_MEM_SIZE ; i++ )
        {
            for ( j = 0 ; j < C6545_MAX_CHR_HEIGHT ; j++ )
            {
                ((DEBDEREF(c6545_CHAR_MEMORY(what),i)).lines)[j] = 0x000;
            }

            (DEBDEREF(c6545_CHAR_MEMORY(what),i)).first_occur = NULL;
        }

        (DEBDEREF(c6545_CHAR_MEMORY(what),C6545_DEFAULT_CHAR)).first_occur = c6545_VDU_MEMORY(what);

        for ( i = 0 ; i < C6545_VDU_MEM_SIZE ; i++ )
        {
            (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_num = C6545_DEFAULT_CHAR;

            ((DEBDEREF(c6545_VDU_MEMORY(what),i)).fore_colour)[0] = DEFAULT_FORE_COLOUR;
            ((DEBDEREF(c6545_VDU_MEMORY(what),i)).back_colour)[0] = DEFAULT_BACK_COLOUR;

            ((DEBDEREF(c6545_VDU_MEMORY(what),i)).fore_colour)[1] = DEFAULT_BACK_COLOUR;
            ((DEBDEREF(c6545_VDU_MEMORY(what),i)).back_colour)[1] = DEFAULT_FORE_COLOUR;

            (DEBDEREF(c6545_VDU_MEMORY(what),i)).line_change_mask = 0x0FFFFFFFF;

            switch ( i )
            {
                case 0:
                {
                    (DEBDEREF(c6545_VDU_MEMORY(what),i)).prev_same_char = NULL;
                    (DEBDEREF(c6545_VDU_MEMORY(what),i)).next_same_char = &(DEBDEREF(c6545_VDU_MEMORY(what),i+1));

                    break;
                }

                case C6545_VDU_MEM_SIZE-1:
                {
                    (DEBDEREF(c6545_VDU_MEMORY(what),i)).prev_same_char = &(DEBDEREF(c6545_VDU_MEMORY(what),i-1));
                    (DEBDEREF(c6545_VDU_MEMORY(what),i)).next_same_char = NULL;

                    break;
                }

                default:
                {
                    (DEBDEREF(c6545_VDU_MEMORY(what),i)).prev_same_char = &(DEBDEREF(c6545_VDU_MEMORY(what),i-1));
                    (DEBDEREF(c6545_VDU_MEMORY(what),i)).next_same_char = &(DEBDEREF(c6545_VDU_MEMORY(what),i+1));

                    break;
                }
            }

            (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_x_coord = 0;
            (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_y_coord = 0;

            (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_pointer = 0;
            (DEBDEREF(c6545_VDU_MEMORY(what),i)).fore_pointer = 0;
            (DEBDEREF(c6545_VDU_MEMORY(what),i)).back_pointer = 0;
        }

        #ifdef DEBUGMODE
        fprintf(stderr,"reset 6545 state\n");
        #endif

        c6545_reset(what);

        #ifdef DEBUGMODE
        fprintf(stderr,"initialise values\n");
        #endif

        c6545_LATCH_LPEN(what)          = 0;
        c6545_MA_BUS_NO_UPDATE(what)    = 0;
        c6545_UPDATE_DISPEN_COUNT(what) = 0;
        c6545_LINE_UP_MASK(what)        = 0;
        c6545_IS_CURSOR(what)           = 0;
        c6545_DISPEN(what)              = 0;
        c6545_IS_HSYNC(what)            = 0;
        c6545_IS_VSYNC(what)            = 0;
        c6545_IS_LPEN_CLOW(what)        = 0;
        c6545_IS_LPEN(what)             = 0;
        c6545_PREVIOUS_LPEN(what)       = 0;
        c6545_PREVIOUS_LPEN_CLOW(what)  = 0;
    }

    return what;
}




/*
Function: c6545_reset()
Operation: Reset the internal state of the 6545 to power on defaults.
*/

void c6545_reset(c6545_state *what)
{
    #ifdef DEBUGMODE
    fprintf(stderr,"reset start\n");
    #endif

    RADDR(what)       = DEFAULT_Raddr;
    R0_(what)         = DEFAULT_R0_;
    R1_(what)         = DEFAULT_R1_;
    R2_(what)         = DEFAULT_R2_;
    R3_H(what)        = DEFAULT_R3_h;
    R3_V(what)        = DEFAULT_R3_v;
    R4_(what)         = DEFAULT_R4_;
    R5_(what)         = DEFAULT_R5_;
    R6_(what)         = DEFAULT_R6_;
    R7_(what)         = DEFAULT_R7_;
    R8_(what)         = DEFAULT_R8_;
    R8_ADM(what)      = DEFAULT_R8_adm;
    R8_CSK(what)      = DEFAULT_R8_csk;
    R9_(what)         = DEFAULT_R9_;
    R10_BB(what)      = DEFAULT_R10_bb;
    R10_CS(what)      = DEFAULT_R10_cs;
    R11_(what)        = DEFAULT_R11_;
    R12_13_(what)     = DEFAULT_R12_13_;
    R12_RA(what)      = DEFAULT_R12_ra;
    R13_CA(what)      = DEFAULT_R13_ca;
    R14_15_(what)     = DEFAULT_R14_15_;
    R14_RA(what)      = DEFAULT_R14_ra;
    R15_CA(what)      = DEFAULT_R15_ca;
    R16_17_(what)     = DEFAULT_R16_17_;
    R16_RA(what)      = DEFAULT_R16_ra;
    R17_CA(what)      = DEFAULT_R17_ca;
    R18_19_(what)     = DEFAULT_R18_19_;
    R18_RA(what)      = DEFAULT_R18_ra;
    R19_CA(what)      = DEFAULT_R19_ca;

    c6545_HORIZ_CHAR_COUNT(what) = 0;
    c6545_VERT_CHAR_COUNT(what)  = 0;
    c6545_VERT_SCAN_COUNT(what)  = 0;
    c6545_VERT_SYNC_COUNT(what)  = 0;
    c6545_FRAME_COUNT(what)      = 0;

    c6545_VBLANK(what)             = 0;
    c6545_HBLANK(what)             = 0;
    c6545_LPEN_REGISTER_FULL(what) = 0;
    c6545_UPDATE_READY(what)       = 0x080;

    #ifdef DEBUGMODE
    fprintf(stderr,"set margins\n");
    #endif

    SET_C6545_LEFT_MARGIN(what);
    SET_C6545_SCREEN_WIDTH(what);
    SET_C6545_RIGHT_MARGIN(what);

    SET_C6545_TOP_MARGIN(what);
    SET_C6545_SCREEN_HEIGHT(what);
    SET_C6545_BOTTOM_MARGIN(what);

    #ifdef DEBUGMODE
    fprintf(stderr,"call externals to set margins there\n");
    #endif

    *c6545_GEOMETRY_BUS(what) = c6545_LEFT_MARGIN(what);  c6545_CHANGE_LEFT_MARGIN(what)();
    *c6545_GEOMETRY_BUS(what) = c6545_SCREEN_WIDTH(what); c6545_CHANGE_SCREEN_WIDTH(what)();
    *c6545_GEOMETRY_BUS(what) = c6545_RIGHT_MARGIN(what); c6545_CHANGE_RIGHT_MARGIN(what)();

    *c6545_GEOMETRY_BUS(what) = c6545_TOP_MARGIN(what);    c6545_CHANGE_TOP_MARGIN(what)();
    *c6545_GEOMETRY_BUS(what) = c6545_SCREEN_HEIGHT(what); c6545_CHANGE_SCREEN_HEIGHT(what)();
    *c6545_GEOMETRY_BUS(what) = c6545_BOTTOM_MARGIN(what); c6545_CHANGE_BOTTOM_MARGIN(what)();

    #ifdef DEBUGMODE
    fprintf(stderr,"reset extended pointers\n");
    #endif

    c6545_LPEN_FEEDBACK_ADDR(what)      = 0;
    c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDBACK_TABLE(what);

    #ifdef DEBUGMODE
    fprintf(stderr,"set to redraw\n");
    #endif

    c6545_REDRAW_BUS(what) |= 0x02;

    #ifdef DEBUGMODE
    fprintf(stderr,"fix details\n");
    #endif

    FIX_VDU_DIM(what);
    FIX_VDU_SIZE(what);
    FIX_VDU_MARGIN(what);
    FIX_VDU_CHAR(what);
    FIX_VDU_CURSOR(what);

    #ifdef DEBUGMODE
    fprintf(stderr,"start map\n");
    #endif

    c6545_fix_coordspoint(what);

    #ifdef DEBUGMODE
    fprintf(stderr,"fix cursor\n");
    #endif

    FIX_VDU_CURSOR(what)

    return;
}


/*
Function: c6545_reset()
Operation: Reset the internal state of the 6545 to power on defaults.
*/

void c6545_refresh(c6545_state *what)
{
    c6545_REDRAW_BUS(what) |= 0x02;

    return;
}




/*
Function: c6545_remove()
Operation: Remove 6545 emulator.
*/

void c6545_remove(c6545_state *what)
{
    UINT_32 i,j;

    for ( i = 0 ; i < C6545_CHAR_MEM_SIZE ; i++ )
    {
        if ( ((c6545_VDU_DETAIL(what)).pcg_map)[i] != NULL )
        {
            free(((c6545_VDU_DETAIL(what)).pcg_map)[i]);
        }
    }

    if ( (c6545_VDU_DETAIL(what)).pcg_map != NULL )
    {
        free((c6545_VDU_DETAIL(what)).pcg_map);
    }

    for ( i = 0 ; i < C6545_MAX_SCN_WIDTH ; i++ )
    {
        if ( ((c6545_VDU_DETAIL(what)).scn_map)[i] != NULL )
        {
            free(((c6545_VDU_DETAIL(what)).scn_map)[i]);
        }
    }

    if ( (c6545_VDU_DETAIL(what)).scn_map != NULL )
    {
        free((c6545_VDU_DETAIL(what)).scn_map);
    }

    for ( i = 0 ; i < C6545_MAX_SCN_WIDTH ; i++ )
    {
        for ( j = 0 ; j < 2 ; j++ )
        {
            if ( ((c6545_VDU_DETAIL(what)).col_map)[i][j] != NULL )
            {
                free(((c6545_VDU_DETAIL(what)).col_map)[i][j]);
            }
        }

        if ( ((c6545_VDU_DETAIL(what)).col_map)[i] != NULL )
        {
            free(((c6545_VDU_DETAIL(what)).col_map)[i]);
        }
    }

    if ( (c6545_VDU_DETAIL(what)).col_map != NULL )
    {
        free((c6545_VDU_DETAIL(what)).col_map);
    }

    if ( c6545_VDU_MEMORY(what) != NULL )
    {
        DEBFREE(c6545_VDU_MEMORY(what));
    }

    if ( c6545_CHAR_MEMORY(what) != NULL )
    {
        DEBFREE(c6545_CHAR_MEMORY(what));
    }

    if ( what != NULL )
    {
        DEBFREE(what);
    }

    return;
}




/*
Function: c6545_addr_wr(void)
Operation: Write to the 6545 address register.
*/

void c6545_addr_wr(c6545_state *what)
{
    RADDR(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x01F;

    return;
}




/*
Function: void c6545_addr_rd(void)
Operation: Read from the 6545 address register.
*/

void c6545_addr_rd(c6545_state *what)
{
    (*c6545_COMMS_DATA_BUS(what)) = c6545_VBLANK(what) | c6545_LPEN_REGISTER_FULL(what) | c6545_UPDATE_READY(what);

    return;
}





/*
Function: c6545_data_wr(void)
Operation: Write to the 6545 data register.
*/

void c6545_data_wr(c6545_state *what)
{
    switch ( RADDR(what) )
    {
        case 0x000:
        {
            if ( R0_(what) != (*c6545_COMMS_DATA_BUS(what)) )
            {
                R0_(what) = (*c6545_COMMS_DATA_BUS(what));

                SET_C6545_LEFT_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_LEFT_MARGIN(what);
                c6545_CHANGE_LEFT_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
            }

            break;
        }

        case 0x001:
        {
            if ( R1_(what) != (*c6545_COMMS_DATA_BUS(what)) )
            {
                R1_(what) = (*c6545_COMMS_DATA_BUS(what));

                SET_C6545_SCREEN_WIDTH(what);
                *c6545_GEOMETRY_BUS(what) = c6545_SCREEN_WIDTH(what);
                c6545_CHANGE_SCREEN_WIDTH(what)();

                SET_C6545_RIGHT_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_RIGHT_MARGIN(what);
                c6545_CHANGE_RIGHT_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_DIM(what);
                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
                FIX_VDU_CURSOR(what);

                c6545_fix_coordspoint(what);

                FIX_VDU_CURSOR(what);
            }

            break;
        }

        case 0x002:
        {
            if ( R2_(what) != (*c6545_COMMS_DATA_BUS(what)) )
            {
                R2_(what) = (*c6545_COMMS_DATA_BUS(what));

                SET_C6545_LEFT_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_LEFT_MARGIN(what);
                c6545_CHANGE_LEFT_MARGIN(what)();

                SET_C6545_RIGHT_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_RIGHT_MARGIN(what);
                c6545_CHANGE_RIGHT_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_MARGIN(what);
            }

            break;
        }

        case 0x003:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x00F;

            if ( R3_H(what) != c6545_TEMP_8(what) )
            {
                R3_H(what) = c6545_TEMP_8(what);

                SET_C6545_TOP_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_TOP_MARGIN(what);
                c6545_CHANGE_TOP_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
            }

            c6545_TEMP_8(what) = ( (*c6545_COMMS_DATA_BUS(what)) >> 4 ) & 0x00F;

            if ( c6545_TEMP_8(what) > 0 ) { c6545_TEMP_8(what)--;       }
            else                          { c6545_TEMP_8(what) = 0x00F; }

            if ( R3_V(what) != c6545_TEMP_8(what) )
            {
                R3_V(what) = c6545_TEMP_8(what);

                SET_C6545_LEFT_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_LEFT_MARGIN(what);
                c6545_CHANGE_LEFT_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
            }

            break;
        }

        case 0x004:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x07F;

            if ( R4_(what) != c6545_TEMP_8(what) )
            {
                R4_(what) = c6545_TEMP_8(what);

                SET_C6545_TOP_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_TOP_MARGIN(what);
                c6545_CHANGE_TOP_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
            }

            break;
        }

        case 0x005:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x01F;

            if ( R5_(what) != c6545_TEMP_8(what) )
            {
                R5_(what) = c6545_TEMP_8(what);

                SET_C6545_TOP_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_TOP_MARGIN(what);
                c6545_CHANGE_TOP_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
            }

            break;
        }

        case 0x006:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x07F;

            if ( R6_(what) != c6545_TEMP_8(what) )
            {
                R6_(what) = c6545_TEMP_8(what);

                SET_C6545_SCREEN_HEIGHT(what);
                *c6545_GEOMETRY_BUS(what) = c6545_SCREEN_HEIGHT(what);
                c6545_CHANGE_SCREEN_HEIGHT(what)();

                SET_C6545_BOTTOM_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_BOTTOM_MARGIN(what);
                c6545_CHANGE_BOTTOM_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_DIM(what);
                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
                FIX_VDU_CURSOR(what);

                c6545_fix_coordspoint(what);

                FIX_VDU_CURSOR(what);
            }

            break;
        }

        case 0x007:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x07F;

            if ( R7_(what) != c6545_TEMP_8(what) )
            {
                R7_(what) = c6545_TEMP_8(what);

                SET_C6545_TOP_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_TOP_MARGIN(what);
                c6545_CHANGE_TOP_MARGIN(what)();

                SET_C6545_BOTTOM_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_BOTTOM_MARGIN(what);
                c6545_CHANGE_BOTTOM_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_MARGIN(what);
            }

            break;
        }

        case 0x008:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x004;

            if ( R8_ADM(what) != c6545_TEMP_8(what) )
            {
                R8_ADM(what) = c6545_TEMP_8(what);

                c6545_REDRAW_BUS(what) |= 0x02;
            }

            R8_CSK(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x030;
            R8_(what)    = (*c6545_COMMS_DATA_BUS(what)) & 0x0FC;

            FIX_VDU_DIM(what);
            FIX_VDU_SIZE(what);
            FIX_VDU_MARGIN(what);
            FIX_VDU_CHAR(what);
            FIX_VDU_CURSOR(what);

            c6545_fix_coordspoint(what);

            FIX_VDU_CURSOR(what);

            break;
        }

        case 0x009:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x01F;

            if ( R9_(what) != c6545_TEMP_8(what) )
            {
                R9_(what) = c6545_TEMP_8(what);

                SET_C6545_TOP_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_TOP_MARGIN(what);
                c6545_CHANGE_TOP_MARGIN(what)();

                SET_C6545_SCREEN_HEIGHT(what);
                *c6545_GEOMETRY_BUS(what) = c6545_SCREEN_HEIGHT(what);
                c6545_CHANGE_SCREEN_HEIGHT(what)();

                SET_C6545_BOTTOM_MARGIN(what);
                *c6545_GEOMETRY_BUS(what) = c6545_BOTTOM_MARGIN(what);
                c6545_CHANGE_BOTTOM_MARGIN(what)();

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_SIZE(what);
                FIX_VDU_MARGIN(what);
                FIX_VDU_CHAR(what);
                FIX_VDU_CURSOR(what);
            }

            break;
        }

        case 0x00A:
        {
            R10_CS(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x01F;
            R10_BB(what) = ( (*c6545_COMMS_DATA_BUS(what)) >> 5 ) & 0x003;

            FIX_VDU_CURSOR(what);

            break;
        }

        case 0x00B:
        {
            R11_(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x01F;

            FIX_VDU_CURSOR(what);

            break;
        }

        case 0x00C:
        {
            c6545_TEMP_8(what) = (*c6545_COMMS_DATA_BUS(what)) & 0x03F;

            if ( R12_RA(what) != c6545_TEMP_8(what) )
            {
                R12_RA(what)  = c6545_TEMP_8(what);
                R12_13_(what) = ( R12_RA(what) << 8 ) | R13_CA(what);

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_CURSOR(what);

                c6545_fix_coordspoint(what);

                FIX_VDU_CURSOR(what);
            }

            break;
        }

        case 0x00D:
        {
            if ( R13_CA(what) != (*c6545_COMMS_DATA_BUS(what)) )
            {
                R13_CA(what)  = (*c6545_COMMS_DATA_BUS(what));
                R12_13_(what) = ( R12_RA(what) << 8 ) | R13_CA(what);

                c6545_REDRAW_BUS(what) |= 0x02;

                FIX_VDU_CURSOR(what);

                c6545_fix_coordspoint(what);

                FIX_VDU_CURSOR(what);
            }

            break;
        }

        case 0x00E:
        {
            R14_RA(what)  = (*c6545_COMMS_DATA_BUS(what)) & 0x03F;
            R14_15_(what) = ( R14_RA(what) << 8 ) | R15_CA(what);

            FIX_VDU_CURSOR(what);

            break;
        }

        case 0x00F:
        {
            R15_CA(what)  = (*c6545_COMMS_DATA_BUS(what));
            R14_15_(what) = ( R14_RA(what) << 8 ) | R15_CA(what);

            FIX_VDU_CURSOR(what);

            break;
        }

        case 0x012:
        {
            R18_RA(what)  = (*c6545_COMMS_DATA_BUS(what)) & 0x03F;
            R18_19_(what) = ( R18_RA(what) << 8 ) | R19_CA(what);

            break;
        }

        case 0x013:
        {
            R19_CA(what)  = (*c6545_COMMS_DATA_BUS(what));
            R18_19_(what) = ( R18_RA(what) << 8 ) | R19_CA(what);

            break;
        }

        case 0x01F:
        {
            c6545_UPDATE_READY(what) = 0;

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}





/*
Function: void c6545_data_rd(void)
Operation: Read from the 6545 data register.
*/

void c6545_data_rd(c6545_state *what)
{
    (*c6545_COMMS_DATA_BUS(what)) = 0;

    switch ( RADDR(what) )
    {
        case 0x00E:
        {
            (*c6545_COMMS_DATA_BUS(what)) = R14_RA(what);

            break;
        }

        case 0x00F:
        {
            (*c6545_COMMS_DATA_BUS(what)) = R15_CA(what);

            break;
        }

        case 0x010:
        {
            c6545_LPEN_REGISTER_FULL(what) = 0;

            (*c6545_COMMS_DATA_BUS(what)) = R16_RA(what);

            (*(c6545_LPEN_RESET_COUNTER_BUS(what)))++;

            break;
        }

        case 0x011:
        {
            c6545_LPEN_REGISTER_FULL(what) = 0;

            (*c6545_COMMS_DATA_BUS(what)) = R17_CA(what);

            (*(c6545_LPEN_RESET_COUNTER_BUS(what)))++;

            break;
        }

        case 0x01F:
        {
            c6545_UPDATE_READY(what) = 0;

            (*(c6545_UPDATE_RESET_COUNTER_BUS(what)))++;

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}






/*
Function: void c6545_write_char_mem(void)
Operation: Write to character memory
*/

void c6545_write_char_mem(c6545_state *what)
{
    /*
       Do nothing unless something has changed.
    */

    if ( *c6545_VIDEO_DATA_BUS(what) != ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).lines)[*c6545_VIDEO_CHAR_LINE_BUS(what)] )
    {
        (*c6545_XPOS_BUS(what)) = *c6545_VIDEO_MEM_ADDR_BUS(what);
        (*c6545_YPOS_BUS(what)) = *c6545_VIDEO_CHAR_LINE_BUS(what);
        ((c6545_VDU_DETAIL(what)).pcg_map)[*c6545_XPOS_BUS(what)][*c6545_YPOS_BUS(what)] = *c6545_VIDEO_DATA_BUS(what);


        ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).lines)[*c6545_VIDEO_CHAR_LINE_BUS(what)] = *c6545_VIDEO_DATA_BUS(what);

        c6545_I_32(what)   = 1;
        c6545_I_32(what) <<= *c6545_VIDEO_CHAR_LINE_BUS(what);

        c6545_TEMP_VDU(what) = (DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).first_occur;

        /*
           Go through list of screen positions where this character can
           be found and set the line mask bit of each appropriately.
        */

        while ( c6545_TEMP_VDU(what) != NULL )
        {
            (c6545_TEMP_VDU(what)->line_change_mask) |= c6545_I_32(what);

            c6545_TEMP_VDU(what) = c6545_TEMP_VDU(what)->next_same_char;
        }
    }

    return;
}








/*
Function: void c6545_write_vdu_mem(void)
Operation: Write to VDU memory
*/

void c6545_write_vdu_mem(c6545_state *what)
{
    /*
       Do nothing unless the data has changed.
    */

    if ( *c6545_VIDEO_DATA_BUS(what) != (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num )
    {
        (*c6545_XPOS_BUS(what)) = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_x_coord;
        (*c6545_YPOS_BUS(what)) = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_y_coord;
        ((c6545_VDU_DETAIL(what)).scn_map)[*c6545_XPOS_BUS(what)][*c6545_YPOS_BUS(what)] = *c6545_VIDEO_DATA_BUS(what);


        /* update the update mask */

        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x000] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x000] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000001; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x001] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x001] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000002; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x002] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x002] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000004; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x003] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x003] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000008; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x004] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x004] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000010; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x005] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x005] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000020; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x006] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x006] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000040; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x007] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x007] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000080; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x008] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x008] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000100; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x009] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x009] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000200; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x00a] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00a] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000400; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x00b] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00b] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000800; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x00c] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00c] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000001000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x00d] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00d] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000002000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x00e] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00e] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000004000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x00f] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00f] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000008000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x010] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x010] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000010000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x011] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x011] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000020000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x012] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x012] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000040000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x013] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x013] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000080000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x014] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x014] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000100000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x015] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x015] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000200000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x016] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x016] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000400000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x017] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x017] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000800000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x018] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x018] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x001000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x019] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x019] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x002000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x01a] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01a] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x004000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x01b] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01b] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x008000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x01c] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01c] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x010000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x01d] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01d] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x020000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x01e] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01e] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x040000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).lines)[0x01f] != ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01f] ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x080000000; }

        /* remove from current char linked list */

        if ( (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).prev_same_char == NULL )
        {
            if ( (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char == NULL )
            {
                /* only one in list */

                (DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).first_occur = NULL;
            }

            else
            {
                /* first one in list */

                (DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).first_occur = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char;
                ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char)->prev_same_char = NULL;
            }
        }

        else
        {
            if ( (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char == NULL )
            {
                /* last one in list */

                ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).prev_same_char)->next_same_char = NULL;
            }

            else
            {
                /* somewhere in middle of list */

                ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).prev_same_char)->next_same_char = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char;
                ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char)->prev_same_char = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).prev_same_char;
            }
        }

        (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num = *c6545_VIDEO_DATA_BUS(what);

        /* put at start of new list */

        if ( (DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).first_occur == NULL )
        {
            /* start new list */

            (DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).first_occur = &(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what)));

            (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).prev_same_char = NULL;
            (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char = NULL;
        }

        else
        {
            /* add to start of existing list */

            ((DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).first_occur)->prev_same_char = &(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what)));

            (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).next_same_char = (DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).first_occur;
            (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).prev_same_char = NULL;

            (DEBDEREF(c6545_CHAR_MEMORY(what),*c6545_VIDEO_DATA_BUS(what))).first_occur = &(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what)));
        }
    }

    return;
}




/*
Function: void c6545_write_fore_colour(void)
Operation: Write to foreground colour memory
*/

void c6545_write_fore_colour(c6545_state *what)
{
    if ( *c6545_VIDEO_DATA_BUS(what) != ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).fore_colour)[0] )
    {
        (*c6545_XPOS_BUS(what)) = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_x_coord;
        (*c6545_YPOS_BUS(what)) = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_y_coord;
        ((c6545_VDU_DETAIL(what)).col_map)[*c6545_XPOS_BUS(what)][*c6545_YPOS_BUS(what)][0] = *c6545_VIDEO_DATA_BUS(what);


        (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).fore_colour[0] = *c6545_VIDEO_DATA_BUS(what);
        (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).back_colour[1] = *c6545_VIDEO_DATA_BUS(what);

        /* update the update mask */

        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x000] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000001; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x001] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000002; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x002] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000004; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x003] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000008; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x004] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000010; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x005] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000020; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x006] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000040; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x007] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000080; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x008] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000100; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x009] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000200; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00a] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000400; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00b] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000800; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00c] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000001000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00d] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000002000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00e] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000004000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00f] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000008000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x010] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000010000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x011] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000020000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x012] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000040000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x013] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000080000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x014] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000100000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x015] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000200000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x016] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000400000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x017] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000800000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x018] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x001000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x019] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x002000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01a] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x004000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01b] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x008000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01c] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x010000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01d] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x020000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01e] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x040000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01f] != 0x000 ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x080000000; }
    }

    return;
}







/*
Function: void c6545_write_back_colour(void)
Operation: Write to background colour memory
*/

void c6545_write_back_colour(c6545_state *what)
{
    if ( *c6545_VIDEO_DATA_BUS(what) != ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).back_colour)[0] )
    {
        (*c6545_XPOS_BUS(what)) = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_x_coord;
        (*c6545_YPOS_BUS(what)) = (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_y_coord;
        ((c6545_VDU_DETAIL(what)).col_map)[*c6545_XPOS_BUS(what)][*c6545_YPOS_BUS(what)][1] = *c6545_VIDEO_DATA_BUS(what);


        ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).back_colour)[0] = *c6545_VIDEO_DATA_BUS(what);
        ((DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).fore_colour)[1] = *c6545_VIDEO_DATA_BUS(what);

        /* update the update mask */

        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x000] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000001; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x001] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000002; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x002] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000004; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x003] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000008; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x004] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000010; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x005] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000020; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x006] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000040; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x007] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000080; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x008] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000100; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x009] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000200; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00a] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000400; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00b] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000000800; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00c] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000001000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00d] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000002000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00e] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000004000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x00f] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000008000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x010] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000010000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x011] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000020000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x012] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000040000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x013] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000080000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x014] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000100000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x015] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000200000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x016] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000400000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x017] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x000800000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x018] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x001000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x019] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x002000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01a] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x004000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01b] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x008000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01c] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x010000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01d] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x020000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01e] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x040000000; }
        if ( ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).char_num)).lines)[0x01f] != 0x0FF ) { (DEBDEREF(c6545_VDU_MEMORY(what),*c6545_VIDEO_MEM_ADDR_BUS(what))).line_change_mask |= 0x080000000; }
    }

    return;
}









void c6545_fix_coordspoint(c6545_state *what)
{
    UINT_32 i,k;
    UINT_8 x,y;

    for ( i = 0x00000 ; i < C6545_VDU_MEM_SIZE ; i++ )
    {
        (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_x_coord = 0;
        (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_y_coord = 0;

        (DEBDEREF(c6545_VDU_MEMORY(what),i)).char_pointer = NULL;
        (DEBDEREF(c6545_VDU_MEMORY(what),i)).back_pointer = NULL;
        (DEBDEREF(c6545_VDU_MEMORY(what),i)).fore_pointer = NULL;
    }

    if ( !R8_ADM(what) )
    {
        /*
           linear display mode
        */

        for ( i = 0x00000 ; i < R1_(what)*R6_(what) ; i++ )
        {
            k = ( i + R12_13_(what) ) & 0x0FFFF;

            x = (UINT_8) ( i % R1_(what) );
            y = (UINT_8) ( i / R1_(what) );

            (DEBDEREF(c6545_VDU_MEMORY(what),k)).char_x_coord = x;
            (DEBDEREF(c6545_VDU_MEMORY(what),k)).char_y_coord = y;

            (DEBDEREF(c6545_VDU_MEMORY(what),k)).char_pointer = &(((c6545_VDU_DETAIL(what)).scn_map)[x][y]);
            (DEBDEREF(c6545_VDU_MEMORY(what),k)).back_pointer = &(((c6545_VDU_DETAIL(what)).col_map)[x][y][0]);
            (DEBDEREF(c6545_VDU_MEMORY(what),k)).fore_pointer = &(((c6545_VDU_DETAIL(what)).col_map)[x][y][1]);

            *((DEBDEREF(c6545_VDU_MEMORY(what),k)).char_pointer) = ((DEBDEREF(c6545_VDU_MEMORY(what),k)).char_num);
            *((DEBDEREF(c6545_VDU_MEMORY(what),k)).back_pointer) = ((DEBDEREF(c6545_VDU_MEMORY(what),k)).back_colour)[0];
            *((DEBDEREF(c6545_VDU_MEMORY(what),k)).fore_pointer) = ((DEBDEREF(c6545_VDU_MEMORY(what),k)).fore_colour)[0];
        }
    }

    else
    {
        /*
           row/column mode
        */

        for ( y = 0x000 ; y < R6_(what) ; y++ )
        {
            for ( x = 0x000 ; x < R1_(what) ; x++ )
            {
                k = ( ( ( y * 0x0100 ) + x ) + R12_13_(what) ) & 0x0FFFF;

                (DEBDEREF(c6545_VDU_MEMORY(what),k)).char_x_coord = x;
                (DEBDEREF(c6545_VDU_MEMORY(what),k)).char_y_coord = y;

                (DEBDEREF(c6545_VDU_MEMORY(what),k)).char_pointer = &(((c6545_VDU_DETAIL(what)).scn_map)[x][y]);
                (DEBDEREF(c6545_VDU_MEMORY(what),k)).back_pointer = &(((c6545_VDU_DETAIL(what)).col_map)[x][y][0]);
                (DEBDEREF(c6545_VDU_MEMORY(what),k)).fore_pointer = &(((c6545_VDU_DETAIL(what)).col_map)[x][y][1]);

                *((DEBDEREF(c6545_VDU_MEMORY(what),k)).char_pointer) = ((DEBDEREF(c6545_VDU_MEMORY(what),k)).char_num);
                *((DEBDEREF(c6545_VDU_MEMORY(what),k)).back_pointer) = ((DEBDEREF(c6545_VDU_MEMORY(what),k)).back_colour)[0];
                *((DEBDEREF(c6545_VDU_MEMORY(what),k)).fore_pointer) = ((DEBDEREF(c6545_VDU_MEMORY(what),k)).fore_colour)[0];
            }
        }
    }

    return;
}



/*
Function: c6545_do_cycles(UINT_16 how_many)
Operation: Run the 6545 through how_many clock cycles.
*/

/*
   Note: Assumed here that carry from column to row is allowed

   Note: In the latch_lpen stuff above, where R16_17_ is loaded, the specs
         say that this is set according to the contents of the "internal
         scan counter" on the next negative going clock edge after the
         lpen transition (low-high) occurs.  I've followed this, and it
         seems to work for the MicroBee.
         BUT: the diagram in same datasheet (SY6545) clearly indicates
              that the contents of MA_bus should be loaded on the negative
              going clock edge.  This would be c6545_MA_bus.  The fact
              that the dispen based update lasts 3 clock cycles also
              indicates that this should be true (ie. update register
              loaded, not the scan address).  I've chosen the internal bus
              method, but I'm not entirely convinced either way.

   Update counters for 1 clock cycle.  In list of priority, the counters
   are:

        c6545_horiz_char_count: ranges from 0 to R0_
        c6545_vert_scan_count:  ranges from 0 to R9_ (R5_-1 if c6545_vert_char_count == R4_+1)
        c6545_vert_char_count:  ranges from 0 to R4_ (R4_+1 if R5_ > 0)
        c6545_frame_count:      ranges from 0 to 63

   there is also the c6545_vert_sync_count, as described elsewhere.
*/

#define INCR_UPD_ADDR                                                   \
{                                                                       \
    R18_19_(what) = ( ( R18_19_(what) + 1 ) & 0x03FFF );                \
    R19_CA(what)  = R18_19_(what) & 0x0FF;                              \
    R18_RA(what)  = (R18_19_(what) >> 8) & 0x03F;                       \
}


/*
For speed reasons, the do_cycles while loop is enclosed in a switch statement
to avoid too many repetetive decisions inside the loop.  Thus, rather than
one big loop full of small decisions, there are many small loops only one
of which will be excecuted.  This is done with macros.
Additionally, putting the dispen condition outside most of the operations
(so there are separate macros for dispen and overscan/flyback) resulted in
a significant speedup.
*/

/*
FIRST_PART_DO_CYCLE: This part of the loop works out the horizonal blanking,
                     vertical blanking, display enable, vertical sync and
                     horizontal sync signals, as well as the default state
                     of the CR bus.

                     vblank = 0x000 or 0x020
                     hblank = 0x000 or 0x001
                     dispen = 0x000 or 0x008

AMID_PART_DO_CYCLE: This masks (and modifies if CR4 is an update strobe) the
                    CR bus, and modifies the MA buses if required.  It also
                    sets the update state (internal) of the 6545 and the
                    update strobing.

BMID_PART_DO_CYCLE: set c6545_line_up_mask (bit mask, 1 bit set,
                    indicating that the relevant line is being drawn.

CMID_PART_DO_CYCLE: Ignoring the position on the screen, work out if the
                    cursor is on or off for this frame.

DMID_PART_DO_CYCLE: Ignoring the position on the screen, work out if the
                    cursor is on or off for this frame.
*/



#define GENERIC_SETUP_PART                                              \
                                                                        \
    c6545_DISPEN(what) = ( ~( ( c6545_VBLANK(what) >> 2 ) | ( c6545_HBLANK(what) << 3 ) ) ) & 0x008; \
                                                                        \
    c6545_LPEN_FEEDBACK_ADDR_TYPE_CLW(what) = 0;                        \
    c6545_LPEN_FEEDBACK_ADDR_TYPE(what)     = 0;

#define GENERIC_FINAL_PART                                              \
                                                                        \
    if ( c6545_LATCH_LPEN(what) )                                       \
    {                                                                   \
        c6545_LATCH_LPEN(what) = 0;                                     \
                                                                        \
        (DEBDEREF((*c6545_LPEN_FEEDBACK_TABLE_SEL(what)),(c6545_LPEN_FEEDBACK_ADDR(what) & c6545_LPEN_ALIAS(what))))++; \
                                                                        \
        R16_17_(what) = 0x000;                                          \
        R16_RA(what)  = 0x000;                                          \
        R17_CA(what)  = 0x000;                                          \
                                                                        \
        c6545_LPEN_REGISTER_FULL(what) = 0x040;                         \
    }                                                                   \
                                                                        \
    if ( ( c6545_PREVIOUS_LPEN(what) < c6545_IS_LPEN_CLOW(what) ) ||    \
         ( c6545_IS_LPEN_CLOW(what)  < c6545_IS_LPEN(what)      )    )  \
    {                                                                   \
        c6545_LATCH_LPEN(what) = 1;                                     \
    }                                                                   \
                                                                        \
    c6545_PREVIOUS_LPEN(what)      = c6545_IS_LPEN(what);               \
    c6545_PREVIOUS_LPEN_CLOW(what) = c6545_IS_LPEN_CLOW(what);          \
                                                                        \
    if ( ++c6545_HORIZ_CHAR_COUNT(what) == R1_(what) )                  \
    {                                                                   \
        c6545_HBLANK(what) = 0x001;                                     \
    }                                                                   \
                                                                        \
    if ( c6545_HORIZ_CHAR_COUNT(what) == R2_(what) )                    \
    {                                                                   \
        c6545_IS_HSYNC(what) = 0x004;                                   \
    }                                                                   \
                                                                        \
    else if ( c6545_HORIZ_CHAR_COUNT(what) == R2_(what)+R3_H(what) )    \
    {                                                                   \
        c6545_IS_HSYNC(what) = 0x000;                                   \
    }                                                                   \
                                                                        \
    if ( c6545_HORIZ_CHAR_COUNT(what) > R0_(what) )                     \
    {                                                                   \
        c6545_IS_HSYNC(what) = 0x000;                                   \
        c6545_HBLANK(what)   = 0x000;                                   \
                                                                        \
        c6545_HORIZ_CHAR_COUNT(what) = 0;                               \
                                                                        \
        if ( ( ( c6545_VERT_CHAR_COUNT(what) == R7_(what) ) && ( c6545_VERT_SCAN_COUNT(what) == 0 ) ) ||     \
               ( c6545_VERT_SYNC_COUNT(what) > 0                                                    )      ) \
        {                                                               \
            c6545_VERT_SYNC_COUNT(what)++;                              \
            c6545_IS_VSYNC(what) = 0x002;                               \
                                                                        \
            if ( c6545_VERT_SYNC_COUNT(what) > R3_V(what) )             \
            {                                                           \
                c6545_VERT_SYNC_COUNT(what) = 0;                        \
                c6545_IS_VSYNC(what) = 0x000;                           \
            }                                                           \
        }                                                               \
                                                                        \
        c6545_VERT_SCAN_COUNT(what)++;                                  \
                                                                        \
        if ( ( ( c6545_VERT_CHAR_COUNT(what) <= R4_(what)   ) && ( c6545_VERT_SCAN_COUNT(what) > R9_(what)   ) ) ||   \
             ( ( c6545_VERT_CHAR_COUNT(what) == R4_(what)+1 ) && ( c6545_VERT_SCAN_COUNT(what) > R5_(what)-1 ) )    ) \
        {                                                               \
            c6545_VERT_SCAN_COUNT(what) = 0;                            \
                                                                        \
            if ( ++c6545_VERT_CHAR_COUNT(what) == R6_(what) )           \
            {                                                           \
                c6545_VBLANK(what) = 0x020;                             \
            }                                                           \
                                                                        \
            if ( ( ( c6545_VERT_CHAR_COUNT(what) >  R4_(what)+1 )                           ) ||   \
                 ( ( c6545_VERT_CHAR_COUNT(what) == R4_(what)+1 ) && ( R5_(what) ==     0 ) )    ) \
            {                                                           \
                c6545_VBLANK(what) = 0x000;                             \
                                                                        \
                c6545_VERT_CHAR_COUNT(what) = 0;                        \
                                                                        \
                if ( c6545_REDRAW_BUS(what) & 0x03 )                    \
                {                                                       \
                    if ( c6545_REDRAW_BUS(what) & 0x02 )                \
                    {                                                   \
                        c6545_REDRAW_BUS(what) &= 0x04;                 \
                        c6545_REDRAW_BUS(what) |= 0x01;                 \
                    }                                                   \
                                                                        \
                    else if ( c6545_REDRAW_BUS(what) & 0x01 )           \
                    {                                                   \
                        c6545_REDRAW_BUS(what) &= 0x04;                 \
                    }                                                   \
                }                                                       \
                                                                        \
                c6545_FRAME_COUNT(what) += clock_div;                   \
                                                                        \
                if ( c6545_FRAME_COUNT(what) > 63 )                     \
                {                                                       \
                    c6545_FRAME_COUNT(what) = 0;                        \
                }                                                       \
            }                                                           \
        }                                                               \
    }                                                                   \
                                                                        \
    num_cycles--;






#define FIRST_PART_DO_CYCLE_LINEAR(CR_mask)                             \
                                                                        \
    c6545_CR_BUS_CLOW(what) = c6545_VERT_SCAN_COUNT(what) & CR_mask;    \
    c6545_CR_BUS(what)      = c6545_CR_BUS_CLOW(what);                  \
                                                                        \
    c6545_MA_BUS_NO_UPDATE(what) = ((c6545_VERT_CHAR_COUNT(what)*R1_(what))+c6545_HORIZ_CHAR_COUNT(what)+R12_13_(what)) & 0x03FFF; \
                                                                        \
    c6545_MA_BUS_CLOW(what) = c6545_MA_BUS_NO_UPDATE(what);             \
    c6545_MA_BUS(what)      = c6545_MA_BUS_NO_UPDATE(what);

#define FIRST_PART_DO_CYCLE_ROWCOL(CR_mask)                             \
                                                                        \
    c6545_CR_BUS_CLOW(what) = c6545_VERT_SCAN_COUNT(what) & CR_mask;    \
    c6545_CR_BUS(what)      = c6545_CR_BUS_CLOW(what);                  \
                                                                        \
    c6545_MA_BUS_NO_UPDATE(what) = ((c6545_VERT_CHAR_COUNT(what)<<8)+c6545_HORIZ_CHAR_COUNT(what)+R12_13_(what)) & 0x03FFF; \
                                                                        \
    c6545_MA_BUS_CLOW(what) = c6545_MA_BUS_NO_UPDATE(what);             \
    c6545_MA_BUS(what)      = c6545_MA_BUS_NO_UPDATE(what);

#define AMID_DO_NOTHING

#define AMID_PART_DO_CYCLE001xq                                         \
                                                                        \
    if ( c6545_UPDATE_DISPEN_COUNT(what) )                              \
    {                                                                   \
        c6545_MA_BUS(what) = R18_19_(what);                             \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what) = 1;                        \
                                                                        \
        switch ( c6545_UPDATE_DISPEN_COUNT(what) )                      \
        {                                                               \
            case 1:                                                     \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 2;                    \
                                                                        \
                break;                                                  \
            }                                                           \
                                                                        \
            default:                                                    \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 0;                    \
                                                                        \
                c6545_UPDATE_READY(what) = 0x080;                       \
                                                                        \
                INCR_UPD_ADDR;                                          \
                                                                        \
                break;                                                  \
            }                                                           \
        }                                                               \
    }

#define AMID_PART_DO_CYCLE011xq                                         \
                                                                        \
    if ( c6545_UPDATE_DISPEN_COUNT(what) )                              \
    {                                                                   \
        c6545_MA_BUS(what) = R18_19_(what);                             \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what) = 1;                        \
                                                                        \
        switch ( c6545_UPDATE_DISPEN_COUNT(what) )                      \
        {                                                               \
            case 1:                                                     \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 2;                    \
                                                                        \
                c6545_CR_BUS(what) |= 0x010;                            \
                                                                        \
                break;                                                  \
            }                                                           \
                                                                        \
            default:                                                    \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 0;                    \
                                                                        \
                c6545_UPDATE_READY(what) = 0x080;                       \
                                                                        \
                INCR_UPD_ADDR;                                          \
                                                                        \
                break;                                                  \
            }                                                           \
        }                                                               \
    }

#define AMID_PART_DO_CYCLE101xq                                         \
                                                                        \
    if ( !c6545_UPDATE_READY(what) )                                    \
    {                                                                   \
        c6545_MA_BUS(what) = R18_19_(what);                             \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what) = 1;                        \
                                                                        \
        c6545_UPDATE_READY(what) = 0x080;                               \
                                                                        \
        INCR_UPD_ADDR;                                                  \
    }

#define AMID_PART_DO_CYCLE111xq                                         \
                                                                        \
    if ( !c6545_UPDATE_READY(what) )                                    \
    {                                                                   \
        c6545_MA_BUS(what) = R18_19_(what);                             \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what) = 1;                        \
                                                                        \
        c6545_UPDATE_READY(what) = 0x080;                               \
                                                                        \
        INCR_UPD_ADDR;                                                  \
                                                                        \
        c6545_CR_BUS(what) |= 0x010;                                    \
    }

#define BMID_DO_NOTHING

#define BMID_PART_DO_CYCLE                                              \
                                                                        \
    c6545_IS_CURSOR(what) = 0;                                          \
                                                                        \
    c6545_LINE_UP_MASK(what) = 1 << c6545_VERT_SCAN_COUNT(what);


#define CMID_DO_NOTHING

#define CMID_PART_DO_CYCLE00q                                           \
                                                                        \
    {

#define CMID_PART_DO_CYCLE10q                                           \
                                                                        \
    if ( c6545_FRAME_COUNT(what) & 0x010 )                              \
    {

#define CMID_PART_DO_CYCLE11q                                           \
                                                                        \
    if ( c6545_FRAME_COUNT(what) & 0x020 )                              \
    {

#define DMID_DO_NOTHING

#define DMID_PART_DO_CYCLExxq                                           \
                                                                        \
        if ( c6545_MA_BUS_NO_UPDATE(what) == R14_15_(what) )            \
        {                                                               \
            if ( R11_(what) >= R10_CS(what) )                           \
            {                                                           \
                if ( ( c6545_VERT_SCAN_COUNT(what) >= R10_CS(what) ) &&   \
                     ( c6545_VERT_SCAN_COUNT(what) <= R11_(what)   )    ) \
                {                                                       \
                    c6545_IS_CURSOR(what) = 1;                          \
                                                                        \
                    ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).line_change_mask) |= c6545_LINE_UP_MASK(what); \
                }                                                       \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                if ( ( c6545_VERT_SCAN_COUNT(what) <= R10_CS(what) ) ||   \
                     ( c6545_VERT_SCAN_COUNT(what) >= R11_(what)   )    ) \
                {                                                       \
                    c6545_IS_CURSOR(what) = 0;                          \
                }                                                       \
            }                                                           \
        }                                                               \
    }

#define DMID_PART_DO_CYCLE01q                                           \
                                                                        \
        if ( ( c6545_MA_BUS_NO_UPDATE(what) == R14_15_(what)-1 ) && ( c6545_HORIZ_CHAR_COUNT(what) > 0 ) ) \
        {                                                               \
            if ( R11_(what) >= R10_CS(what) )                           \
            {                                                           \
                if ( ( c6545_VERT_SCAN_COUNT(what) >= R10_CS(what) ) &&   \
                     ( c6545_VERT_SCAN_COUNT(what) <= R11_(what)   )    ) \
                {                                                       \
                    c6545_IS_CURSOR(what) = 1;                          \
                                                                        \
                    ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).line_change_mask) |= c6545_LINE_UP_MASK(what); \
                }                                                       \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                if ( ( c6545_VERT_SCAN_COUNT(what) <= R10_CS(what) ) ||   \
                     ( c6545_VERT_SCAN_COUNT(what) >= R11_(what)   )    ) \
                {                                                       \
                    c6545_IS_CURSOR(what) = 0;                          \
                }                                                       \
            }                                                           \
        }                                                               \
    }

#define DMID_PART_DO_CYCLE10q                                           \
                                                                        \
        if ( ( c6545_MA_BUS_NO_UPDATE(what) == R14_15_(what)+1 ) && ( c6545_HORIZ_CHAR_COUNT(what) < R0_(what) ) ) \
        {                                                               \
            if ( R11_(what) >= R10_CS(what) )                           \
            {                                                           \
                if ( ( c6545_VERT_SCAN_COUNT(what) >= R10_CS(what) ) &&   \
                     ( c6545_VERT_SCAN_COUNT(what) <= R11_(what)   )    ) \
                {                                                       \
                    c6545_IS_CURSOR(what) = 1;                          \
                                                                        \
                    ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).line_change_mask) |= c6545_LINE_UP_MASK(what); \
                }                                                       \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                if ( ( c6545_VERT_SCAN_COUNT(what) <= R10_CS(what) ) ||   \
                     ( c6545_VERT_SCAN_COUNT(what) >= R11_(what)   )    ) \
                {                                                       \
                    c6545_IS_CURSOR(what) = 0;                          \
                }                                                       \
            }                                                           \
        }                                                               \
    }

#define LAST_PART_DO_CYCLE                                              \
                                                                        \
    if ( ( ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).line_change_mask) & c6545_LINE_UP_MASK(what) ) || c6545_REDRAW_BUS(what) ) \
    {                                                                   \
        (*c6545_FORE_COLOUR_BUS(what)) = ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).fore_colour)[c6545_IS_CURSOR(what)]; \
        (*c6545_BACK_COLOUR_BUS(what)) = ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).back_colour)[c6545_IS_CURSOR(what)]; \
        (*c6545_INV__COLOUR_BUS(what)) = c6545_IS_CURSOR(what);         \
                                                                        \
        (*c6545_XPOS_BUS(what)) = c6545_HORIZ_CHAR_COUNT(what) << 3;    \
        (*c6545_YPOS_BUS(what)) = ((((UINT_16) R9_(what))+1)*c6545_VERT_CHAR_COUNT(what))+c6545_VERT_SCAN_COUNT(what); \
                                                                        \
        (*c6545_IS_FORE_BUS(what)) = ((DEBDEREF(c6545_CHAR_MEMORY(what),(DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).char_num)).lines)[c6545_VERT_SCAN_COUNT(what)]; \
                                                                        \
        c6545_PIXEL_DRAWER(what)();                                     \
                                                                        \
        if ( !c6545_IS_CURSOR(what) )                                   \
        {                                                               \
            c6545_LINE_UP_MASK(what) ^= 0x0FFFFFFFF;                    \
                                                                        \
            ((DEBDEREF(c6545_VDU_MEMORY(what),c6545_MA_BUS_CLOW(what))).line_change_mask) &= c6545_LINE_UP_MASK(what); \
        }                                                               \
    }                                                                   \
                                                                        \
    c6545_IS_LPEN_CLOW(what) = 0;                                       \
    c6545_IS_LPEN(what)      = 0;                                       \
                                                                        \
    if ( (1<<((c6545_CR_BUS(what)      & 0x010)|c6545_DISPEN(what)|c6545_IS_HSYNC(what)|c6545_IS_VSYNC(what)|c6545_IS_CURSOR(what))) & (*c6545_LPEN_CALL_MASK_BUS(what)) ) \
    {                                                                   \
        if ( ( c6545_IS_LPEN(what)      = DEBDEREF((*c6545_POLE_LPEN_TABLE(what)),     (c6545_MA_BUS(what)      & c6545_LPEN_ALIAS(what))) ) ) \
        {                                                               \
            c6545_LPEN_FEEDBACK_ADDR(what) = c6545_MA_BUS(what);        \
                                                                        \
            if ( c6545_LPEN_FEEDBACK_ADDR_TYPE(what) )                  \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDRFSH_TABLE(what); \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDBACK_TABLE(what); \
            }                                                           \
        }                                                               \
    }                                                                   \
                                                                        \
    if ( (1<<((c6545_CR_BUS_CLOW(what) & 0x010)|c6545_DISPEN(what)|c6545_IS_HSYNC(what)|c6545_IS_VSYNC(what)|c6545_IS_CURSOR(what))) & (*c6545_LPEN_CALL_MASK_BUS(what)) ) \
    {                                                                   \
        if ( ( c6545_IS_LPEN_CLOW(what) = DEBDEREF((*c6545_POLE_LPEN_CLOW_TABLE(what)),(c6545_MA_BUS_CLOW(what) & c6545_LPEN_ALIAS(what))) ) ) \
        {                                                               \
            c6545_LPEN_FEEDBACK_ADDR(what) = c6545_MA_BUS_CLOW(what);   \
                                                                        \
            if ( c6545_LPEN_FEEDBACK_ADDR_TYPE_CLW(what) )              \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDRFSH_CLOW_TABLE(what); \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDBACK_CLOW_TABLE(what); \
            }                                                           \
        }                                                               \
    }

/*
NOTE: the ordering of the above (first lpen_table, then lpen_clow_table) is
      important (although not in the microbee context).  The 6545 cycle is
      first clock_low, then clock_high.  Now, we want to capture the address
      of the *earliest* low-high transition of the lpen pin and store the
      address corresponding to this in c6545_LPEN_FEEDBACK_ADDR(what).  The
      first event is the clow event, hence we put it second so that the
      value written will override later events.
*/




#define FIRST_PART_DO_CYCLE_LINEAR_NODISP(CR_mask)                      \
                                                                        \
    c6545_CR_BUS_CLOW(what) = 0x000;                                    \
    c6545_CR_BUS(what)      = 0x000;                                    \
                                                                        \
    c6545_MA_BUS_CLOW(what) = 0x000;                                    \
    c6545_MA_BUS(what)      = 0x000;

#define FIRST_PART_DO_CYCLE_ROWCOL_NODISP(CR_mask)                      \
                                                                        \
    c6545_CR_BUS_CLOW(what) = 0x000;                                    \
    c6545_CR_BUS(what)      = 0x000;                                    \
                                                                        \
    c6545_MA_BUS_CLOW(what) = 0x000;                                    \
    c6545_MA_BUS(what)      = 0x000;

#define AMID_DO_NOTHING_NODISP

#define AMID_PART_DO_CYCLE001xq_NODISP                                  \
                                                                        \
    if ( !c6545_UPDATE_READY(what) || c6545_UPDATE_DISPEN_COUNT(what) ) \
    {                                                                   \
        c6545_MA_BUS_CLOW(what) = R18_19_(what);                        \
        c6545_MA_BUS(what)      = R18_19_(what);                        \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE_CLW(what) = 1;                    \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what)     = 1;                    \
                                                                        \
        switch ( c6545_UPDATE_DISPEN_COUNT(what) )                      \
        {                                                               \
            case 0:                                                     \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 1;                    \
                                                                        \
                break;                                                  \
            }                                                           \
                                                                        \
            case 1:                                                     \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 2;                    \
                                                                        \
                break;                                                  \
            }                                                           \
                                                                        \
            default:                                                    \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 0;                    \
                                                                        \
                c6545_UPDATE_READY(what) = 0x080;                       \
                                                                        \
                INCR_UPD_ADDR;                                          \
                                                                        \
                break;                                                  \
            }                                                           \
        }                                                               \
    }

#define AMID_PART_DO_CYCLE011xq_NODISP                                  \
                                                                        \
    if ( !c6545_UPDATE_READY(what) || c6545_UPDATE_DISPEN_COUNT(what) ) \
    {                                                                   \
        c6545_MA_BUS_CLOW(what) = R18_19_(what);                        \
        c6545_MA_BUS(what)      = R18_19_(what);                        \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE_CLW(what) = 1;                    \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what)     = 1;                    \
                                                                        \
        switch ( c6545_UPDATE_DISPEN_COUNT(what) )                      \
        {                                                               \
            case 0:                                                     \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 1;                    \
                                                                        \
                break;                                                  \
            }                                                           \
                                                                        \
            case 1:                                                     \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 2;                    \
                                                                        \
                c6545_CR_BUS_CLOW(what) = 0x010;                        \
                c6545_CR_BUS(what)      = 0x010;                        \
                                                                        \
                break;                                                  \
            }                                                           \
                                                                        \
            default:                                                    \
            {                                                           \
                c6545_UPDATE_DISPEN_COUNT(what) = 0;                    \
                                                                        \
                c6545_UPDATE_READY(what) = 0x080;                       \
                                                                        \
                INCR_UPD_ADDR;                                          \
                                                                        \
                break;                                                  \
            }                                                           \
        }                                                               \
    }

#define AMID_PART_DO_CYCLE101xq_NODISP                                  \
                                                                        \
    if ( !c6545_UPDATE_READY(what) )                                    \
    {                                                                   \
        c6545_MA_BUS(what) = R18_19_(what);                             \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what) = 1;                        \
                                                                        \
        c6545_UPDATE_READY(what) = 0x080;                               \
                                                                        \
        INCR_UPD_ADDR;                                                  \
    }

#define AMID_PART_DO_CYCLE111xq_NODISP                                  \
                                                                        \
    if ( !c6545_UPDATE_READY(what) )                                    \
    {                                                                   \
        c6545_MA_BUS(what) = R18_19_(what);                             \
                                                                        \
        c6545_LPEN_FEEDBACK_ADDR_TYPE(what) = 1;                        \
                                                                        \
        c6545_UPDATE_READY(what) = 0x080;                               \
                                                                        \
        INCR_UPD_ADDR;                                                  \
                                                                        \
        c6545_CR_BUS(what) = 0x010;                                     \
    }

#define BMID_DO_NOTHING_NODISP
#define BMID_PART_DO_CYCLE_NODISP

#define CMID_DO_NOTHING_NODISP
#define CMID_PART_DO_CYCLE00q_NODISP
#define CMID_PART_DO_CYCLE10q_NODISP
#define CMID_PART_DO_CYCLE11q_NODISP

#define DMID_DO_NOTHING_NODISP
#define DMID_PART_DO_CYCLExxq_NODISP
#define DMID_PART_DO_CYCLE01q_NODISP
#define DMID_PART_DO_CYCLE10q_NODISP

#define LAST_PART_DO_CYCLE_NODISP                                       \
                                                                        \
    c6545_IS_LPEN_CLOW(what) = 0;                                       \
    c6545_IS_LPEN(what)      = 0;                                       \
                                                                        \
    if ( (1<<(c6545_CR_BUS(what)     |c6545_IS_HSYNC(what)|c6545_IS_VSYNC(what))) & (*c6545_LPEN_CALL_MASK_BUS(what)) ) \
    {                                                                   \
        if ( ( c6545_IS_LPEN(what)      = DEBDEREF((*c6545_POLE_LPEN_TABLE(what)),     c6545_MA_BUS(what)      & c6545_LPEN_ALIAS(what)) ) ) \
        {                                                               \
            c6545_LPEN_FEEDBACK_ADDR(what) = c6545_MA_BUS(what);        \
                                                                        \
            if ( c6545_LPEN_FEEDBACK_ADDR_TYPE(what) )                  \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDRFSH_TABLE(what); \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDBACK_TABLE(what); \
            }                                                           \
        }                                                               \
    }                                                                   \
                                                                        \
    if ( (1<<(c6545_CR_BUS_CLOW(what)|c6545_IS_HSYNC(what)|c6545_IS_VSYNC(what))) & (*c6545_LPEN_CALL_MASK_BUS(what)) ) \
    {                                                                   \
        if ( ( c6545_IS_LPEN_CLOW(what) = DEBDEREF((*c6545_POLE_LPEN_CLOW_TABLE(what)),c6545_MA_BUS_CLOW(what) & c6545_LPEN_ALIAS(what)) ) ) \
        {                                                               \
            c6545_LPEN_FEEDBACK_ADDR(what) = c6545_MA_BUS_CLOW(what);   \
                                                                        \
            if ( c6545_LPEN_FEEDBACK_ADDR_TYPE_CLW(what) )              \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDRFSH_CLOW_TABLE(what); \
            }                                                           \
                                                                        \
            else                                                        \
            {                                                           \
                c6545_LPEN_FEEDBACK_TABLE_SEL(what) = c6545_LPEN_FEEDBACK_CLOW_TABLE(what); \
            }                                                           \
        }                                                               \
    }                                                                   \

void c6545_do_cycles_00(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_01(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_02(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_03(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_04(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_05(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_06(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_07(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_08(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_09(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_0a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_0b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_0c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_0d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_0e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_0f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_10(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_11(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_12(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_13(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_14(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_15(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_16(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_17(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_18(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_19(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_1a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_1b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_1c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_1d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_1e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_1f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_20(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_21(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_22(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_23(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_24(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_25(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_26(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_27(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_28(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_29(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_2a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_2b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_2c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_2d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_2e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_2f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_30(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_31(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_32(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_33(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_34(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_35(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_36(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_37(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_38(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_39(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_3a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_3b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_3c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_3d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_3e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_3f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_40(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_41(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_42(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_43(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_44(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_45(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_46(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_47(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_48(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_49(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_4a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_4b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_4c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_4d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_4e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_4f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_50(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_51(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_52(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_53(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_54(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_55(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_56(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_57(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_58(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_59(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_5a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_5b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_5c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_5d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_5e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_5f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_60(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_61(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_62(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_63(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_64(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_65(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_66(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_67(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_68(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_69(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_6a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_6b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_6c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_6d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_6e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_6f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_70(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_71(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_72(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_73(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_74(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_75(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_76(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);
void c6545_do_cycles_77(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div);



void c6545_do_cycles(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
    switch ( R8_(what) | R10_BB(what) )
    {
        case 0x000: /* 00xx00xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x080: /* 10xx00xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x030: /* 00xx00xx */ /* xx11xxxx */ /* xxxxxx00 */
        case 0x0B0: /* 10xx00xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_00(what,num_cycles,clock_div);

            break;
        }

        case 0x010: /* 00xx00xx */ /* xx01xxxx */ /* xxxxxx00 */
        case 0x090: /* 10xx00xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_01(what,num_cycles,clock_div);

            break;
        }

        case 0x020: /* 00xx00xx */ /* xx10xxxx */ /* xxxxxx00 */
        case 0x0A0: /* 10xx00xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_02(what,num_cycles,clock_div);

            break;
        }

        case 0x040: /* 01xx00xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x0C0: /* 11xx00xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x070: /* 01xx00xx */ /* xx11xxxx */ /* xxxxxx00 */
        case 0x0F0: /* 11xx00xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_03(what,num_cycles,clock_div);

            break;
        }

        case 0x050: /* 01xx00xx */ /* xx01xxxx */ /* xxxxxx00 */
        case 0x0D0: /* 11xx00xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_04(what,num_cycles,clock_div);

            break;
        }

        case 0x060: /* 01xx00xx */ /* xx10xxxx */ /* xxxxxx00 */
        case 0x0E0: /* 11xx00xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_05(what,num_cycles,clock_div);

            break;
        }

        case 0x004: /* 00xx01xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x084: /* 10xx01xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x034: /* 00xx01xx */ /* xx11xxxx */ /* xxxxxx00 */
        case 0x0B4: /* 10xx01xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_06(what,num_cycles,clock_div);

            break;
        }

        case 0x014: /* 00xx01xx */ /* xx01xxxx */ /* xxxxxx00 */
        case 0x094: /* 10xx01xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_07(what,num_cycles,clock_div);

            break;
        }

        case 0x024: /* 00xx01xx */ /* xx10xxxx */ /* xxxxxx00 */
        case 0x0A4: /* 10xx01xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_08(what,num_cycles,clock_div);

            break;
        }

        case 0x044: /* 01xx01xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x0C4: /* 11xx01xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x074: /* 01xx01xx */ /* xx11xxxx */ /* xxxxxx00 */
        case 0x0F4: /* 11xx01xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_09(what,num_cycles,clock_div);

            break;
        }

        case 0x054: /* 01xx01xx */ /* xx01xxxx */ /* xxxxxx00 */
        case 0x0D4: /* 11xx01xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_0a(what,num_cycles,clock_div);

            break;
        }

        case 0x064: /* 01xx01xx */ /* xx10xxxx */ /* xxxxxx00 */
        case 0x0E4: /* 11xx01xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_0b(what,num_cycles,clock_div);

            break;
        }

        case 0x008: /* 00xx10xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x038: /* 00xx10xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_0c(what,num_cycles,clock_div);

            break;
        }

        case 0x018: /* 00xx10xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_0d(what,num_cycles,clock_div);

            break;
        }

        case 0x028: /* 00xx10xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_0e(what,num_cycles,clock_div);

            break;
        }

        case 0x048: /* 01xx10xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x078: /* 01xx10xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_0f(what,num_cycles,clock_div);

            break;
        }

        case 0x058: /* 01xx10xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_10(what,num_cycles,clock_div);

            break;
        }

        case 0x068: /* 01xx10xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_11(what,num_cycles,clock_div);

            break;
        }

        case 0x00C: /* 00xx11xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x03C: /* 00xx11xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_12(what,num_cycles,clock_div);

            break;
        }

        case 0x01C: /* 00xx11xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_13(what,num_cycles,clock_div);

            break;
        }

        case 0x02C: /* 00xx11xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_14(what,num_cycles,clock_div);

            break;
        }

        case 0x04C: /* 01xx11xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x07C: /* 01xx11xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_15(what,num_cycles,clock_div);

            break;
        }

        case 0x05C: /* 01xx11xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_16(what,num_cycles,clock_div);

            break;
        }

        case 0x06C: /* 01xx11xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_17(what,num_cycles,clock_div);

            break;
        }

        case 0x088: /* 10xx10xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x0B8: /* 10xx10xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_18(what,num_cycles,clock_div);

            break;
        }

        case 0x098: /* 10xx10xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_19(what,num_cycles,clock_div);

            break;
        }

        case 0x0A8: /* 10xx10xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_1a(what,num_cycles,clock_div);

            break;
        }

        case 0x0C8: /* 11xx10xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x0F8: /* 11xx10xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_1b(what,num_cycles,clock_div);

            break;
        }

        case 0x0D8: /* 11xx10xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_1c(what,num_cycles,clock_div);

            break;
        }

        case 0x0E8: /* 11xx10xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_1d(what,num_cycles,clock_div);

            break;
        }

        case 0x08C: /* 10xx11xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x0BC: /* 10xx11xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_1e(what,num_cycles,clock_div);

            break;
        }

        case 0x09C: /* 10xx11xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_1f(what,num_cycles,clock_div);

            break;
        }

        case 0x0AC: /* 10xx11xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_20(what,num_cycles,clock_div);

            break;
        }

        case 0x0CC: /* 11xx11xx */ /* xx00xxxx */ /* xxxxxx00 */
        case 0x0FC: /* 11xx11xx */ /* xx11xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_21(what,num_cycles,clock_div);

            break;
        }

        case 0x0DC: /* 11xx11xx */ /* xx01xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_22(what,num_cycles,clock_div);

            break;
        }

        case 0x0EC: /* 11xx11xx */ /* xx10xxxx */ /* xxxxxx00 */
        {
            c6545_do_cycles_23(what,num_cycles,clock_div);

            break;
        }


        case 0x001: /* 00xx00xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x081: /* 10xx00xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x031: /* 00xx00xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x0B1: /* 10xx00xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x011: /* 00xx00xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x091: /* 10xx00xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x021: /* 00xx00xx */ /* xx10xxxx */ /* xxxxxx01 */
        case 0x0A1: /* 10xx00xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_24(what,num_cycles,clock_div);

            break;
        }

        case 0x041: /* 01xx00xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x0C1: /* 11xx00xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x071: /* 01xx00xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x0F1: /* 11xx00xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x051: /* 01xx00xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x0D1: /* 11xx00xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x061: /* 01xx00xx */ /* xx10xxxx */ /* xxxxxx01 */
        case 0x0E1: /* 11xx00xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_25(what,num_cycles,clock_div);

            break;
        }

        case 0x005: /* 00xx01xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x085: /* 10xx01xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x035: /* 00xx01xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x0B5: /* 10xx01xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x015: /* 00xx01xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x095: /* 10xx01xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x025: /* 00xx01xx */ /* xx10xxxx */ /* xxxxxx01 */
        case 0x0A5: /* 10xx01xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_26(what,num_cycles,clock_div);

            break;
        }

        case 0x045: /* 01xx01xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x0C5: /* 11xx01xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x075: /* 01xx01xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x0F5: /* 11xx01xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x055: /* 01xx01xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x0D5: /* 11xx01xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x065: /* 01xx01xx */ /* xx10xxxx */ /* xxxxxx01 */
        case 0x0E5: /* 11xx01xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_27(what,num_cycles,clock_div);

            break;
        }

        case 0x009: /* 00xx10xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x039: /* 00xx10xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x019: /* 00xx10xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x029: /* 00xx10xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_28(what,num_cycles,clock_div);

            break;
        }

        case 0x049: /* 01xx10xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x079: /* 01xx10xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x059: /* 01xx10xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x069: /* 01xx10xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_29(what,num_cycles,clock_div);

            break;
        }

        case 0x00D: /* 00xx11xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x03D: /* 00xx11xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x01D: /* 00xx11xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x02D: /* 00xx11xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_2a(what,num_cycles,clock_div);

            break;
        }

        case 0x04D: /* 01xx11xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x07D: /* 01xx11xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x05D: /* 01xx11xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x06D: /* 01xx11xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_2b(what,num_cycles,clock_div);

            break;
        }

        case 0x089: /* 10xx10xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x0B9: /* 10xx10xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x099: /* 10xx10xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x0A9: /* 10xx10xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_2c(what,num_cycles,clock_div);

            break;
        }

        case 0x0C9: /* 11xx10xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x0F9: /* 11xx10xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x0D9: /* 11xx10xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x0E9: /* 11xx10xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_2d(what,num_cycles,clock_div);

            break;
        }

        case 0x08D: /* 10xx11xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x0BD: /* 10xx11xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x09D: /* 10xx11xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x0AD: /* 10xx11xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_2e(what,num_cycles,clock_div);

            break;
        }

        case 0x0CD: /* 11xx11xx */ /* xx00xxxx */ /* xxxxxx01 */
        case 0x0FD: /* 11xx11xx */ /* xx11xxxx */ /* xxxxxx01 */
        case 0x0DD: /* 11xx11xx */ /* xx01xxxx */ /* xxxxxx01 */
        case 0x0ED: /* 11xx11xx */ /* xx10xxxx */ /* xxxxxx01 */
        {
            c6545_do_cycles_2f(what,num_cycles,clock_div);

            break;
        }

        case 0x002: /* 00xx00xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x082: /* 10xx00xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x032: /* 00xx00xx */ /* xx11xxxx */ /* xxxxxx10 */
        case 0x0B2: /* 10xx00xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_30(what,num_cycles,clock_div);

            break;
        }

        case 0x012: /* 00xx00xx */ /* xx01xxxx */ /* xxxxxx10 */
        case 0x092: /* 10xx00xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_31(what,num_cycles,clock_div);

            break;
        }

        case 0x022: /* 00xx00xx */ /* xx10xxxx */ /* xxxxxx10 */
        case 0x0A2: /* 10xx00xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_32(what,num_cycles,clock_div);

            break;
        }

        case 0x042: /* 01xx00xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x0C2: /* 11xx00xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x072: /* 01xx00xx */ /* xx11xxxx */ /* xxxxxx10 */
        case 0x0F2: /* 11xx00xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_33(what,num_cycles,clock_div);

            break;
        }

        case 0x052: /* 01xx00xx */ /* xx01xxxx */ /* xxxxxx10 */
        case 0x0D2: /* 11xx00xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_34(what,num_cycles,clock_div);

            break;
        }

        case 0x062: /* 01xx00xx */ /* xx10xxxx */ /* xxxxxx10 */
        case 0x0E2: /* 11xx00xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_35(what,num_cycles,clock_div);

            break;
        }

        case 0x006: /* 00xx01xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x086: /* 10xx01xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x036: /* 00xx01xx */ /* xx11xxxx */ /* xxxxxx10 */
        case 0x0B6: /* 10xx01xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_36(what,num_cycles,clock_div);

            break;
        }

        case 0x016: /* 00xx01xx */ /* xx01xxxx */ /* xxxxxx10 */
        case 0x096: /* 10xx01xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_37(what,num_cycles,clock_div);

            break;
        }

        case 0x026: /* 00xx01xx */ /* xx10xxxx */ /* xxxxxx10 */
        case 0x0A6: /* 10xx01xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_38(what,num_cycles,clock_div);

            break;
        }

        case 0x046: /* 01xx01xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x0C6: /* 11xx01xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x076: /* 01xx01xx */ /* xx11xxxx */ /* xxxxxx10 */
        case 0x0F6: /* 11xx01xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_39(what,num_cycles,clock_div);

            break;
        }

        case 0x056: /* 01xx01xx */ /* xx01xxxx */ /* xxxxxx10 */
        case 0x0D6: /* 11xx01xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_3a(what,num_cycles,clock_div);

            break;
        }

        case 0x066: /* 01xx01xx */ /* xx10xxxx */ /* xxxxxx10 */
        case 0x0E6: /* 11xx01xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_3b(what,num_cycles,clock_div);

            break;
        }

        case 0x00A: /* 00xx10xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x03A: /* 00xx10xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_3c(what,num_cycles,clock_div);

            break;
        }

        case 0x01A: /* 00xx10xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_3d(what,num_cycles,clock_div);

            break;
        }

        case 0x02A: /* 00xx10xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_3e(what,num_cycles,clock_div);

            break;
        }

        case 0x04A: /* 01xx10xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x07A: /* 01xx10xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_3f(what,num_cycles,clock_div);

            break;
        }

        case 0x05A: /* 01xx10xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_40(what,num_cycles,clock_div);

            break;
        }

        case 0x06A: /* 01xx10xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_41(what,num_cycles,clock_div);

            break;
        }

        case 0x00E: /* 00xx11xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x03E: /* 00xx11xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_42(what,num_cycles,clock_div);

            break;
        }

        case 0x01E: /* 00xx11xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_43(what,num_cycles,clock_div);

            break;
        }

        case 0x02E: /* 00xx11xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_44(what,num_cycles,clock_div);

            break;
        }

        case 0x04E: /* 01xx11xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x07E: /* 01xx11xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_45(what,num_cycles,clock_div);

            break;
        }

        case 0x05E: /* 01xx11xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_46(what,num_cycles,clock_div);

            break;
        }

        case 0x06E: /* 01xx11xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_47(what,num_cycles,clock_div);

            break;
        }

        case 0x08A: /* 10xx10xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x0BA: /* 10xx10xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_48(what,num_cycles,clock_div);

            break;
        }

        case 0x09A: /* 10xx10xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_49(what,num_cycles,clock_div);

            break;
        }

        case 0x0AA: /* 10xx10xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_4a(what,num_cycles,clock_div);

            break;
        }

        case 0x0CA: /* 11xx10xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x0FA: /* 11xx10xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_4b(what,num_cycles,clock_div);

            break;
        }

        case 0x0DA: /* 11xx10xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_4c(what,num_cycles,clock_div);

            break;
        }

        case 0x0EA: /* 11xx10xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_4d(what,num_cycles,clock_div);

            break;
        }

        case 0x08E: /* 10xx11xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x0BE: /* 10xx11xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_4e(what,num_cycles,clock_div);

            break;
        }

        case 0x09E: /* 10xx11xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_4f(what,num_cycles,clock_div);

            break;
        }

        case 0x0AE: /* 10xx11xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_50(what,num_cycles,clock_div);

            break;
        }

        case 0x0CE: /* 11xx11xx */ /* xx00xxxx */ /* xxxxxx10 */
        case 0x0FE: /* 11xx11xx */ /* xx11xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_51(what,num_cycles,clock_div);

            break;
        }

        case 0x0DE: /* 11xx11xx */ /* xx01xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_52(what,num_cycles,clock_div);

            break;
        }

        case 0x0EE: /* 11xx11xx */ /* xx10xxxx */ /* xxxxxx10 */
        {
            c6545_do_cycles_53(what,num_cycles,clock_div);

            break;
        }


        case 0x003: /* 00xx00xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x083: /* 10xx00xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x033: /* 00xx00xx */ /* xx11xxxx */ /* xxxxxx11 */
        case 0x0B3: /* 10xx00xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_54(what,num_cycles,clock_div);

            break;
        }

        case 0x013: /* 00xx00xx */ /* xx01xxxx */ /* xxxxxx11 */
        case 0x093: /* 10xx00xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_55(what,num_cycles,clock_div);

            break;
        }

        case 0x023: /* 00xx00xx */ /* xx10xxxx */ /* xxxxxx11 */
        case 0x0A3: /* 10xx00xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_56(what,num_cycles,clock_div);

            break;
        }

        case 0x043: /* 01xx00xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x0C3: /* 11xx00xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x073: /* 01xx00xx */ /* xx11xxxx */ /* xxxxxx11 */
        case 0x0F3: /* 11xx00xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_57(what,num_cycles,clock_div);

            break;
        }

        case 0x053: /* 01xx00xx */ /* xx01xxxx */ /* xxxxxx11 */
        case 0x0D3: /* 11xx00xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_58(what,num_cycles,clock_div);

            break;
        }

        case 0x063: /* 01xx00xx */ /* xx10xxxx */ /* xxxxxx11 */
        case 0x0E3: /* 11xx00xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_59(what,num_cycles,clock_div);

            break;
        }

        case 0x007: /* 00xx01xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x087: /* 10xx01xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x037: /* 00xx01xx */ /* xx11xxxx */ /* xxxxxx11 */
        case 0x0B7: /* 10xx01xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_5a(what,num_cycles,clock_div);

            break;
        }

        case 0x017: /* 00xx01xx */ /* xx01xxxx */ /* xxxxxx11 */
        case 0x097: /* 10xx01xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_5b(what,num_cycles,clock_div);

            break;
        }

        case 0x027: /* 00xx01xx */ /* xx10xxxx */ /* xxxxxx11 */
        case 0x0A7: /* 10xx01xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_5c(what,num_cycles,clock_div);

            break;
        }

        case 0x047: /* 01xx01xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x0C7: /* 11xx01xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x077: /* 01xx01xx */ /* xx11xxxx */ /* xxxxxx11 */
        case 0x0F7: /* 11xx01xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_5d(what,num_cycles,clock_div);

            break;
        }

        case 0x057: /* 01xx01xx */ /* xx01xxxx */ /* xxxxxx11 */
        case 0x0D7: /* 11xx01xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_5e(what,num_cycles,clock_div);

            break;
        }

        case 0x067: /* 01xx01xx */ /* xx10xxxx */ /* xxxxxx11 */
        case 0x0E7: /* 11xx01xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_5f(what,num_cycles,clock_div);

            break;
        }

        case 0x00B: /* 00xx10xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x03B: /* 00xx10xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_60(what,num_cycles,clock_div);

            break;
        }

        case 0x01B: /* 00xx10xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_61(what,num_cycles,clock_div);

            break;
        }

        case 0x02B: /* 00xx10xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_62(what,num_cycles,clock_div);

            break;
        }

        case 0x04B: /* 01xx10xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x07B: /* 01xx10xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_63(what,num_cycles,clock_div);

            break;
        }

        case 0x05B: /* 01xx10xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_64(what,num_cycles,clock_div);

            break;
        }

        case 0x06B: /* 01xx10xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_65(what,num_cycles,clock_div);

            break;
        }

        case 0x00F: /* 00xx11xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x03F: /* 00xx11xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_66(what,num_cycles,clock_div);

            break;
        }

        case 0x01F: /* 00xx11xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_67(what,num_cycles,clock_div);

            break;
        }

        case 0x02F: /* 00xx11xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_68(what,num_cycles,clock_div);

            break;
        }

        case 0x04F: /* 01xx11xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x07F: /* 01xx11xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_69(what,num_cycles,clock_div);

            break;
        }

        case 0x05F: /* 01xx11xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_6a(what,num_cycles,clock_div);

            break;
        }

        case 0x06F: /* 01xx11xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_6b(what,num_cycles,clock_div);

            break;
        }

        case 0x08B: /* 10xx10xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x0BB: /* 10xx10xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_6c(what,num_cycles,clock_div);

            break;
        }

        case 0x09B: /* 10xx10xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_6d(what,num_cycles,clock_div);

            break;
        }

        case 0x0AB: /* 10xx10xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_6e(what,num_cycles,clock_div);

            break;
        }

        case 0x0CB: /* 11xx10xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x0FB: /* 11xx10xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_6f(what,num_cycles,clock_div);

            break;
        }

        case 0x0DB: /* 11xx10xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_70(what,num_cycles,clock_div);

            break;
        }

        case 0x0EB: /* 11xx10xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_71(what,num_cycles,clock_div);

            break;
        }

        case 0x08F: /* 10xx11xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x0BF: /* 10xx11xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_72(what,num_cycles,clock_div);

            break;
        }

        case 0x09F: /* 10xx11xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_73(what,num_cycles,clock_div);

            break;
        }

        case 0x0AF: /* 10xx11xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_74(what,num_cycles,clock_div);

            break;
        }

        case 0x0CF: /* 11xx11xx */ /* xx00xxxx */ /* xxxxxx11 */
        case 0x0FF: /* 11xx11xx */ /* xx11xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_75(what,num_cycles,clock_div);

            break;
        }

        case 0x0DF: /* 11xx11xx */ /* xx01xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_76(what,num_cycles,clock_div);

            break;
        }

        default: /* 11xx11xx */ /* xx10xxxx */ /* xxxxxx11 */
        {
            c6545_do_cycles_77(what,num_cycles,clock_div);

            break;
        }
    }

    return;
}

void c6545_do_cycles_00(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_01(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_02(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_03(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_04(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_05(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_06(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_07(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_08(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_09(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_0a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_0b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_0c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_0d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_0e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_0f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_10(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_11(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_12(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_13(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_14(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_15(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_16(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_17(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_18(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_19(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_1a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_1b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_1c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_1d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_1e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_1f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_20(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_21(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_22(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_23(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE00q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE00q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_24(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_25(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_26(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_27(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_28(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_29(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_2a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_2b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_2c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_2d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_2e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_2f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_DO_NOTHING
    DMID_DO_NOTHING
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_DO_NOTHING_NODISP
    DMID_DO_NOTHING_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_30(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_31(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_32(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_33(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_34(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_35(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_36(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_37(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_38(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_39(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_3a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_3b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_3c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_3d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_3e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_3f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_40(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_41(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_42(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_43(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_44(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_45(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_46(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_47(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_48(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_49(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_4a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_4b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_4c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_4d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_4e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_4f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_50(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_51(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_52(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_53(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE10q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE10q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_54(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_55(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_56(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_57(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_58(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_59(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_5a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_5b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_5c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_5d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_5e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_5f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_DO_NOTHING
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_DO_NOTHING_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_60(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_61(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_62(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_63(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_64(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_65(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_66(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_67(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_68(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE001xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE001xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_69(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_6a(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_6b(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE011xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE011xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_6c(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_6d(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_6e(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_6f(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_70(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_71(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_LINEAR(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_LINEAR_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_72(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_73(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_74(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x01F)
    AMID_PART_DO_CYCLE101xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x01F)
    AMID_PART_DO_CYCLE101xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_75(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLExxq
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLExxq_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_76(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE01q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE01q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}

void c6545_do_cycles_77(c6545_state *what, UINT_16 num_cycles, UINT_8 clock_div)
{
  while ( num_cycles > 0 )
  {
   GENERIC_SETUP_PART

   if ( c6545_DISPEN(what) )
   {
    FIRST_PART_DO_CYCLE_ROWCOL(0x00F)
    AMID_PART_DO_CYCLE111xq
    BMID_PART_DO_CYCLE
    CMID_PART_DO_CYCLE11q
    DMID_PART_DO_CYCLE10q
    LAST_PART_DO_CYCLE
   }

   else
   {
    FIRST_PART_DO_CYCLE_ROWCOL_NODISP(0x00F)
    AMID_PART_DO_CYCLE111xq_NODISP
    BMID_PART_DO_CYCLE_NODISP
    CMID_PART_DO_CYCLE11q_NODISP
    DMID_PART_DO_CYCLE10q_NODISP
    LAST_PART_DO_CYCLE_NODISP
   }

   GENERIC_FINAL_PART
  }

  return;
}





