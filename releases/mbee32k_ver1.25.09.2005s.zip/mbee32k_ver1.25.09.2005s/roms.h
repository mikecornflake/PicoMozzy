extern UINT_8 basic_ROM_a[0x02003];
extern UINT_8 basic_ROM_b[0x02003];
extern UINT_8 wordbee_ROM[0x02003];
extern UINT_8 edasm_ROM[0x02003];
extern UINT_8 forth_ROM[0x02003];
extern UINT_8 network_ROM[0x02003];
extern UINT_8 CHAR_ROM[0x02003];

