
#include "z80pio.h"
#include "u_dtype.h"
#include "debmaloc.h"


/*

   +-------+
  -|       |-            
  -|       |-            
  -|       |-            
  -|       |-      \\            __________
  -|       | ====== \\          /  / \    /\
  -|                 \\        /   \ /   /--`
  -|                  \\      / >{|||}  /
  -| z80pio Emulator   \\    |   / \   |
  -|                    _  +-------------+
  -| Alistair Shilton  |_|=|        .... |
  -| apsh@ecr.mu.oz.au     |_____________|
  -| http://           //   \___________/
  -|                  //
  -|                 // 
  -|       | ====== //   
  -|       |-      //    
  -|       |-            
  -|       |-            
  -|       |-            
  -|       |-
   +-------+

   NB: Data for the z80pio is somewhat sketchy, so the functionality of
       this emulator is not likely to be exactly accurate.  I have
       attempted to leave notes at the more important murky points and
       larger assumptions, but not being an expert, I've probably missed
       some.  Here are the main unknowns (to me):

       - what happens if port b is set to mode 2?
       - what happens if port a is mode 2 and port b is not set as required
         by the docs?
       - if an interupt is inhibitted, is this interupt kept in a queue
         to be sent once the inbibition is removed (which I have assumed)
         or is it just lost?
       - what if a byte written to the control byte doesn't match the
         templates given?  For example, what if I write xxxx1011, or
         xxxx1101?
       - what happens when an output, input or whatever cycle is not
         finished and the computer starts another, or changes the mode
         or similar?


   State data
   ==========

   *_reg_output:   output register
   *_reg_input:    input register
   *_reg_mode:     mode byte ab000000
                   ab = 00 mode 0 - output mode
                        01 mode 1 - input mode
                        10 mode 2 - bidirectional mode
                        11 mode 3 - bit mode
   *_reg_intvect:  interupt vector abcdefg0
   *_reg_ioctrl:   I/O register control byte.  For each bit:
                   0 = means output
                   1 = means input
   *_reg_intctrl:  interupt control byte - abc00000
                   a = 0 interupt disable
                       1 interupt enable
                   b = 0 interupt on OR function
                       1 interupt on AND function
                   c = 0 active level is LOW
                       1 active level is HIGH
   *_reg_maskctrl: mask control byte.  For each bit:
                   0 = monitor for interupt if input
                   1 = ignore

   *_regctrl_pending:  0 = normal
                       1 = next write to ctrl port is reg ctrl byte
   *_maskctrl_pending: 0 = normal
                       1 = next write to ctrl port is mask ctrl byte
   *_int_inhibit:      0 = normal
                       1 = ints inhibitted by higher priority device
   *_mode02_state:     0 = no data to send.
                       1 = data sent to destination, waiting for reply.
                       2 = got reply, want to send int, inhibitted.
                       3 = got reply, sent int, waiting for ack.
                       4 = got reply, sent int, waiting for ack, inhibitted.
                       5 = got reply, send int, received ack, wait for reti.
                       6 = got reply, send int, received ack, wait for reti,
                           inhibitted.
   *_mode123_state:    0 = no data received, none expected.
                       1 = asked for data, waiting for reply.
                       2 = data recd, want to send int, inhibitted.
                       3 = data recd, sent int, waiting for ack.
                       4 = data recd, sent int, waiting for ack, inhibitted.
                       5 = data recd, sent int, received ack, wait for reti.
                       6 = data recd, sent int, received ack, wait for reti,
                           inhibitted.
   *_strb_prime:       0 = normal.
                       1 = strb low, waiting for rising edge.

*/

#define DEFAULT_Z80PIO_A_REG_OUTPUT     0x000
#define DEFAULT_Z80PIO_A_REG_INPUT      0x000
#define DEFAULT_Z80PIO_A_REG_MODE       0x001
#define DEFAULT_Z80PIO_A_REG_INTVECT    0x000
#define DEFAULT_Z80PIO_A_REG_IOCTRL     0x0FF
#define DEFAULT_Z80PIO_A_REG_INTCTRL    0x000
#define DEFAULT_Z80PIO_A_REG_MASKCTRL   0x000

#define DEFAULT_Z80PIO_A_REGCTRL_PENDING        0
#define DEFAULT_Z80PIO_A_MASKCTRL_PENDING       0
#define DEFAULT_Z80PIO_A_INT_INHIBIT            0

#define DEFAULT_Z80PIO_B_REG_OUTPUT     0x000
#define DEFAULT_Z80PIO_B_REG_INPUT      0x000
#define DEFAULT_Z80PIO_B_REG_MODE       0x001
#define DEFAULT_Z80PIO_B_REG_INTVECT    0x000
#define DEFAULT_Z80PIO_B_REG_IOCTRL     0x0FF
#define DEFAULT_Z80PIO_B_REG_INTCTRL    0x000
#define DEFAULT_Z80PIO_B_REG_MASKCTRL   0x000

#define DEFAULT_Z80PIO_B_REGCTRL_PENDING        0
#define DEFAULT_Z80PIO_B_MASKCTRL_PENDING       0
#define DEFAULT_Z80PIO_B_INT_INHIBIT            0

#define DEFAULT_Z80PIO_A_RDY    0
#define DEFAULT_Z80PIO_B_RDY    0
#define DEFAULT_Z80PIO_IEO      0


#define Z80PIO_IEO(what)        (*(what->ieo))
#define Z80PIO_IEI(what)        (*(what->iei))
#define Z80PIO_DATA_BUS(what)   (*(what->data_bus))

#define Z80PIO_A_RDY(what)      (*(what->a_rdy))
#define Z80PIO_A_STRB(what)     (*(what->a_strb))
#define Z80PIO_A_DATA(what)     (*(what->a_data))

#define Z80PIO_B_RDY(what)      (*(what->b_rdy))
#define Z80PIO_B_STRB(what)     (*(what->b_strb))
#define Z80PIO_B_DATA(what)     (*(what->b_data))

#define Z80PIO_IEO_ADDR(what)       (what->ieo)
#define Z80PIO_IEI_ADDR(what)       (what->iei)
#define Z80PIO_DATA_BUS_ADDR(what)  (what->data_bus)

#define Z80PIO_A_RDY_ADDR(what)     (what->a_rdy)
#define Z80PIO_A_STRB_ADDR(what)    (what->a_strb)
#define Z80PIO_A_DATA_ADDR(what)    (what->a_data)

#define Z80PIO_B_RDY_ADDR(what)     (what->b_rdy)
#define Z80PIO_B_STRB_ADDR(what)    (what->b_strb)
#define Z80PIO_B_DATA_ADDR(what)    (what->b_data)

#define Z80PIO_A_RDY_DATA_OUT(what)     (*(what->a_rdy_data_out))()
#define Z80PIO_B_RDY_DATA_OUT(what)     (*(what->b_rdy_data_out))()
#define Z80PIO_IEO_OUT(what)            (*(what->ieo_out))()
#define Z80PIO_SIGNAL_INTERUPT(what)    (*(what->signal_interupt))()

#define Z80PIO_A_RDY_DATA_OUT_ADDR(what)     (what->a_rdy_data_out)
#define Z80PIO_B_RDY_DATA_OUT_ADDR(what)     (what->b_rdy_data_out)
#define Z80PIO_IEO_OUT_ADDR(what)            (what->ieo_out)
#define Z80PIO_SIGNAL_INTERUPT_ADDR(what)    (what->signal_interupt)

#define Z80PIO_A_REG_OUTPUT(what)   (what->a_reg_output)
#define Z80PIO_A_REG_INPUT(what)    (what->a_reg_input)
#define Z80PIO_A_REG_MODE(what)     (what->a_reg_mode)
#define Z80PIO_A_REG_INTVECT(what)  (what->a_reg_intvect)
#define Z80PIO_A_REG_IOCTRL(what)   (what->a_reg_ioctrl)
#define Z80PIO_A_REG_INTCTRL(what)  (what->a_reg_intctrl)
#define Z80PIO_A_REG_MASKCTRL(what) (what->a_reg_maskctrl)

#define Z80PIO_A_REGCTRL_PENDING(what)  (what->a_regctrl_pending)
#define Z80PIO_A_MASKCTRL_PENDING(what) (what->a_maskctrl_pending)
#define Z80PIO_A_INT_INHIBIT(what)      (what->a_int_inhibit)
#define Z80PIO_A_MODE02_STATE(what)     (what->a_mode02_state)
#define Z80PIO_A_MODE123_STATE(what)    (what->a_mode123_state)
#define Z80PIO_A_STRB_PRIME(what)       (what->a_strb_prime)

#define Z80PIO_B_REG_OUTPUT(what)   (what->b_reg_output)
#define Z80PIO_B_REG_INPUT(what)    (what->b_reg_input)
#define Z80PIO_B_REG_MODE(what)     (what->b_reg_mode)
#define Z80PIO_B_REG_INTVECT(what)  (what->b_reg_intvect)
#define Z80PIO_B_REG_IOCTRL(what)   (what->b_reg_ioctrl)
#define Z80PIO_B_REG_INTCTRL(what)  (what->b_reg_intctrl)
#define Z80PIO_B_REG_MASKCTRL(what) (what->b_reg_maskctrl)

#define Z80PIO_B_REGCTRL_PENDING(what)  (what->b_regctrl_pending)
#define Z80PIO_B_MASKCTRL_PENDING(what) (what->b_maskctrl_pending)
#define Z80PIO_B_INT_INHIBIT(what)      (what->b_int_inhibit)
#define Z80PIO_B_MODE02_STATE(what)     (what->b_mode02_state)
#define Z80PIO_B_MODE123_STATE(what)    (what->b_mode123_state)
#define Z80PIO_B_STRB_PRIME(what)       (what->b_strb_prime)


inline void z80pio_a_setup_0_mode(z80pio_state *what);
inline void z80pio_a_setup_1_mode(z80pio_state *what);
inline void z80pio_a_setup_2_mode(z80pio_state *what);
inline void z80pio_a_setup_3_mode(z80pio_state *what);

inline void z80pio_b_setup_0_mode(z80pio_state *what);
inline void z80pio_b_setup_1_mode(z80pio_state *what);
inline void z80pio_b_setup_3_mode(z80pio_state *what);

inline void z80pio_a_mode_3_int_gen_test(z80pio_state *what);
inline void z80pio_b_mode_3_int_gen_test(z80pio_state *what);

void z80pio_inhibit_int_from_a(z80pio_state *what);
void z80pio_inhibit_int_from_b(z80pio_state *what);

void z80pio_uninhibit_int_from_a(z80pio_state *what);
void z80pio_uninhibit_int_from_b(z80pio_state *what);



z80pio_state *z80pio_init(UINT_8 *ieo,
                          UINT_8 *iei,
                          UINT_8 *data_bus,
                          UINT_8 *a_rdy,
                          UINT_8 *a_strb,
                          UINT_8 *a_data,
                          UINT_8 *b_rdy,
                          UINT_8 *b_strb,
                          UINT_8 *b_data,
                          weird_pointer_jive a_rdy_data_out,
                          weird_pointer_jive b_rdy_data_out,
                          weird_pointer_jive ieo_out,
                          weird_pointer_jive signal_interupt)
{
    z80pio_state *what;

    if ( ( what = (z80pio_state *) DEBMALLOC(sizeof(z80pio_state)) ) != NULL )
    {
        /*
           Set buses and function pointers.
        */

        Z80PIO_IEO_ADDR(what)      = ieo;
        Z80PIO_IEI_ADDR(what)      = iei;
        Z80PIO_DATA_BUS_ADDR(what) = data_bus;

        Z80PIO_A_RDY_ADDR(what)  = a_rdy;
        Z80PIO_A_STRB_ADDR(what) = a_strb;
        Z80PIO_A_DATA_ADDR(what) = a_data;

        Z80PIO_B_RDY_ADDR(what)  = b_rdy;
        Z80PIO_B_STRB_ADDR(what) = b_strb;
        Z80PIO_B_DATA_ADDR(what) = b_data;

        Z80PIO_A_RDY_DATA_OUT_ADDR(what)  = a_rdy_data_out;
        Z80PIO_B_RDY_DATA_OUT_ADDR(what)  = b_rdy_data_out;
        Z80PIO_IEO_OUT_ADDR(what)         = ieo_out;
        Z80PIO_SIGNAL_INTERUPT_ADDR(what) = signal_interupt;

        /*
           This will set most of the internal state.
        */

        z80pio_reset(what);

        /*
           These are unaffected by reset, so must be set separately on
           powerup.
        */

        Z80PIO_A_REG_INTVECT(what) = DEFAULT_Z80PIO_A_REG_INTVECT;
        Z80PIO_B_REG_INTVECT(what) = DEFAULT_Z80PIO_B_REG_INTVECT;
    }

    return what;
}

void z80pio_reset(z80pio_state *what)
{
    /*
       Reset the pio state.  Note that the vector address registers are
       not reset by the reset signal on a real PIO, and hence are not
       changed here.  Also, mode 1 is a guess.
    */


    Z80PIO_A_REG_OUTPUT(what)   = DEFAULT_Z80PIO_A_REG_OUTPUT;
    Z80PIO_A_REG_INPUT(what)    = DEFAULT_Z80PIO_A_REG_INPUT;
    Z80PIO_A_REG_MODE(what)     = DEFAULT_Z80PIO_A_REG_MODE;
    Z80PIO_A_REG_IOCTRL(what)   = DEFAULT_Z80PIO_A_REG_IOCTRL;
    Z80PIO_A_REG_INTCTRL(what)  = DEFAULT_Z80PIO_A_REG_INTCTRL;
    Z80PIO_A_REG_MASKCTRL(what) = DEFAULT_Z80PIO_A_REG_MASKCTRL;

    Z80PIO_A_REGCTRL_PENDING(what)  = DEFAULT_Z80PIO_A_REGCTRL_PENDING;
    Z80PIO_A_MASKCTRL_PENDING(what) = DEFAULT_Z80PIO_A_MASKCTRL_PENDING;
    Z80PIO_A_INT_INHIBIT(what)      = DEFAULT_Z80PIO_A_INT_INHIBIT;

    Z80PIO_B_REG_OUTPUT(what)   = DEFAULT_Z80PIO_B_REG_OUTPUT;
    Z80PIO_B_REG_INPUT(what)    = DEFAULT_Z80PIO_B_REG_INPUT;
    Z80PIO_B_REG_MODE(what)     = DEFAULT_Z80PIO_B_REG_MODE;
    Z80PIO_B_REG_IOCTRL(what)   = DEFAULT_Z80PIO_B_REG_IOCTRL;
    Z80PIO_B_REG_INTCTRL(what)  = DEFAULT_Z80PIO_B_REG_INTCTRL;
    Z80PIO_B_REG_MASKCTRL(what) = DEFAULT_Z80PIO_B_REG_MASKCTRL;

    Z80PIO_B_REGCTRL_PENDING(what)  = DEFAULT_Z80PIO_B_REGCTRL_PENDING;
    Z80PIO_B_MASKCTRL_PENDING(what) = DEFAULT_Z80PIO_B_MASKCTRL_PENDING;
    Z80PIO_B_INT_INHIBIT(what)      = DEFAULT_Z80PIO_B_INT_INHIBIT;

    /* this is a guess, really */

    z80pio_a_setup_1_mode(what);
    z80pio_b_setup_1_mode(what);

    z80pio_iei_in(what);

    return;
}

void z80pio_remove(z80pio_state *what)
{
    if ( what != NULL )
    {
        DEBFREE(what);
    }

    return;
}

void z80pio_ctrl_wr_A(z80pio_state *what)
{
    if ( Z80PIO_A_REGCTRL_PENDING(what) )
    {
        /*
           The last write set mode 3, so this must be the IO register
           control word.
        */

        Z80PIO_A_REGCTRL_PENDING(what) = 0;
        Z80PIO_A_REG_IOCTRL(what)      = Z80PIO_DATA_BUS(what);

        return;
    }

    if ( Z80PIO_A_MASKCTRL_PENDING(what) )
    {
        /*
           The last write was the interupt control word, and this indicated
           that the next write must be the mask control word.  So this must
           be it.
        */

        Z80PIO_A_MASKCTRL_PENDING(what) = 0;
        Z80PIO_A_REG_MASKCTRL(what)     = Z80PIO_DATA_BUS(what);

        /*
           If bit 4 was set then this also causes any pending interupts
           to be reset.  Hence the following code.
        */

        switch ( Z80PIO_A_REG_MODE(what) )
        {
            case 0x000: /* mode 0 set */
            {
                z80pio_a_setup_0_mode(what);

                break;
            }

            case 0x040: /* mode 1 set */
            {
                z80pio_a_setup_1_mode(what);

                Z80PIO_A_RDY(what)           = 0;
                Z80PIO_A_MODE123_STATE(what) = 1;

                Z80PIO_A_RDY_DATA_OUT(what);

                break;
            }

            case 0x080: /* mode 2 set */
            {
                z80pio_a_setup_2_mode(what);

                Z80PIO_B_RDY(what)           = 0;
                Z80PIO_B_MODE123_STATE(what) = 1;

                break;
            }

            default:    /* mode 3 set */
            {
                z80pio_a_setup_3_mode(what);

                break;
            }
        }

        return;
    }

    if ( Z80PIO_DATA_BUS(what) & 0x001 )
    {
        switch ( Z80PIO_DATA_BUS(what) & 0x00F )
        {
            case 0x00F: /* xxxx1111 == mode control word */
            {
                Z80PIO_A_REG_MODE(what) = Z80PIO_DATA_BUS(what) & 0x0C0;

                switch ( Z80PIO_A_REG_MODE(what) )
                {
                    case 0x000: /* mode 0 set */
                    {
                        z80pio_a_setup_0_mode(what);

                        break;
                    }

                    case 0x040: /* mode 1 set */
                    {
                        z80pio_a_setup_1_mode(what);

                        Z80PIO_A_RDY(what)           = 0;
                        Z80PIO_A_MODE123_STATE(what) = 1;

                        Z80PIO_A_RDY_DATA_OUT(what);

                        break;
                    }

                    case 0x080: /* mode 2 set */
                    {
                        z80pio_a_setup_2_mode(what);

                        Z80PIO_B_RDY(what)           = 0;
                        Z80PIO_B_MODE123_STATE(what) = 1;

                        break;
                    }

                    default:    /* mode 3 set */
                    {
                        z80pio_a_setup_3_mode(what);
                        z80pio_a_mode_3_int_gen_test(what);

                        Z80PIO_A_REGCTRL_PENDING(what) = 1;

                        break;
                    }
                }

                break;
            }

            case 0x007: /* xxxx0111 == interupt control word */
            {
                Z80PIO_A_MASKCTRL_PENDING(what) = Z80PIO_DATA_BUS(what) & 0x010;
                Z80PIO_A_REG_INTCTRL(what)      = Z80PIO_DATA_BUS(what) & 0x0E0;

                break;
            }

            case 0x003: /* xxxx0011 == interupt disable word */
            {
                Z80PIO_A_REG_INTCTRL(what) &= 0x07F;
                Z80PIO_A_REG_INTCTRL(what) |= ( Z80PIO_DATA_BUS(what) & 0x080 );

                break;
            }

            default:   /* unknown control word */
            {
                /*
                   Presumably, this just gets ignored (don't know for sure,
                   though).
                */

                break;
            }
        }
    }

    else
    {
        /*
           LSB == 0, indicating that this must be an interupt vector word.
        */

        Z80PIO_A_REG_INTVECT(what) = Z80PIO_DATA_BUS(what);
    }

    return;
}

void z80pio_ctrl_wr_B(z80pio_state *what)
{
    if ( Z80PIO_B_REGCTRL_PENDING(what) )
    {
        /*
           The last write set mode 3, so this must be the IO register
           control word.
        */

        Z80PIO_B_REGCTRL_PENDING(what) = 0;
        Z80PIO_B_REG_IOCTRL(what)      = Z80PIO_DATA_BUS(what);

        return;
    }

    if ( Z80PIO_B_MASKCTRL_PENDING(what) )
    {
        /*
           The last write was the interupt control word, and this indicated
           that the next write must be the mask control word.  So this must
           be it.
        */

        Z80PIO_B_MASKCTRL_PENDING(what) = 0;
        Z80PIO_B_REG_MASKCTRL(what)     = Z80PIO_DATA_BUS(what);

        /*
           If bit 4 was set then this also causes any pending interupts
           to be reset.  Hence the following code.
        */

        switch ( Z80PIO_B_REG_MODE(what) )
        {
            case 0x000: /* mode 0 set */
            {
                z80pio_b_setup_0_mode(what);

                break;
            }

            case 0x040: /* mode 1 set */
            {
                z80pio_b_setup_1_mode(what);

                Z80PIO_B_RDY(what)           = 0;
                Z80PIO_B_MODE123_STATE(what) = 1;

                Z80PIO_B_RDY_DATA_OUT(what);

                break;
            }

            case 0x080: /* mode 2 set (not allowed?) */
            {
                break;
            }

            default:    /* mode 3 set */
            {
                z80pio_b_setup_3_mode(what);

                break;
            }
        }

        return;
    }

    if ( Z80PIO_DATA_BUS(what) & 0x001 )
    {
        switch ( Z80PIO_DATA_BUS(what) & 0x00F )
        {
            case 0x00F: /* xxxx1111 == mode control word */
            {
                Z80PIO_B_REG_MODE(what) = Z80PIO_DATA_BUS(what) & 0x0C0;

                switch ( Z80PIO_B_REG_MODE(what) )
                {
                    case 0x000: /* mode 0 set */
                    {
                        z80pio_b_setup_0_mode(what);

                        break;
                    }

                    case 0x040: /* mode 1 set */
                    {
                        z80pio_b_setup_1_mode(what);

                        Z80PIO_B_RDY(what)           = 0;
                        Z80PIO_B_MODE123_STATE(what) = 1;

                        Z80PIO_B_RDY_DATA_OUT(what);

                        break;
                    }

                    case 0x080: /* mode 2 set (not allowed?) */
                    {
                        break;
                    }

                    default:    /* mode 3 set */
                    {
                        z80pio_b_setup_3_mode(what);
                        z80pio_b_mode_3_int_gen_test(what);

                        Z80PIO_B_REGCTRL_PENDING(what) = 1;

                        break;
                    }
                }

                break;
            }

            case 0x007: /* xxxx0111 == interupt control word */
            {
                Z80PIO_B_MASKCTRL_PENDING(what) = Z80PIO_DATA_BUS(what) & 0x010;
                Z80PIO_B_REG_INTCTRL(what)      = Z80PIO_DATA_BUS(what) & 0x0E0;

                break;
            }

            case 0x003: /* xxxx0011 == interupt disable word */
            {
                Z80PIO_B_REG_INTCTRL(what) &= 0x07F;
                Z80PIO_B_REG_INTCTRL(what) |= ( Z80PIO_DATA_BUS(what) & 0x080 );

                break;
            }

            default:   /* unknown control word */
            {
                /*
                   Presumably, this just gets ignored (don't know for sure,
                   though).
                */

                break;
            }
        }
    }

    else
    {
        /*
           LSB == 0, indicating that this must be an interupt vector word.
        */

        Z80PIO_B_REG_INTVECT(what) = Z80PIO_DATA_BUS(what);
    }

    return;
}

void z80pio_ctrl_rd_A(z80pio_state *what)
{
    /* this is a guess */

    Z80PIO_DATA_BUS(what) = 0;

    return;
}

void z80pio_ctrl_rd_B(z80pio_state *what)
{
    /* this is a guess */

    Z80PIO_DATA_BUS(what) = 0;

    return;
}

void z80pio_data_wr_A(z80pio_state *what)
{
    switch ( Z80PIO_A_REG_MODE(what) )
    {
        case 0x000:
        {
            Z80PIO_A_REG_OUTPUT(what) = Z80PIO_DATA_BUS(what);

            z80pio_a_setup_0_mode(what);

            Z80PIO_A_RDY(what)          = 1;
            Z80PIO_A_DATA(what)         = Z80PIO_A_REG_OUTPUT(what);
            Z80PIO_A_MODE02_STATE(what) = 1;
            Z80PIO_A_STRB_PRIME(what)   = 0;

            Z80PIO_A_RDY_DATA_OUT(what);

            break;
        }

        case 0x040:
        {
            Z80PIO_A_REG_OUTPUT(what) = Z80PIO_DATA_BUS(what);

            break;
        }

        case 0x080:
        {
            Z80PIO_A_REG_OUTPUT(what) = Z80PIO_DATA_BUS(what);

            z80pio_a_setup_2_mode(what);

            Z80PIO_A_RDY(what)          = 1;
            /* Data doesn't get put on the lines until strobe goes low */
            Z80PIO_A_MODE02_STATE(what) = 1;
            Z80PIO_A_STRB_PRIME(what)   = 0;

            Z80PIO_A_RDY_DATA_OUT(what);

            break;
        }

        case 0x0C0:
        {
            Z80PIO_A_REG_OUTPUT(what)  = Z80PIO_DATA_BUS(what);
            Z80PIO_A_REG_OUTPUT(what) &= ( Z80PIO_A_REG_IOCTRL(what) ^ 0x0ff );
            Z80PIO_A_REG_OUTPUT(what) |= ( Z80PIO_A_REG_INPUT(what) & ( Z80PIO_A_REG_IOCTRL(what) ) );
            Z80PIO_A_REG_INPUT(what)   = Z80PIO_A_REG_OUTPUT(what);

            z80pio_a_setup_3_mode(what);

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_data_wr_B(z80pio_state *what)
{
    switch ( Z80PIO_B_REG_MODE(what) )
    {
        case 0x000:
        {
            Z80PIO_B_REG_OUTPUT(what) = Z80PIO_DATA_BUS(what);

            z80pio_b_setup_0_mode(what);

            Z80PIO_B_RDY(what)          = 1;
            Z80PIO_B_DATA(what)         = Z80PIO_B_REG_OUTPUT(what);
            Z80PIO_B_MODE02_STATE(what) = 1;
            Z80PIO_B_STRB_PRIME(what)   = 0;

            Z80PIO_B_RDY_DATA_OUT(what);

            break;
        }

        case 0x040:
        case 0x080:
        {
            Z80PIO_B_REG_OUTPUT(what) = Z80PIO_DATA_BUS(what);

            break;
        }

        case 0x0C0:
        {
            Z80PIO_B_REG_OUTPUT(what)  = Z80PIO_DATA_BUS(what);
            Z80PIO_B_REG_OUTPUT(what) &= ( Z80PIO_B_REG_IOCTRL(what) ^ 0x0ff );
            Z80PIO_B_REG_OUTPUT(what) |= ( Z80PIO_B_REG_INPUT(what) & ( Z80PIO_B_REG_IOCTRL(what) ) );
            Z80PIO_B_REG_INPUT(what)   = Z80PIO_B_REG_OUTPUT(what);

            z80pio_b_setup_3_mode(what);

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_data_rd_A(z80pio_state *what)
{
    switch ( Z80PIO_A_REG_MODE(what) )
    {
        case 0x000:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_A_REG_OUTPUT(what);

            break;
        }

        case 0x040:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_A_REG_INPUT(what);

            z80pio_a_setup_1_mode(what);

            Z80PIO_A_RDY(what)           = 0;
            Z80PIO_A_MODE123_STATE(what) = 1;

            Z80PIO_A_RDY_DATA_OUT(what);

            break;
        }

        case 0x080:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_A_REG_INPUT(what);

            z80pio_a_setup_2_mode(what);

            Z80PIO_B_RDY(what)           = 0;
            Z80PIO_A_MODE123_STATE(what) = 1;

            Z80PIO_B_RDY_DATA_OUT(what);

            break;
        }

        case 0x0C0:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_A_REG_OUTPUT(what);

            z80pio_a_setup_3_mode(what);

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_data_rd_B(z80pio_state *what)
{
    switch ( Z80PIO_B_REG_MODE(what) )
    {
        case 0x000:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_B_REG_OUTPUT(what);

            break;
        }

        case 0x040:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_B_REG_INPUT(what);

            z80pio_b_setup_1_mode(what);

            Z80PIO_B_RDY(what)           = 0;
            Z80PIO_B_MODE123_STATE(what) = 1;

            Z80PIO_B_RDY_DATA_OUT(what);

            break;
        }

        case 0x0C0:
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_B_REG_OUTPUT(what);

            z80pio_b_setup_3_mode(what);

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_a_strb_data_in(z80pio_state *what)
{
    switch ( Z80PIO_A_REG_MODE(what) )
    {
        case 0x000:
        {
            if ( Z80PIO_A_MODE02_STATE(what) == 1 )
            {
                /* just to make sure */

                Z80PIO_A_RDY(what)  = 1;
                Z80PIO_A_DATA(what) = Z80PIO_A_REG_OUTPUT(what); 

                if ( Z80PIO_A_STRB_PRIME(what) == 0 )
                {
                    /* first, need a high-low transition */

                    if ( Z80PIO_A_STRB(what) == 0 )
                    {
                        Z80PIO_A_STRB_PRIME(what) = 1;
                    }
                }

                else
                {
                    /* do stuff if this is a low-high transition */

                    if ( Z80PIO_A_STRB(what) == 1 )
                    {
                        Z80PIO_A_RDY(what)        = 0;
                        Z80PIO_A_STRB_PRIME(what) = 0;

                        Z80PIO_A_RDY_DATA_OUT(what);


                        if ( Z80PIO_A_REG_INTCTRL(what) & 0x080 )
                        {
                            if ( Z80PIO_A_INT_INHIBIT(what) )
                            {
                                Z80PIO_A_MODE02_STATE(what) = 2;
                            }

                            else
                            {
                                z80pio_inhibit_int_from_a(what);

                                Z80PIO_A_MODE02_STATE(what) = 3;

                                Z80PIO_SIGNAL_INTERUPT(what);
                            }
                        }

                        else
                        {
                            z80pio_a_setup_0_mode(what);
                        }
                    }
                }
            }

            break;
        }

        case 0x040:
        {
            if ( Z80PIO_A_MODE123_STATE(what) == 1 )
            {
                /* just to make sure */

                Z80PIO_A_RDY(what) = 0;

                if ( Z80PIO_A_STRB_PRIME(what) == 0 )
                {
                    if ( Z80PIO_A_STRB(what) == 0 )
                    {
                        Z80PIO_A_STRB_PRIME(what) = 1;
                    }
                }

                else
                {
                    if ( Z80PIO_A_STRB(what) == 1 )
                    {
                        Z80PIO_A_REG_INPUT(what) = Z80PIO_A_DATA(what);

                        Z80PIO_A_RDY(what)        = 1;
                        Z80PIO_A_STRB_PRIME(what) = 0;

                        Z80PIO_A_RDY_DATA_OUT(what);

                        if ( Z80PIO_A_REG_INTCTRL(what) & 0x080 )
                        {
                            if ( Z80PIO_A_INT_INHIBIT(what) )
                            {
                                Z80PIO_A_MODE123_STATE(what) = 2;
                            }

                            else
                            {
                                z80pio_inhibit_int_from_a(what);

                                Z80PIO_A_MODE123_STATE(what) = 3;

                                Z80PIO_SIGNAL_INTERUPT(what);
                            }
                        }

                        else
                        {
                            z80pio_a_setup_1_mode(what);
                        }
                    }
                }
            }

            break;
        }

        case 0x080:
        {
            if ( Z80PIO_A_MODE02_STATE(what) == 1 )
            {
                /* just to make sure */

                Z80PIO_A_RDY(what) = 1;

                if ( Z80PIO_A_STRB_PRIME(what) == 0 )
                {
                    if ( Z80PIO_A_STRB(what) == 0 )
                    {
                        /* in mode 2, data is put onto the bus now */

                        Z80PIO_A_DATA(what) = Z80PIO_A_REG_OUTPUT(what);

                        Z80PIO_A_STRB_PRIME(what) = 1;

                        Z80PIO_A_RDY_DATA_OUT(what);
                    }
                }

                else
                {
                    if ( Z80PIO_A_STRB(what) == 1 )
                    {
                        Z80PIO_A_RDY(what)        = 0;
                        Z80PIO_A_STRB_PRIME(what) = 0;

                        Z80PIO_A_RDY_DATA_OUT(what);

                        if ( Z80PIO_A_REG_INTCTRL(what) & 0x080 )
                        {
                            if ( Z80PIO_A_INT_INHIBIT(what) )
                            {
                                Z80PIO_A_MODE02_STATE(what) = 2;
                            }

                            else
                            {
                                z80pio_inhibit_int_from_a(what);

                                Z80PIO_A_MODE02_STATE(what) = 3;

                                Z80PIO_SIGNAL_INTERUPT(what);
                            }
                        }

                        else
                        {
                            z80pio_a_setup_2_mode(what);
                        }
                    }
                }
            }

            break;
        }

        case 0x0C0:
        {
            Z80PIO_A_REG_INPUT(what)   = Z80PIO_A_DATA(what);
            Z80PIO_A_REG_OUTPUT(what) &= ( Z80PIO_A_REG_IOCTRL(what) ^ 0x0ff );
            Z80PIO_A_REG_OUTPUT(what) |= ( Z80PIO_A_REG_INPUT(what) & ( Z80PIO_A_REG_IOCTRL(what) ) );
            Z80PIO_A_REG_INPUT(what)   = Z80PIO_A_REG_OUTPUT(what);

            z80pio_a_mode_3_int_gen_test(what);

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_b_strb_data_in(z80pio_state *what)
{
    switch ( Z80PIO_B_REG_MODE(what) )
    {
        case 0x000:
        {
            if ( Z80PIO_B_MODE02_STATE(what) == 1 )
            {
                /* just to make sure */

                Z80PIO_B_RDY(what)  = 1;
                Z80PIO_B_DATA(what) = Z80PIO_B_REG_OUTPUT(what); 

                if ( Z80PIO_B_STRB_PRIME(what) == 0 )
                {
                    if ( Z80PIO_B_STRB(what) == 0 )
                    {
                        Z80PIO_B_STRB_PRIME(what) = 1;
                    }
                }

                else
                {
                    if ( Z80PIO_B_STRB(what) == 1 )
                    {
                        Z80PIO_B_RDY(what)        = 0;
                        Z80PIO_B_STRB_PRIME(what) = 0;

                        Z80PIO_B_RDY_DATA_OUT(what);

                        if ( Z80PIO_B_REG_INTCTRL(what) & 0x080 )
                        {
                            if ( Z80PIO_B_INT_INHIBIT(what) )
                            {
                                Z80PIO_B_MODE02_STATE(what) = 2;
                            }

                            else
                            {
                                z80pio_inhibit_int_from_b(what);

                                Z80PIO_B_MODE02_STATE(what) = 3;

                                Z80PIO_SIGNAL_INTERUPT(what);
                            }
                        }

                        else
                        {
                            z80pio_b_setup_0_mode(what);
                        }
                    }
                }
            }

            break;
        }

        case 0x040:
        {
            if ( Z80PIO_B_MODE123_STATE(what) == 1 )
            {
                /* just to make sure */

                Z80PIO_B_RDY(what) = 0;

                if ( Z80PIO_B_STRB_PRIME(what) == 0 )
                {
                    if ( Z80PIO_B_STRB(what) == 0 )
                    {
                        Z80PIO_B_STRB_PRIME(what) = 1;
                    }
                }

                else
                {
                    if ( Z80PIO_B_STRB(what) == 1 )
                    {
                        Z80PIO_B_REG_INPUT(what) = Z80PIO_B_DATA(what);

                        Z80PIO_B_RDY(what)        = 1;
                        Z80PIO_B_STRB_PRIME(what) = 0;

                        Z80PIO_B_RDY_DATA_OUT(what);

                        if ( Z80PIO_B_REG_INTCTRL(what) & 0x080 )
                        {
                            if ( Z80PIO_B_INT_INHIBIT(what) )
                            {
                                Z80PIO_B_MODE123_STATE(what) = 2;
                            }

                            else
                            {
                                z80pio_inhibit_int_from_b(what);

                                Z80PIO_B_MODE123_STATE(what) = 3;

                                Z80PIO_SIGNAL_INTERUPT(what);
                            }
                        }

                        else
                        {
                            z80pio_b_setup_1_mode(what);
                        }
                    }
                }
            }

            break;
        }

        case 0x0C0:
        {
            Z80PIO_B_REG_INPUT(what)   = Z80PIO_B_DATA(what);
            Z80PIO_B_REG_OUTPUT(what) &= ( Z80PIO_B_REG_IOCTRL(what) ^ 0x0ff );
            Z80PIO_B_REG_OUTPUT(what) |= ( Z80PIO_B_REG_INPUT(what) & ( Z80PIO_B_REG_IOCTRL(what) ) );
            Z80PIO_B_REG_INPUT(what)   = Z80PIO_B_REG_OUTPUT(what);

            z80pio_b_mode_3_int_gen_test(what);

            break;
        }

        default:
        {
            break;
        }
    }

    if ( ( Z80PIO_A_REG_MODE(what) == 0x080 ) && ( Z80PIO_A_MODE123_STATE(what) == 1 ) )
    {
        /* just to make sure */

        Z80PIO_B_RDY(what) = 0;

        if ( Z80PIO_B_STRB_PRIME(what) == 0 )
        {
            if ( Z80PIO_B_STRB(what) == 0 )
            {
                Z80PIO_B_STRB_PRIME(what) = 1;
            }
        }

        else
        {
            if ( Z80PIO_B_STRB(what) == 1 )
            {
                Z80PIO_A_REG_INPUT(what) = Z80PIO_A_DATA(what);

                Z80PIO_B_RDY(what)        = 1;
                Z80PIO_B_STRB_PRIME(what) = 0;

                Z80PIO_B_RDY_DATA_OUT(what);

                if ( Z80PIO_A_REG_INTCTRL(what) & 0x080 )
                {
                    if ( Z80PIO_A_INT_INHIBIT(what) )
                    {
                        Z80PIO_A_MODE123_STATE(what) = 2;
                    }

                    else
                    {
                        z80pio_inhibit_int_from_a(what);

                        Z80PIO_A_MODE123_STATE(what) = 3;

                        Z80PIO_SIGNAL_INTERUPT(what);
                    }
                }

                else
                {
                    z80pio_a_setup_2_mode(what);
                }
            }
        }
    }

    return;
}

void z80pio_iei_in(z80pio_state *what)
{
    if ( Z80PIO_IEI(what) )
    {
        Z80PIO_A_INT_INHIBIT(what) = 1;

        switch ( Z80PIO_A_MODE02_STATE(what) )
        {
            case 0:
            case 1:
            {
                z80pio_inhibit_int_from_a(what);

                break;
            }

            case 3:
            {
                Z80PIO_A_MODE02_STATE(what) = 4;

                z80pio_inhibit_int_from_a(what);

                break;
            }

            case 5:
            {
                Z80PIO_A_MODE02_STATE(what) = 6;

                z80pio_inhibit_int_from_a(what);

                break;
            }

            default:
            {
                break;
            }
        }

        switch ( Z80PIO_A_MODE123_STATE(what) )
        {
            case 0:
            case 1:
            {
                z80pio_inhibit_int_from_a(what);

                break;
            }

            case 3:
            {
                Z80PIO_A_MODE123_STATE(what) = 4;

                z80pio_inhibit_int_from_a(what);

                break;
            }

            case 5:
            {
                Z80PIO_A_MODE123_STATE(what) = 6;

                z80pio_inhibit_int_from_a(what);

                break;
            }

            default:
            {
                break;
            }
        }
    }

    else
    {
        Z80PIO_A_INT_INHIBIT(what) = 0;

        switch ( Z80PIO_A_MODE02_STATE(what) )
        {
            case 0:
            case 1:
            {
                z80pio_uninhibit_int_from_a(what);

                break;
            }

            case 2:
            {
                z80pio_inhibit_int_from_a(what);

                Z80PIO_A_MODE02_STATE(what) = 3;

                Z80PIO_SIGNAL_INTERUPT(what);

                break;
            }

            case 4:
            {
                Z80PIO_A_MODE02_STATE(what) = 3;

                break;
            }

            case 6:
            {
                Z80PIO_A_MODE02_STATE(what) = 5;

                break;
            }

            default:
            {
                break;
            }
        }

        switch ( Z80PIO_A_MODE123_STATE(what) )
        {
            case 0:
            case 1:
            {
                z80pio_uninhibit_int_from_a(what);

                break;
            }

            case 2:
            {
                z80pio_inhibit_int_from_a(what);

                Z80PIO_A_MODE02_STATE(what) = 3;

                Z80PIO_SIGNAL_INTERUPT(what);

                break;
            }

            case 4:
            {
                Z80PIO_A_MODE123_STATE(what) = 3;

                break;
            }

            case 6:
            {
                Z80PIO_A_MODE123_STATE(what) = 5;

                break;
            }

            default:
            {
                break;
            }
        }
    }

    return;
}

void z80pio_ack_int(z80pio_state *what)
{
    Z80PIO_DATA_BUS(what) = 0;

    if ( Z80PIO_A_MODE02_STATE(what) == 3 )
    {
        Z80PIO_DATA_BUS(what) = Z80PIO_A_REG_INTVECT(what);

        Z80PIO_A_MODE02_STATE(what) = 5;
    }

    if ( Z80PIO_B_MODE02_STATE(what) == 3 )
    {
        Z80PIO_DATA_BUS(what) = Z80PIO_B_REG_INTVECT(what);

        Z80PIO_B_MODE02_STATE(what) = 5;
    }

    if ( Z80PIO_A_MODE123_STATE(what) == 3 )
    {
        if ( Z80PIO_A_REG_MODE(what) == 0x080 )
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_B_REG_INTVECT(what);
        }

        else
        {
            Z80PIO_DATA_BUS(what) = Z80PIO_A_REG_INTVECT(what);
        }

        Z80PIO_A_MODE123_STATE(what) = 5;
    }

    if ( Z80PIO_B_MODE123_STATE(what) == 3 )
    {
        Z80PIO_DATA_BUS(what) = Z80PIO_B_REG_INTVECT(what);

        Z80PIO_B_MODE123_STATE(what) = 5;
    }

    return;
}

void z80pio_reti_signal(z80pio_state *what)
{
    if ( Z80PIO_A_MODE02_STATE(what) == 5 )
    {
        Z80PIO_A_MODE02_STATE(what) = 0;

        z80pio_uninhibit_int_from_a(what);
    }

    if ( Z80PIO_B_MODE02_STATE(what) == 5 )
    {
        Z80PIO_B_MODE02_STATE(what) = 0;

        z80pio_uninhibit_int_from_b(what);
    }

    if ( Z80PIO_A_MODE123_STATE(what) == 5 )
    {
        Z80PIO_A_MODE123_STATE(what) = 0;

        z80pio_uninhibit_int_from_a(what);
    }

    if ( Z80PIO_B_MODE123_STATE(what) == 5 )
    {
        Z80PIO_B_MODE123_STATE(what) = 0;

        z80pio_uninhibit_int_from_b(what);
    }

    return;
}



void z80pio_a_setup_0_mode(z80pio_state *what)
{
    Z80PIO_A_STRB_PRIME(what) = 0;

    Z80PIO_A_REG_MODE(what) = 0x000;

    Z80PIO_A_MODE02_STATE(what)  = 0;
    Z80PIO_A_MODE123_STATE(what) = 0;

    Z80PIO_A_RDY(what)  = 0;
    Z80PIO_A_DATA(what) = Z80PIO_A_REG_OUTPUT(what);

    Z80PIO_A_RDY_DATA_OUT(what);

    return;
}

void z80pio_a_setup_1_mode(z80pio_state *what)
{
    Z80PIO_A_STRB_PRIME(what) = 0;

    Z80PIO_A_REG_MODE(what) = 0x040;

    Z80PIO_A_MODE02_STATE(what)  = 0;
    Z80PIO_A_MODE123_STATE(what) = 0;

    Z80PIO_A_RDY(what) = 1;

    Z80PIO_A_RDY_DATA_OUT(what);

    return;
}

void z80pio_a_setup_2_mode(z80pio_state *what)
{
    Z80PIO_A_STRB_PRIME(what) = 0;
    Z80PIO_B_STRB_PRIME(what) = 0;

    Z80PIO_A_REG_MODE(what) = 0x080;

    Z80PIO_A_MODE02_STATE(what)  = 0;
    Z80PIO_A_MODE123_STATE(what) = 0;

    Z80PIO_A_RDY(what) = 0;

    Z80PIO_A_RDY_DATA_OUT(what);

    Z80PIO_B_RDY(what) = 1;

    Z80PIO_B_RDY_DATA_OUT(what);

    return;
}

void z80pio_a_setup_3_mode(z80pio_state *what)
{
    Z80PIO_A_STRB_PRIME(what) = 0;

    Z80PIO_A_REG_MODE(what) = 0x0C0;

    Z80PIO_A_MODE02_STATE(what)  = 0;
    Z80PIO_A_MODE123_STATE(what) = 0;

    Z80PIO_A_RDY(what) = DEFAULT_Z80PIO_A_RDY;

    Z80PIO_A_DATA(what) &= Z80PIO_A_REG_IOCTRL(what);
    Z80PIO_A_DATA(what) |= ( Z80PIO_A_REG_OUTPUT(what) & ( Z80PIO_A_REG_IOCTRL(what) ^ 0x0FF ) );

    Z80PIO_A_RDY_DATA_OUT(what);

    return;
}

void z80pio_b_setup_0_mode(z80pio_state *what)
{
    Z80PIO_B_STRB_PRIME(what) = 0;

    Z80PIO_B_REG_MODE(what) = 0x000;

    Z80PIO_B_MODE02_STATE(what)  = 0;
    Z80PIO_B_MODE123_STATE(what) = 0;

    Z80PIO_B_RDY(what)  = 0;
    Z80PIO_B_DATA(what) = Z80PIO_B_REG_OUTPUT(what);

    Z80PIO_B_RDY_DATA_OUT(what);

    return;
}

void z80pio_b_setup_1_mode(z80pio_state *what)
{
    Z80PIO_B_STRB_PRIME(what) = 0;

    Z80PIO_B_REG_MODE(what) = 0x040;

    Z80PIO_B_MODE02_STATE(what)  = 0;
    Z80PIO_B_MODE123_STATE(what) = 0;

    Z80PIO_B_RDY(what) = 1;

    Z80PIO_B_RDY_DATA_OUT(what);

    return;
}

void z80pio_b_setup_3_mode(z80pio_state *what)
{
    Z80PIO_B_STRB_PRIME(what) = 0;

    Z80PIO_B_REG_MODE(what) = 0x0C0;

    Z80PIO_B_MODE02_STATE(what)  = 0;
    Z80PIO_B_MODE123_STATE(what) = 0;

    Z80PIO_B_RDY(what) = DEFAULT_Z80PIO_B_RDY;

    Z80PIO_B_DATA(what) &= Z80PIO_B_REG_IOCTRL(what);
    Z80PIO_B_DATA(what) |= ( Z80PIO_B_REG_OUTPUT(what) & ( Z80PIO_B_REG_IOCTRL(what) ^ 0x0FF ) );

    Z80PIO_B_RDY_DATA_OUT(what);

    return;
}

void z80pio_a_mode_3_int_gen_test(z80pio_state *what)
{
    UINT_16 i;
    UINT_8 is_int = 0;

    if ( Z80PIO_A_REG_INTCTRL(what) & 0x080 )
    {
        switch ( Z80PIO_A_REG_INTCTRL(what) & 0x060 )
        {
            case 0x000:
            {
                /* LOW OR */

                is_int = 0;

                for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                {
                    /* its an input   */
                    /* its not masked */
                    /* its low        */

                    if (  ( Z80PIO_A_REG_IOCTRL(what)   & i ) &&
                         !( Z80PIO_A_REG_MASKCTRL(what) & i ) &&
                         !( Z80PIO_A_DATA(what)         & i )    )
                    {
                        is_int = 1;
                    }
                }

                break;
            }

            case 0x020:
            {
                /* HIGH OR */

                is_int = 0;

                for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                {
                    /* its an input   */
                    /* its not masked */
                    /* its high       */

                    if (  ( Z80PIO_A_REG_IOCTRL(what)   & i ) &&
                         !( Z80PIO_A_REG_MASKCTRL(what) & i ) &&
                          ( Z80PIO_A_DATA(what)         & i )    )
                    {
                        is_int = 1;
                    }
                }

                break;
            }

            case 0x040:
            {
                /* LOW AND */

                is_int = 0;

                if ( Z80PIO_A_REG_MASKCTRL(what) != 0x0FF )
                {
                    is_int = 1;

                    for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                    {
                        /* its an input   */
                        /* its not masked */
                        /* its high       */

                        if (  ( Z80PIO_A_REG_IOCTRL(what)   & i ) &&
                             !( Z80PIO_A_REG_MASKCTRL(what) & i ) &&
                              ( Z80PIO_A_DATA(what)         & i )    )
                        {
                            is_int = 0;
                        }
                    }
                }

                break;
            }

            default: /* case 0x060: */
            {
                /* HIGH AND */

                is_int = 0;

                if ( Z80PIO_A_REG_MASKCTRL(what) != 0x0FF )
                {
                    is_int = 1;

                    for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                    {
                        /* its an input   */
                        /* its not masked */
                        /* its low        */

                        if (  ( Z80PIO_A_REG_IOCTRL(what)   & i ) &&
                             !( Z80PIO_A_REG_MASKCTRL(what) & i ) &&
                             !( Z80PIO_A_DATA(what)         & i )    )
                        {
                            is_int = 0;
                        }
                    }
                }

                break;
            }
        }

        if ( is_int )
        {
            if ( Z80PIO_A_INT_INHIBIT(what) )
            {
                Z80PIO_A_MODE123_STATE(what) = 2;
            }

            else
            {
                z80pio_inhibit_int_from_a(what);

                Z80PIO_A_MODE123_STATE(what) = 3;

                Z80PIO_SIGNAL_INTERUPT(what);
            }
        }
    }

    return;
}

void z80pio_b_mode_3_int_gen_test(z80pio_state *what)
{
    UINT_16 i;
    UINT_8 is_int = 0;

    /* interupts are enabled   */
    /* port a is not in mode 2 */

    if ( ( Z80PIO_B_REG_INTCTRL(what)  & 0x080 ) &&
         ( Z80PIO_A_REG_MODE(what)    != 0x080 )    )
    {
        switch ( Z80PIO_B_REG_INTCTRL(what) & 0x060 )
        {
            case 0x000:
            {
                /* LOW OR */

                is_int = 0;

                for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                {
                    /* its an input   */
                    /* its not masked */
                    /* its low        */

                    if (  ( Z80PIO_B_REG_IOCTRL(what)   & i ) &&
                         !( Z80PIO_B_REG_MASKCTRL(what) & i ) &&
                         !( Z80PIO_B_DATA(what)         & i )    )
                    {
                        is_int = 1;
                    }
                }

                break;
            }

            case 0x020:
            {
                /* HIGH OR */

                is_int = 0;

                for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                {
                    /* its an input   */
                    /* its not masked */
                    /* its high       */

                    if (  ( Z80PIO_B_REG_IOCTRL(what)   & i ) &&
                         !( Z80PIO_B_REG_MASKCTRL(what) & i ) &&
                          ( Z80PIO_B_DATA(what)         & i )    )
                    {
                        is_int = 1;
                    }
                }

                break;
            }

            case 0x040:
            {
                /* LOW AND */

                is_int = 0;

                if ( Z80PIO_B_REG_MASKCTRL(what) != 0x0FF )
                {
                    is_int = 1;

                    for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                    {
                        /* its an input   */
                        /* its not masked */
                        /* its high       */

                        if (  ( Z80PIO_B_REG_IOCTRL(what)   & i ) &&
                             !( Z80PIO_B_REG_MASKCTRL(what) & i ) &&
                              ( Z80PIO_B_DATA(what)         & i )    )
                        {
                            is_int = 0;
                        }
                    }
                }

                break;
            }

            default: /* case 0x060: */
            {
                /* HIGH AND */

                is_int = 0;

                if ( Z80PIO_B_REG_MASKCTRL(what) != 0x0FF )
                {
                    is_int = 1;

                    for ( i = 0x00001 ; i < 0x00100 ; i *= 2 )
                    {
                        /* its an input   */
                        /* its not masked */
                        /* its low        */

                        if (  ( Z80PIO_B_REG_IOCTRL(what)   & i ) &&
                             !( Z80PIO_B_REG_MASKCTRL(what) & i ) &&
                             !( Z80PIO_B_DATA(what)         & i )    )
                        {
                            is_int = 0;
                        }
                    }
                }

                break;
            }
        }

        if ( is_int )
        {
            if ( Z80PIO_B_INT_INHIBIT(what) )
            {
                Z80PIO_B_MODE123_STATE(what) = 2;
            }

            else
            {
                z80pio_inhibit_int_from_b(what);

                Z80PIO_B_MODE123_STATE(what) = 3;

                Z80PIO_SIGNAL_INTERUPT(what);
            }
        }
    }

    return;
}

void z80pio_inhibit_int_from_a(z80pio_state *what)
{
    Z80PIO_B_INT_INHIBIT(what) = 1;

    switch ( Z80PIO_B_MODE02_STATE(what) )
    {
        case 0:
        case 1:
        {
            z80pio_inhibit_int_from_b(what);

            break;
        }

        case 3:
        {
            Z80PIO_B_MODE02_STATE(what) = 4;

            z80pio_inhibit_int_from_b(what);

            break;
        }

        case 5:
        {
            Z80PIO_B_MODE02_STATE(what) = 6;

            z80pio_inhibit_int_from_b(what);

            break;
        }

        default:
        {
            break;
        }
    }

    switch ( Z80PIO_B_MODE123_STATE(what) )
    {
        case 0:
        case 1:
        {
            z80pio_inhibit_int_from_b(what);

            break;
        }

        case 3:
        {
            Z80PIO_B_MODE123_STATE(what) = 4;

            z80pio_inhibit_int_from_b(what);

            break;
        }

        case 5:
        {
            Z80PIO_B_MODE123_STATE(what) = 6;

            z80pio_inhibit_int_from_b(what);

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_inhibit_int_from_b(z80pio_state *what)
{
    Z80PIO_IEO(what) = 1;

    Z80PIO_IEO_OUT(what);

    return;
}

void z80pio_uninhibit_int_from_a(z80pio_state *what)
{
    Z80PIO_B_INT_INHIBIT(what) = 0;

    switch ( Z80PIO_B_MODE02_STATE(what) )
    {
        case 0:
        case 1:
        {
            z80pio_uninhibit_int_from_b(what);

            break;
        }

        case 2:
        {
            Z80PIO_B_MODE02_STATE(what) = 3;

            Z80PIO_SIGNAL_INTERUPT(what);

            break;
        }

        case 4:
        {
            Z80PIO_B_MODE02_STATE(what) = 3;

            break;
        }

        case 6:
        {
            Z80PIO_B_MODE02_STATE(what) = 5;

            break;
        }

        default:
        {
            break;
        }
    }

    switch ( Z80PIO_B_MODE123_STATE(what) )
    {
        case 0:
        case 1:
        {
            z80pio_uninhibit_int_from_b(what);

            break;
        }

        case 2:
        {
            Z80PIO_B_MODE123_STATE(what) = 3;

            Z80PIO_SIGNAL_INTERUPT(what);

            break;
        }

        case 4:
        {
            Z80PIO_B_MODE123_STATE(what) = 3;

            break;
        }

        case 6:
        {
            Z80PIO_B_MODE123_STATE(what) = 5;

            break;
        }

        default:
        {
            break;
        }
    }

    return;
}

void z80pio_uninhibit_int_from_b(z80pio_state *what)
{
    Z80PIO_IEO(what) = 0;

    Z80PIO_IEO_OUT(what);

    return;
}

