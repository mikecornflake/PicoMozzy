 
/*
   Windows parallel/serial:

   http://www.geocities.com/firepower_50ae/CodeNote/WinAPIfaq.html

   (mingw32 faq)
*/

#include "u_dtype.h"
#include "configer.h"


#ifndef _beelowpc_h
#define _beelowpc_h

#ifndef BUS_PREFIX
#define BUS_PREFIX extern
#endif

/*
   Close to hardware stuff, or potentially os dependent.
*/

BUS_PREFIX int beelowpc_trigger_pulse;
BUS_PREFIX int beelowpc_lpt_port;

void gen_sndcycle(UINT_16 num_cycles, UINT_8 speaker_state);
void gen_nosound(void);
void gen_sound(int freq);
void gen_soundclick(void);

char **splash_screen_green(void);
char **splash_screen_colour(void);

int splash_graphic(char **whatsplash);

int init_parallel_state(void);
int write_parallel_state(UINT_8 data, UINT_8 ready);
int read_parallel_state(UINT_8 *data, UINT_8 *strobe);

int init_parallel_state_bios(void);
int print_parallel_bios(UINT_8 data);

SetupData *beelowpc_setup(void);
int        beelowpc_init(void);
int        beelowpc_remove(void);

#define CTRL_DEF_PRINT  0x00E

/*
   Capabilities:

   PARALLEL_ACCESSIBLE is defined if hardware access to the parallel port
   is possible under the current OS.
*/


#ifdef IS_CYGWIN
/*#define PARALLEL_ACCESSABLE_ALL*/
/*#define PARALLEL_ACCESSABLE_BIOS_ONLY*/
/*#define PARALLEL_ACCESSABLE_HW_ONLY */
#define PARALLEL_HIDDEN
#define USE_SOUNDCARD
#endif

#ifndef IS_CYGWIN
#define PARALLEL_ACCESSABLE_ALL
/*#define PARALLEL_ACCESSABLE_BIOS_ONLY */
/*#define PARALLEL_ACCESSABLE_HW_ONLY */
/*#define PARALLEL_HIDDEN */
#define PC_SPEAKER_AVAILABLE
#define USE_PC_SPEAKER
#endif

#ifdef DOSTEST_SOUNDCARD
#undef USE_PC_SPEAKER
#define USE_SOUNDCARD
#endif

#ifdef PARALLEL_ACCESSABLE_ALL
#define BEELOWPC_SYNC_CLOCK                                             \
{                                                                       \
    if ( beelowpc_trigger_pulse )                                       \
    {                                                                   \
        beelowpc_trigger_pulse--;                                       \
                                                                        \
        if ( !beelowpc_trigger_pulse )                                  \
        {                                                               \
            outportb(beelowpc_lpt_port+2,0x00C);                        \
        }                                                               \
    }                                                                   \
}
#endif

#ifndef PARALLEL_ACCESSABLE_ALL
#ifdef PARALLEL_ACCESSABLE_HW_ONLY
#define BEELOWPC_SYNC_CLOCK                                             \
{                                                                       \
    if ( beelowpc_trigger_pulse )                                       \
    {                                                                   \
        beelowpc_trigger_pulse--;                                       \
                                                                        \
        if ( !beelowpc_trigger_pulse )                                  \
        {                                                               \
            outportb(beelowpc_lpt_port+2,0x00C);                        \
        }                                                               \
    }                                                                   \
}
#endif

#ifndef PARALLEL_ACCESSABLE_HW_ONLY
#define BEELOWPC_SYNC_CLOCK
#endif
#endif

#ifndef PARALLEL_ACCESSABLE_ALL
#define BEELOWPC_SYNC_CLOCK
#endif

/*
   Oddities: The pause key on the pc is weird (but in a standard way).
   Rather than two calls for a lowlevel keyboard callback (once for
   press, once for release), there is just one for press, which alternates
   between press and release codes.

   Comment out for other, more sane, architectures.
*/

#define STICKY_PAUSE

#endif
