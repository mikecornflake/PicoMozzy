
#include "fakealeg.h"
#include "beescrn.h"
#include "u_dtype.h"
#include "6545.h"
#include "configer.h"
#include "debmaloc.h"

/*
                            The Microbee Screen
                            ===================

   The microbee screen is memory mapped and controlled by the 6545.  The
   following callback functions control the operation of the screen:

   beescrn_change_left_margin:  change the left margin of the virtual screen.
   beescrn_change_screen_width: change the width of the virtual screen.
   beescrn_change_right_margin: change the right margin of the virtual screen.

   beescrn_change_top_margin:    change the top margin of the virtual screen.
   beescrn_change_screen_height: change the height of the virtual screen.
   beescrn_change_bottom_margin: change the bottom margin of the virtual screen.


   The following control functions are also provided:

   beescrn_init:                  install the screen emulation, setup bitmaps etc.
   beescrn_remove:                remove the screen emulation.
   beescrn_blank_screen:          blank the virtual screen.
   beescrn_blank_physical_screen: blank the physical screen.
   beescrn_refresh_bee_screen:    blit the virtual screen to the physical (ish).


   Screen Position and size
   ========================

   The size and geometry of the screen is:

      (0,0)-------(bw,0)-----------(bw+sw,0)--------(PSW,0)
        |                                               |
      (0,bh)      (bw,bh)----------(bw+sw,bh)       (PSW,bh)
        |            |*******************|              |
        |            |****Bee screen*****|              |
        |            |*******************|              |
      (0,bh+sh)   (bw,bh+sh)-------(bw+sw,bh+sh)   (PSW,bh+sh)
        |                                               |
      (0,PSH)-----(bw,PSH)---------(bw+sw,PSH)------(PSW,PSH)


   where: bh = beescrn_l_top_offset*vert_line_multiplier
          bw = beescrn_l_left_offset*horiz_line_multiplier
          sh = beescrn_l_s_height*vert_line_multiplier
          sw = beescrn_l_s_width*horiz_line_multiplier

          PSW = physical_screen_width-1
          PSH = physical_screen_height-1


   COLOUR PALLETTE
   ===============

   Colour depth is 8 bits.  These colours are programmed in the pallette as
   follows.  First, bit 7 is always set (allegro considers 00 see-through).
   Otherwise, the low 6 bits are the standard microbee colour selections:

   bit 0: RED intensity
   bit 1: GREEN intensity
   bit 2: BLUE intensity
   bit 3: RED
   bit 4: GREEN
   bit 5: BLUE

    80 - Black
    81 - Black
    82 - Black
    83 - Black
    84 - Black
    85 - Black
    86 - Black
    87 - Black
    88 -                       Blue half
    89 -                       Blue full
    8A -                       Blue half
    8B -                       Blue full
    8C -                       Blue half
    8D -                       Blue full
    8E -                       Blue half
    8F -                       Blue full
    90 -           Green half
    91 -           Green half
    92 -           Green full
    93 -           Green full
    94 -           Green half
    95 -           Green half
    96 -           Green full
    97 -           Green full
    98 -           Green half, Blue half
    99 -           Green half, Blue full
    9A -           Green full, Blue half
    9B -           Green full, Blue full
    9C -           Green half, Blue half
    9D -           Green half, Blue full
    9E -           Green full, Blue half
    9F -           Green full, Blue full
    A0 - Red half
    A1 - Red half
    A2 - Red half
    A3 - Red half
    A4 - Red full
    A5 - Red full
    A6 - Red full
    A7 - Red full
    A8 - Red half,             Blue half
    A9 - Red half,             Blue full
    AA - Red half,             Blue half
    AB - Red half,             Blue full
    AC - Red full,             Blue half
    AD - Red full,             Blue full
    AE - Red full,             Blue half
    AF - Red full,             Blue full
    B0 - Red half, Green half
    B1 - Red half, Green half
    B2 - Red half, Green full
    B3 - Red half, Green full
    B4 - Red full, Green half
    B5 - Red full, Green half
    B6 - Red full, Green full
    B7 - Red full, Green full
    B8 - Red half, Green half, Blue half
    B9 - Red half, Green half, Blue full
    BA - Red half, Green full, Blue half
    BB - Red half, Green full, Blue full
    BC - Red full, Green half, Blue half
    BD - Red full, Green half, Blue full
    BE - Red full, Green full, Blue half
    BF - Red full, Green full, Blue full



   VDU RAM arrangement
   ===================

   bit 0-6: character number
   bit 7:   source bit -  0 = character ROM
                          1 = PCG RAM


   Colour RAM:
   ===========

   Colour on the 32k is "odd" and not fully specified in any of the docs I
   have.  Each colour line (Red, Green or Blue) is specified by 2 bits,
   namely data (0 = off, 1 = on) and intensity (0 = half, 1 = full), giving
   a total of 6 TTL lines / pixel.  So for each of colour line we have 3
   states:

    DATA   INTENSITY
     0      x            no colour (gun off)
     1      0            half intensity colour (gun half on)
     1      1            full intensity colour (gun full on)

   (giving 27 distinguishable shadings, but probably easier to round off
   to 6 bits, or 64 (0x040) colours with redundant blacknesses).

   Each byte of colour RAM is thus:

       bit 0-4 foreground colour selection
       bit 5   "BLUE" background data (1 = on)
       bit 6   "GREEN" background data (1 = on)
       bit 7   "RED" background data (1 = on)

   Snooping (see update below) indicates that the background colours are in
   this order (reverse of standard).  Background intensity is the same for
   the entire screen, and is set by port 08 above.

   UPDATE: going from the Microbee Basic reference manual for the premium
   series, section 27.1, the following table is given for "old" (pre
   premium) machines:

   Foreground Colour          Decimal code          (added: RGB value)
   ---------------------------------------
   Black                          0                       000
   Blue                           1                       001
   Green                          2                       010
   Cyan                           3                       011
   Red                            4                       100
   Magenta                        5                       101
   Yellow                         6                       110
   White                          7                       111
   Black II                       16
   Blue II                        17
   Green II                       18
   Cyan II                        19
   Red II                         20
   Magenta II                     21
   Yellow II                      22
   White II                       23
   
   Background Colour          Decimal code          (added: RGB value)
   ---------------------------------------
   Black                         0                        000
   Red                           1                        100
   Green                         2                        010
   Yellow                        3                        110
   Blue                          4                        001
   Magenta                       5                        101
   Cyan                          6                        011
   White                         7                        111
   
   Which, after some snooping on what basic does with the colour command
   given these values, indicates that the background is as above, and for
   the foreground:

   bit 0    "RED" foreground
   bit 1    "GREEN" foreground
   bit 2    "BLUE" foreground
   bit 3    ??
   bit 4    ??

   Bits 3 and 4 remain a mystery - I presume that they control intensity,
   and pattern association suggests that colours 8-15 and colours 24-31
   are some duplicate of colours 0-7 and 16-23.  Not having a (working)
   colour monitor for my bee, I can't tell for sure, so my (baseless)
   *guess* is that colours 16-23 are high intensity (ie. all intensity bits
   high).  The rest are just a guess - I've chosen 8-15 with RG intensity
   high, and 24-31 with RB intensity high.  This is done via a LUT.

   BASIC colour commands: colour  n - set foreground colour 0 <= n <= 31
                          colourb n - set background colour 0 <= n <= 7
                          colourm n - set background intensity 0 <= n <= 7



   Screen Emulator Data
   ====================

   COLOUR_GREEN:  default foreground colour in greenscreen mode
   COLOUR_BLACK:  default background colour in greenscreen mode.
   COLOUR_OFFSET: amount by which "microbee" colours must be offset
                  to get colours in the allegro pallete.  This basically
                  just makes sure that bit 7 is set, preventing the
                  accidental use of "see-through" colours.

   BEESCRN_MAX_SCREEN_WIDTH_BEE:  maximum screen width supported by the 6545
   BEESCRN_MAX_SCREEN_HEIGHT_BEE: maximum screen height supported by the 6545


   physical_screen_width:  width of the physical pc screen.
   physical_screen_height: height of the physical pc screen.

   horiz_line_multiplier: 1 microbee col -> this # physical cols
   vert_line_multiplier:  1 microbee row -> this # physical rows

   beescrn_bee_screen:        A local copy of the screen is kept here.
   beescrn_mbee_palette[256]: Colour pallette - starts at COLOUR_OFFSET.

   beescrn_l_left_offset:  # pixels on screen to left of 6545 screen.
   beescrn_l_s_width:      width of bee screen addressed by the 6545.
   beescrn_l_right_offset: # pixels on screen to right of 6545 screen.

   beescrn_l_top_offset:    # pixels on screen to top of 6545 screen.
   beescrn_l_s_height:      height of bee scrn addressed by the 6545.
   beescrn_l_bottom_offset: # pixels on scrn to bottom of 6545 screen.

   beescrn_left_correction: "0"
   beescrn_top_correction:  "0"

   beescrn_fore_colour_LUT: look-up table to convert contents of colour RAM
                            to standard format RiGiBiRGB


   video_mode_is: defines the video mode used by the emulator.  Possible
                  modes are:

                 mode  resolution  vert_stretch  horiz_stretch  fill_stretch
                  0     640x480      no           no             n/a
                  1     800x600      yes          no             yes
                  2     1024x768     yes          no             yes
                  3     1280x1024    yes          yes            yes
                  4     800x600      yes          no             no
                  5     1024x768     yes          no             no
                  6     1280x1024    yes          yes            no
                  7     800x600      no           no             n/a
                  8     1024x768     no           no             n/a
                  9     1280x1024    no           no             n/a

*/

/*
   beescrn_do_colour: set if colour emulation is on.
   beescrn_mono_type: colour used for monochrome monitor

   beescrn_monochrome_fore_colour: colour for "foreground" pixels in noncolour mode.
   beescrn_monochrome_back_colour: colour for "background" pixels in noncolour mode.
*/


#define COLOUR_BLACK    0x000
#define COLOUR_GREEN    0x011
#define COLOUR_AMBER    0x031
#define COLOUR_WHITE    0x038

#define COLOUR_OFFSET   0x080


int beescrn_screen_shotter(void);
int beescrn_screen_grabber(void);

int beescrn_set_vidmode0(void);
int beescrn_set_vidmode1(void);
int beescrn_set_vidmode2(void);
int beescrn_set_vidmode3(void);
int beescrn_set_vidmode4(void);
int beescrn_set_vidmode5(void);
int beescrn_set_vidmode6(void);
int beescrn_set_vidmode7(void);
int beescrn_set_vidmode8(void);
int beescrn_set_vidmode9(void);

int beescrn_set_vidmodewind(void);
int beescrn_set_vidmodefull(void);
int beescrn_set_video_mode(int what);

int beescrn_scr_colour(void);
int beescrn_scr_green_colour(void);
int beescrn_scr_amber_colour(void);
int beescrn_scr_bw_colour(void);
int beescrn_scr_invgreen_colour(void);
int beescrn_scr_invamber_colour(void);
int beescrn_scr_invbw_colour(void);

void beescrn_update_menu_marks(void);
void beescrn_fixup_palette(void);
void beescrn_correct_screensize_change(void);
void beescrn_want_fullscreen(void);
void beescrn_want_windowed(void);

int beescrn_get_video_mode(void);
int beescrn_prefer_fullscreen_is(void);

weird_pointer_jive beescrn_scrngrab;


/*
   Communication buses
*/

int     *beescrn_in_step_mode;
UINT_16 *beescrn_geometry_bus;

UINT_16 *beescrn_xpos;        /* x position when drawing pixels         */
UINT_16 *beescrn_ypos;        /* y position when drawing pixels         */
UINT_8  *beescrn_is_fore;     /* pixel indicator bus (8 pixels), 1 fore */
UINT_8  *beescrn_fore_colour; /* foreground colour bus                  */
UINT_8  *beescrn_back_colour; /* background colour bus                  */
UINT_8  *beescrn_inv__colour; /* colour inversion bus                   */
int     *beescrn_do_colour;   /* colour emulation mode (colour if 1)    */

UINT_8  beescrn_monochrome_fore_colour;
UINT_8  beescrn_monochrome_back_colour;

UINT_8  beescrn_multip_fill_option;
UINT_16 beescrn_horiz_line_multiplier;
UINT_16 beescrn_vert_line_multiplier;
UINT_16 beescrn_physical_screen_width;
UINT_16 beescrn_physical_screen_height;
UINT_16 beescrn_left_correction;
UINT_16 beescrn_top_correction;
UINT_16 beescrn_l_left_offset;
UINT_16 beescrn_l_top_offset;

UINT_8 beescrn_dont_draw;

int beescrn_default_do_colour;
int beescrn_mono_type;

UINT_8 beescrn_colour_full;
UINT_8 beescrn_colour_half;
UINT_8 beescrn_colour_back;

UINT_8 beescrn_bright;
UINT_8 beescrn_contrast;

int beescrn_video_mode_is;
int beescrn_prefer_fullscreen;

long beescrn_aa_xpos;
long beescrn_aa_ypos;
long beescrn_za_xpos;
long beescrn_za_ypos;
long beescrn_qa_xpos;
long beescrn_qa_ypos;
long beescrn_ra_xpos;
long beescrn_ra_ypos;

char beescrn_filename_shot[1800] = "\0";

char beescrn_menu_optiona[] = "- &Colour mode";
char beescrn_menu_optionb[] = "- &Greenscreen mode";
char beescrn_menu_optionc[] = "- &Amberscreen mode";
char beescrn_menu_optiond[] = "- &Black and White mode";
char beescrn_menu_optione[] = "- Inverted G&reenscreen mode";
char beescrn_menu_optionf[] = "- Inverted A&mberscreen mode";
char beescrn_menu_optiong[] = "- Inverted B&lack and White mode";

char beescrn_resol_optiona[] = "- &0. 640x480";
char beescrn_resol_optionb[] = "- &1. 800x600 (vertically doubled)";
char beescrn_resol_optionc[] = "- &2. 1024x768 (vertically doubled)";
char beescrn_resol_optiond[] = "- &3. 1280x1024 (bi-directionally doubled)";
char beescrn_resol_optione[] = "- &4. 800x600 (vertically stretched)";
char beescrn_resol_optionf[] = "- &5. 1024x768 (vertically stretched)";
char beescrn_resol_optiong[] = "- &6. 1280x1024 (bi-directionally stretched)";
char beescrn_resol_optionh[] = "- &7. 800x600";
char beescrn_resol_optioni[] = "- &8. 1024x768";
char beescrn_resol_optionj[] = "- &9. 1280x1024";
char beescrn_resol_optionx[] = "- Default to &window";
char beescrn_resol_optiony[] = "  Default to &fullscreen";

MENU beescrn_resol_menu[] =
{
    { beescrn_resol_optiona, beescrn_set_vidmode0,    NULL, 0, NULL },
    { beescrn_resol_optionb, beescrn_set_vidmode1,    NULL, 0, NULL },
    { beescrn_resol_optionc, beescrn_set_vidmode2,    NULL, 0, NULL },
    { beescrn_resol_optiond, beescrn_set_vidmode3,    NULL, 0, NULL },
    { beescrn_resol_optione, beescrn_set_vidmode4,    NULL, 0, NULL },
    { beescrn_resol_optionf, beescrn_set_vidmode5,    NULL, 0, NULL },
    { beescrn_resol_optiong, beescrn_set_vidmode6,    NULL, 0, NULL },
    { beescrn_resol_optionh, beescrn_set_vidmode7,    NULL, 0, NULL },
    { beescrn_resol_optioni, beescrn_set_vidmode8,    NULL, 0, NULL },
    { beescrn_resol_optionj, beescrn_set_vidmode9,    NULL, 0, NULL },
    { "",                    NULL,                    NULL, 0, NULL },
    { beescrn_resol_optionx, beescrn_set_vidmodewind, NULL, 0, NULL },
    { beescrn_resol_optiony, beescrn_set_vidmodefull, NULL, 0, NULL },
    { NULL,                  NULL,                    NULL, 0, NULL }
};


MENU beescrn_menu[] =
{
    { "Take &Screenshot",      beescrn_screen_shotter,      NULL,               0, NULL },
    { "Grab Scr&een Contents", beescrn_screen_grabber,      NULL,               0, NULL },
    { "",                      NULL,                        NULL,               0, NULL },
    { beescrn_menu_optiona,    beescrn_scr_colour,          NULL,               0, NULL },
    { beescrn_menu_optionb,    beescrn_scr_green_colour,    NULL,               0, NULL },
    { beescrn_menu_optionc,    beescrn_scr_amber_colour,    NULL,               0, NULL },
    { beescrn_menu_optiond,    beescrn_scr_bw_colour,       NULL,               0, NULL },
    { beescrn_menu_optione,    beescrn_scr_invgreen_colour, NULL,               0, NULL },
    { beescrn_menu_optionf,    beescrn_scr_invamber_colour, NULL,               0, NULL },
    { beescrn_menu_optiong,    beescrn_scr_invbw_colour,    NULL,               0, NULL },
    { "",                      NULL,                        NULL,               0, NULL },
    { "Se&t Resolution",       NULL,                        beescrn_resol_menu, 0, NULL },
    { NULL,                    NULL,                        NULL,               0, NULL }
};


UINT_16 beescrn_left_source;
UINT_16 beescrn_right_source;
UINT_16 beescrn_top_source;
UINT_16 beescrn_bottom_source;

UINT_16 beescrn_left_dest;
UINT_16 beescrn_right_dest;
UINT_16 beescrn_top_dest;
UINT_16 beescrn_bottom_dest;

UINT_16 beescrn_l_s_width;
UINT_16 beescrn_l_right_offset;

UINT_16 beescrn_l_s_height;
UINT_16 beescrn_l_bottom_offset;

BITMAP *beescrn_bee_screen;



#define BEESCRN_DEFAULT_L_LEFT_OFFSET   0
#define BEESCRN_DEFAULT_L_S_WIDTH       1
#define BEESCRN_DEFAULT_L_RIGHT_OFFSET  0
#define BEESCRN_DEFAULT_L_TOP_OFFSET    0
#define BEESCRN_DEFAULT_L_S_HEIGHT      1
#define BEESCRN_DEFAULT_L_BOTTOM_OFFSET 0
#define BEESCRN_MAX_SCREEN_WIDTH_BEE    2048
#define BEESCRN_MAX_SCREEN_HEIGHT_BEE   4096




RGB beescrn_mbee_palette[256];

UINT_8 beescrn_fore_colour_LUT[0x020] = {
    0x000, 0x008, 0x010, 0x018, 0x020, 0x028, 0x030, 0x038,
    0x006, 0x00e, 0x016, 0x01e, 0x026, 0x02e, 0x036, 0x03e,
    0x007, 0x00f, 0x017, 0x01f, 0x027, 0x02f, 0x037, 0x03f,
    0x005, 0x00d, 0x015, 0x01d, 0x025, 0x02d, 0x035, 0x03d };


RGB colour_ooo = { 0,  0,  0  ,0 };
RGB colour_ool = { 0,  0,  31 ,0 };
RGB colour_ooh = { 0,  0,  63 ,0 };
RGB colour_olo = { 0,  31, 0  ,0 };
RGB colour_oll = { 0,  31, 31 ,0 };
RGB colour_olh = { 0,  31, 63 ,0 };
RGB colour_oho = { 0,  63, 0  ,0 };
RGB colour_ohl = { 0,  63, 31 ,0 };
RGB colour_ohh = { 0,  63, 63 ,0 };
RGB colour_loo = { 31, 0,  0  ,0 };
RGB colour_lol = { 31, 0,  31 ,0 };
RGB colour_loh = { 31, 0,  63 ,0 };
RGB colour_llo = { 31, 31, 0  ,0 };
RGB colour_lll = { 31, 31, 31 ,0 };
RGB colour_llh = { 31, 31, 63 ,0 };
RGB colour_lho = { 31, 63, 0  ,0 };
RGB colour_lhl = { 31, 63, 31 ,0 };
RGB colour_lhh = { 31, 63, 63 ,0 };
RGB colour_hoo = { 63, 0,  0  ,0 };
RGB colour_hol = { 63, 0,  31 ,0 };
RGB colour_hoh = { 63, 0,  63 ,0 };
RGB colour_hlo = { 63, 31, 0  ,0 };
RGB colour_hll = { 63, 31, 31 ,0 };
RGB colour_hlh = { 63, 31, 63 ,0 };
RGB colour_hho = { 63, 63, 0  ,0 };
RGB colour_hhl = { 63, 63, 31 ,0 };
RGB colour_hhh = { 63, 63, 63 ,0 };

RGB full_colour_ooo = { 0,  0,  0  ,0 };
RGB full_colour_ool = { 0,  0,  31 ,0 };
RGB full_colour_ooh = { 0,  0,  63 ,0 };
RGB full_colour_olo = { 0,  31, 0  ,0 };
RGB full_colour_oll = { 0,  31, 31 ,0 };
RGB full_colour_olh = { 0,  31, 63 ,0 };
RGB full_colour_oho = { 0,  63, 0  ,0 };
RGB full_colour_ohl = { 0,  63, 31 ,0 };
RGB full_colour_ohh = { 0,  63, 63 ,0 };
RGB full_colour_loo = { 31, 0,  0  ,0 };
RGB full_colour_lol = { 31, 0,  31 ,0 };
RGB full_colour_loh = { 31, 0,  63 ,0 };
RGB full_colour_llo = { 31, 31, 0  ,0 };
RGB full_colour_lll = { 31, 31, 31 ,0 };
RGB full_colour_llh = { 31, 31, 63 ,0 };
RGB full_colour_lho = { 31, 63, 0  ,0 };
RGB full_colour_lhl = { 31, 63, 31 ,0 };
RGB full_colour_lhh = { 31, 63, 63 ,0 };
RGB full_colour_hoo = { 63, 0,  0  ,0 };
RGB full_colour_hol = { 63, 0,  31 ,0 };
RGB full_colour_hoh = { 63, 0,  63 ,0 };
RGB full_colour_hlo = { 63, 31, 0  ,0 };
RGB full_colour_hll = { 63, 31, 31 ,0 };
RGB full_colour_hlh = { 63, 31, 63 ,0 };
RGB full_colour_hho = { 63, 63, 0  ,0 };
RGB full_colour_hhl = { 63, 63, 31 ,0 };
RGB full_colour_hhh = { 63, 63, 63 ,0 };

RGB full_colour_xxx = { 15, 15, 15 ,0 };


void beescrn_set_colour_full(UINT_8 what);
void beescrn_set_colour_half(UINT_8 what);
void beescrn_set_colour_back(UINT_8 what);


void beescrn_refresh_bee_screen_assumptive();



SetupData beescrn_setdat[] =
{
   { "screen_mode",       &beescrn_video_mode_is,     6 },
   { "prefer_fullscreen", &beescrn_prefer_fullscreen, 6 },
   { "bright",            &beescrn_bright,            0 },
   { "contrast",          &beescrn_contrast,          0 },
   { "do_colour",         &beescrn_default_do_colour, 6 },
   { "mono_type",         &beescrn_mono_type,         6 },
   { "",                  NULL,                       0 }
};

SetupData *beescrn_setup(void)
{
    beescrn_video_mode_is = 0;

    beescrn_bright   = 255;
    beescrn_contrast = 75;

    beescrn_default_do_colour = 1;
    beescrn_mono_type         = 1;

    return beescrn_setdat;
}

int beescrn_init(int                *_beescrn_in_step_mode,
                 UINT_16            *_beescrn_geometry_bus,
                 int                *_beescrn_do_colour,
                 UINT_16            *_beescrn_xpos,
                 UINT_16            *_beescrn_ypos,
                 UINT_8             *_beescrn_is_fore,
                 UINT_8             *_beescrn_fore_colour,
                 UINT_8             *_beescrn_back_colour,
                 UINT_8             *_beescrn_inv__colour,
                 weird_pointer_jive  _beescrn_scrngrab)
{
    beescrn_in_step_mode           = _beescrn_in_step_mode;
    beescrn_geometry_bus           = _beescrn_geometry_bus;
    beescrn_do_colour              = _beescrn_do_colour;
    beescrn_xpos                   = _beescrn_xpos;
    beescrn_ypos                   = _beescrn_ypos;
    beescrn_is_fore                = _beescrn_is_fore;
    beescrn_fore_colour            = _beescrn_fore_colour;
    beescrn_back_colour            = _beescrn_back_colour;
    beescrn_inv__colour            = _beescrn_inv__colour;

    beescrn_scrngrab = _beescrn_scrngrab;

    beescrn_multip_fill_option     = 0;
    beescrn_horiz_line_multiplier  = 0;
    beescrn_vert_line_multiplier   = 0;
    beescrn_physical_screen_width  = 0;
    beescrn_physical_screen_height = 0;
    beescrn_left_correction        = 0;
    beescrn_top_correction         = 0;
    beescrn_l_left_offset          = 0;
    beescrn_l_top_offset           = 0;

    beescrn_dont_draw = 0;

    (*beescrn_do_colour) = beescrn_default_do_colour;

    switch ( beescrn_mono_type )
    {
        case 1:
        {
            beescrn_monochrome_fore_colour = COLOUR_GREEN;
            beescrn_monochrome_back_colour = COLOUR_BLACK;

            break;
        }

        case 2:
        {
            beescrn_monochrome_fore_colour = COLOUR_AMBER;
            beescrn_monochrome_back_colour = COLOUR_BLACK;

            break;
        }

        case 3:
        {
            beescrn_monochrome_fore_colour = COLOUR_WHITE;
            beescrn_monochrome_back_colour = COLOUR_BLACK;

            break;
        }

        case 4:
        {
            beescrn_monochrome_fore_colour = COLOUR_BLACK;
            beescrn_monochrome_back_colour = COLOUR_GREEN;

            break;
        }

        case 5:
        {
            beescrn_monochrome_fore_colour = COLOUR_BLACK;
            beescrn_monochrome_back_colour = COLOUR_AMBER;

            break;
        }

        case 6:
        {
            beescrn_monochrome_fore_colour = COLOUR_BLACK;
            beescrn_monochrome_back_colour = COLOUR_WHITE;

            break;
        }

        default:
        {
            return 0;

            break;
        }
    }

    beescrn_left_source     = 0;
    beescrn_right_source    = 0;
    beescrn_top_source      = 0;
    beescrn_bottom_source   = 0;

    beescrn_left_dest       = 0;
    beescrn_right_dest      = 0;
    beescrn_top_dest        = 0;
    beescrn_bottom_dest     = 0;

    beescrn_l_left_offset  = BEESCRN_DEFAULT_L_LEFT_OFFSET;
    beescrn_l_s_width      = BEESCRN_DEFAULT_L_S_WIDTH;
    beescrn_l_right_offset = BEESCRN_DEFAULT_L_RIGHT_OFFSET;

    beescrn_l_top_offset    = BEESCRN_DEFAULT_L_TOP_OFFSET;
    beescrn_l_s_height      = BEESCRN_DEFAULT_L_S_HEIGHT;
    beescrn_l_bottom_offset = BEESCRN_DEFAULT_L_BOTTOM_OFFSET;

    beescrn_left_correction = BEESCRN_MAX_SCREEN_WIDTH_BEE/2;
    beescrn_top_correction  = BEESCRN_MAX_SCREEN_HEIGHT_BEE/2;

    beescrn_set_bright((beescrn_bright));
    beescrn_set_contrast((beescrn_contrast));

    if ( beescrn_set_video_mode((beescrn_video_mode_is)) )
    {
        return 0;
    }

    set_window_title("PicoMozzy");

    /*
       Set Palette
    */

    beescrn_fixup_palette();

    /*
       Set graphics mode
    */

    set_color_depth(8);

    if ( beescrn_revert_gfx_mode() )
    {
        return 0;
    }

    set_palette(beescrn_mbee_palette);

    /*
       Clear the screens, go to the microbee screen space
    */

    set_clip(screen,0,0,beescrn_physical_screen_width-1,beescrn_physical_screen_height-1);
    rectfill(screen,0,0,beescrn_physical_screen_width-1,beescrn_physical_screen_height-1,beescrn_monochrome_back_colour+COLOUR_OFFSET);

    /*
       Make temporary (blitting) screen
    */

    if ( ( beescrn_bee_screen = create_bitmap(BEESCRN_MAX_SCREEN_HEIGHT_BEE,BEESCRN_MAX_SCREEN_WIDTH_BEE) ) == NULL )
    {
        return 0;
    }

    set_clip(beescrn_bee_screen,0,0,BEESCRN_MAX_SCREEN_HEIGHT_BEE-1,BEESCRN_MAX_SCREEN_WIDTH_BEE-1);
    rectfill(beescrn_bee_screen,0,0,BEESCRN_MAX_SCREEN_HEIGHT_BEE-1,BEESCRN_MAX_SCREEN_WIDTH_BEE-1,beescrn_monochrome_back_colour+COLOUR_OFFSET);

    return 1;
}

void beescrn_remove(void)
{
    if ( beescrn_bee_screen != NULL )
    {
        destroy_bitmap(beescrn_bee_screen);
    }

    return;
}




#define LEFT_CORRECT (   (beescrn_physical_screen_width/beescrn_horiz_line_multiplier)  \
                       + BEESCRN_MAX_SCREEN_WIDTH_BEE                   \
                       - (beescrn_l_left_offset+beescrn_l_s_width+beescrn_l_right_offset)  ) / 2

#define TOP_CORRECT  (   (beescrn_physical_screen_height/beescrn_vert_line_multiplier)  \
                       + BEESCRN_MAX_SCREEN_HEIGHT_BEE                  \
                       - (beescrn_l_top_offset+beescrn_l_s_height+beescrn_l_bottom_offset) ) / 2

void beescrn_change_left_margin(void)
{
    beescrn_blank_physical_screen();

    beescrn_l_left_offset   = (*beescrn_geometry_bus);
    beescrn_left_correction = LEFT_CORRECT;

    beescrn_refresh_bee_screen();

    return;
}

void beescrn_change_screen_width(void)
{
    beescrn_blank_physical_screen();

    beescrn_l_s_width       = (*beescrn_geometry_bus);
    beescrn_left_correction = LEFT_CORRECT;

    beescrn_refresh_bee_screen();

    return;
}

void beescrn_change_right_margin(void)
{
    beescrn_blank_physical_screen();

    beescrn_l_right_offset  = (*beescrn_geometry_bus);
    beescrn_left_correction = LEFT_CORRECT;

    beescrn_refresh_bee_screen();

    return;
}

void beescrn_change_top_margin(void)
{
    beescrn_blank_physical_screen();

    beescrn_l_top_offset   = (*beescrn_geometry_bus);
    beescrn_top_correction = TOP_CORRECT;

    beescrn_refresh_bee_screen();

    return;
}

void beescrn_change_screen_height(void)
{
    beescrn_blank_physical_screen();

    beescrn_l_s_height     = (*beescrn_geometry_bus);
    beescrn_top_correction = TOP_CORRECT;

    beescrn_refresh_bee_screen();

    return;
}

void beescrn_change_bottom_margin(void)
{
    beescrn_blank_physical_screen();

    beescrn_l_bottom_offset = (*beescrn_geometry_bus);
    beescrn_top_correction  = TOP_CORRECT;

    beescrn_refresh_bee_screen();

    return;
}

void beescrn_blank_screen(void)
{
    beescrn_blank_physical_screen();

    rectfill(beescrn_bee_screen,0,0,BEESCRN_MAX_SCREEN_HEIGHT_BEE-1,BEESCRN_MAX_SCREEN_WIDTH_BEE-1,beescrn_monochrome_back_colour+COLOUR_OFFSET);

    return;
}

void beescrn_blank_physical_screen(void)
{
    if ( !(*beescrn_in_step_mode) )
    {
        rectfill(screen,0,0,beescrn_physical_screen_width-1,beescrn_physical_screen_height-1,beescrn_monochrome_back_colour+COLOUR_OFFSET);
    }

    return;
}

void beescrn_refresh_bee_screen_assumptive()
{
    beescrn_refresh_bee_screen();

    return;
}

void beescrn_refresh_bee_screen(void)
{
    UINT_16 i;

    beescrn_left_source  = 0;
    beescrn_right_source = beescrn_l_s_width;

    beescrn_left_dest  = beescrn_left_correction+beescrn_l_left_offset;
    beescrn_right_dest = beescrn_left_correction+beescrn_l_s_width+beescrn_l_left_offset-(BEESCRN_MAX_SCREEN_WIDTH_BEE/2);

    if ( beescrn_left_dest < (BEESCRN_MAX_SCREEN_WIDTH_BEE/2) )
    {
        beescrn_left_source += ((BEESCRN_MAX_SCREEN_WIDTH_BEE/2)-beescrn_left_dest);
        beescrn_left_dest   =  0;
    }

    else
    {
        beescrn_left_dest -= (BEESCRN_MAX_SCREEN_WIDTH_BEE/2);
    }

    if ( beescrn_right_dest > beescrn_physical_screen_width )
    {
        beescrn_right_source -= (beescrn_right_dest-beescrn_physical_screen_width);
        beescrn_right_dest   =  beescrn_physical_screen_width;
    }

    beescrn_top_source    = 0;
    beescrn_bottom_source = beescrn_l_s_height;

    beescrn_top_dest    = beescrn_top_correction+beescrn_l_top_offset;
    beescrn_bottom_dest = beescrn_top_correction+beescrn_l_s_height+beescrn_l_top_offset-(BEESCRN_MAX_SCREEN_HEIGHT_BEE/2);

    if ( beescrn_top_dest < (BEESCRN_MAX_SCREEN_HEIGHT_BEE/2) )
    {
        beescrn_top_source += ((BEESCRN_MAX_SCREEN_HEIGHT_BEE/2)-beescrn_top_dest);
        beescrn_top_dest   =  0;
    }

    else
    {
        beescrn_top_dest -= (BEESCRN_MAX_SCREEN_HEIGHT_BEE/2);
    }

    if ( beescrn_bottom_dest > beescrn_physical_screen_height )
    {
        beescrn_bottom_source -= (beescrn_bottom_dest-beescrn_physical_screen_height);
        beescrn_bottom_dest   =  beescrn_physical_screen_height;
    }

    if ( !(*beescrn_in_step_mode) )
    {
        stretch_blit(beescrn_bee_screen,screen,beescrn_left_source,beescrn_top_source,(beescrn_right_source-beescrn_left_source),(beescrn_bottom_source-beescrn_top_source),beescrn_left_dest*beescrn_horiz_line_multiplier,beescrn_top_dest*beescrn_vert_line_multiplier,(beescrn_right_source-beescrn_left_source)*beescrn_horiz_line_multiplier,(beescrn_bottom_source-beescrn_top_source)*beescrn_vert_line_multiplier);
    }

    /* ASSUMPTION HERE: stretch_blit will do line multiplication by
       duplication of lines.  Hence, if multip_fill_option == 0 we need
       to overwrite odd numbered lines with black. */

    if ( !(*beescrn_in_step_mode) && !beescrn_multip_fill_option & ( beescrn_horiz_line_multiplier == 2 ) )
    {
        for ( i = 0x001 ; i < beescrn_physical_screen_width ; i += beescrn_horiz_line_multiplier )
        {
            vline(screen,i,0,beescrn_physical_screen_height-1,beescrn_monochrome_back_colour+COLOUR_OFFSET);
        }
    }

    if ( !(*beescrn_in_step_mode) && !beescrn_multip_fill_option & ( beescrn_vert_line_multiplier == 2 ) )
    {
        for ( i = 0x001 ; i < beescrn_physical_screen_height ; i += beescrn_vert_line_multiplier )
        {
            hline(screen,0,i,beescrn_physical_screen_width-1,beescrn_monochrome_back_colour+COLOUR_OFFSET);
        }
    }

    return;
}


int beescrn_screenshot(const char shotname[])
{
    BITMAP *screenshot_bmp;

    if ( ( screenshot_bmp = create_sub_bitmap(beescrn_bee_screen,beescrn_left_source,beescrn_top_source,beescrn_right_source-beescrn_left_source,beescrn_bottom_source-beescrn_top_source) ) == NULL )
    {
        return 1;
    }

    if ( save_bmp(shotname,screenshot_bmp,beescrn_mbee_palette) )
    {
        return 1;
    }

    destroy_bitmap(screenshot_bmp);

    return 0;
}


void *beescrn_get_beescreen_copy(void)
{
    BITMAP *screenshot_bmp;

    if ( ( screenshot_bmp = create_bitmap(beescrn_right_source-beescrn_left_source,beescrn_bottom_source-beescrn_top_source) ) == NULL )
    {
        return NULL;
    }

    blit(beescrn_bee_screen,screenshot_bmp,beescrn_left_source,beescrn_top_source,0,0,beescrn_right_source-beescrn_left_source,beescrn_bottom_source-beescrn_top_source);

    return (void *) screenshot_bmp;
}

UINT_16 beescrn_get_beescreen_width(void)
{
    return beescrn_right_source-beescrn_left_source;
}

UINT_16 beescrn_get_beescreen_height(void)
{
    return beescrn_bottom_source-beescrn_top_source;
}

void *beescrn_get_beescreen_palette(void)
{
    return (void *) (&beescrn_mbee_palette);
}

void beescrn_fixup_palette(void)
{
    if ( (beescrn_colour_full) <= 0  ) { (beescrn_colour_full) = 0;  }
    if ( (beescrn_colour_full) >= 63 ) { (beescrn_colour_full) = 63; }

    if ( (beescrn_colour_back) <= 0  ) { (beescrn_colour_back) = 0;  }
    if ( (beescrn_colour_back) >= 63 ) { (beescrn_colour_back) = 63; }

    if ( (beescrn_colour_half) < (beescrn_colour_back) ) { (beescrn_colour_half) = (beescrn_colour_back); }
    if ( (beescrn_colour_half) > (beescrn_colour_full) ) { (beescrn_colour_half) = (beescrn_colour_full); }

    colour_ooo.r = (beescrn_colour_back);
    colour_ool.r = (beescrn_colour_back);
    colour_ooh.r = (beescrn_colour_back);
    colour_olo.r = (beescrn_colour_back);
    colour_oll.r = (beescrn_colour_back);
    colour_olh.r = (beescrn_colour_back);
    colour_oho.r = (beescrn_colour_back);
    colour_ohl.r = (beescrn_colour_back);
    colour_ohh.r = (beescrn_colour_back);
    colour_loo.r = (beescrn_colour_half);
    colour_lol.r = (beescrn_colour_half);
    colour_loh.r = (beescrn_colour_half);
    colour_llo.r = (beescrn_colour_half);
    colour_lll.r = (beescrn_colour_half);
    colour_llh.r = (beescrn_colour_half);
    colour_lho.r = (beescrn_colour_half);
    colour_lhl.r = (beescrn_colour_half);
    colour_lhh.r = (beescrn_colour_half);
    colour_hoo.r = (beescrn_colour_full);
    colour_hol.r = (beescrn_colour_full);
    colour_hoh.r = (beescrn_colour_full);
    colour_hlo.r = (beescrn_colour_full);
    colour_hll.r = (beescrn_colour_full);
    colour_hlh.r = (beescrn_colour_full);
    colour_hho.r = (beescrn_colour_full);
    colour_hhl.r = (beescrn_colour_full);
    colour_hhh.r = (beescrn_colour_full);

    colour_ooo.g = (beescrn_colour_back);
    colour_ool.g = (beescrn_colour_back);
    colour_ooh.g = (beescrn_colour_back);
    colour_olo.g = (beescrn_colour_half);
    colour_oll.g = (beescrn_colour_half);
    colour_olh.g = (beescrn_colour_half);
    colour_oho.g = (beescrn_colour_full);
    colour_ohl.g = (beescrn_colour_full);
    colour_ohh.g = (beescrn_colour_full);
    colour_loo.g = (beescrn_colour_back);
    colour_lol.g = (beescrn_colour_back);
    colour_loh.g = (beescrn_colour_back);
    colour_llo.g = (beescrn_colour_half);
    colour_lll.g = (beescrn_colour_half);
    colour_llh.g = (beescrn_colour_half);
    colour_lho.g = (beescrn_colour_full);
    colour_lhl.g = (beescrn_colour_full);
    colour_lhh.g = (beescrn_colour_full);
    colour_hoo.g = (beescrn_colour_back);
    colour_hol.g = (beescrn_colour_back);
    colour_hoh.g = (beescrn_colour_back);
    colour_hlo.g = (beescrn_colour_half);
    colour_hll.g = (beescrn_colour_half);
    colour_hlh.g = (beescrn_colour_half);
    colour_hho.g = (beescrn_colour_full);
    colour_hhl.g = (beescrn_colour_full);
    colour_hhh.g = (beescrn_colour_full);

    colour_ooo.b = (beescrn_colour_back);
    colour_ool.b = (beescrn_colour_half);
    colour_ooh.b = (beescrn_colour_full);
    colour_olo.b = (beescrn_colour_back);
    colour_oll.b = (beescrn_colour_half);
    colour_olh.b = (beescrn_colour_full);
    colour_oho.b = (beescrn_colour_back);
    colour_ohl.b = (beescrn_colour_half);
    colour_ohh.b = (beescrn_colour_full);
    colour_loo.b = (beescrn_colour_back);
    colour_lol.b = (beescrn_colour_half);
    colour_loh.b = (beescrn_colour_full);
    colour_llo.b = (beescrn_colour_back);
    colour_lll.b = (beescrn_colour_half);
    colour_llh.b = (beescrn_colour_full);
    colour_lho.b = (beescrn_colour_back);
    colour_lhl.b = (beescrn_colour_half);
    colour_lhh.b = (beescrn_colour_full);
    colour_hoo.b = (beescrn_colour_back);
    colour_hol.b = (beescrn_colour_half);
    colour_hoh.b = (beescrn_colour_full);
    colour_hlo.b = (beescrn_colour_back);
    colour_hll.b = (beescrn_colour_half);
    colour_hlh.b = (beescrn_colour_full);
    colour_hho.b = (beescrn_colour_back);
    colour_hhl.b = (beescrn_colour_half);
    colour_hhh.b = (beescrn_colour_full);

    beescrn_mbee_palette[0x080] = colour_ooo;
    beescrn_mbee_palette[0x081] = colour_ooo;
    beescrn_mbee_palette[0x082] = colour_ooo;
    beescrn_mbee_palette[0x083] = colour_ooo;
    beescrn_mbee_palette[0x084] = colour_ooo;
    beescrn_mbee_palette[0x085] = colour_ooo;
    beescrn_mbee_palette[0x086] = colour_ooo;
    beescrn_mbee_palette[0x087] = colour_ooo;
    beescrn_mbee_palette[0x088] = colour_ool;
    beescrn_mbee_palette[0x089] = colour_ooh;
    beescrn_mbee_palette[0x08A] = colour_ool;
    beescrn_mbee_palette[0x08B] = colour_ooh;
    beescrn_mbee_palette[0x08C] = colour_ool;
    beescrn_mbee_palette[0x08D] = colour_ooh;
    beescrn_mbee_palette[0x08E] = colour_ool;
    beescrn_mbee_palette[0x08F] = colour_ooh;
    beescrn_mbee_palette[0x090] = colour_olo;
    beescrn_mbee_palette[0x091] = colour_olo;
    beescrn_mbee_palette[0x092] = colour_oho;
    beescrn_mbee_palette[0x093] = colour_oho;
    beescrn_mbee_palette[0x094] = colour_olo;
    beescrn_mbee_palette[0x095] = colour_olo;
    beescrn_mbee_palette[0x096] = colour_oho;
    beescrn_mbee_palette[0x097] = colour_oho;
    beescrn_mbee_palette[0x098] = colour_oll;
    beescrn_mbee_palette[0x099] = colour_olh;
    beescrn_mbee_palette[0x09A] = colour_ohl;
    beescrn_mbee_palette[0x09B] = colour_ohh;
    beescrn_mbee_palette[0x09C] = colour_oll;
    beescrn_mbee_palette[0x09D] = colour_olh;
    beescrn_mbee_palette[0x09E] = colour_ohl;
    beescrn_mbee_palette[0x09F] = colour_ohh;
    beescrn_mbee_palette[0x0A0] = colour_loo;
    beescrn_mbee_palette[0x0A1] = colour_loo;
    beescrn_mbee_palette[0x0A2] = colour_loo;
    beescrn_mbee_palette[0x0A3] = colour_loo;
    beescrn_mbee_palette[0x0A4] = colour_hoo;
    beescrn_mbee_palette[0x0A5] = colour_hoo;
    beescrn_mbee_palette[0x0A6] = colour_hoo;
    beescrn_mbee_palette[0x0A7] = colour_hoo;
    beescrn_mbee_palette[0x0A8] = colour_lol;
    beescrn_mbee_palette[0x0A9] = colour_loh;
    beescrn_mbee_palette[0x0AA] = colour_lol;
    beescrn_mbee_palette[0x0AB] = colour_loh;
    beescrn_mbee_palette[0x0AC] = colour_hol;
    beescrn_mbee_palette[0x0AD] = colour_hoh;
    beescrn_mbee_palette[0x0AE] = colour_hol;
    beescrn_mbee_palette[0x0AF] = colour_hoh;
    beescrn_mbee_palette[0x0B0] = colour_llo;
    beescrn_mbee_palette[0x0B1] = colour_llo;
    beescrn_mbee_palette[0x0B2] = colour_lho;
    beescrn_mbee_palette[0x0B3] = colour_lho;
    beescrn_mbee_palette[0x0B4] = colour_hlo;
    beescrn_mbee_palette[0x0B5] = colour_hlo;
    beescrn_mbee_palette[0x0B6] = colour_hho;
    beescrn_mbee_palette[0x0B7] = colour_hho;
    beescrn_mbee_palette[0x0B8] = colour_lll;
    beescrn_mbee_palette[0x0B9] = colour_llh;
    beescrn_mbee_palette[0x0BA] = colour_lhl;
    beescrn_mbee_palette[0x0BB] = colour_lhh;
    beescrn_mbee_palette[0x0BC] = colour_hll;
    beescrn_mbee_palette[0x0BD] = colour_hlh;
    beescrn_mbee_palette[0x0BE] = colour_hhl;
    beescrn_mbee_palette[0x0BF] = colour_hhh;

    beescrn_mbee_palette[0x0C1] = full_colour_hhh;
    beescrn_mbee_palette[0x0C2] = full_colour_lll;
    beescrn_mbee_palette[0x0C3] = full_colour_ooo;

    /*
       Bee pointer palette components - these have been reverse engineered
       from mbee32k.bmp
    */

    beescrn_mbee_palette[0x0D1] = full_colour_xxx; /* dark grey */
    beescrn_mbee_palette[0x0D2] = full_colour_hlo; /* orange    */
    beescrn_mbee_palette[0x0D3] = full_colour_hhh; /* white     */

    return;
}

void beescrn_correct_screensize_change(void)
{
    beescrn_left_correction = LEFT_CORRECT;
    beescrn_top_correction  = TOP_CORRECT;

    return;
}

int beescrn_revert_gfx_mode(void)
{
    if ( (beescrn_prefer_fullscreen) )
    {
        if ( set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,beescrn_physical_screen_width,beescrn_physical_screen_height,0,0) )
        {
            if ( set_gfx_mode(GFX_AUTODETECT_WINDOWED,beescrn_physical_screen_width,beescrn_physical_screen_height,0,0) )
            {
                if ( set_gfx_mode(GFX_AUTODETECT,beescrn_physical_screen_width,beescrn_physical_screen_height,0,0) )
                {
                    return 1;
                }
            }
        }
    }

    else
    {
        if ( set_gfx_mode(GFX_AUTODETECT_WINDOWED,beescrn_physical_screen_width,beescrn_physical_screen_height,0,0) )
        {
            if ( set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,beescrn_physical_screen_width,beescrn_physical_screen_height,0,0) )
            {
                if ( set_gfx_mode(GFX_AUTODETECT,beescrn_physical_screen_width,beescrn_physical_screen_height,0,0) )
                {
                    return 1;
                }
            }
        }
    }

    /*
       Set switch mode (in order of preference)
    */

    if ( set_display_switch_mode(SWITCH_BACKGROUND) == -1 )
    {
        if ( set_display_switch_mode(SWITCH_BACKAMNESIA) == -1 )
        {
            if ( set_display_switch_mode(SWITCH_NONE) == -1 )
            {
                return 1;
            }
        }
    }

    set_display_switch_callback(SWITCH_IN,beescrn_refresh_bee_screen_assumptive);

    return 0;
}

int beescrn_menu_gfx_mode(void)
{
    if ( set_gfx_mode(GFX_AUTODETECT_WINDOWED,640,480,0,0) )
    {
        if ( set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,640,480,0,0) )
        {
            if ( set_gfx_mode(GFX_AUTODETECT,640,480,0,0) )
            {
                return 1;
            }
        }
    }

    return 0;
}

UINT_8 beescrn_get_bright(void)
{
    return (beescrn_bright);
}

UINT_8 beescrn_get_contrast(void)
{
    return (beescrn_contrast);
}

void beescrn_set_bright(UINT_8 what)
{
    (beescrn_bright) = what;

    beescrn_set_colour_full((((long) (beescrn_bright))*63)/255);
    beescrn_set_colour_half(((255-((long) (beescrn_contrast)))*((long) (beescrn_colour_full)))/255);
    beescrn_set_colour_back(0);

    beescrn_fixup_palette();

    return;
}

void beescrn_set_contrast(UINT_8 what)
{
    (beescrn_contrast) = what;

    beescrn_set_colour_full((((long) (beescrn_bright))*63)/255);
    beescrn_set_colour_half(((255-((long) (beescrn_contrast)))*((long) (beescrn_colour_full)))/255);
    beescrn_set_colour_back(0);

    beescrn_fixup_palette();

    return;
}

int beescrn_get_video_mode(void)
{
    return (beescrn_video_mode_is);
}

int beescrn_set_video_mode(int what)
{
    (beescrn_video_mode_is) = what;

    switch ( (beescrn_video_mode_is) )
    {
        case 0:
        {
            beescrn_physical_screen_width  = 640;
            beescrn_physical_screen_height = 480;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 1;

            beescrn_multip_fill_option = 0;

            break;
        }

        case 1:
        {
            beescrn_physical_screen_width  = 800;
            beescrn_physical_screen_height = 600;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 2;

            beescrn_multip_fill_option = 1;

            break;
        }

        case 2:
        {
            beescrn_physical_screen_width  = 1024;
            beescrn_physical_screen_height = 768;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 2;

            beescrn_multip_fill_option = 1;

            break;
        }

        case 3:
        {
            beescrn_physical_screen_width  = 1280;
            beescrn_physical_screen_height = 1024;

            beescrn_horiz_line_multiplier = 2;
            beescrn_vert_line_multiplier  = 2;

            beescrn_multip_fill_option = 1;

            break;
        }

        case 4:
        {
            beescrn_physical_screen_width  = 800;
            beescrn_physical_screen_height = 600;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 2;

            beescrn_multip_fill_option = 0;

            break;
        }

        case 5:
        {
            beescrn_physical_screen_width  = 1024;
            beescrn_physical_screen_height = 768;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 2;

            beescrn_multip_fill_option = 0;

            break;
        }

        case 6:
        {
            beescrn_physical_screen_width  = 1280;
            beescrn_physical_screen_height = 1024;

            beescrn_horiz_line_multiplier = 2;
            beescrn_vert_line_multiplier  = 2;

            beescrn_multip_fill_option = 0;

            break;
        }

        case 7:
        {
            beescrn_physical_screen_width  = 800;
            beescrn_physical_screen_height = 600;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 1;

            beescrn_multip_fill_option = 0;

            break;
        }

        case 8:
        {
            beescrn_physical_screen_width  = 1024;
            beescrn_physical_screen_height = 768;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 1;

            beescrn_multip_fill_option = 0;

            break;
        }

        case 9:
        {
            beescrn_physical_screen_width  = 1280;
            beescrn_physical_screen_height = 1024;

            beescrn_horiz_line_multiplier = 1;
            beescrn_vert_line_multiplier  = 1;

            beescrn_multip_fill_option = 0;

            break;
        }

        default:
        {
            return 1;

            break;
        }
    }

    return 0;
}

UINT_8 beescrn_trans_colour(UINT_8 bee_colour)
{
    return beescrn_fore_colour_LUT[bee_colour];
}

void beescrn_want_fullscreen(void)
{
    beescrn_prefer_fullscreen = 1;

    return;
}

void beescrn_want_windowed(void)
{
    (beescrn_prefer_fullscreen) = 0;

    return;
}

void beescrn_set_colour_full(UINT_8 what)
{
    (beescrn_colour_full) = what;

    return;
}

void beescrn_set_colour_half(UINT_8 what)
{
    (beescrn_colour_half) = what;

    return;
}

void beescrn_set_colour_back(UINT_8 what)
{
    (beescrn_colour_back) = what;

    return;
}

int beescrn_prefer_fullscreen_is(void)
{
    return beescrn_prefer_fullscreen;
}

int beescrn_is_in_menu_gfx_mode(void)
{
    if ( ( beescrn_get_video_mode() != 0 ) || beescrn_prefer_fullscreen_is() )
    {
        return 0;
    }

    return 1;
}

int beescrn_screen_grabber(void)
{
    beescrn_scrngrab();

    return D_O_K;
}

int beescrn_screen_shotter(void)
{
    if ( file_select_ex("Select Screenshot File (bmp)",beescrn_filename_shot,NULL,300,0,0) )
    {
        if ( beescrn_screenshot(beescrn_filename_shot) )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }
    }

    return D_O_K;
}

int beescrn_set_vidmode0(void)
{
    if ( beescrn_get_video_mode() != 0 )
    {
        if ( beescrn_set_video_mode(0) )
        {
            alert("","Video mode 0 not available.","","&OK",NULL,'o',0);
        }

        beescrn_correct_screensize_change();
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode1(void)
{
    if ( beescrn_get_video_mode() != 1 )
    {
        if ( alert("Warning:","800x600 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(1) )
            {
                alert("","Video mode 1 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode2(void)
{
    if ( beescrn_get_video_mode() != 2 )
    {
        if ( alert("Warning:","1024x768 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(2) )
            {
                alert("","Video mode 2 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode3(void)
{
    if ( beescrn_get_video_mode() != 3 )
    {
        if ( alert("Warning:","1280x1024 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(3) )
            {
                alert("","Video mode 3 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode4(void)
{
    if ( beescrn_get_video_mode() != 4 )
    {
        if ( alert("Warning:","800x600 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(4) )
            {
                alert("","Video mode 4 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode5(void)
{
    if ( beescrn_get_video_mode() != 5 )
    {
        if ( alert("Warning:","1024x768 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(5) )
            {
                alert("","Video mode 5 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode6(void)
{
    if ( beescrn_get_video_mode() != 6 )
    {
        if ( alert("Warning:","1280x1024 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(6) )
            {
                alert("","Video mode 6 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode7(void)
{
    if ( beescrn_get_video_mode() != 7 )
    {
        if ( alert("Warning:","800x600 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(7) )
            {
                alert("","Video mode 7 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode8(void)
{
    if ( beescrn_get_video_mode() != 8 )
    {
        if ( alert("Warning:","1024x768 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(8) )
            {
                alert("","Video mode 8 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmode9(void)
{
    if ( beescrn_get_video_mode() != 9 )
    {
        if ( alert("Warning:","1280x1024 may cause some systems to hang.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 1 )
        {
            if ( beescrn_set_video_mode(9) )
            {
                alert("","Video mode 9 not available.","","&OK",NULL,'o',0);
            }

            beescrn_correct_screensize_change();
        }
    }

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmodewind(void)
{
    beescrn_want_windowed();

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_set_vidmodefull(void)
{
    beescrn_want_fullscreen();

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_colour(void)
{
    if ( !(*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 1;

    beescrn_monochrome_fore_colour = COLOUR_WHITE;
    beescrn_monochrome_back_colour = COLOUR_BLACK;

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_green_colour(void)
{
    if ( (*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 0;
    beescrn_mono_type = 1;

    beescrn_monochrome_fore_colour = COLOUR_GREEN;
    beescrn_monochrome_back_colour = COLOUR_BLACK;

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_amber_colour(void)
{
    if ( (*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 0;
    beescrn_mono_type = 2;

    beescrn_monochrome_fore_colour = COLOUR_AMBER;
    beescrn_monochrome_back_colour = COLOUR_BLACK;

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_bw_colour(void)
{
    if ( (*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 0;
    beescrn_mono_type = 3;

    beescrn_monochrome_fore_colour = COLOUR_WHITE;
    beescrn_monochrome_back_colour = COLOUR_BLACK;

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_invgreen_colour(void)
{
    if ( (*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 0;
    beescrn_mono_type = 4;

    beescrn_monochrome_fore_colour = COLOUR_BLACK;
    beescrn_monochrome_back_colour = COLOUR_GREEN;

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_invamber_colour(void)
{
    if ( (*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 0;
    beescrn_mono_type = 5;

    beescrn_monochrome_fore_colour = COLOUR_BLACK;
    beescrn_monochrome_back_colour = COLOUR_AMBER;

    beescrn_update_menu_marks();

    return D_O_K;
}

int beescrn_scr_invbw_colour(void)
{
    if ( (*beescrn_do_colour) )
    {
        if ( alert("Note:","Until the next RESET-ESC, Basic may behave oddly.","Continue anyhow?", "&Yes", "&No", 'y', 'n') == 2 )
        {
            return D_O_K;
        }
    }

    (*beescrn_do_colour) = 0;
    beescrn_mono_type = 6;

    beescrn_monochrome_fore_colour = COLOUR_BLACK;
    beescrn_monochrome_back_colour = COLOUR_WHITE;

    beescrn_update_menu_marks();

    return D_O_K;
}

void beescrn_update_menu_marks(void)
{
    if ( (*beescrn_do_colour) )
    {
        beescrn_menu_optiona[0] = '-';

        beescrn_menu_optionb[0] = ' ';
        beescrn_menu_optionc[0] = ' ';
        beescrn_menu_optiond[0] = ' ';
        beescrn_menu_optione[0] = ' ';
        beescrn_menu_optionf[0] = ' ';
        beescrn_menu_optiong[0] = ' ';
    }

    else
    {
        beescrn_menu_optiona[0] = ' ';

        beescrn_menu_optionb[0] = ' ';
        beescrn_menu_optionc[0] = ' ';
        beescrn_menu_optiond[0] = ' ';
        beescrn_menu_optione[0] = ' ';
        beescrn_menu_optionf[0] = ' ';
        beescrn_menu_optiong[0] = ' ';

        switch ( beescrn_mono_type )
        {
            case 1:  { beescrn_menu_optionb[0] = '-'; break; }
            case 2:  { beescrn_menu_optionc[0] = '-'; break; }
            case 3:  { beescrn_menu_optiond[0] = '-'; break; }
            case 4:  { beescrn_menu_optione[0] = '-'; break; }
            case 5:  { beescrn_menu_optionf[0] = '-'; break; }
            default: { beescrn_menu_optiong[0] = '-'; break; }
        }
    }

    {
        beescrn_resol_optiona[0] = ' ';
        beescrn_resol_optionb[0] = ' ';
        beescrn_resol_optionc[0] = ' ';
        beescrn_resol_optiond[0] = ' ';
        beescrn_resol_optione[0] = ' ';
        beescrn_resol_optionf[0] = ' ';
        beescrn_resol_optiong[0] = ' ';
        beescrn_resol_optionh[0] = ' ';
        beescrn_resol_optioni[0] = ' ';
        beescrn_resol_optionj[0] = ' ';

        switch ( beescrn_get_video_mode() )
        {
            case 0:  { beescrn_resol_optiona[0] = '-'; break; }
            case 1:  { beescrn_resol_optionb[0] = '-'; break; }
            case 2:  { beescrn_resol_optionc[0] = '-'; break; }
            case 3:  { beescrn_resol_optiond[0] = '-'; break; }
            case 4:  { beescrn_resol_optione[0] = '-'; break; }
            case 5:  { beescrn_resol_optionf[0] = '-'; break; }
            case 6:  { beescrn_resol_optiong[0] = '-'; break; }
            case 7:  { beescrn_resol_optionh[0] = '-'; break; }
            case 8:  { beescrn_resol_optioni[0] = '-'; break; }
            default: { beescrn_resol_optionj[0] = '-'; break; }
        }
    }

    {
        beescrn_resol_optionx[0] = ' ';
        beescrn_resol_optiony[0] = ' ';

        switch ( beescrn_prefer_fullscreen_is() )
        {
            case 0:  { beescrn_resol_optionx[0] = '-'; break; }
            default: { beescrn_resol_optiony[0] = '-'; break; }
        }
    }

    return;
}

MENU *beescrn_getmenu(void)
{
    beescrn_update_menu_marks();

    return beescrn_menu;
}

void beescrn_draw_on(void)
{
    beescrn_dont_draw = 0;

    return;
}

void beescrn_draw_off(void)
{
    beescrn_dont_draw = 1;

    return;
}

void beescrn_pixel_drawer(void)
{
    beescrn_ra_xpos = (*beescrn_xpos);
    beescrn_ra_ypos = (*beescrn_ypos);

    if ( !(*beescrn_do_colour) )
    {
        if ( *beescrn_inv__colour )
        {
            (*beescrn_fore_colour) = beescrn_monochrome_back_colour;
            (*beescrn_back_colour) = beescrn_monochrome_fore_colour;
        }

        else
        {
            (*beescrn_fore_colour) = beescrn_monochrome_fore_colour;
            (*beescrn_back_colour) = beescrn_monochrome_back_colour;
        }
    }

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x080 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x040 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x020 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x010 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x008 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x004 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x002 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    beescrn_ra_xpos++;

    if ( ( beescrn_ra_xpos < BEESCRN_MAX_SCREEN_WIDTH_BEE ) && ( beescrn_ra_ypos < BEESCRN_MAX_SCREEN_HEIGHT_BEE ) )
    {
        if ( (*beescrn_is_fore) & 0x001 )
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
        }

        else
        {
            _putpixel(beescrn_bee_screen,beescrn_ra_xpos,beescrn_ra_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
        }
    }

    if ( beescrn_multip_fill_option && !beescrn_dont_draw )
    {
        beescrn_qa_xpos = ((beescrn_left_correction+(*beescrn_xpos)+beescrn_l_left_offset-(BEESCRN_MAX_SCREEN_WIDTH_BEE /2)))*beescrn_horiz_line_multiplier;
        beescrn_qa_ypos = ((beescrn_top_correction +(*beescrn_ypos)+beescrn_l_top_offset -(BEESCRN_MAX_SCREEN_HEIGHT_BEE/2)))*beescrn_vert_line_multiplier;

        acquire_bitmap(screen);

        for ( beescrn_za_xpos = 0 ; beescrn_za_xpos < beescrn_horiz_line_multiplier ; beescrn_za_xpos++ )
        {
            for ( beescrn_za_ypos = 0 ; beescrn_za_ypos < beescrn_vert_line_multiplier ; beescrn_za_ypos++ )
            {
                beescrn_aa_xpos = beescrn_qa_xpos+beescrn_za_xpos;
                beescrn_aa_ypos = beescrn_qa_ypos+beescrn_za_ypos;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x080 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x040 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x020 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x010 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x008 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x004 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x002 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }

                beescrn_aa_xpos += beescrn_horiz_line_multiplier;

                if ( ( beescrn_aa_xpos >= 0                              ) &&
                     ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
                     ( beescrn_aa_ypos >= 0                              ) &&
                     ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
                {
                    if ( (*beescrn_is_fore) & 0x001 )
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
                    }

                    else
                    {
                        _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
                    }
                }
            }
        }

        release_bitmap(screen);
    }

    else if ( !beescrn_dont_draw )
    {
        beescrn_aa_xpos = ((beescrn_left_correction+(*beescrn_xpos)+beescrn_l_left_offset-(BEESCRN_MAX_SCREEN_WIDTH_BEE /2)))*beescrn_horiz_line_multiplier;
        beescrn_aa_ypos = ((beescrn_top_correction +(*beescrn_ypos)+beescrn_l_top_offset -(BEESCRN_MAX_SCREEN_HEIGHT_BEE/2)))*beescrn_vert_line_multiplier;

        acquire_bitmap(screen);

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x080 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x040 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x020 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x010 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x008 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x004 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x002 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        beescrn_aa_xpos += beescrn_horiz_line_multiplier;

        if ( ( beescrn_aa_xpos >= 0                              ) &&
             ( beescrn_aa_xpos <  beescrn_physical_screen_width  ) &&
             ( beescrn_aa_ypos >= 0                              ) &&
             ( beescrn_aa_ypos <  beescrn_physical_screen_height )    )
        {
            if ( (*beescrn_is_fore) & 0x001 )
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_fore_colour)+COLOUR_OFFSET);
            }

            else
            {
                _putpixel(screen,beescrn_aa_xpos,beescrn_aa_ypos,(*beescrn_back_colour)+COLOUR_OFFSET);
            }
        }

        release_bitmap(screen);
    }

    return;
}


