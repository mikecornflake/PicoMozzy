
#include "u_dtype.h"

#ifndef _z80pio_h
#define _z80pio_h

/*
   +-------+
  -|       |-            
  -|       |-            
  -|       |-            
  -|       |-      \\            __________
  -|       | ====== \\          /  / \    /\
  -|                 \\        /   \ /   /--`
  -|                  \\      / >{|||}  /
  -| z80pio Emulator   \\    |   / \   |
  -|                    _  +-------------+
  -| Alistair Shilton  |_|=|        .... |
  -| apsh@ecr.mu.oz.au     |_____________|
  -| http://           //   \___________/
  -|                  //
  -|                 // 
  -|       | ====== //   
  -|       |-      //    
  -|       |-            
  -|       |-            
  -|       |-            
  -|       |-
   +-------+

   Communication from the z80 pio to connected devices
   ===================================================

   z80pio_*_strb_data_in - function called to tell pio that relevant *
                           inputs (ie. the data bus and the strb signal)
                           may have been changed.
   z80pio_iei_in         - function called to tell the pio that the iei
                           signal has changed.
   z80pio_ack_int        - called to acknowledge an interupt signal has bee
                           received and action taken.  This will put the
                           relevant interupt vector on the data_bus.
   z80pio_reti_signal    - called when a reti opcode is processed by the
                           cpu.

   Data bus description
   ====================

   ie*      - interupt enable pins.  ieo is an output (to next pio in the
              daisy-chain), and iei is an input (from the previous pio in
              the daisy chain.  In general, 0 means don't inhibit interupts,
              1 means inhibit interupts.
   data_bus - data bus on cpu side.

   *_data - data bus on output side.
   *_rdy  - 0 pio not ready
            1 pio is ready
   *_strb - active low strobe signal


   Function pointer description
   ============================

   *_rdy_data_out  - function called if the relevant * outputs (ie. the data
                     bus or the ready signal) may have changed.
   ieo_out         - function called if the state of the ieo signal has
                     changed.
   signal_interupt - called to signal that an interupt has occured (see
                     below for details).


   Interupt stuff
   ==============

   Interupts function as follows:

   1. the pio sends the interupt by calling signal_interupt().
   2. this is passed to the z80 cpu module, which will (if interupts
      are enabled etc) call back to acknowledge the interupt.
   3. The function so called should then call z80pio_ack_int(), which will
      put the appropriate vector on the data_bus and return.
   4. Once the interupt routine is finished, it may end in reti.  Upon (or
      near) when the reti is got from memory the function z80pio_reti_signal
      should be called to finish the interupt cycle.

*/


typedef struct
{
    /* PIO data buses - CPU side */

    UINT_8 *ieo;        /* output */
    UINT_8 *iei;        /* input  */
    UINT_8 *data_bus;   /* i/o */


    /* PIO data buses - External side */

    UINT_8 *a_rdy;      /* output */
    UINT_8 *a_strb;     /* input  */
    UINT_8 *a_data;     /* i/o    */

    UINT_8 *b_rdy;      /* output */
    UINT_8 *b_strb;     /* input  */
    UINT_8 *b_data;     /* i/o    */


    /* Internal data */

    /* Outward communications functions (nominally read only) */

    weird_pointer_jive a_rdy_data_out;
    weird_pointer_jive b_rdy_data_out;
    weird_pointer_jive ieo_out;
    weird_pointer_jive signal_interupt;


    /* Internal state of A module (nominally read only) */

    UINT_8 a_reg_output;
    UINT_8 a_reg_input;
    UINT_8 a_reg_mode;
    UINT_8 a_reg_intvect;
    UINT_8 a_reg_ioctrl;
    UINT_8 a_reg_intctrl;
    UINT_8 a_reg_maskctrl;

    UINT_8 a_regctrl_pending;
    UINT_8 a_maskctrl_pending;
    UINT_8 a_int_inhibit;
    UINT_8 a_mode02_state;
    UINT_8 a_mode123_state;
    UINT_8 a_strb_prime;


    /* Internal state of B module (nominally read only) */

    UINT_8 b_reg_output;
    UINT_8 b_reg_input;
    UINT_8 b_reg_mode;
    UINT_8 b_reg_intvect;
    UINT_8 b_reg_ioctrl;
    UINT_8 b_reg_intctrl;
    UINT_8 b_reg_maskctrl;

    UINT_8 b_regctrl_pending;
    UINT_8 b_maskctrl_pending;
    UINT_8 b_int_inhibit;
    UINT_8 b_mode02_state;
    UINT_8 b_mode123_state;
    UINT_8 b_strb_prime;
}
z80pio_state;


z80pio_state *z80pio_init(UINT_8 *ieo,
                          UINT_8 *iei,
                          UINT_8 *data_bus,
                          UINT_8 *a_rdy,
                          UINT_8 *a_strb,
                          UINT_8 *a_data,
                          UINT_8 *b_rdy,
                          UINT_8 *b_strb,
                          UINT_8 *b_data,
                          weird_pointer_jive a_rdy_data_out,
                          weird_pointer_jive b_rdy_data_out,
                          weird_pointer_jive ieo_out,
                          weird_pointer_jive signal_interupt);

void z80pio_reset(z80pio_state *what);
void z80pio_remove(z80pio_state *what);

void z80pio_data_wr_A(z80pio_state *what);
void z80pio_ctrl_wr_A(z80pio_state *what);

void z80pio_data_rd_A(z80pio_state *what);
void z80pio_ctrl_rd_A(z80pio_state *what);

void z80pio_data_wr_B(z80pio_state *what);
void z80pio_ctrl_wr_B(z80pio_state *what);

void z80pio_data_rd_B(z80pio_state *what);
void z80pio_ctrl_rd_B(z80pio_state *what);

void z80pio_a_strb_data_in(z80pio_state *what);
void z80pio_b_strb_data_in(z80pio_state *what);

void z80pio_iei_in(z80pio_state *what);
void z80pio_ack_int(z80pio_state *what);
void z80pio_reti_signal(z80pio_state *what);



#endif
