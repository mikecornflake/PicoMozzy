
#include "fakealeg.h"
#include "u_dtype.h"
#include "configer.h"

#ifndef _beers232_h
#define _beers232_h

/*
   MicroBee serial module
   ======================

*/


SetupData *beers232_setup(void);
int beers232_init(UINT_8 *_beers232_out_bus, UINT_8 *_beers232_in_bus, UINT_16 *_beers232_cycle_bus);
MENU *beers232_getmenu(void);
void beers232_remove(void);

void beers232_serial_out_state_change(void);
void beers232_cycle(void);

#endif
