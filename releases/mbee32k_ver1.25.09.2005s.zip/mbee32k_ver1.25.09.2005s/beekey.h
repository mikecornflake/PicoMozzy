
#include <stdio.h>
#include "u_dtype.h"
#include "configer.h"

#ifndef _beekey_h
#define _beekey_h

/*
   Microbee 32k type keyboard emulator
   ===================================

   Functions:

   beekey_setup  - usual setup function.
   beekey_init   - initialise emulator.  Arguments are:
                   pole_lpen_table - memory address of keyboard table
                   worktable       - keyboard scratch area
   beekey_remove - remove emulator

   beekey_update_state - when a key is is pressed or release, call this to
                         translate the keyboard state to update the mbee
                         keyboard table kept at beekey_pole_lpen_table.
   beekey_cycle        - call regularly to run the emulator through
                         cycles z80 clock cycles.
*/

#define KEYBOARD_USES_LPEN      1

#ifdef KEYBOARD_USES_LPEN
#define ROMREAD0_LPEN_MASK 0x0ffffff00
#define ROMREAD1_LPEN_MASK 0x0ffff0000
#endif

SetupData *beekey_setup(void);
int beekey_init(UINT_8 *_beekey_lpen_table,
                UINT_8 *_beekey_lpen_feedback,
                UINT_8 *_beekey_lpen_feedrfsh,
                UINT_32 *_beekey_lpen_reset_counter,
                UINT_32 *_beekey_update_reset_counter,
                int *_beekey_key_down,
                UINT_16 *_beekey_cycle_bus);
MENU *beekey_getmenu(void);
void beekey_remove(void);

void beekey_update_state(void);
void beekey_cycle(void);

#endif
