/*

          PicoMozzy - a Microbee 32k Emulator v1.19.06.2005 (beta)

                        By Alistair Shilton
                           apsh@ee.unimelb.edu.au

          ========================================================

DO: make "microbee" filetype which can do ascii/bin processing
    automatically for microbee conventions.

*/

#define BUS_PREFIX volatile

#include <stdio.h>
#include <allegro.h>
#include <string.h>
#include <time.h>
#include "u_dtype.h"
#include "z80.h"
#include "6545.h"
#include "z80pio.h"
#include "beekey.h"
#include "beesnd.h"
#include "beescrn.h"
#include "beetape.h"
#include "beers232.h"
#include "beelowpc.h"
#include "configer.h"
#include "beepara.h"
#include "roms.h"
#include "debmaloc.h"
#include "beefile.h"


#ifndef ROMREAD0_LPEN_MASK
#define ROMREAD0_LPEN_MASK 0x000000000
#endif
#ifndef ROMREAD1_LPEN_MASK
#define ROMREAD1_LPEN_MASK 0x000000000
#endif


/*
   Functions
   =========

   z80_sync_clock() - this is the core of the emulator - pretty much
                      all the important stuff happens here.

   update_leds() - displays details of the emulator on the keyboard LEDs.
                   Specifically, lights the numlock flag if sound emulation
                   is on, the scroll-lock flag if speed emulation is on and
                   the capslock flag if colour emulation is on.

   key_lowlevel_stuff(scancode) - designed to be called by allegro for all
                                  keyboard events, namely when a key is
                                  pressed or released.
 
   key_lowlevel_exit(scancode) - temporary replacement for key_lowlevel_stuff
                                 used during exit.
 
   main_menu_function() - called to enter interactive mode (see later
                          for details on what this means).

   parallel_strober() - this function acts as a bridge between the pio
                        module and the parallel port.  It is called by the
                        parallel port code, adds a pointer to the z80pio
                        module and then calls the strobe function for the
                        z80 pio.

   tape_strober() - this function is a bridge bw the pio module and
                    the tape port.  It's called by the tape code
                    to indicate a change in the tape port input
                    bit.

   make_bee_icon() - sets up the microbee "bee" mouse pointer and returns
                     a pointer to it.  Will return NULL on failure.
*/

void z80_sync_clock(void);
void update_leds(void);
void key_lowlevel_stuff(int scancode);
void key_lowlevel_exit(int scancode);
void main_menu_function(void);
void parallel_strober(void);
void tape_strober(void);
BITMAP *make_bee_icon(void);
void screengrab(void);

void z80pio_io_wr_data_A(void);
void z80pio_io_wr_ctrl_A(void);
void z80pio_io_wr_data_B(void);
void z80pio_io_wr_ctrl_B(void);
void z80pio_io_rd_data_A(void);
void z80pio_io_rd_ctrl_A(void);
void z80pio_io_rd_data_B(void);
void z80pio_io_rd_ctrl_B(void);
void c6545_addr_wi(void);
void c6545_data_wi(void);
void c6545_addr_ri(void);
void c6545_data_ri(void);



/*
   Setup and removal functions
   ===========================

   In general, there are two types of code block used in this emulator,
   namely resuable modules and single instance blocks.

   Reusable modules: These are emulation blocks which may be reused
   arbitrarily often, where the state of each instance is kept in a single
   allocated structure which must be passed to all functions to indicate
   which block is being used.  In general, such modules will have at least
   three basic functions associated with them, namely:

   module_state *module_init(arguments)   - Causes an instance of the module
                                            to be initialised with the
                                            properties given.  Returns a
                                            pointer to the state of the
                                            module, which identifies the
                                            instance, or NULL on failure.
   void module_reset(module_state *what)  - Resets the state of the instance
                                            what of the module.  This mimics
                                            the operation of the reset pin
                                            on the element being emulated.
   void module_remove(module_state *what) - Frees all memory associated with
                                            instance what of the module.

   Single instance blocks: Essentially a convenient way of enclosing some
   aspect of the emulator.  These blocks are not reusable (only one instance
   allowed).  There are four basic functions associated with them:

   SetupData *block_setup(void) - Returns a data structure containing info
                                  that may be controlled by the user via
                                  the config file (see configer.h for
                                  details - essentially this is an automated
                                  way of setting variables that control the
                                  behaviour of the emulator).
   int block_init(void)         - Initialise the block.  Will return nonzero
                                  on failure, 0 on success.
   void block_remove(void)      - Free any memory and exit the block nicely.
*/

SetupData *main_setup(void);
int main_init(void);
MENU *main_getmenu(void);
MENU *help_getmenu(void);
void main_remove(void);
void main_update_menu_marks(void);



/*
   Menu functions
*/

int loadit(void);
int saveit(void);

int cpu_state_lookup(void);

int step_returner(void); /* pointer pass phantom */
int returner(void);      /* pointer pass phantom */
int quitter(void);       /* pointer pass phantom */

int sel1BASICa(void);
int sel2BASICb(void);
int sel3WORDBEE(void);
int sel3EDASM(void);
int sel3FORTH(void);
int sel4NETWORK(void);
int sel5CHARROM(void);

int cpuclk_on(void);
int cpuclk_off(void);

int load1rom(void);
int load2rom(void);
int load3rom(void);
int load4rom(void);
int load5rom(void);

void find_cpu_state(char *dest);






/*
   Macros
   ======

   CONFIG_FILE: default file where the emulator will check for settings.
                For all settings, first a default value is set.  Then this
                file is checked, which may override these settings.  Finally,
                if specified on the command line, another configuration
                file can be checked, which again overrides the preceeding
                settings (allowing for specific "flavours" to be easily
                emulated).

   DEFAULT_SCREENDUMP_FILE: default destination for bitmap screen dumps.
                            Should have a .bmp filetype.

   INTERACT_KEY: key to be used to enter the microbee emulation menu
                 system (interactive mode).  Should be KEY_PGDN.

   SCREENDUMP_KEY: key to be used to initiate screen capture.  I would
                   like to use KEY_PRTSCR, but this seems to be broken
                   in dos.  Screendump also possible through interactive
                   menu.

   BEERESET_KEY: mapping for the microbee's "reset" key.  Should be KEY_PGDN.

   SCREENRFSH_KEY: key to be used to force the 6545 emulator to redraw the
                   screen.  This should be KEY_PAUSE.  Currently disabled
                   due to KEY_PAUSE weirdness.

   SPEEDCNTRL_KEY: key to toggle the emulator between "bee speed" (ie.
                   emulated to run at 3.141MHz" or "as fast as possible".
                   Should be KEY_SCRLOCK to line up with the use of the
                   scroll lock led to indicate speed state.

   SOUNDCNTRL_KEY: key to toggle sound emulation off and on.  Should be
                   KEY_NUMLOCK to line up with the use of the num lock led
                   to indicate whether sound emulation is on or off.

   CRTC6545_RELATIVE_CLOCK_RATE: default relative clock rate of 6545.
*/

#define CONFIG_FILE "mbee32k.ini"
#define DEFAULT_SCREENDUMP_FILE "screen.bmp"

#define INTERACT_KEY    KEY_PGDN
#define SCREENDUMP_KEY  KEY_PRTSCR
#define BEERESET_KEY    KEY_PGUP
#define SCREENRFSH_KEY  KEY_PAUSE
#define SPEEDCNTRL_KEY  KEY_SCRLOCK
#define SOUNDCNTRL_KEY  KEY_NUMLOCK

#define CRTC6545_RELATIVE_CLOCK_RATE    2





/*
   Variables
   =========

   interact_flag:    If set, the emulator will enter interactive mode asap.
   mbee_reset_flag:  Set if the reset key is held down, reset otherwise.
   printscreen_flag: If set, the emulator will do a screen capture asap.

   do_throttle: set if speed emulation is on.

   keyboard_poll_mode: set if keyboard must be polled.
   mouse_poll_mode:    set if mouse must be polled.

   bee_pointer: bitmap used for a mouse pointer.

   in_menu_mode: set when in interupt mode (emulation paused).
   in_step_mode: set when in single step mode.

   local_c6545_cycle_counter: cycle counter for 6545.
   c6545_clk_odds:            missed cycle counter for 6545.
   cycle_counter_c6545_bus:   cycle counter bus used when communicating the
                              number of cycles the 6545 should go through.

   zzzbmp: used when dumping the screen.
   zzzpal: used when dumping the screen.

   lpen_table:          this table is used by the 6545 module to control the
                        lightpen functionality of the 6545.  In the microbee
                        32k it was used by the keyboard.
   lpen_feedback_table: this table is used by the 6545 module to record
                        when a particular lightpen address being "set" causes
                        a trigger event by incrementing the relevant addr.
   lpen_call_mask:      this mask controls when the 6545 module should look
                        at the lightpen table, and when it can safely assume
                        the result will be zero.  See 6545 for gory details.

   key_down:  tells us whether a microbee key is currently depressed.  This
              is necessary for timing control here.
   do_colour: if 1, colour emulation is on (0 off).  This controls how the
              memory map will look, amongst other things.

   sync_point: this is set whenever the timer interupt function is called
               so that the z80_sync_clock can then do stuff that should be
               in the timer interupt but can't be because you can't call
               functions in this context.

   z80pio_base: z80 pio module pointer.  Null if module not installed.
   c6545_base:  6545 module pointer.  Null if module not installed.

   is_snd_ready:    set if the sound block has installed correctly.
   is_scrn_ready:   set if the screen control block has installed correctly.
   is_para_ready:   set if the parallel port block has installed correctly.
   is_key_ready:    set if the keyboard block has installed correctly.
   is_tape_ready:   set if the tape block has installed correctly.
   is_serial_ready: set if the serial block has installed correctly.
*/

volatile int interact_flag;
volatile int mbee_reset_flag;
volatile int printscreen_flag;

volatile int do_throttle;

volatile int keyboard_poll_mode;
volatile int mouse_poll_mode;

BITMAP *bee_pointer;

volatile int in_menu_mode;
volatile int in_step_mode;

UINT_32 local_c6545_cycle_counter;
UINT_32 c6545_clk_odds;
UINT_16 cycle_counter_c6545_bus;

BITMAP  *zzzbmp;
PALETTE  zzzpal;

UINT_8  *lpen_table;
UINT_8  *lpen_feedback_table;
UINT_8  *lpen_feedrfsh_table;
UINT_32  lpen_call_mask;

volatile int key_down;
volatile int do_colour;

volatile int sync_point;

z80pio_state *z80pio_base = NULL;
c6545_state  *c6545_base  = NULL;

int is_snd_ready    = 0;
int is_scrn_ready   = 0;
int is_para_ready   = 0;
int is_key_ready    = 0;
int is_tape_ready   = 0;
int is_serial_ready = 0;

UINT_32 lpen_reset_counter;
UINT_32 update_reset_counter;






/*
   Comms buses
   ===========

   geometry_bus:        comms bus b/w the beescrn block and the 6545 module.
   video_mem_addr_bus:  6545 comms bus - address in 6545 video mem map.
   video_data_bus:      6545 data bus.
   video_char_line_bus: 6545 line bus - says which line of a char is being
                        refered to when writing to character RAM.

   xpos_bus:        comms bus b/w beescrn block and 6545 module.
   ypos_bus:        comms bus b/w beescrn block and 6545 module.
   is_fore_bus:     comms bus b/w beescrn block and 6545 module.
   fore_colour_bus: comms bus b/w beescrn block and 6545 module.
   back_colour_bus: comms bus b/w beescrn block and 6545 module.
   inv__colour_bus: comms bus b/w beescrn block and 6545 module.

   pio_ieo_bus:    (1 bit) ieo bus for z80 pio module.
   pio_iei_bus:    (1 bit) iei bus for z80 pio module.
   pio_a_rdy_bus:  (1 bit) port a ready bus for z80 pio module.
   pio_a_strb_bus: (1 bit) port a strobe bus for z80 pio module.
   pio_a_data_bus: (8 bit) port a data bus for z80 pio module.
   pio_b_rdy_bus:  (1 bit) port b ready bus for z80 pio module.
   pio_b_strb_bus: (1 bit) port b strobe bus for z80 pio module.
   pio_b_data_bus: (8 bit) port b data bus for z80 pio module.

   sound_bit_bus: (1 bit) used to communicate the state of the sound bit (ie.
                  pio port b bit 6) to the sound block

   tape_out_bus: (1 bit) comms the state of the tape out bit to tape block.
   tape_in_bus:  (1 bit) comms the state of the tape in bit from tape block.

   serial_out_bus: (1 bit) comms the state of the serial out bit to serial block.
   serial_in_bus:  (1 bit) comms the state of the serial in bit from serial block.
*/

UINT_16 geometry_bus;
UINT_16 video_mem_addr_bus;
UINT_16 video_data_bus;
UINT_8  video_char_line_bus;

UINT_16 xpos_bus;
UINT_16 ypos_bus;
UINT_8  is_fore_bus;
UINT_8  fore_colour_bus;
UINT_8  back_colour_bus;
UINT_8  inv__colour_bus;



UINT_8 pio_ieo_bus;
UINT_8 pio_iei_bus;
UINT_8 pio_a_rdy_bus;
UINT_8 pio_a_strb_bus;
UINT_8 pio_a_data_bus;
UINT_8 pio_b_rdy_bus;
UINT_8 pio_b_strb_bus;
UINT_8 pio_b_data_bus;

UINT_8 sound_bit_bus;

UINT_8 tape_out_bus;
UINT_8 tape_in_bus;

UINT_8 serial_out_bus;
UINT_8 serial_in_bus;





/*
                     Clocking and Speed Control
                     ==========================


   How it Works - Basics
   =====================

   The z80 emulator will call z80_sync_clock after each op to report the
   number of cycles carried out by the virtual z80 during that op.  The
   z80_sync_clock function will subtract this from the signed counter
   actual_clocks.  If this counter is below the threshold value
   -catchup_point (which is negative) then it will wait until it goes above
   0 before continuing.

   There is also an interupt function, speed_throttle, which is called every
   timer_period_x nanoseconds (where timer_period_x must be a mutliple of
   1000000, as interupts can only have millisecond granularity).  When this
   is called, the value timer_period_x/clock_period (which is the number
   of clock cycles which should have passed on a real microbee running with
   clock period clock_period nanoseconds over a period of timer_period_x
   nanoseconds) is added to actual_clocks.

   Thus, on average, if actual_clocks is negative then the emulator is
   getting ahead of itself - that is, virtual cycles are being done on the
   emulator faster than actual cycles would have been on a real microbee.
   Hence we should stop for a bit to slow things up.  If actual_clocks is
   positive things are moving too fast - see below for details on how this
   is fixed.

   So we want to keep actual_clocks as close to zero as possible, and can
   insert wait states to make this happen.  To summarise:

   actual_clocks > 0: emulation is running too slowly
   actual_clocks = 0: emulation is running at precisely the right speed
   actual_clocks < 0: emulation is running faster than required

   Of course, there is a certain granularity here - actual_clocks is not
   increased continually, but in bursts.  Hence we need some leeway in how
   stricly we control the rate of the emulator.  This is why a wait state
   is only inserted when actual_clocks goes below -catchup_point.


   When the Computer Can't Keep Up
   ===============================

   While there is some leeway in the actual_clocks counter, if it becomes
   excessive then clearly the computer just can't go fast enough.  This is
   detected when actual_clocks > max_clockovr cycles (at which point
   actual_clocks is reset to max_clockovr_pb to prevent a counter overflow).
   While there are no guarantees, there are some things that can be done to
   fix this to a certain degree.  In particular, much of the computational
   load in the emulator is taken by the 6545 module.  However, much of this
   may be sacrificed if necessary - after all, much of this time is spent
   scanning back and foward across the screen doing nothing productive!

   6545 operation can be "slowed" in thusly:

   - the rate at which the 6545 is ran may be reduced using
     max_crtc_clock_division.  The number of clock cycles the 6545 does is
     the number of z80 cycle divided by (2*max_crtc_clock_division) (of
     course, the 6545 needs to be told about this so the cursor rate can be
     increased to compensate).  This will result in some weirdness if the
     display is changing quickly, but it's a reasonable compromise.
   - the granularity of the 6545 can be changed.  Rather than calling the
     6545 "go through n cycles" function whenever there is a cycle to be
     done, it will accumulate then untill the number of cycles exceeds
     crtc_granularity, and then call to do them all at once.  This saves
     on function calls and setup times.

   So, when we detect that actual_clocks > max_clockovr the following is
   done:

   1. set actual_clocks = max_clockovr_pb
   2. if ctrc_granularity < max_ctrc_granularity then increase
      ctrc_granularity by one and finish.
   3. if crtc_clock_division < max_crtc_clock division then set
      crtc_granularity = REAL_CRTC_GRANULARITY, double crtc_clock_division
      and tell the 6545 module about the change.

   Temporary process loads may make the emulator think that the computer
   is slower than it truly is, causing permanent degraded performance for
   where only temporary was necessary.  To overcome this, when the emulator
   enters a "wait" loop the is_wait counter will be set to 1 (it is zero by
   default).  When speed_throttle is called, it tests to see if is_wait is
   greater than lag_point.  If not, is_wait is incremented and nothing is
   done - nothing will happen until the lag_point^th call to speed_throttle
   during a single wait loop.  Upon the lag_point^th call to speed_throttle,
   however, the emulator accuracy can most likely be increased safely to
   give more accurate emulation without causing trouble.  The following
   steps are followed:

   1. if ctrc_granularity > REAL_CRTC_GRANULARITY then decrease
      ctrc_granularity by one and finish.
   2. if crtc_clock_division_is_key > REAL_CRTC_CLOCK_DIV then set
      crtc_granularity = max_crtc_granularity, halve crtc_clock_division
      and tell the 6545 module about the change.

   In this way, a compromise should be reached so that the emulator will
   run fast enough to pass for a "real" microbee while also being as accurate
   as possible on the given computer/load.

   An added complication here is that the microbee keyboard hangs off the
   6545 module, using the lightpen function.  Unfortunately, while the
   effect of slowing the 6545 on display quality is not too bad, the
   effect on keyboard responce can be more severe.  For this reason, the
   clock division and granularity variables (and their upper bounds)
   come in two varieties, one for when no keys are pressed and one for
   when keys are pressed (which can be detected using the key_down variable).
   Whenever key_down changes, the granularity and clock division parts are
   changed to the correct set.

   Finally, there are some temp variables used when speed control is turned
   off altogether.


   Erata - Automatic accuracy tracking
   ===================================

   I've found that the interupt function in allegro is not altogether
   accurate, especially when requested interupts are of the order of a few
   milliseconds.  Hence a second level timer interupt has been included that
   works as follows:

   1. When speed_throttle is called, the throttle_call_count counter is
      incremented.  So throttle_call_count*timer_period_x should be the
      number of nanoseconds since throttle_call_count was last reset to
      zero.
   2. Every OVERLOOK_TIMER_PERIOD seconds (where OVERLOOK_TIMER_PERIOD
      should be of the order of 2 seconds), timer_period_x will be adjusted
      to make it represent the "real" timer period, averaged over
      OVERLOOK_TIMER_PERIOD seconds.  The counter throttle_call_count will
      also be reset at this point.  Hence:

      timer_period_x = t_overlook / throttle_call_count

   where t_overlook is the time (in nanoseconds) since the last call to the
   overlook timer, as measured using a non-allegro time system (see time.h).



   Functions
   =========

   timer_speed_emul_off: called to turn off speed emulation.
   timer_speed_emul_on:  called to turn on speed emulation.
   speed_throttle:       interupt function which controls speed.
*/

#define DEFAULT_CLOCK_PERIOD    296
#define DEFAULT_TIMER_PERIOD    1000000
#define DEFAULT_CATCHUP_COUNT   500

#define DEFAULT_MAX_CLOCKOVR    60000
#define DEFAULT_MAX_CLOCKOVR_PB 50000
#define DEFAULT_LAG_POINT       2

#define REAL_CRTC_GRANULARITY   1
#define REAL_CRTC_CLOCK_DIV     1

#define DEFAULT_MAX_CRTC_GRANULARITY            128
#define DEFAULT_MAX_CRTC_GRANULARITY_KEY        16
#define DEFAULT_MAX_CRTC_CLOCK_DIV              16
#define DEFAULT_MAX_CRTC_CLOCK_DIV_KEY          2

#define OVERLOOK_TIMER_PERIOD   2

volatile clock_t time_prev;
volatile clock_t time_now;

volatile int     overlook_timer_firstcall;
volatile UINT_64 throttle_call_count;

volatile SINT_64 actual_clocks;
volatile long    clock_period;
volatile UINT_32 timer_period_x;
volatile long    catchup_point;

volatile int  is_wait;
volatile long max_clockovr;
volatile long max_clockovr_pb;
volatile long lag_point;

volatile UINT_32 crtc_granularity;
volatile UINT_32 crtc_granularity_no_key;
volatile UINT_32 crtc_granularity_is_key;
volatile UINT_32 max_crtc_granularity;
volatile UINT_32 max_crtc_granularity_key;
volatile UINT_32 temp_crtc_granularity_no_key;
volatile UINT_32 temp_crtc_granularity_is_key;


volatile UINT_8  crtc_clock_division;
volatile UINT_8  max_crtc_clock_division;
volatile UINT_8  max_crtc_clock_division_key;
volatile UINT_8  crtc_clock_division_no_key;
volatile UINT_8  crtc_clock_division_is_key;
volatile UINT_8  temp_crtc_clock_division_no_key;
volatile UINT_8  temp_crtc_clock_division_is_key;


void timer_speed_emul_off(void);
void timer_speed_emul_on(void);
void speed_throttle(void);
void overlook_timer(void);

#define TIMER_KEYLOOK(key_state)                                        \
{                                                                       \
    if ( key_state )                                                    \
    {                                                                   \
        crtc_granularity = crtc_granularity_is_key;                     \
        crtc_clock_division  = crtc_clock_division_is_key;              \
                                                                        \
                                                                        \
    }                                                                   \
                                                                        \
    else                                                                \
    {                                                                   \
        crtc_granularity = crtc_granularity_no_key;                     \
        crtc_clock_division  = crtc_clock_division_no_key;              \
                                                                        \
                                                                        \
    }                                                                   \
}





/*
                Memory Map and Basic IO Functionality
                =====================================


   Microbee Memory Map - Basics
   ============================

   Usually, the microbee memory map is:

   0000 - 3FFF: 16k user RAM (user_RAM_a).
   4000 - 7FFF: 16k user RAM (user_RAM_b).
   8000 - 9FFF: Microworld Level II Basic ROM part a.
   A000 - BFFF: Microworld Level II Basic ROM part b.
   C000 - DFFF: Either EDASM or WordBee.
   E000 - EFFF: Empty.
   F000 - F7FF: VDU RAM (romread = 0) and character ROM (romread = 1).
   F800 - FFFF: PCG RAM (colctrl = 0) and colour RAM (colctrl = 1), unless
                this isn't a colour bee, in which case always PCG.

   This is implemented as follows using pointers:

   0000 - 3FFF: user_RAM_a (points to allocated memory).
   4000 - 7FFF: user_RAM_b (points to allocated memory).
   8000 - 9FFF: rom1_sel (basic_ROM_a by default).
   A000 - BFFF: rom1_sel (basic_ROM_a by default).
   C000 - DFFF: rom3_sel (either wordbee_ROM, edasm_ROM or forth_ROM).
   E000 - EFFF: rom4_sel (network_ROM by default).
   F000 - F7FF: VDU_RAM (points to allocated memory) if romread = 0.
                rom5_sel (CHAR_ROM by default) if romread = 1.
   F800 - FFFF: PCG_RAM (pt to alloc mem) if colctrl = 0 or no colour emu.
                Colour_RAM if colctrl = 1 and colour emulation is on.


   NB: - RAM is persistent on reset.
       - For optimality reasons, most reads in the z80 emulator core
         read dwords rather than bytes (ie 32 bits, rather than 8).
         Hence, an additional 3 bytes are allocated to each memory block
         to ensure that reads from memory always read from allocated
         memory.
       - Where possible, the z80 core is instructed to directly access
         memory, bypassing the relevant calls.


   Microbee Memory Map - Control Data
   ==================================

   startup_flag: When the Microbee 32k is turned on (or reset), the z80
                 will start reading from PC = 0.  However, the microbee
                 will put NOPs (0) on the bus until the trigger address
                 (8000) is reached.
                 To simulate this, the startup_flag is initially 0, and
                 also 0 upon reset of emulator.  While this is 0, any
                 memory reads below (which will be indirect upon
                 startup/reset) will return 0 (NOP).  This will continue
                 until the trigger address START_READ_TRIGGER is reached,
                 at which time startup_flag will be set to 1 (a NOP
                 returned for the read at START_READ_TRIGGER), and memory
                 access from 0-START_READ_TRIGGER set to direct.
   romread:      This controls what appears in the mem range F000-F7FF.
                 If romread = 0 then VDU RAM appears here.  Otherwise
                 character ROM is found in this range.  romread is also
                 used by the keyboard circuit in the microbee, as
                 described later.
   colctrl:      This controls what appears in the mem range F800-FFFF.
                 If colctrl = 0 then PCG RAM appears here.  Otherwise
                 colour RAM is to be found.
   colback:      background colour intensity information.
                 bit 0: RED   intensity (1 = full)
                 bit 1: GREEN intensity (1 = full)
                 bit 2: BLUE  intensity (1 = full)


   Microbee Port Assignments - Basics
   ==================================

   00/10:       PIO port A data port.
   01/11:       PIO port A control port.
   02/12:       PIO port B data port.
   03/13:       PIO port B control port.
   04-07/14-17: not used.
   08/18:       COLOUR control port (see below).
                bit 0: not used.
                bit 1: RED background intensity (1 = full).
                bit 2: GREEN background intensity (1 = full).
                bit 3: BLUE background intensity (1 = full).
                bit 4: not used.
                bit 5: not used.
                bit 6: Colour RAM enable (0 = PCG, 1 = colour).
                bit 7: not used.
   09/19:       Colour "Wait off" (not used^).
   0A/1A:       Extended addressing port (not used*).
   0B/1B:       bit 0: ROMREAD
                bit 1-7: not used
   0C/1C/0E/1E: 6545 CRTC address/status port.
   0D/1D/0F/1F: 6545 CRTC data port.
   44:          FDC command/status (not yet implemented).
   45:          FDC track register (not yet implemented).
   46:          FDC sector register (not yet implemented).
   47:          FDC data register (not yet implemented).
   48:          Controller select/side/DD latch (not yet implemented).

   Notes: ^ This *might* have had something to do with VDU RAM timing at
            some stage.  Pages C.32-33 of the Microbee Technical Manual
            (32k version) say that screen deglitching is done by inserting
            wait states into the CPU when access to video RAM is attempted
            during non-blanked display.  These wait states halt the CPU
            until the blanked region is reached, when operation may
            continue.  This port is meant to disable this wait mechanism,
            making timing predictable for disk io...
            HOWEVER: on pages C.23 of the same manual describes a video
            blanking method that simply blanks characters around the time
            of any write to video RAM, thus avoiding snow without inserting
            wait states.  The blanking signal is called F000*.  Inspection
            of the circuit diagrams in the manual shows no evidence of any
            wait state insertion or colour "wait off" signals (although
            port 09 is decoded, it appears to not be used).  There is,
            however, a signal F000*, which does act in the manner described
            on C.23, so it appears that the blanking method is used, and
            thus this port seems to be irrelevant.  In any case, the F000*
            method is simpler to implement and appears the better option
            from a design standpoint, so I assume it is used in this
            emulator.
          * This has something to do with S100, apparently - ie. really old
            bees.  Unfortunately this is all I know.


   Microbee Port Assignments - Functions
   =====================================

   col_ctrl_wr:   called on write to port 08/18
   rom_read_wr:   called on write to port 0B/1B
   io_wr_default: the default, do nothing port io function.
   io_rd_default: the default, do nothing port io function.


   Microbee Port Assignments - Data
   ================================

   io_wr_table: When a port is written to the lower byte of the address is
                used to select a function from this table, and the function
                found is called to complete the write.
   io_rd_table: The same thing, but for port read operations.


   Microbee memory map helper functions
   ====================================

   setup_mem_opindirect_rw(start,end,memaddr) - tells the z80 emulation core
        that reads and writes in the range start-end should go directly to
        the memory at memaddr (where memaddr[0] corresponds to start),
        bypassing any calls.  Opreads, however, must be retrieved via
        calls to the emulator.

   setup_mem_wrindirect_rw(start,end,memaddr) - like above, but in this
        case opreads are direct (bypass) and writes must go through the
        appropriate emulation calls.

   setup_mem_rw(start,end,memaddr) - like setup_mem_opindirect_rw, except
        that in this case opreads are also direct (bypass), so all reference
        to memory bypasses function calls

   setup_mem_ro(start,end,memaddr) - similar to set_mem_rw, except that
        writes are disgarded, as the memory is to be treated (nominally)
        as read only.

   refresh_charrom() - when character ROM is swapped (or loaded for the
        first time) it is necessary to load the (new) contents into the
        6545's memory.  This function does that.

   Specific Microbee Port Callback Functions
   =========================================

   pio_a_rdy_data_out:  called by the pio to indicate state change on port a
   pio_b_rdy_data_out:  called by the pio to indicate state change on port b
   pio_ieo_out:         called by the pio to indicate state change on ieo
   pio_signal_interupt: called by the pio to indicate an interupt
*/

#define START_READ_TRIGGER      0x07FFF

UINT_8 startup_flag;
UINT_8 romread;
UINT_8 colctrl;
UINT_8 colback;

UINT_8 *user_RAM_a;  /* 0x04003 */
UINT_8 *user_RAM_b;  /* 0x04003 */
UINT_8 *VDU_RAM;     /* 0x00803 */
UINT_8 *PCG_RAM;     /* 0x00803 */
UINT_8 *colour_RAM;  /* 0x00803 */

UINT_8 *rom1_load;   /* 0x02003 */
UINT_8 *rom2_load;   /* 0x02003 */
UINT_8 *rom3_load;   /* 0x02003 */
UINT_8 *rom4_load;   /* 0x01003 */
UINT_8 *rom5_load;   /* 0x00803 */

char rom1_name[CONFIG_BUFFER_LEN];
char rom2_name[CONFIG_BUFFER_LEN];
char rom3_name[CONFIG_BUFFER_LEN];
char rom4_name[CONFIG_BUFFER_LEN];
char rom5_name[CONFIG_BUFFER_LEN];

UINT_8 *rom1_sel;
UINT_8 *rom2_sel;
UINT_8 *rom3_sel;
UINT_8 *rom4_sel;
UINT_8 *rom5_sel;

#define DEFAULT_ROM1_NUM 0
#define DEFAULT_ROM2_NUM 0
#define DEFAULT_ROM3_NUM 0
#define DEFAULT_ROM4_NUM 0
#define DEFAULT_ROM5_NUM 0

int rom1_num;
int rom2_num;
int rom3_num;
int rom4_num;
int rom5_num;

void setup_mem_opindirect_rw(UINT_16 start, UINT_16 end, UINT_8 *memaddr);
void setup_mem_wrindirect_rw(UINT_16 start, UINT_16 end, UINT_8 *memaddr);
void setup_mem_rw(UINT_16 start, UINT_16 end, UINT_8 *memaddr);
void setup_mem_ro(UINT_16 start, UINT_16 end, UINT_8 *memaddr);

void refresh_charrom(void);

void col_ctrl_wr(void);
void rom_read_wr(void);

void io_wr_default(void);
void io_rd_default(void);

void pio_a_rdy_data_out(void);
void pio_b_rdy_data_out(void);
void pio_ieo_out(void);
void pio_signal_interupt(void);

#ifdef NO_PIO
#define PIO_A_data_wr io_wr_default
#define PIO_A_ctrl_wr io_wr_default
#define PIO_B_data_wr io_wr_default
#define PIO_B_ctrl_wr io_wr_default
#define PIO_A_data_rd io_rd_default
#define PIO_A_ctrl_rd io_rd_default
#define PIO_B_data_rd io_rd_default
#define PIO_B_ctrl_rd io_rd_default
#endif

#ifndef NO_PIO
#define PIO_A_data_wr z80pio_io_wr_data_A
#define PIO_A_ctrl_wr z80pio_io_wr_ctrl_A
#define PIO_B_data_wr z80pio_io_wr_data_B
#define PIO_B_ctrl_wr z80pio_io_wr_ctrl_B
#define PIO_A_data_rd z80pio_io_rd_data_A
#define PIO_A_ctrl_rd z80pio_io_rd_ctrl_A
#define PIO_B_data_rd z80pio_io_rd_data_B
#define PIO_B_ctrl_rd z80pio_io_rd_ctrl_B
#endif

weird_pointer_jive io_wr_table[256] =
{ PIO_A_data_wr, PIO_A_ctrl_wr, PIO_B_data_wr, PIO_B_ctrl_wr,   /* 00-03 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 04-07 */
  col_ctrl_wr,   io_wr_default, io_wr_default, rom_read_wr,     /* 08-0B */
  c6545_addr_wi, c6545_data_wi, c6545_addr_wi, c6545_data_wi,   /* 0C-0F */
  PIO_A_data_wr, PIO_A_ctrl_wr, PIO_B_data_wr, PIO_B_ctrl_wr,   /* 10-13 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 14-17 */
  col_ctrl_wr,   io_wr_default, io_wr_default, rom_read_wr,     /* 18-1B */
  c6545_addr_wi, c6545_data_wi, c6545_addr_wi, c6545_data_wi,   /* 1C-1F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 20-23 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 24-27 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 28-2B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 2C-2F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 30-33 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 34-37 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 38-3B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 3C-3F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 40-43 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 44-47 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 48-4B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 4C-4F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 50-53 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 54-57 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 58-5B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 5C-5F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 60-63 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 64-67 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 68-6B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 6C-6F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 70-73 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 74-77 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 78-7B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 7C-7F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 80-83 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 84-87 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 88-8B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 8C-8F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 90-93 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 94-97 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 98-9B */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* 9C-9F */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* A0-A3 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* A4-A7 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* A8-AB */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* AC-AF */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* B0-B3 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* B4-B7 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* B8-BB */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* BC-BF */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* C0-C3 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* C4-C7 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* C8-CB */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* CC-CF */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* D0-D3 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* D4-D7 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* D8-DB */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* DC-DF */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* E0-E3 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* E4-E7 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* E8-EB */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* EC-EF */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* F0-F3 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* F4-F7 */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default,   /* F8-FB */
  io_wr_default, io_wr_default, io_wr_default, io_wr_default }; /* FC-FF */

weird_pointer_jive io_rd_table[256] =
{ PIO_A_data_rd, PIO_A_ctrl_rd, PIO_B_data_rd, PIO_B_ctrl_rd,   /* 00-03 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 04-07 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 08-0B */
  c6545_addr_ri, c6545_data_ri, c6545_addr_ri, c6545_data_ri,   /* 0C-0F */
  PIO_A_data_rd, PIO_A_ctrl_rd, PIO_B_data_rd, PIO_B_ctrl_rd,   /* 10-13 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 14-17 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 08-0B */
  c6545_addr_ri, c6545_data_ri, c6545_addr_ri, c6545_data_ri,   /* 1C-1F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 20-23 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 24-27 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 28-2B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 2C-2F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 30-33 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 34-37 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 38-3B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 3C-3F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 40-43 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 44-47 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 48-4B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 4C-4F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 50-53 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 54-57 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 58-5B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 5C-5F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 60-63 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 64-67 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 68-6B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 6C-6F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 70-73 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 74-77 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 78-7B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 7C-7F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 80-83 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 84-87 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 88-8B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 8C-8F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 90-93 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 94-97 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 98-9B */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* 9C-9F */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* A0-A3 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* A4-A7 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* A8-AB */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* AC-AF */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* B0-B3 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* B4-B7 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* B8-BB */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* BC-BF */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* C0-C3 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* C4-C7 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* C8-CB */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* CC-CF */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* D0-D3 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* D4-D7 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* D8-DB */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* DC-DF */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* E0-E3 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* E4-E7 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* E8-EB */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* EC-EF */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* F0-F3 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* F4-F7 */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default,   /* F8-FB */
  io_rd_default, io_rd_default, io_rd_default, io_rd_default }; /* FC-FF */







/************************************************************************/
/************************************************************************/

#ifdef DEBUGMODE
FILE *error_log;
#endif


int main(int argc, char *argv[])
{
    int errcode;
    SetupData *all_setdat[9];
    char **whatsplash;

    #ifdef DEBUGMODE
    error_log = fopen("error.log","wt");
    fprintf(error_log,"starting emulator\n");
    #endif

    /*
       Automated configuration routine
    */

    all_setdat[0] = main_setup();
    all_setdat[1] = beesnd_setup();
    all_setdat[2] = beescrn_setup();
    all_setdat[3] = beekey_setup();
    all_setdat[4] = beepara_setup();
    all_setdat[5] = beelowpc_setup();
    all_setdat[6] = beetape_setup();
    all_setdat[7] = beers232_setup();
    all_setdat[8] = NULL;

    load_config_file(CONFIG_FILE,all_setdat);

    switch ( argc )
    {
        case 1:
        {
            break;
        }

        case 2:
        {
            if ( load_config_file(argv[1],all_setdat) )
            {
                printf("Control file %s not found.\n",argv[1]);

                return 1;
            }

            break;
        }

        case 3:
        {
            printf("Usage: mbee32k {control_file}\n");

            return 2;

            break;
        }
    }

    /*
       Draw the splash screen intro.
    */

    whatsplash = splash_screen_colour();

    /*
       Install allegro
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"initialise allegro modules\n");
    fflush(error_log);
    #endif

    if ( ( errcode = allegro_init() ) )
    {
        printf("Allegro initialisation error %d.\n",errcode);

        return 3;
    }

    if ( ( errcode = install_timer() ) )
    {
        printf("Timer installation error %d.\n",errcode);

        return 4;
    }           

    if ( ( errcode = install_mouse() < 0 ) )
    {
        printf("Mouse installation error %d.\n",errcode);

        return 5;
    }

    if ( ( errcode = install_keyboard() ) )
    {
        printf("Keyboard installation error %d.\n",errcode);

        return 6;
    }

    /*
       Graphical splashscreen if relevant
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"gui splash\n");
    fflush(error_log);
    #endif

    set_window_title("PicoMozzy");

    if ( whatsplash != NULL )
    {
        if ( splash_graphic(whatsplash) )
        {
            return 100;
        }
    }

    /*
       Install the MicroBee 32k specific emulation modules:

       Note: beescrn_init must come before c6545_init
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"main init\n");
    fflush(error_log);
    #endif

    if ( ( errcode = main_init() ) )
    {
        printf("Main installation routine error %d.\n",errcode);

        return 7;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"lowlevel init\n");
    fflush(error_log);
    #endif

    if ( ( errcode = beelowpc_init() ) )
    {
        printf("Low level installation routine error %d.\n",errcode);

        return 7;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"screen init\n");
    fflush(error_log);
    #endif

    if ( ( is_scrn_ready = beescrn_init(&in_step_mode,
                                        &geometry_bus,
                                        &do_colour,
                                        &xpos_bus,
                                        &ypos_bus,
                                        &is_fore_bus,
                                        &fore_colour_bus,
                                        &back_colour_bus,
                                        &inv__colour_bus,
                                        screengrab) ) == 0 )
    {
        printf("Screen driver initialisation error %d.\n",is_scrn_ready);

        return 9;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"6545 init\n");
    fflush(error_log);
    #endif

    if ( ( c6545_base = c6545_init(0x03f0,
                                   &z80_data_bus,
                                   &lpen_call_mask,
                                   &geometry_bus,
                                   &video_mem_addr_bus,
                                   &video_data_bus,
                                   &video_char_line_bus,
                                   &xpos_bus,
                                   &ypos_bus,
                                   &is_fore_bus,
                                   &fore_colour_bus,
                                   &back_colour_bus,
                                   &inv__colour_bus,
                                   &lpen_reset_counter,
                                   &update_reset_counter,
                                   &lpen_table,
                                   &lpen_table,
                                   &lpen_feedback_table,
                                   &lpen_feedback_table,
                                   &lpen_feedrfsh_table,
                                   &lpen_feedrfsh_table,
                                   beescrn_change_left_margin,
                                   beescrn_change_screen_width,
                                   beescrn_change_right_margin,
                                   beescrn_change_top_margin,
                                   beescrn_change_screen_height,
                                   beescrn_change_bottom_margin,
                                   beescrn_pixel_drawer) ) == NULL )
    {
        return 10;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"pio init\n");
    fflush(error_log);
    #endif

    if ( ( z80pio_base = z80pio_init(&pio_ieo_bus,
                                     &pio_iei_bus,
                                     &z80_data_bus,
                                     &pio_a_rdy_bus,
                                     &pio_a_strb_bus,
                                     &pio_a_data_bus,
                                     &pio_b_rdy_bus,
                                     &pio_b_strb_bus,
                                     &pio_b_data_bus,
                                     &pio_a_rdy_data_out,
                                     &pio_b_rdy_data_out,
                                     &pio_ieo_out,
                                     &pio_signal_interupt) ) == NULL )
    {
        return 11;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"keyboard init\n");
    fflush(error_log);
    #endif

    if ( ( is_key_ready = beekey_init(lpen_table,
                                      lpen_feedback_table,
                                      lpen_feedrfsh_table,
                                      &lpen_reset_counter,
                                      &update_reset_counter,
                                      &key_down,
                                      &z80_clk_bus) ) == 0 )
    {
        return 12;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"sound init\n");
    fflush(error_log);
    #endif

    if ( ( is_snd_ready = beesnd_init(&sound_bit_bus,
                                      &z80_clk_bus) ) == 0 )
    {
        return 13;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"parallel port init\n");
    fflush(error_log);
    #endif

    if ( ( is_para_ready = beepara_init(&pio_a_data_bus,
                                        &pio_a_strb_bus,
                                        &pio_a_rdy_bus,
                                        parallel_strober,
                                        &z80_clk_bus) ) == 0 )
    {
        return 13;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"tape port init\n");
    fflush(error_log);
    #endif

    if ( ( is_tape_ready = beetape_init(&tape_out_bus,
                                        &tape_in_bus,
                                        tape_strober,
                                        &z80_clk_bus) ) == 0 )
    {
        return 13;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"serial port init\n");
    fflush(error_log);
    #endif

    if ( ( is_serial_ready = beers232_init(&serial_out_bus,
                                           &serial_in_bus,
                                           &z80_clk_bus) ) == 0 )
    {
        return 13;
    }

    /*
       Load character ROM into 6545 module
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"refresh character ROM\n");
    fflush(error_log);
    #endif

    refresh_charrom();

    /*
       Turn off automatic keyboard LEDs.
       Update keyboard LEDs to reflect state.
       See if keyboard needs polling.
       See if mouse needs polling.
       Turn off keyboard delays, max out responce speed.
       Clear the keyboard buffer.
       Set the lowlevel keyboard callback function.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"bits and stuff\n");
    fflush(error_log);
    #endif

    key_led_flag = 0;
    update_leds();
    keyboard_poll_mode = keyboard_needs_poll();
    mouse_poll_mode    = mouse_needs_poll();
    set_keyboard_rate(750,100); /* a windows bug makes this not work */
    clear_keybuf();
    keyboard_lowlevel_callback = key_lowlevel_stuff;

    /*
       Install the timer function.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"timer install\n");
    fflush(error_log);
    #endif

    if ( install_int_ex(speed_throttle,MSEC_TO_TIMER(timer_period_x/1000000)) )
    {
        return 14;
    }

    if ( install_int_ex(overlook_timer,SECS_TO_TIMER(OVERLOOK_TIMER_PERIOD)) )
    {
        return 15;
    }

    /*
       Start the emulator.  This will only exit when the emulation is
       finished, and the "off" signal is passed to the emulator.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"enter emulator\n");
    fflush(error_log);
    #endif

    z80_enter();

    #ifdef DEBUGMODE
    fprintf(error_log,"exited emulator\n");
    fflush(error_log);
    #endif

    /*
       Redirect keyboard function to prevent errors.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"redirect keyboard function\n");
    fflush(error_log);
    #endif

    keyboard_lowlevel_callback = key_lowlevel_exit;

    /*
       Remove timer interupt.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"remove timer interupt\n");
    fflush(error_log);
    #endif

    remove_int(speed_throttle);

    /*
       Remove emulation modules in reverse order.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"remove modules\n");
    fflush(error_log);
    #endif

    beers232_remove();          is_serial_ready = 0;
    beetape_remove();           is_tape_ready   = 0;
    beepara_remove();           is_para_ready   = 0;
    beesnd_remove();            is_snd_ready    = 0;
    beekey_remove();            is_key_ready    = 0;
    z80pio_remove(z80pio_base); z80pio_base     = NULL;
    c6545_remove(c6545_base);   c6545_base      = NULL;
    beescrn_remove();           is_scrn_ready   = 0;

    beelowpc_remove();
    main_remove();

    /*
       Remove allegro modules
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"remove allegro\n");
    fflush(error_log);
    #endif

    remove_keyboard();
    remove_mouse();
    remove_timer();

    allegro_exit();

    return 0;
}
END_OF_MAIN()





/**********************************************************************

                           Core of emulator
                           ================

The z80_sync_clock function provides linking between the various emulator
modules.  The z80 cpu emulation is central - every so often, if will call
this to say "I've done z80_clk_bus clock cycles, time to let the other
emulator modules catch up".  This function will make take other emulation
blocks through an appropriate number of cycles each, allowing them to
update there internal states and make relevant calls (ie. update the screen,
check the ports, etc.).

                          Clock synchronisation
                          =====================

For each clock cycle of the z80, the 6545 through 1/2 a clock cycle.
However, this results in very slow emulation.  To overcome this problems,
some cheating is necessary.

crtc_granularity: the 6545 clock synchronisation function is only called
                  when the number of accumulated 6545 clock cycles reaches
                  this number.

These can be set one of two values.  When no (relevant) keys are down,
they are set to the _no_key values, which can be quite large, meaning that
the screen updates are slowed.  As there are no keys down, this should not
affect the operation of the microbee (which uses the 6545 to test for keys)
overly much.

If a relevant key is pressed, however, this is throttled back to true (no
granularity, no division) operation, with the 6545 running at true (1/2
cpu clock speed) speed.  Thus the keyboard operation is not impeeded.

These values have been selected by trial and error.


**********************************************************************/

void z80_sync_clock(void)
{
    /*
       Because we can't call functions from the timer interupt function,
       we need to do it here.
    */

    switch ( sync_point )
    {
        case 1:
        {
            BEELOWPC_SYNC_CLOCK;
            beesnd_timing_accur_signal();

            break;
        }

        case 2:
        {
            BEELOWPC_SYNC_CLOCK;
            beesnd_timing_accur_signal();


            break;
        }

        default:
        {
            break;
        }
    }

    sync_point = 0;

    /*
       Poll hardware if necessary.
    */

    if ( keyboard_poll_mode ) { poll_keyboard(); }
    if ( mouse_poll_mode    ) { poll_mouse();    }

    /*
       Microbee clock sync section.
    */

    if ( do_throttle )
    {
        actual_clocks -= z80_clk_bus;

        if ( actual_clocks < -catchup_point )
        {
            is_wait = 1;

            while ( actual_clocks < 0 )
            {
                if ( !do_throttle )
                {
                    break;
                }
            }
        }
    }

    is_wait = 0;

    /*
       Sound emulation module.
    */

    beesnd_cycle();

    /*
       6545 clock

       - Add any "left over" clock cycles to the z80_clk_bus counter.
       - Round the clock count to half the z80 cpu frequency and save
         any leftovers for next time.
       - Halve the count.
       - update the 6545 cycle counter.
    */

    local_c6545_cycle_counter += ( (z80_clk_bus+c6545_clk_odds) / CRTC6545_RELATIVE_CLOCK_RATE );
    c6545_clk_odds             = ( (z80_clk_bus+c6545_clk_odds) % CRTC6545_RELATIVE_CLOCK_RATE );

    if ( local_c6545_cycle_counter > crtc_granularity )
    {
        cycle_counter_c6545_bus    = local_c6545_cycle_counter / crtc_clock_division;
        local_c6545_cycle_counter -= cycle_counter_c6545_bus * crtc_clock_division;

        c6545_do_cycles(c6545_base,cycle_counter_c6545_bus,crtc_clock_division);
    }

    /*
       Keyboard stuff
    */

    beekey_cycle();
    TIMER_KEYLOOK(key_down);

    /*
       Tape port emulation
    */

    beetape_cycle();

    /*
       Serial port emulation
    */

    beers232_cycle();

    /*
       Parallel port emulation
    */

    beepara_cycle();

    /*
       Clear the clock cycle bus
    */

    z80_clk_bus = 0;

    /*
       Flag response section.
    */

    if ( interact_flag || in_step_mode )
    {
        /*
           Enter interactive mode.
        */

        main_menu_function();

        interact_flag = 0;
    }

    if ( printscreen_flag )
    {
        /*
           Save screen snapshot.
        */

        beescrn_screenshot(DEFAULT_SCREENDUMP_FILE);

        printscreen_flag = 0;
    }

    if ( mbee_reset_flag )
    {
        /*
           The reset key has been pressed.  Pass this signal back to the z80
           emulation module.  This module will subsequently call the correct
           reset function.
        */

        z80_set_reset();
    }

    /*
       Finally, some pio stuff to take care of - if a reti instruction has
       occured, we need to tell the z80 pio about it.
    */

    if ( z80_reti_count )
    {
        z80_reti_count = 0;

        z80pio_reti_signal(z80pio_base);
    }

    return;
}

void z80_ack_reset(void)
{
    /*
       This function is called by the z80 emulator when a reset signal is
       received.  It calls functions to reset all other modules.
    */

    startup_flag = 0;
    romread      = 0;
    colctrl      = 0;
    colback      = 0;

    c6545_clk_odds = 0;

    /*
       FIXME - shouldn't be calling 6545_reset here, but it appears to be
               necessary.
    */

    c6545_reset(c6545_base);
    z80pio_reset(z80pio_base);

    /*
       Set memory reads to indirect to mask the contents of RAM until the
       trip address START_READ_TRIGGER is reached.
    */

    setup_mem_opindirect_rw(0x000,0x03F,user_RAM_a);
    setup_mem_opindirect_rw(0x040,0x07F,user_RAM_b);
    setup_mem_wrindirect_rw(0x0F0,0x0F7,VDU_RAM);
    setup_mem_wrindirect_rw(0x0F8,0x0FF,PCG_RAM);

    lpen_call_mask = ROMREAD0_LPEN_MASK;

    return;
}







/**********************************************************************

                        Microbee memory mapping
                        =======================

**********************************************************************/

void z80_rd_mem(void)
{
    z80_wait_bus = 0;
    z80_data_bus = 0;

    switch ( z80_addr_bus & 0x0F800 )
    {
        case 0x00000:
        case 0x00800:
        case 0x01000:
        case 0x01800:
        case 0x02000:
        case 0x02800:
        case 0x03000:
        case 0x03800:
        {
            /*
               If just reset, don't read.
            */

            if ( startup_flag )
            {
                z80_data_bus = DEBDEREF(user_RAM_a,z80_addr_bus);
            }

            break;
        }

        case 0x04000:
        case 0x04800:
        case 0x05000:
        case 0x05800:
        case 0x06000:
        case 0x06800:
        case 0x07000:
        case 0x07800:
        {
            /*
               If just reset, don't read.
            */

            if ( startup_flag )
            {
                z80_data_bus = DEBDEREF(user_RAM_b,z80_addr_bus - 0x04000);
            }

            else
            {
                /*
                   START_READ_TRIGGER is a "trigger address".  When this
                   address is hit, we still read 0.  However, we can at this
                   point start doing direct reads from memory (no need to
                   mask reads to 0), so any future reads will come from
                   memory.
                */

                if ( z80_addr_bus == START_READ_TRIGGER )
                {
                    startup_flag = 1;

                    setup_mem_rw(0x000,0x03F,user_RAM_a);
                    setup_mem_rw(0x040,0x07F,user_RAM_b);
                }
            }

            break;
        }

        case 0x08000:
        case 0x08800:
        case 0x09000:
        case 0x09800:
        {
            z80_data_bus = rom1_sel[z80_addr_bus - 0x08000];

            break;
        }

        case 0x0A000:
        case 0x0A800:
        case 0x0B000:
        case 0x0B800:
        {
            z80_data_bus = rom2_sel[z80_addr_bus - 0x0A000];

            break;
        }

        case 0x0C000:
        case 0x0C800:
        case 0x0D000:
        case 0x0D800:
        {
            z80_data_bus = rom3_sel[z80_addr_bus - 0x0C000];

            break;
        }

        case 0x0E000:
        case 0x0E800:
        {
            z80_data_bus = rom4_sel[z80_addr_bus - 0x0E000];

            break;
        }

        case 0x0F000:
        {
            /*
               If romread the character rom will overlay VDU ram at this
               point in memory.
            */

            if ( romread )
            {
                z80_data_bus = rom5_sel[z80_addr_bus - 0x0F000];
            }

            else
            {
                z80_data_bus = DEBDEREF(VDU_RAM,z80_addr_bus - 0x0F000);
            }

            break;
        }

        case 0x0F800:
        default:
        {
            /*
              Colour RAM may overwrite PCG RAM here.
            */

            if ( colctrl )
            {
                z80_data_bus = DEBDEREF(colour_RAM,z80_addr_bus - 0x0F800);
            }

            else
            {
                z80_data_bus = DEBDEREF(PCG_RAM,z80_addr_bus - 0x0F800);
            }

            break;
        }
    }

    return;
}

void z80_wr_mem(void)
{
    z80_wait_bus = 0;

    switch ( z80_addr_bus & 0x0F800 )
    {
        case 0x00000:
        case 0x00800:
        case 0x01000:
        case 0x01800:
        case 0x02000:
        case 0x02800:
        case 0x03000:
        case 0x03800:
        {
            DEBDEREF(user_RAM_a,z80_addr_bus) = z80_data_bus;

            break;
        }

        case 0x04000:
        case 0x04800:
        case 0x05000:
        case 0x05800:
        case 0x06000:
        case 0x06800:
        case 0x07000:
        case 0x07800:
        {
            DEBDEREF(user_RAM_b,z80_addr_bus - 0x04000) = z80_data_bus;

            break;
        }

        case 0x0F000:
        {
            /*
               If character ROM is present at this point then writes will
               go nowhere.  Otherwise, writes must go both to the usual
               RAM memory and also be passed onto the 6545 emulator so that
               changes are reflected on the screen.
            */

            if ( !romread )
            {
                video_mem_addr_bus = z80_addr_bus & 0x007FF;
                video_data_bus     = z80_data_bus;

                DEBDEREF(VDU_RAM,video_mem_addr_bus) = video_data_bus;

                c6545_write_vdu_mem(c6545_base);
            }

            break;
        }

        case 0x0F800:
        {
            if ( colctrl )
            {
                /*
                   Writes to colour RAM must also be re-directed to the
                   6545 emulator.
                */

                video_mem_addr_bus = z80_addr_bus & 0x007FF;

                DEBDEREF(colour_RAM,video_mem_addr_bus) = z80_data_bus;

                video_data_bus = beescrn_trans_colour(z80_data_bus & 0x01f);

                c6545_write_fore_colour(c6545_base);

                video_data_bus  = ( ( z80_data_bus & 0x040 ) >> 2 ) +
                                  ( ( z80_data_bus & 0x020 )      ) +
                                  ( ( z80_data_bus & 0x080 ) >> 4 );
                video_data_bus |= colback;

                c6545_write_back_colour(c6545_base);
            }

            else
            {
                /*
                   Writes to character RAM must also be re-directed to the
                   6545 emulator.
                */

                video_mem_addr_bus = z80_addr_bus & 0x007FF;
                video_data_bus     = z80_data_bus;

                DEBDEREF(PCG_RAM,video_mem_addr_bus) = video_data_bus;

                video_char_line_bus = video_mem_addr_bus & 0x00F;

                video_mem_addr_bus >>= 0x004;
                video_mem_addr_bus +=  0x00080;

                c6545_write_char_mem(c6545_base);
            }

            break;
        }

        case 0x08000:
        case 0x08800:
        case 0x09000:
        case 0x09800:
        case 0x0A000:
        case 0x0A800:
        case 0x0B000:
        case 0x0B800:
        case 0x0C000:
        case 0x0C800:
        case 0x0D000:
        case 0x0D800:
        case 0x0E000:
        case 0x0E800:
        default:
        {
            /*
               Writes to ROM go nowhere
            */

            break;
        }
    }

    return;
}






/**********************************************************************
 ***                                                                ***
 ***                         Port Functions                         ***
 ***                                                                ***
 **********************************************************************/


void z80_wr_io(void)
{
    z80_wait_bus = 0;

    (io_wr_table[( z80_addr_bus & 0x0FF )])();

    return;
}

void z80_rd_io(void)
{
    z80_wait_bus = 0;

    (io_rd_table[( z80_addr_bus & 0x0FF )])();

    return;
}

void io_wr_default(void)
{
    return;
}

void io_rd_default(void)
{
    z80_data_bus = 0;

    return;
}

void z80pio_io_wr_data_A(void)
{
    z80pio_data_wr_A(z80pio_base);

    return;
}

void z80pio_io_wr_ctrl_A(void)
{
    z80pio_ctrl_wr_A(z80pio_base);

    return;
}

void z80pio_io_wr_data_B(void)
{
    z80pio_data_wr_B(z80pio_base);

    return;
}

void z80pio_io_wr_ctrl_B(void)
{
    z80pio_ctrl_wr_B(z80pio_base);

    return;
}

void z80pio_io_rd_data_A(void)
{
    z80pio_data_rd_A(z80pio_base);

    return;
}

void z80pio_io_rd_ctrl_A(void)
{
    z80pio_ctrl_rd_A(z80pio_base);

    return;
}

void z80pio_io_rd_data_B(void)
{
    z80pio_data_rd_B(z80pio_base);

    return;
}

void z80pio_io_rd_ctrl_B(void)
{
    z80pio_ctrl_rd_B(z80pio_base);

    return;
}

void c6545_addr_wi(void)
{
    c6545_addr_wr(c6545_base);

    return;
}

void c6545_data_wi(void)
{
    c6545_data_wr(c6545_base);

    return;
}

void c6545_addr_ri(void)
{
    c6545_addr_rd(c6545_base);

    return;
}

void c6545_data_ri(void)
{
    c6545_data_rd(c6545_base);

    return;
}


#define SWITCH_IN_PCG(addr)                                             \
{                                                                       \
    z80_mem_addr_table[addr] = PCG_RAM + ( ( addr - 0x0F8 ) * 0x00100 ); \
    z80_mem_wtwr_table[addr] = 0;                                       \
    z80_mem_wtrd_table[addr] = 0;                                       \
}

#define SWITCH_IN_colour(addr)                                          \
{                                                                       \
    z80_mem_addr_table[addr] = colour_RAM + ( ( addr - 0x0F8 ) * 0x00100 ); \
    z80_mem_wtwr_table[addr] = 0;                                       \
    z80_mem_wtrd_table[addr] = 0;                                       \
}

void col_ctrl_wr(void)
{
    UINT_8 old_colback;
    UINT_8 old_colctrl;

    if ( do_colour || colctrl )
    {
        old_colback = colback;
        old_colctrl = colctrl;

        colback = ( z80_data_bus & 0x00e ) >> 1;
        colctrl = ( z80_data_bus & 0x040 ) >> 6;

        if ( colback != old_colback )
        {
            /*
               Background colour has changed over the whole screen, so need
               to rewrite the background colour RAM of the 6545 emulator.
            */

            for ( video_mem_addr_bus = 0 ; video_mem_addr_bus <= 0x007FF ; video_mem_addr_bus++ )
            {
                video_data_bus  = ( DEBDEREF(colour_RAM,video_mem_addr_bus) & 0x0e0 ) >> 2;
                video_data_bus |= colback;

                c6545_write_back_colour(c6545_base);
            }
        }

        if ( colctrl != old_colctrl )
        {
            if ( colctrl )
            {
                SWITCH_IN_colour(0x0F8);
                SWITCH_IN_colour(0x0F9);
                SWITCH_IN_colour(0x0FA);
                SWITCH_IN_colour(0x0FB);
                SWITCH_IN_colour(0x0FC);
                SWITCH_IN_colour(0x0FD);
                SWITCH_IN_colour(0x0FE);
                SWITCH_IN_colour(0x0FF);
            }

            else
            {
                SWITCH_IN_PCG(0x0F8);
                SWITCH_IN_PCG(0x0F9);
                SWITCH_IN_PCG(0x0FA);
                SWITCH_IN_PCG(0x0FB);
                SWITCH_IN_PCG(0x0FC);
                SWITCH_IN_PCG(0x0FD);
                SWITCH_IN_PCG(0x0FE);
                SWITCH_IN_PCG(0x0FF);
            }
        }
    }

    return;
}

#define SWITCH_IN_CHARROM(addr)                                         \
{                                                                       \
    z80_mem_addr_table[addr] = rom5_sel + ( ( addr - 0x0F0 ) * 0x00100 ); \
    z80_mem_wtwr_table[addr] = 0;                                       \
    z80_mem_wtrd_table[addr] = 0;                                       \
}

#define SWITCH_IN_VDU(addr)                                             \
{                                                                       \
    z80_mem_addr_table[addr] = VDU_RAM + ( ( addr - 0x0F0 ) * 0x00100 ); \
    z80_mem_wtwr_table[addr] = 0;                                       \
    z80_mem_wtrd_table[addr] = 0;                                       \
}

void rom_read_wr(void)
{
    UINT_8 old_romread;

    old_romread = romread;

    romread = z80_data_bus & 0x001;

    /*
       The lightpen mask (which controls whether the 6545 emulator will
       call the lightpen function (keyboard) when the time is right) is
       dependent on the the romread state.  So, we need to change this
       mask according to the setting made here.
    */

    if ( romread != old_romread )
    {
        if ( romread )
        {
            lpen_call_mask = ROMREAD1_LPEN_MASK;

            SWITCH_IN_CHARROM(0x0F0);
            SWITCH_IN_CHARROM(0x0F1);
            SWITCH_IN_CHARROM(0x0F2);
            SWITCH_IN_CHARROM(0x0F3);
            SWITCH_IN_CHARROM(0x0F4);
            SWITCH_IN_CHARROM(0x0F5);
            SWITCH_IN_CHARROM(0x0F6);
            SWITCH_IN_CHARROM(0x0F7);
        }

        else
        {
            lpen_call_mask = ROMREAD0_LPEN_MASK;

            SWITCH_IN_VDU(0x0F0);
            SWITCH_IN_VDU(0x0F1);
            SWITCH_IN_VDU(0x0F2);
            SWITCH_IN_VDU(0x0F3);
            SWITCH_IN_VDU(0x0F4);
            SWITCH_IN_VDU(0x0F5);
            SWITCH_IN_VDU(0x0F6);
            SWITCH_IN_VDU(0x0F7);
        }
    }

    return;
}




/**********************************************************************
 ***                                                                ***
 ***                          PIO Functions                         ***
 ***                                                                ***
 **********************************************************************/



void pio_a_rdy_data_out(void)
{
    if ( is_para_ready )
    {
        beepara_data_written();
    }

    return;
}

void pio_b_rdy_data_out(void)
{
    if ( is_serial_ready )
    {
        serial_out_bus = (pio_b_data_bus & 0x024);

        beers232_serial_out_state_change();
    }

    if ( is_tape_ready )
    {
        tape_out_bus = (pio_b_data_bus & 0x002);

        beetape_state_change();
    }

    if ( is_snd_ready )
    {
        sound_bit_bus = (pio_b_data_bus & 0x040);

        beesnd_speaker_state_change();
    }

    return;
}

void pio_ieo_out(void)
{
    return;
}

void pio_signal_interupt(void)
{
    z80_set_INT();

    return;
}

void z80_ack_INT(void)
{
    z80_data_bus = 0;
    z80_wait_bus = 0;

    z80pio_ack_int(z80pio_base);
    z80_res_INT();

    return;
}

void parallel_strober(void)
{
    if ( is_para_ready )
    {
        z80pio_a_strb_data_in(z80pio_base);
    }

    return;
}

void tape_strober(void)
{
    if ( is_tape_ready )
    {
        pio_b_data_bus ^= 0x001;

        z80pio_b_strb_data_in(z80pio_base);
    }

    return;
}




/**********************************************************************
 ***                                                                ***
 ***     Unused, uninformative or irrelevant z80 functionality      ***
 ***                                                                ***
 **********************************************************************/

void z80_ack_busrq(void)
{
    z80_wait_bus = 0;

    return;
}

void z80_ack_halt(void)
{
    return;
}

void z80_ack_NMI(void)
{
    return;
}

void z80_opfetch(void)
{
    z80_rd_mem();

    return;
}



/**********************************************************************
 ***                                                                ***
 ***                       Timing stuff                             ***
 ***                                                                ***
 **********************************************************************/

void timer_speed_emul_off(void)
{
    temp_crtc_granularity_is_key    = crtc_granularity_is_key;
    temp_crtc_clock_division_is_key = crtc_clock_division_is_key;
    temp_crtc_granularity_no_key    = crtc_granularity_no_key;
    temp_crtc_clock_division_no_key = crtc_clock_division_no_key;

    #ifdef FAST_IS_SLOW
    crtc_granularity_is_key    = REAL_CRTC_GRANULARITY;
    crtc_clock_division_is_key = REAL_CRTC_CLOCK_DIV;
    crtc_granularity_no_key    = REAL_CRTC_GRANULARITY;
    crtc_clock_division_no_key = REAL_CRTC_CLOCK_DIV;
    #endif

    #ifndef FAST_IS_SLOW
    crtc_granularity_is_key    = max_crtc_granularity_key;
    crtc_clock_division_is_key = max_crtc_clock_division_key;
    crtc_granularity_no_key    = max_crtc_granularity;
    crtc_clock_division_no_key = max_crtc_clock_division;
    #endif

    actual_clocks = 0;

    return;
}
END_OF_FUNCTION(timer_speed_emul_off);

void timer_speed_emul_on(void)
{
    crtc_granularity_is_key    = temp_crtc_granularity_is_key;
    crtc_clock_division_is_key = temp_crtc_clock_division_is_key;
    crtc_granularity_no_key    = temp_crtc_granularity_no_key;
    crtc_clock_division_no_key = temp_crtc_clock_division_no_key;

    actual_clocks = 0;

    return;
}
END_OF_FUNCTION(timer_speed_emul_on);





/**********************************************************************
 ***                                                                ***
 ***                       Various bits                             ***
 ***                                                                ***
 **********************************************************************/

void key_lowlevel_exit(int scancode)
{
    scancode = 0;

    return;
}
END_OF_FUNCTION(key_lowlevel_exit)

void key_lowlevel_stuff(int scancode)
{
    /*
       These need local scope (otherwise, what if it's called twice, the
       second time before the 1st is finished?).
    */

    if ( !in_menu_mode )
    {
        switch ( scancode )
        {
            case SCREENDUMP_KEY:
            {
                /* Set flag to save screenshot */

                printscreen_flag = 1;

                break;
            }

            case INTERACT_KEY:
            {
                /* Set flag to enter interactive mode */

                interact_flag = 1;

                break;
            }

            case BEERESET_KEY:
            {
                /* Reset key pressed */

                mbee_reset_flag = 1;

                break;
            }

            case (BEERESET_KEY | 0x080):
            {
                /* Reset key released */

                mbee_reset_flag = 0;

                break;
            }

            case SCREENRFSH_KEY:
            {
                c6545_refresh(c6545_base);

                break;
            }

            case SPEEDCNTRL_KEY:
            {
                /* toggle speed emulation. */

                if ( do_throttle )
                {
                    do_throttle = 0;

                    timer_speed_emul_off();
                }

                else
                {
                    do_throttle = 1;

                    timer_speed_emul_on();
                }

                TIMER_KEYLOOK(key_down);

                update_leds();

                break;
            }

            case SOUNDCNTRL_KEY:
            {
                /* toggle sound emulation. */

                beesnd_toggle_sound();

                update_leds();

                break;
            }

            case KEY_ESC:           case (KEY_ESC           | 0x080):

            case KEY_F1:            case (KEY_F1            | 0x080):
            case KEY_F2:            case (KEY_F2            | 0x080):
            case KEY_F3:            case (KEY_F3            | 0x080):
            case KEY_F4:            case (KEY_F4            | 0x080):

            case KEY_F5:            case (KEY_F5            | 0x080):
            case KEY_F6:            case (KEY_F6            | 0x080):
            case KEY_F7:            case (KEY_F7            | 0x080):
            case KEY_F8:            case (KEY_F8            | 0x080):

            case KEY_F9:            case (KEY_F9            | 0x080):
            case KEY_F10:           case (KEY_F10           | 0x080):
            case KEY_F11:           case (KEY_F11           | 0x080):
            case KEY_F12:           case (KEY_F12           | 0x080):

            case KEY_TILDE:         case (KEY_TILDE         | 0x080):
            case KEY_1:             case (KEY_1             | 0x080):
            case KEY_2:             case (KEY_2             | 0x080):
            case KEY_3:             case (KEY_3             | 0x080):
            case KEY_4:             case (KEY_4             | 0x080):
            case KEY_5:             case (KEY_5             | 0x080):
            case KEY_6:             case (KEY_6             | 0x080):
            case KEY_7:             case (KEY_7             | 0x080):
            case KEY_8:             case (KEY_8             | 0x080):
            case KEY_9:             case (KEY_9             | 0x080):
            case KEY_0:             case (KEY_0             | 0x080):
            case KEY_MINUS:         case (KEY_MINUS         | 0x080):
            case KEY_EQUALS:        case (KEY_EQUALS        | 0x080):
            case KEY_BACKSLASH:     case (KEY_BACKSLASH     | 0x080):
            case KEY_BACKSPACE:     case (KEY_BACKSPACE     | 0x080):

            case KEY_TAB:           case (KEY_TAB           | 0x080):
            case KEY_Q:             case (KEY_Q             | 0x080):
            case KEY_W:             case (KEY_W             | 0x080):
            case KEY_E:             case (KEY_E             | 0x080):
            case KEY_R:             case (KEY_R             | 0x080):
            case KEY_T:             case (KEY_T             | 0x080):
            case KEY_Y:             case (KEY_Y             | 0x080):
            case KEY_U:             case (KEY_U             | 0x080):
            case KEY_I:             case (KEY_I             | 0x080):
            case KEY_O:             case (KEY_O             | 0x080):
            case KEY_P:             case (KEY_P             | 0x080):
            case KEY_OPENBRACE:     case (KEY_OPENBRACE     | 0x080):
            case KEY_CLOSEBRACE:    case (KEY_CLOSEBRACE    | 0x080):

            case KEY_CAPSLOCK:      case (KEY_CAPSLOCK      | 0x080):
            case KEY_A:             case (KEY_A             | 0x080):
            case KEY_S:             case (KEY_S             | 0x080):
            case KEY_D:             case (KEY_D             | 0x080):
            case KEY_F:             case (KEY_F             | 0x080):
            case KEY_G:             case (KEY_G             | 0x080):
            case KEY_H:             case (KEY_H             | 0x080):
            case KEY_J:             case (KEY_J             | 0x080):
            case KEY_K:             case (KEY_K             | 0x080):
            case KEY_L:             case (KEY_L             | 0x080):
            case KEY_COLON:         case (KEY_COLON         | 0x080):
            case KEY_QUOTE:         case (KEY_QUOTE         | 0x080):
            case KEY_ENTER:         case (KEY_ENTER         | 0x080):

            case KEY_LSHIFT:        case (KEY_LSHIFT        | 0x080):
            case KEY_Z:             case (KEY_Z             | 0x080):
            case KEY_X:             case (KEY_X             | 0x080):
            case KEY_C:             case (KEY_C             | 0x080):
            case KEY_V:             case (KEY_V             | 0x080):
            case KEY_B:             case (KEY_B             | 0x080):
            case KEY_N:             case (KEY_N             | 0x080):
            case KEY_M:             case (KEY_M             | 0x080):
            case KEY_COMMA:         case (KEY_COMMA         | 0x080):
            case KEY_STOP:          case (KEY_STOP          | 0x080):
            case KEY_SLASH:         case (KEY_SLASH         | 0x080):
            case KEY_RSHIFT:        case (KEY_RSHIFT        | 0x080):

            case KEY_LCONTROL:      case (KEY_LCONTROL      | 0x080):
            case KEY_ALT:           case (KEY_ALT           | 0x080):
            case KEY_SPACE:         case (KEY_SPACE         | 0x080):
            case KEY_ALTGR:         case (KEY_ALTGR         | 0x080):
            case KEY_RCONTROL:      case (KEY_RCONTROL      | 0x080):

            case KEY_INSERT:        case (KEY_INSERT        | 0x080):
            case KEY_HOME:          case (KEY_HOME          | 0x080):
            case KEY_DEL:           case (KEY_DEL           | 0x080):
            case KEY_END:           case (KEY_END           | 0x080):

            case KEY_LEFT:          case (KEY_LEFT          | 0x080):
            case KEY_RIGHT:         case (KEY_RIGHT         | 0x080):
            case KEY_UP:            case (KEY_UP            | 0x080):
            case KEY_DOWN:          case (KEY_DOWN          | 0x080):

            case KEY_SLASH_PAD:     case (KEY_SLASH_PAD     | 0x080):
            case KEY_ASTERISK:      case (KEY_ASTERISK      | 0x080):
            case KEY_MINUS_PAD:     case (KEY_MINUS_PAD     | 0x080):
            case KEY_PLUS_PAD:      case (KEY_PLUS_PAD      | 0x080):
            case KEY_0_PAD:         case (KEY_0_PAD         | 0x080):
            case KEY_1_PAD:         case (KEY_1_PAD         | 0x080):
            case KEY_2_PAD:         case (KEY_2_PAD         | 0x080):
            case KEY_3_PAD:         case (KEY_3_PAD         | 0x080):
            case KEY_4_PAD:         case (KEY_4_PAD         | 0x080):
            case KEY_5_PAD:         case (KEY_5_PAD         | 0x080):
            case KEY_6_PAD:         case (KEY_6_PAD         | 0x080):
            case KEY_7_PAD:         case (KEY_7_PAD         | 0x080):
            case KEY_8_PAD:         case (KEY_8_PAD         | 0x080):
            case KEY_9_PAD:         case (KEY_9_PAD         | 0x080):
            case KEY_DEL_PAD:       case (KEY_DEL_PAD       | 0x080):
            {
                /* Potential "bee" key has been pressed - call an
                   appropriate functon to update the bee keyboard state */

                beekey_update_state();

                TIMER_KEYLOOK(key_down);

                break;
            }

            default:
            {
                break;
            }
        }
    }

    else
    {
        switch ( scancode )
        {
            case SCREENDUMP_KEY:
            {
                /* Set flag to save screenshot */

                get_palette(zzzpal);
                zzzbmp = create_sub_bitmap(screen,0,0,640,480);
                save_bitmap(DEFAULT_SCREENDUMP_FILE,zzzbmp,zzzpal);
                destroy_bitmap(zzzbmp);

                break;
            }

            default:
            {
                break;
            }
        }
    }

    return;
}
END_OF_FUNCTION(key_lowlevel_stuff)

void speed_throttle(void)
{
    sync_point = 1;

    if ( !in_menu_mode )
    {
        throttle_call_count++;

        if ( do_throttle )
        {
            if ( key_down )
            {
                actual_clocks += timer_period_x/clock_period;

                #ifndef DISABLE_CRTC_THROTTLING
                if ( actual_clocks > max_clockovr )
                {
                    actual_clocks = max_clockovr_pb;

                    /*
                       The emulator is not keeping up, so try to reduce the
                       load due to CRTC emulation.
                    */

                    if ( crtc_granularity_is_key < max_crtc_granularity_key )
                    {
                        crtc_granularity_is_key++;

                        crtc_granularity = crtc_granularity_is_key;
                    }

                    else if ( crtc_clock_division_is_key < max_crtc_clock_division_key )
                    {
                        crtc_granularity_is_key = REAL_CRTC_GRANULARITY;

                        crtc_clock_division_is_key *= 2;

                        crtc_granularity     = crtc_granularity_is_key;
                        crtc_clock_division  = crtc_clock_division_is_key;

                        sync_point = 2;
                    }
                }
                #endif

                /*
                   If we're going really fast, we can afford to slow down
                   CRTC emulation to improve accuracy.
                */

                #ifndef DISABLE_CRTC_THROTTLING
                if ( is_wait )
                {
                    if ( is_wait >= lag_point )
                    {
                        if ( crtc_granularity_is_key > REAL_CRTC_GRANULARITY )
                        {
                            crtc_granularity_is_key--;

                            crtc_granularity = crtc_granularity_is_key;
                        }

                        else if ( crtc_clock_division_is_key > REAL_CRTC_CLOCK_DIV )
                        {
                            crtc_granularity_is_key = max_crtc_granularity_key;

                            crtc_clock_division_is_key /= 2;

                            crtc_granularity     = crtc_granularity_is_key;
                            crtc_clock_division  = crtc_clock_division_is_key;

                            sync_point = 2;
                        }

                        is_wait = 1;
                    }

                    else
                    {
                        is_wait++;
                    }
                }
                #endif
            }

            else
            {
                actual_clocks += timer_period_x/clock_period;

                #ifndef DISABLE_CRTC_THROTTLING
                if ( actual_clocks > max_clockovr )
                {
                    actual_clocks = max_clockovr_pb;

                    /*
                       The emulator is not keeping up, so try to reduce the
                       load due to CRTC emulation.
                    */

                    if ( crtc_granularity_no_key < max_crtc_granularity )
                    {
                        crtc_granularity_no_key++;

                        crtc_granularity = crtc_granularity_no_key;
                    }

                    else if ( crtc_clock_division_no_key < max_crtc_clock_division )
                    {
                        crtc_granularity_no_key = REAL_CRTC_GRANULARITY;

                        crtc_clock_division_no_key *= 2;

                        crtc_granularity     = crtc_granularity_no_key;
                        crtc_clock_division  = crtc_clock_division_no_key;

                        sync_point = 2;
                    }
                }
                #endif

                /*
                   If we're going really fast, we can afford to slow down
                   CRTC emulation to improve accuracy.
                */

                #ifndef DISABLE_CRTC_THROTTLING
                if ( is_wait )
                {
                    if ( is_wait >= lag_point )
                    {
                        if ( crtc_granularity_no_key > REAL_CRTC_GRANULARITY )
                        {
                            crtc_granularity_no_key--;

                            crtc_granularity = crtc_granularity_no_key;
                        }

                        else if ( crtc_clock_division_no_key > REAL_CRTC_CLOCK_DIV )
                        {
                            crtc_granularity_no_key = max_crtc_granularity;

                            crtc_clock_division_no_key /= 2;

                            crtc_granularity     = crtc_granularity_no_key;
                            crtc_clock_division  = crtc_clock_division_no_key;

                            sync_point = 2;
                        }

                        is_wait = 1;
                    }

                    else
                    {
                        is_wait++;
                    }
                }
                #endif
            }
        }
    }

    return;
}
END_OF_FUNCTION(speed_throttle)

void overlook_timer(void)
{
    if ( !in_menu_mode )
    {
        if ( !overlook_timer_firstcall )
        {
            timer_period_x = (OVERLOOK_TIMER_PERIOD*10000000)/(throttle_call_count/100);
            throttle_call_count = 0;
        }

        else
        {
            overlook_timer_firstcall = 0;
            throttle_call_count      = 0;
        }
    }

    else
    {
        overlook_timer_firstcall = 1;
        throttle_call_count      = 0;
    }

    return;
}
END_OF_FUNCTION(overlook_timer)


void update_leds(void)
{
    #ifndef IS_CYGWIN
    int leds = 0;

    if ( beesnd_is_snd_on()  ) { leds |= KB_NUMLOCK_FLAG;  }
    if ( do_throttle         ) { leds |= KB_SCROLOCK_FLAG; }
    if ( do_colour           ) { leds |= KB_CAPSLOCK_FLAG; }

    set_leds(leds);
    #endif

    return;
}
END_OF_FUNCTION(update_leds)

void setup_mem_opindirect_rw(UINT_16 start, UINT_16 end, UINT_8 *memaddr)
{
    static UINT_16 i;

    for ( i = start ; i <= end ; i++ )
    {
        z80_tab_num_bus     = i;
        z80_tab_addr_bus    = memaddr + ( ( i - start ) * 0x00100 );
        z80_tab_wr_wait_bus = 0;
        z80_tab_rd_wait_bus = 0;

        z80_set_mem_write_direct_naw();
        z80_set_mem_read_direct_naw();
        z80_set_mem_opread_indirect_naw();
    }

    return;
}

void setup_mem_wrindirect_rw(UINT_16 start, UINT_16 end, UINT_8 *memaddr)
{
    static UINT_16 i;

    for ( i = start ; i <= end ; i++ )
    {
        z80_tab_num_bus     = i;
        z80_tab_addr_bus    = memaddr + ( ( i - start ) * 0x00100 );
        z80_tab_wr_wait_bus = 0;
        z80_tab_rd_wait_bus = 0;

        z80_set_mem_write_indirect_naw();
        z80_set_mem_read_direct_naw();
        z80_set_mem_opread_direct_naw();
    }

    return;
}

void setup_mem_rw(UINT_16 start, UINT_16 end, UINT_8 *memaddr)
{
    static UINT_16 i;

    for ( i = start ; i <= end ; i++ )
    {
        z80_tab_num_bus     = i;
        z80_tab_addr_bus    = memaddr + ( ( i - start ) * 0x00100 );
        z80_tab_wr_wait_bus = 0;
        z80_tab_rd_wait_bus = 0;

        z80_set_mem_write_direct_naw();
        z80_set_mem_read_direct_naw();
        z80_set_mem_opread_direct_naw();
    }

    return;
}

void setup_mem_ro(UINT_16 start, UINT_16 end, UINT_8 *memaddr)
{
    static UINT_16 i;

    for ( i = start ; i <= end ; i++ )
    {
        z80_tab_num_bus     = i;
        z80_tab_addr_bus    = memaddr + ( ( i - start ) * 0x00100 );
        z80_tab_wr_wait_bus = 0;
        z80_tab_rd_wait_bus = 0;

        z80_set_mem_write_none_naw();
        z80_set_mem_read_direct_naw();
        z80_set_mem_opread_direct_naw();
    }

    return;
}

void refresh_charrom(void)
{
    static UINT_16 i;

    for ( i = 0 ; i < 0x00800 ; i++ )
    {
        #ifdef DEBUGMODE
        fprintf(error_log,"refresh char %d\n",(int) i);
        fflush(error_log);
        #endif

        video_mem_addr_bus  = i >> 0x004;
        video_data_bus      = rom5_sel[i];
        video_char_line_bus = i & 0x00F;

        c6545_write_char_mem(c6545_base);
    }

    return;
}

BITMAP *make_bee_icon(void)
{
    BITMAP *result;

    result = create_bitmap(20,20);

    /*
       The following was machine generated based on mbee32k.bmp, which is
       a scaled, re-colored version of mbee32k.ico.  Re-coloring was done
       to 3 colours: black, white and orange.  Subsequent Colour relabelling
       code generation was thus:

       0x0d7 -> 0x0D1
       0x0dc -> 0x0D2
       0x0ef -> 0x0D3

       Relevant code:

            bee_pointer = load_bmp("mbee32k.bmp",*((PALETTE *) beescrn_get_beescreen_palette()));
        { UINT_16 j;
        for ( i = 0 ; i <= 19 ; i++ ) {
        for ( j = 0 ; j <= 19 ; j++ ) {
        fprintf(stderr,"    putpixel(bee_pointer,%d,%d,0x0%2x)\n",i,j,getpixel(bee_pointer,i,j));
        } } }

    */

    if ( result != NULL )
    {
        putpixel(result, 0, 0,0x000);
        putpixel(result, 0, 1,0x000);
        putpixel(result, 0, 2,0x000);
        putpixel(result, 0, 3,0x0D1);
        putpixel(result, 0, 4,0x0D1);
        putpixel(result, 0, 5,0x0D1);
        putpixel(result, 0, 6,0x0D1);
        putpixel(result, 0, 7,0x000);
        putpixel(result, 0, 8,0x000);
        putpixel(result, 0, 9,0x000);
        putpixel(result, 0,10,0x000);
        putpixel(result, 0,11,0x000);
        putpixel(result, 0,12,0x000);
        putpixel(result, 0,13,0x000);
        putpixel(result, 0,14,0x000);
        putpixel(result, 0,15,0x000);
        putpixel(result, 0,16,0x000);
        putpixel(result, 0,17,0x000);
        putpixel(result, 0,18,0x000);
        putpixel(result, 0,19,0x000);
        putpixel(result, 1, 0,0x000);
        putpixel(result, 1, 1,0x000);
        putpixel(result, 1, 2,0x0D1);
        putpixel(result, 1, 3,0x0D1);
        putpixel(result, 1, 4,0x0D3);
        putpixel(result, 1, 5,0x0D3);
        putpixel(result, 1, 6,0x0D1);
        putpixel(result, 1, 7,0x0D1);
        putpixel(result, 1, 8,0x000);
        putpixel(result, 1, 9,0x000);
        putpixel(result, 1,10,0x000);
        putpixel(result, 1,11,0x000);
        putpixel(result, 1,12,0x0D1);
        putpixel(result, 1,13,0x0D1);
        putpixel(result, 1,14,0x0D1);
        putpixel(result, 1,15,0x000);
        putpixel(result, 1,16,0x000);
        putpixel(result, 1,17,0x000);
        putpixel(result, 1,18,0x000);
        putpixel(result, 1,19,0x000);
        putpixel(result, 2, 0,0x000);
        putpixel(result, 2, 1,0x0D1);
        putpixel(result, 2, 2,0x0D3);
        putpixel(result, 2, 3,0x0D3);
        putpixel(result, 2, 4,0x0D3);
        putpixel(result, 2, 5,0x0D3);
        putpixel(result, 2, 6,0x0D3);
        putpixel(result, 2, 7,0x0D3);
        putpixel(result, 2, 8,0x0D1);
        putpixel(result, 2, 9,0x0D1);
        putpixel(result, 2,10,0x000);
        putpixel(result, 2,11,0x0D1);
        putpixel(result, 2,12,0x0D3);
        putpixel(result, 2,13,0x0D3);
        putpixel(result, 2,14,0x0D3);
        putpixel(result, 2,15,0x0D1);
        putpixel(result, 2,16,0x000);
        putpixel(result, 2,17,0x000);
        putpixel(result, 2,18,0x000);
        putpixel(result, 2,19,0x000);
        putpixel(result, 3, 0,0x0D1);
        putpixel(result, 3, 1,0x0D1);
        putpixel(result, 3, 2,0x0D3);
        putpixel(result, 3, 3,0x0D3);
        putpixel(result, 3, 4,0x0D3);
        putpixel(result, 3, 5,0x0D3);
        putpixel(result, 3, 6,0x0D3);
        putpixel(result, 3, 7,0x0D3);
        putpixel(result, 3, 8,0x0D3);
        putpixel(result, 3, 9,0x0D1);
        putpixel(result, 3,10,0x0D1);
        putpixel(result, 3,11,0x0D3);
        putpixel(result, 3,12,0x0D3);
        putpixel(result, 3,13,0x0D3);
        putpixel(result, 3,14,0x0D3);
        putpixel(result, 3,15,0x0D1);
        putpixel(result, 3,16,0x000);
        putpixel(result, 3,17,0x000);
        putpixel(result, 3,18,0x000);
        putpixel(result, 3,19,0x000);
        putpixel(result, 4, 0,0x0D1);
        putpixel(result, 4, 1,0x0D3);
        putpixel(result, 4, 2,0x0D3);
        putpixel(result, 4, 3,0x0D3);
        putpixel(result, 4, 4,0x0D3);
        putpixel(result, 4, 5,0x0D3);
        putpixel(result, 4, 6,0x0D3);
        putpixel(result, 4, 7,0x0D3);
        putpixel(result, 4, 8,0x0D3);
        putpixel(result, 4, 9,0x0D1);
        putpixel(result, 4,10,0x0D1);
        putpixel(result, 4,11,0x0D3);
        putpixel(result, 4,12,0x0D3);
        putpixel(result, 4,13,0x0D3);
        putpixel(result, 4,14,0x0D3);
        putpixel(result, 4,15,0x0D1);
        putpixel(result, 4,16,0x000);
        putpixel(result, 4,17,0x000);
        putpixel(result, 4,18,0x000);
        putpixel(result, 4,19,0x000);
        putpixel(result, 5, 0,0x0D1);
        putpixel(result, 5, 1,0x0D3);
        putpixel(result, 5, 2,0x0D3);
        putpixel(result, 5, 3,0x0D3);
        putpixel(result, 5, 4,0x0D3);
        putpixel(result, 5, 5,0x0D3);
        putpixel(result, 5, 6,0x0D3);
        putpixel(result, 5, 7,0x0D1);
        putpixel(result, 5, 8,0x0D1);
        putpixel(result, 5, 9,0x0D3);
        putpixel(result, 5,10,0x0D1);
        putpixel(result, 5,11,0x0D3);
        putpixel(result, 5,12,0x0D3);
        putpixel(result, 5,13,0x0D3);
        putpixel(result, 5,14,0x0D3);
        putpixel(result, 5,15,0x0D1);
        putpixel(result, 5,16,0x0D1);
        putpixel(result, 5,17,0x000);
        putpixel(result, 5,18,0x000);
        putpixel(result, 5,19,0x000);
        putpixel(result, 6, 0,0x0D1);
        putpixel(result, 6, 1,0x0D3);
        putpixel(result, 6, 2,0x0D3);
        putpixel(result, 6, 3,0x0D3);
        putpixel(result, 6, 4,0x0D3);
        putpixel(result, 6, 5,0x0D1);
        putpixel(result, 6, 6,0x0D1);
        putpixel(result, 6, 7,0x0D3);
        putpixel(result, 6, 8,0x0D1);
        putpixel(result, 6, 9,0x0D1);
        putpixel(result, 6,10,0x0D1);
        putpixel(result, 6,11,0x0D1);
        putpixel(result, 6,12,0x0D3);
        putpixel(result, 6,13,0x0D1);
        putpixel(result, 6,14,0x0D1);
        putpixel(result, 6,15,0x0D1);
        putpixel(result, 6,16,0x0D1);
        putpixel(result, 6,17,0x0D1);
        putpixel(result, 6,18,0x000);
        putpixel(result, 6,19,0x000);
        putpixel(result, 7, 0,0x0D1);
        putpixel(result, 7, 1,0x0D1);
        putpixel(result, 7, 2,0x0D3);
        putpixel(result, 7, 3,0x0D1);
        putpixel(result, 7, 4,0x0D1);
        putpixel(result, 7, 5,0x0D3);
        putpixel(result, 7, 6,0x0D3);
        putpixel(result, 7, 7,0x0D3);
        putpixel(result, 7, 8,0x0D3);
        putpixel(result, 7, 9,0x0D3);
        putpixel(result, 7,10,0x0D1);
        putpixel(result, 7,11,0x0D1);
        putpixel(result, 7,12,0x0D1);
        putpixel(result, 7,13,0x0D1);
        putpixel(result, 7,14,0x0D1);
        putpixel(result, 7,15,0x0D1);
        putpixel(result, 7,16,0x0D2);
        putpixel(result, 7,17,0x0D1);
        putpixel(result, 7,18,0x000);
        putpixel(result, 7,19,0x000);
        putpixel(result, 8, 0,0x000);
        putpixel(result, 8, 1,0x0D1);
        putpixel(result, 8, 2,0x0D1);
        putpixel(result, 8, 3,0x0D3);
        putpixel(result, 8, 4,0x0D3);
        putpixel(result, 8, 5,0x0D3);
        putpixel(result, 8, 6,0x0D3);
        putpixel(result, 8, 7,0x0D3);
        putpixel(result, 8, 8,0x0D3);
        putpixel(result, 8, 9,0x0D3);
        putpixel(result, 8,10,0x0D3);
        putpixel(result, 8,11,0x0D1);
        putpixel(result, 8,12,0x0D1);
        putpixel(result, 8,13,0x0D1);
        putpixel(result, 8,14,0x0D1);
        putpixel(result, 8,15,0x0D2);
        putpixel(result, 8,16,0x0D2);
        putpixel(result, 8,17,0x0D2);
        putpixel(result, 8,18,0x0D1);
        putpixel(result, 8,19,0x000);
        putpixel(result, 9, 0,0x000);
        putpixel(result, 9, 1,0x0D1);
        putpixel(result, 9, 2,0x0D3);
        putpixel(result, 9, 3,0x0D3);
        putpixel(result, 9, 4,0x0D3);
        putpixel(result, 9, 5,0x0D3);
        putpixel(result, 9, 6,0x0D3);
        putpixel(result, 9, 7,0x0D3);
        putpixel(result, 9, 8,0x0D3);
        putpixel(result, 9, 9,0x0D3);
        putpixel(result, 9,10,0x0D3);
        putpixel(result, 9,11,0x0D1);
        putpixel(result, 9,12,0x0D2);
        putpixel(result, 9,13,0x0D2);
        putpixel(result, 9,14,0x0D2);
        putpixel(result, 9,15,0x0D2);
        putpixel(result, 9,16,0x0D2);
        putpixel(result, 9,17,0x0D1);
        putpixel(result, 9,18,0x0D1);
        putpixel(result, 9,19,0x000);
        putpixel(result,10, 0,0x000);
        putpixel(result,10, 1,0x0D1);
        putpixel(result,10, 2,0x0D3);
        putpixel(result,10, 3,0x0D3);
        putpixel(result,10, 4,0x0D3);
        putpixel(result,10, 5,0x0D3);
        putpixel(result,10, 6,0x0D3);
        putpixel(result,10, 7,0x0D3);
        putpixel(result,10, 8,0x0D3);
        putpixel(result,10, 9,0x0D3);
        putpixel(result,10,10,0x0D3);
        putpixel(result,10,11,0x0D1);
        putpixel(result,10,12,0x0D2);
        putpixel(result,10,13,0x0D2);
        putpixel(result,10,14,0x0D1);
        putpixel(result,10,15,0x0D1);
        putpixel(result,10,16,0x0D1);
        putpixel(result,10,17,0x0D1);
        putpixel(result,10,18,0x0D1);
        putpixel(result,10,19,0x000);
        putpixel(result,11, 0,0x0D1);
        putpixel(result,11, 1,0x0D1);
        putpixel(result,11, 2,0x0D3);
        putpixel(result,11, 3,0x0D3);
        putpixel(result,11, 4,0x0D3);
        putpixel(result,11, 5,0x0D3);
        putpixel(result,11, 6,0x0D3);
        putpixel(result,11, 7,0x0D3);
        putpixel(result,11, 8,0x0D3);
        putpixel(result,11, 9,0x0D3);
        putpixel(result,11,10,0x0D3);
        putpixel(result,11,11,0x0D1);
        putpixel(result,11,12,0x0D1);
        putpixel(result,11,13,0x0D1);
        putpixel(result,11,14,0x0D1);
        putpixel(result,11,15,0x0D1);
        putpixel(result,11,16,0x0D1);
        putpixel(result,11,17,0x0D2);
        putpixel(result,11,18,0x0D1);
        putpixel(result,11,19,0x000);
        putpixel(result,12, 0,0x0D1);
        putpixel(result,12, 1,0x0D3);
        putpixel(result,12, 2,0x0D3);
        putpixel(result,12, 3,0x0D3);
        putpixel(result,12, 4,0x0D3);
        putpixel(result,12, 5,0x0D3);
        putpixel(result,12, 6,0x0D3);
        putpixel(result,12, 7,0x0D3);
        putpixel(result,12, 8,0x0D3);
        putpixel(result,12, 9,0x0D3);
        putpixel(result,12,10,0x0D1);
        putpixel(result,12,11,0x0D1);
        putpixel(result,12,12,0x0D1);
        putpixel(result,12,13,0x0D1);
        putpixel(result,12,14,0x0D1);
        putpixel(result,12,15,0x0D2);
        putpixel(result,12,16,0x0D2);
        putpixel(result,12,17,0x0D2);
        putpixel(result,12,18,0x0D1);
        putpixel(result,12,19,0x000);
        putpixel(result,13, 0,0x0D1);
        putpixel(result,13, 1,0x0D3);
        putpixel(result,13, 2,0x0D3);
        putpixel(result,13, 3,0x0D3);
        putpixel(result,13, 4,0x0D3);
        putpixel(result,13, 5,0x0D3);
        putpixel(result,13, 6,0x0D3);
        putpixel(result,13, 7,0x0D3);
        putpixel(result,13, 8,0x0D3);
        putpixel(result,13, 9,0x0D3);
        putpixel(result,13,10,0x0D1);
        putpixel(result,13,11,0x0D1);
        putpixel(result,13,12,0x0D1);
        putpixel(result,13,13,0x0D2);
        putpixel(result,13,14,0x0D2);
        putpixel(result,13,15,0x0D2);
        putpixel(result,13,16,0x0D2);
        putpixel(result,13,17,0x0D1);
        putpixel(result,13,18,0x0D1);
        putpixel(result,13,19,0x000);
        putpixel(result,14, 0,0x0D1);
        putpixel(result,14, 1,0x0D3);
        putpixel(result,14, 2,0x0D3);
        putpixel(result,14, 3,0x0D3);
        putpixel(result,14, 4,0x0D3);
        putpixel(result,14, 5,0x0D3);
        putpixel(result,14, 6,0x0D3);
        putpixel(result,14, 7,0x0D3);
        putpixel(result,14, 8,0x0D3);
        putpixel(result,14, 9,0x0D1);
        putpixel(result,14,10,0x0D1);
        putpixel(result,14,11,0x0D2);
        putpixel(result,14,12,0x0D2);
        putpixel(result,14,13,0x0D2);
        putpixel(result,14,14,0x0D2);
        putpixel(result,14,15,0x0D1);
        putpixel(result,14,16,0x0D1);
        putpixel(result,14,17,0x0D1);
        putpixel(result,14,18,0x0D1);
        putpixel(result,14,19,0x000);
        putpixel(result,15, 0,0x000);
        putpixel(result,15, 1,0x0D1);
        putpixel(result,15, 2,0x0D3);
        putpixel(result,15, 3,0x0D3);
        putpixel(result,15, 4,0x0D3);
        putpixel(result,15, 5,0x0D3);
        putpixel(result,15, 6,0x0D3);
        putpixel(result,15, 7,0x0D3);
        putpixel(result,15, 8,0x0D1);
        putpixel(result,15, 9,0x0D1);
        putpixel(result,15,10,0x0D2);
        putpixel(result,15,11,0x0D2);
        putpixel(result,15,12,0x0D1);
        putpixel(result,15,13,0x0D1);
        putpixel(result,15,14,0x0D1);
        putpixel(result,15,15,0x0D1);
        putpixel(result,15,16,0x0D1);
        putpixel(result,15,17,0x0D1);
        putpixel(result,15,18,0x000);
        putpixel(result,15,19,0x000);
        putpixel(result,16, 0,0x000);
        putpixel(result,16, 1,0x0D1);
        putpixel(result,16, 2,0x0D1);
        putpixel(result,16, 3,0x0D3);
        putpixel(result,16, 4,0x0D3);
        putpixel(result,16, 5,0x0D3);
        putpixel(result,16, 6,0x0D3);
        putpixel(result,16, 7,0x0D1);
        putpixel(result,16, 8,0x0D1);
        putpixel(result,16, 9,0x0D1);
        putpixel(result,16,10,0x0D1);
        putpixel(result,16,11,0x0D1);
        putpixel(result,16,12,0x0D1);
        putpixel(result,16,13,0x0D1);
        putpixel(result,16,14,0x0D1);
        putpixel(result,16,15,0x0D1);
        putpixel(result,16,16,0x0D2);
        putpixel(result,16,17,0x0D1);
        putpixel(result,16,18,0x000);
        putpixel(result,16,19,0x000);
        putpixel(result,17, 0,0x000);
        putpixel(result,17, 1,0x000);
        putpixel(result,17, 2,0x000);
        putpixel(result,17, 3,0x0D1);
        putpixel(result,17, 4,0x0D1);
        putpixel(result,17, 5,0x0D1);
        putpixel(result,17, 6,0x0D1);
        putpixel(result,17, 7,0x000);
        putpixel(result,17, 8,0x000);
        putpixel(result,17, 9,0x000);
        putpixel(result,17,10,0x0D1);
        putpixel(result,17,11,0x0D1);
        putpixel(result,17,12,0x0D1);
        putpixel(result,17,13,0x0D2);
        putpixel(result,17,14,0x0D2);
        putpixel(result,17,15,0x0D2);
        putpixel(result,17,16,0x0D1);
        putpixel(result,17,17,0x000);
        putpixel(result,17,18,0x000);
        putpixel(result,17,19,0x000);
        putpixel(result,18, 0,0x000);
        putpixel(result,18, 1,0x000);
        putpixel(result,18, 2,0x000);
        putpixel(result,18, 3,0x000);
        putpixel(result,18, 4,0x000);
        putpixel(result,18, 5,0x000);
        putpixel(result,18, 6,0x000);
        putpixel(result,18, 7,0x000);
        putpixel(result,18, 8,0x000);
        putpixel(result,18, 9,0x000);
        putpixel(result,18,10,0x000);
        putpixel(result,18,11,0x0D1);
        putpixel(result,18,12,0x0D2);
        putpixel(result,18,13,0x0D2);
        putpixel(result,18,14,0x0D1);
        putpixel(result,18,15,0x0D1);
        putpixel(result,18,16,0x000);
        putpixel(result,18,17,0x000);
        putpixel(result,18,18,0x000);
        putpixel(result,18,19,0x000);
        putpixel(result,19, 0,0x000);
        putpixel(result,19, 1,0x000);
        putpixel(result,19, 2,0x000);
        putpixel(result,19, 3,0x000);
        putpixel(result,19, 4,0x000);
        putpixel(result,19, 5,0x000);
        putpixel(result,19, 6,0x000);
        putpixel(result,19, 7,0x000);
        putpixel(result,19, 8,0x000);
        putpixel(result,19, 9,0x000);
        putpixel(result,19,10,0x000);
        putpixel(result,19,11,0x000);
        putpixel(result,19,12,0x0D1);
        putpixel(result,19,13,0x0D1);
        putpixel(result,19,14,0x0D1);
        putpixel(result,19,15,0x000);
        putpixel(result,19,16,0x000);
        putpixel(result,19,17,0x000);
        putpixel(result,19,18,0x000);
        putpixel(result,19,19,0x000);
    }

    return result;
}

SetupData main_setdat[] =
{
   { "rom_sel1",                 &rom1_num,                    6 },
   { "rom_sel2",                 &rom2_num,                    6 },
   { "rom_sel3",                 &rom3_num,                    6 },
   { "rom_sel4",                 &rom4_num,                    6 },
   { "rom_sel5",                 &rom5_num,                    6 },
   { "rom_preload1",             &rom1_name,                   7 },
   { "rom_preload2",             &rom2_name,                   7 },
   { "rom_preload3",             &rom3_name,                   7 },
   { "rom_preload4",             &rom4_name,                   7 },
   { "rom_preload5",             &rom5_name,                   7 },
   { "timer_period",             &timer_period_x,              2 },
   { "max_crtc_granularity",     &max_crtc_granularity,        2 },
   { "max_crtc_granularity_key", &max_crtc_granularity_key,    2 },
   { "max_crtc_clock_div",       &max_crtc_clock_division,     0 },
   { "max_crtc_clock_div_key",   &max_crtc_clock_division_key, 0 },
   { "clock_period",             &clock_period,                8 },
   { "max_clockovr",             &max_clockovr,                8 },
   { "max_clockovr_pb",          &max_clockovr_pb,             8 },
   { "catchup_point",            &catchup_point,               8 },
   { "lag_point",                &lag_point,                   8 },
   { "",                         NULL,                         0 }
};

SetupData *main_setup(void)
{
    rom1_num = DEFAULT_ROM1_NUM;
    rom2_num = DEFAULT_ROM2_NUM;
    rom3_num = DEFAULT_ROM3_NUM;
    rom4_num = DEFAULT_ROM4_NUM;
    rom5_num = DEFAULT_ROM5_NUM;

    strcpy(rom1_name,"");
    strcpy(rom2_name,"");
    strcpy(rom3_name,"");
    strcpy(rom4_name,"");
    strcpy(rom5_name,"");

    timer_period_x = DEFAULT_TIMER_PERIOD;

    max_crtc_granularity        = DEFAULT_MAX_CRTC_GRANULARITY;
    max_crtc_clock_division     = DEFAULT_MAX_CRTC_CLOCK_DIV;
    max_crtc_granularity_key    = DEFAULT_MAX_CRTC_GRANULARITY_KEY;
    max_crtc_clock_division_key = DEFAULT_MAX_CRTC_CLOCK_DIV_KEY;

    clock_period    = DEFAULT_CLOCK_PERIOD;
    max_clockovr    = DEFAULT_MAX_CLOCKOVR;
    max_clockovr_pb = DEFAULT_MAX_CLOCKOVR_PB;
    catchup_point   = DEFAULT_CATCHUP_COUNT;
    lag_point       = DEFAULT_LAG_POINT;

    return main_setdat;
}

int main_init(void)
{
    LOCK_FUNCTION(key_lowlevel_stuff);
    LOCK_FUNCTION(key_lowlevel_exit);
    LOCK_FUNCTION(speed_throttle);
    LOCK_FUNCTION(overlook_timer);
    LOCK_FUNCTION(update_leds);
    LOCK_FUNCTION(timer_speed_emul_on);
    LOCK_FUNCTION(timer_speed_emul_off);

    LOCK_VARIABLE(printscreen_flag);
    LOCK_VARIABLE(interact_flag);
    LOCK_VARIABLE(mbee_reset_flag);
    LOCK_VARIABLE(do_throttle);
    LOCK_VARIABLE(keyboard_poll_mode);
    LOCK_VARIABLE(mouse_poll_mode);
    LOCK_VARIABLE(in_menu_mode);
    LOCK_VARIABLE(in_step_mode);
    LOCK_VARIABLE(key_down);
    LOCK_VARIABLE(do_colour);
    LOCK_VARIABLE(actual_clocks);
    LOCK_VARIABLE(clock_period);
    LOCK_VARIABLE(timer_period_x);
    LOCK_VARIABLE(catchup_point);
    LOCK_VARIABLE(is_wait);
    LOCK_VARIABLE(max_clockovr);
    LOCK_VARIABLE(max_clockovr_pb);
    LOCK_VARIABLE(lag_point);
    LOCK_VARIABLE(crtc_granularity);
    LOCK_VARIABLE(crtc_clock_division);
    LOCK_VARIABLE(max_crtc_granularity);
    LOCK_VARIABLE(max_crtc_clock_division);
    LOCK_VARIABLE(max_crtc_granularity_key);
    LOCK_VARIABLE(max_crtc_clock_division_key);
    LOCK_VARIABLE(crtc_granularity_no_key);
    LOCK_VARIABLE(crtc_clock_division_no_key);
    LOCK_VARIABLE(crtc_granularity_is_key);
    LOCK_VARIABLE(crtc_clock_division_is_key);
    LOCK_VARIABLE(temp_crtc_granularity_no_key);
    LOCK_VARIABLE(temp_crtc_clock_division_no_key);
    LOCK_VARIABLE(temp_crtc_granularity_is_key);
    LOCK_VARIABLE(temp_crtc_clock_division_is_key);
    LOCK_VARIABLE(sync_point);
    LOCK_VARIABLE(overlook_timer_firstcall);
    LOCK_VARIABLE(throttle_call_count);

    UINT_16 i;
    FILE *fp;

    overlook_timer_firstcall = 1;
    throttle_call_count      = 0;

    interact_flag    = 0;
    mbee_reset_flag  = 0;
    printscreen_flag = 0;

    do_throttle = 1;

    sync_point = 0;

    if ( ( bee_pointer = make_bee_icon() ) == NULL )
    {
        return 1;
    }

    in_menu_mode = 0; /* not in menu mode */
    in_step_mode = 0; /* not in step mode */

    local_c6545_cycle_counter = 0;
    c6545_clk_odds            = 0;
    cycle_counter_c6545_bus   = 0;

    /*
       Setup lightpen table.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"lightpen setup\n");
    fflush(error_log);
    #endif

    if ( ( lpen_table = (UINT_8 *) DEBMALLOC(0x04003*sizeof(UINT_8)) ) == NULL )
    {
        return 2;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"lightpen setup a\n");
    fflush(error_log);
    #endif

    if ( ( lpen_feedback_table = (UINT_8 *) DEBMALLOC(0x04003*sizeof(UINT_8)) ) == NULL )
    {
        return 3;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"lightpen setup b\n");
    fflush(error_log);
    #endif

    if ( ( lpen_feedrfsh_table = (UINT_8 *) DEBMALLOC(0x04003*sizeof(UINT_8)) ) == NULL )
    {
        return 4;
    }

    #ifdef DEBUGMODE
    fprintf(error_log,"lightpen setup c\n");
    fflush(error_log);
    #endif

    for ( i = 0 ; i < 0x04003 ; i++ )
    {
        DEBDEREF(lpen_table,i)          = 0;
        DEBDEREF(lpen_feedback_table,i) = 0;
        DEBDEREF(lpen_feedrfsh_table,i) = 0;
    }

    /*
       lpen_call_mask tells the 6545 emulator when it should be
       calling the lightpen functions (this is like a hurdle, and it if
       isn't cleared then there is no point wasting time calling the
       lightpen testing function externally).
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"lightpen setup d\n");
    fflush(error_log);
    #endif

    lpen_call_mask = ROMREAD0_LPEN_MASK;

    #ifdef DEBUGMODE
    fprintf(error_log,"lightpen setup e\n");
    fflush(error_log);
    #endif

    key_down  = 0;
    do_colour = 1; /* this will be over-rided elsewhere */

    /*
       Timer setup
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"timer setup\n");
    fflush(error_log);
    #endif

    if ( timer_period_x > 50 )
    {
        timer_period_x = 50;
    }

    timer_period_x *= 1000000;

    if ( max_crtc_granularity > 512 )
    {
        max_crtc_granularity = 512;
    }

    if ( max_crtc_granularity_key > 512 )
    {
        max_crtc_granularity_key = 512;
    }

    if ( max_clockovr < 100 )
    {
        max_clockovr = 100;
    }

    if ( max_clockovr > 200000 )
    {
        max_clockovr = 200000;
    }

    if ( max_clockovr_pb < 100 )
    {
        max_clockovr_pb = 100;
    }

    if ( max_clockovr_pb > 200000 )
    {
        max_clockovr_pb = 200000;
    }

    if ( max_clockovr_pb > max_clockovr )
    {
        max_clockovr_pb = max_clockovr;
    }

    if ( clock_period < 10 )
    {
        clock_period = 10;
    }

    if ( clock_period > 10000 )
    {
        clock_period = 10000;
    }

    if ( catchup_point < 100 )
    {
        catchup_point = 100;
    }

    if ( catchup_point > 200000 )
    {
        catchup_point = 200000;
    }

    if ( lag_point < 2 )
    {
        lag_point = 2;
    }

    if ( lag_point > 100 )
    {
        lag_point = 100;
    }

    actual_clocks = 0;

    crtc_granularity_no_key    = REAL_CRTC_GRANULARITY;
    crtc_clock_division_no_key = REAL_CRTC_CLOCK_DIV;
    crtc_granularity_is_key    = REAL_CRTC_GRANULARITY;
    crtc_clock_division_is_key = REAL_CRTC_CLOCK_DIV;

    crtc_granularity    = crtc_granularity_no_key;
    crtc_clock_division = crtc_clock_division_no_key;

    temp_crtc_granularity_no_key    = REAL_CRTC_GRANULARITY;
    temp_crtc_clock_division_no_key = REAL_CRTC_CLOCK_DIV;
    temp_crtc_granularity_is_key    = REAL_CRTC_GRANULARITY;
    temp_crtc_clock_division_is_key = REAL_CRTC_CLOCK_DIV;

    is_wait = 0;

    /*
       malloc stuff
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"mallocation\n");
    fflush(error_log);
    #endif

    if ( ( user_RAM_a = (UINT_8 *) DEBMALLOC(0x04003*sizeof(UINT_8)) ) == NULL )
    {
        return 5;
    }

    if ( ( user_RAM_b = (UINT_8 *) DEBMALLOC(0x04003*sizeof(UINT_8)) ) == NULL )
    {
        return 6;
    }

    for ( i = 0 ; i < 0x04003 ; i++ )
    {
        DEBDEREF(user_RAM_a,i) = 0;
        DEBDEREF(user_RAM_b,i) = 0;
    }

    if ( ( VDU_RAM = (UINT_8 *) DEBMALLOC(0x00803*sizeof(UINT_8)) ) == NULL )
    {
        return 7;
    }

    if ( ( PCG_RAM = (UINT_8 *) DEBMALLOC(0x00803*sizeof(UINT_8)) ) == NULL )
    {
        return 8;
    }

    if ( ( colour_RAM = (UINT_8 *) DEBMALLOC(0x00803*sizeof(UINT_8)) ) == NULL )
    {
        return 9;
    }

    for ( i = 0 ; i < 0x00803 ; i++ )
    {
        DEBDEREF(VDU_RAM,i)    = 0;
        DEBDEREF(PCG_RAM,i)    = 0;
        DEBDEREF(colour_RAM,i) = 0;
    }

    if ( ( rom1_load = (UINT_8 *) DEBMALLOC(0x02003*sizeof(UINT_8)) ) == NULL )
    {
        return 10;
    }

    if ( ( rom2_load = (UINT_8 *) DEBMALLOC(0x02003*sizeof(UINT_8)) ) == NULL )
    {
        return 11;
    }

    if ( ( rom3_load = (UINT_8 *) DEBMALLOC(0x02003*sizeof(UINT_8)) ) == NULL )
    {
        return 12;
    }

    for ( i = 0 ; i < 0x02003 ; i++ )
    {
        DEBDEREF(rom1_load,i) = 0;
        DEBDEREF(rom2_load,i) = 0;
        DEBDEREF(rom3_load,i) = 0;
    }

    if ( ( rom4_load = (UINT_8 *) DEBMALLOC(0x01003*sizeof(UINT_8)) ) == NULL )
    {
        return 13;
    }

    for ( i = 0 ; i < 0x01003 ; i++ )
    {
        DEBDEREF(rom4_load,i) = 0;
    }

    if ( ( rom5_load = (UINT_8 *) DEBMALLOC(0x00803*sizeof(UINT_8)) ) == NULL )
    {
        return 14;
    }

    for ( i = 0 ; i < 0x00803 ; i++ )
    {
        DEBDEREF(rom5_load,i) = 0;
    }

    /*
       FIXME: their is something strange here - if the following "cheat"
              code is left out, the emulator will boot in colour mode,
              BUT the background colour will be all wrong until a cold
              reset occurs.
    */

    if ( do_colour )
    {
        DEBDEREF(user_RAM_a,0x099) = 0x0ff;
    }

    /*
       The rest
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"the rest\n");
    fflush(error_log);
    #endif

    if ( strlen(rom1_name) > 0 )
    {
        if ( ( fp = fopen(rom1_name,"rb") ) == NULL )
        {
            return 15;
        }

        for ( i = 0 ; i < 0x02000 ; i++ )
        {
            DEBDEREF(rom1_load,i) = fgetc(fp);
        }

        fclose(fp);
    }

    if ( strlen(rom2_name) > 0 )
    {
        if ( ( fp = fopen(rom2_name,"rb") ) == NULL )
        {
            return 16;
        }

        for ( i = 0 ; i < 0x02000 ; i++ )
        {
            DEBDEREF(rom2_load,i) = fgetc(fp);
        }

        fclose(fp);
    }

    if ( strlen(rom3_name) > 0 )
    {
        if ( ( fp = fopen(rom3_name,"rb") ) == NULL )
        {
            return 17;
        }

        for ( i = 0 ; i < 0x02000 ; i++ )
        {
            DEBDEREF(rom3_load,i) = fgetc(fp);
        }

        fclose(fp);
    }

    if ( strlen(rom4_name) > 0 )
    {
        if ( ( fp = fopen(rom4_name,"rb") ) == NULL )
        {
            return 18;
        }

        for ( i = 0 ; i < 0x01000 ; i++ )
        {
            DEBDEREF(rom4_load,i) = fgetc(fp);
        }

        fclose(fp);
    }

    if ( strlen(rom5_name) > 0 )
    {
        if ( ( fp = fopen(rom5_name,"rb") ) == NULL )
        {
            return 19;
        }

        for ( i = 0 ; i < 0x00800 ; i++ )
        {
            DEBDEREF(rom5_load,i) = fgetc(fp);
        }

        fclose(fp);
    }

    rom1again:

    switch ( rom1_num )
    {
        case 0:
        {
            rom1_sel = basic_ROM_a;

            break;
        }

        case 1:
        {
            rom1_sel = rom1_load;

            break;
        }

        default:
        {
            rom1_num = DEFAULT_ROM1_NUM;

            goto rom1again;

            break;
        }
    }

    rom2again:

    switch ( rom2_num )
    {
        case 0:
        {
            rom2_sel = basic_ROM_b;

            break;
        }

        case 1:
        {
            rom2_sel = rom2_load;

            break;
        }

        default:
        {
            rom2_num = DEFAULT_ROM2_NUM;

            goto rom2again;

            break;
        }
    }

    rom3again:

    switch ( rom3_num )
    {
        case 0:
        {
            rom3_sel = wordbee_ROM;

            break;
        }

        case 1:
        {
            rom3_sel = edasm_ROM;

            break;
        }

        case 2:
        {
            rom3_sel = forth_ROM;

            break;
        }

        case 3:
        {
            rom3_sel = rom3_load;

            break;
        }

        default:
        {
            rom3_num = DEFAULT_ROM3_NUM;

            goto rom3again;

            break;
        }
    }

    rom4again:

    switch ( rom4_num )
    {
        case 0:
        {
            rom4_sel = network_ROM;

            break;
        }

        case 1:
        {
            rom4_sel = rom4_load;

            break;
        }

        default:
        {
            rom4_num = DEFAULT_ROM4_NUM;

            goto rom4again;

            break;
        }
    }

    rom5again:

    switch ( rom5_num )
    {
        case 0:
        {
            rom5_sel = CHAR_ROM;

            break;
        }

        case 1:
        {
            rom5_sel = rom5_load;

            break;
        }

        default:
        {
            rom5_num = DEFAULT_ROM5_NUM;

            goto rom5again;

            break;
        }
    }

    /*
       Zero memory and state.
    */

    #ifdef DEBUGMODE
    fprintf(error_log,"init state\n");
    fflush(error_log);
    #endif

    startup_flag = 0;
    romread      = 0;
    colctrl      = 0;
    colback      = 0;

    /*
       Memory banks 00-7F are standard RAM, so can be read, written and
       opread directly by the z80 emulator.  There are no speed issues
       here, so naw (no auto wait) is used.

       Note: Until mem addr START_READ_TRIGGER is reached, opreads are
             indirect.
    */

    setup_mem_opindirect_rw(0x000,0x03F,user_RAM_a);
    setup_mem_opindirect_rw(0x040,0x07F,user_RAM_b);

    /*
       Memory banks 80-EF are standard ROM, so can be read and opread
       directly by the z80 emulator, but not written.  There are no
       speed issues here, so naw (no auto wait) is used.
    */

    setup_mem_ro(0x080,0x09F,rom1_sel);
    setup_mem_ro(0x0A0,0x0BF,rom2_sel);
    setup_mem_ro(0x0C0,0x0DF,rom3_sel);
    setup_mem_ro(0x0E0,0x0EF,rom4_sel);

    /*
       Memory banks F0-F7 are RAM, and can be read and opread directly
       by the z80 emulator.  However, writes must also go to the 6545
       emulator, as they are displayed on the monitor.  There are no
       speed issues here, so naw (no auto wait) is used.
    */

    setup_mem_wrindirect_rw(0x0F0,0x0F7,VDU_RAM);
    setup_mem_wrindirect_rw(0x0F8,0x0FF,PCG_RAM);

    return 0;
}

void main_remove(void)
{
    if ( rom5_load != NULL ) { DEBFREE(rom5_load); }
    if ( rom4_load != NULL ) { DEBFREE(rom4_load); }
    if ( rom3_load != NULL ) { DEBFREE(rom3_load); }
    if ( rom2_load != NULL ) { DEBFREE(rom2_load); }
    if ( rom1_load != NULL ) { DEBFREE(rom1_load); }

    if ( colour_RAM != NULL ) { DEBFREE(colour_RAM); }
    if ( PCG_RAM    != NULL ) { DEBFREE(PCG_RAM);    }
    if ( VDU_RAM    != NULL ) { DEBFREE(VDU_RAM);    }

    if ( user_RAM_b != NULL ) { DEBFREE(user_RAM_b); }
    if ( user_RAM_a != NULL ) { DEBFREE(user_RAM_a); }

    if ( lpen_table          != NULL ) { DEBFREE(lpen_table);          }
    if ( lpen_feedback_table != NULL ) { DEBFREE(lpen_feedback_table); }
    if ( lpen_feedrfsh_table != NULL ) { DEBFREE(lpen_feedrfsh_table); }

    return;
}


char rom1_menu_optiona[] = "- BAS522a ROM (&default)";
char rom1_menu_optionb[] = "- &Load ROM from file";

char rom2_menu_optiona[] = "- BAS522b ROM (&default)";
char rom2_menu_optionb[] = "- &Load ROM from file";

char rom3_menu_optiona[] = "- &WORDBEE ROM.";
char rom3_menu_optionb[] = "- &EDASM ROM";
char rom3_menu_optionc[] = "- &FORTH ROM";
char rom3_menu_optiond[] = "- &Load ROM from file";

char rom4_menu_optiona[] = "- &Network ROM";
char rom4_menu_optionb[] = "- &Load ROM from file";

char rom5_menu_optiona[] = "- &Standard character ROM.";
char rom5_menu_optionb[] = "- &Load ROM from file";

char clock_menu_optiona[] = "- CPU clock speed &normal (3.141 MHz).";
char clock_menu_optionb[] = "- CPU clock speed &unlimited.";

MENU rom1_menu[] =
{
    { rom1_menu_optiona, sel1BASICa, NULL, 0, NULL },
    { rom1_menu_optionb, load1rom,   NULL, 0, NULL },
    { NULL,              NULL,       NULL, 0, NULL }
};

MENU rom2_menu[] =
{
    { rom2_menu_optiona, sel2BASICb, NULL, 0, NULL },
    { rom2_menu_optionb, load2rom,   NULL, 0, NULL },
    { NULL,              NULL,       NULL, 0, NULL }
};

MENU rom3_menu[] =
{
    { rom3_menu_optiona, sel3WORDBEE, NULL, 0, NULL },
    { rom3_menu_optionb, sel3EDASM,   NULL, 0, NULL },
    { rom3_menu_optionc, sel3FORTH,   NULL, 0, NULL },
    { rom3_menu_optiond, load3rom,    NULL, 0, NULL },
    { NULL,              NULL,        NULL, 0, NULL }
};

MENU rom4_menu[] =
{
    { rom4_menu_optiona, sel4NETWORK, NULL, 0, NULL },
    { rom4_menu_optionb, load4rom,    NULL, 0, NULL },
    { NULL,              NULL,        NULL, 0, NULL }
};

MENU rom5_menu[] =
{
    { rom5_menu_optiona, sel5CHARROM, NULL, 0, NULL },
    { rom5_menu_optionb, load5rom,    NULL, 0, NULL },
    { NULL,              NULL,        NULL, 0, NULL }
};

MENU clock_menu[] =
{
    { clock_menu_optiona, cpuclk_on,  NULL, 0, NULL },
    { clock_menu_optionb, cpuclk_off, NULL, 0, NULL },
    { NULL,               NULL,       NULL, 0, NULL }
};

MENU main_menu[] =
{
    { "&Load file into RAM",           loadit,               NULL,       0,          NULL },
    { "&Save contents of RAM",         saveit,               NULL,       0,          NULL },
    { "",                              NULL,                 NULL,       0,          NULL },
    { "View &CPU/PIO State \tctrl-v",  cpu_state_lookup,     NULL,       0,          NULL },
    { "View/&Edit Memory \tctrl-e",    NULL,                 NULL,       D_DISABLED, NULL },
    { "",                              NULL,                 NULL,       0,          NULL },
    { "ROM &1 (basic 1) options",      NULL,                 rom1_menu,  0,          NULL },
    { "ROM &2 (basic 2) options",      NULL,                 rom2_menu,  0,          NULL },
    { "ROM &3 (edasm) options",        NULL,                 rom3_menu,  0,          NULL },
    { "ROM &4 (net) options",          NULL,                 rom4_menu,  0,          NULL },
    { "ROM &5 (char) options",         NULL,                 rom5_menu,  0,          NULL },
    { "",                              NULL,                 NULL,       0,          NULL },
    { "CPU clock &rate",               NULL,                 clock_menu, 0,          NULL },
    { "",                              NULL,                 NULL,       0,          NULL },
    { "S&ingle step emulator \tENTER", step_returner,        NULL,       0,          NULL },
    { "Res&tart emulator \tESC",       returner,             NULL,       0,          NULL },
    { "E&xit emulator \tctrl-x",       quitter,              NULL,       0,          NULL },
    { NULL,                            NULL,                 NULL,       0,          NULL }
};

MENU help_menu[] =
{
    { "General &help",    NULL, NULL, D_DISABLED, NULL },
    { "Shortcut &keys",   NULL, NULL, D_DISABLED, NULL },
    { "",                 NULL, NULL, 0,          NULL },
    { "About &PicoMozzy", NULL, NULL, D_DISABLED, NULL },
    { NULL,               NULL, NULL, 0,          NULL }
};

MENU *main_getmenu(void)
{
    main_update_menu_marks();

    return main_menu;
}

MENU *help_getmenu(void)
{
    return help_menu;
}

int temp_throttle;

void main_update_menu_marks(void)
{
    {
        rom1_menu_optiona[0] = ' ';
        rom1_menu_optionb[0] = ' ';

        switch ( rom1_num )
        {
            case 0:  { rom1_menu_optiona[0] = '-'; break; }
            default: { rom1_menu_optionb[0] = '-'; break; }
        }

        rom2_menu_optiona[0] = ' ';
        rom2_menu_optionb[0] = ' ';

        switch ( rom2_num )
        {
            case 0:  { rom2_menu_optiona[0] = '-'; break; }
            default: { rom2_menu_optionb[0] = '-'; break; }
        }

        rom3_menu_optiona[0] = ' ';
        rom3_menu_optionb[0] = ' ';
        rom3_menu_optionc[0] = ' ';
        rom3_menu_optiond[0] = ' ';

        switch ( rom3_num )
        {
            case 0:  { rom3_menu_optiona[0] = '-'; break; }
            case 1:  { rom3_menu_optionb[0] = '-'; break; }
            case 2:  { rom3_menu_optionc[0] = '-'; break; }
            default: { rom3_menu_optiond[0] = '-'; break; }
        }

        rom4_menu_optiona[0] = ' ';
        rom4_menu_optionb[0] = ' ';

        switch ( rom4_num )
        {
            case 0:  { rom4_menu_optiona[0] = '-'; break; }
            default: { rom4_menu_optionb[0] = '-'; break; }
        }

        rom5_menu_optiona[0] = ' ';
        rom5_menu_optionb[0] = ' ';

        switch ( rom5_num )
        {
            case 0:  { rom5_menu_optiona[0] = '-'; break; }
            default: { rom5_menu_optionb[0] = '-'; break; }
        }
    }

    {
        clock_menu_optiona[0] = ' ';
        clock_menu_optionb[0] = ' ';

        switch ( temp_throttle )
        {
            case 1:  { clock_menu_optiona[0] = '-'; break; }
            default: { clock_menu_optionb[0] = '-'; break; }
        }
    }

    return;
}






/**********************************************************************
 ***                                                                ***
 ***                      MENU control stuff                        ***
 ***                                                                ***
 **********************************************************************/

#define MENU_WHITE      0x0C1
#define MENU_GREY       0x0C2
#define MENU_BLACK      0x0C3

int just_enter;

int xstepper_entry(int msg, DIALOG *d, int c);
int xstepper_proc(int msg, DIALOG *d, int c);
int done_detail(void);
int step_detail(void);

int set_bright(void *dp3, int d2);
int set_contrast(void *dp3, int d2);

MENU menu_list[] =
{
    { "&Main",     NULL, NULL, 0, NULL },
    { "&Sound",    NULL, NULL, 0, NULL },
    { "&Display",  NULL, NULL, 0, NULL },
    { "&Keyboard", NULL, NULL, 0, NULL },
    { "&Parallel", NULL, NULL, 0, NULL },
    { "S&erial",   NULL, NULL, 0, NULL },
    { "&Tape",     NULL, NULL, 0, NULL },
    { "&Help",     NULL, NULL, 0, NULL },
    { NULL,        NULL, NULL, 0, NULL }
};

#define ctrl(x)      (x - 'a' + 1)

char filename_load[1800] = "\0";
char filename_save[1800] = "\0";
char filename_grab[1800] = "\0";
char filename_romm[1800] = "\0";

char mem_range_start[8]  = "0x08c0\0";
char mem_range_end[8]    = "0x07eff\0";
char mem_range_offset[8] = "0x0\0";

char cpu_state_text[4096] = "\0";

long local_bright_ranger;
long local_contrast_ranger;

#define ctrl(x)      (x - 'a' + 1)

DIALOG main_dialog[] =
{
    /* (dialog proc)   (x)  (y)  (w)  (h) (fg)         (bg)     (key)        (f) (d1)(d2)(dp) */

    { d_clear_proc,    0,   0,   640, 480, MENU_BLACK, MENU_BLACK, 0,         0, 0,   0, NULL,             NULL,         NULL },
    { d_bitmap_proc,   0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0,         0, 0,   0, NULL,             NULL,         NULL },
    { d_menu_proc,     0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0,         0, 0,   0, menu_list,        NULL,         NULL },
    { d_slider_proc,   50,  400, 200, 20,  MENU_WHITE, MENU_BLACK, 0,         0, 255, 0, NULL,             set_bright,   NULL },
    { d_text_proc,     50,  425, 200, 30,  MENU_WHITE, MENU_BLACK, 0,         0, 0,   0, "Bright",         NULL,         NULL },
    { d_slider_proc,   340, 400, 200, 20,  MENU_WHITE, MENU_BLACK, 0,         0, 255, 0, NULL,             set_contrast, NULL },
    { d_text_proc,     340, 425, 200, 30,  MENU_WHITE, MENU_BLACK, 0,         0, 0,   0, "Contrast",       NULL,         NULL },
    { d_yield_proc,    0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0,         0, 0,   0, NULL,             NULL,         NULL },
    { d_keyboard_proc, 0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, ctrl('v'), 0, 0,   0, cpu_state_lookup, NULL,         NULL },
    { d_keyboard_proc, 0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, ctrl('x'), 0, 0,   0, quitter,          NULL,         NULL },
    { d_keyboard_proc, 0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, ctrl('m'), 0, 0,   0, step_returner,    NULL,         NULL },
    { xstepper_entry,  0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0,         0, 0,   0, NULL,             NULL,         NULL },
    { NULL,            0,   0,   0,   0,   0,          0,          0,         0, 0,   0, NULL,             NULL,         NULL }
};


DIALOG cpu_state_dialog[] =
{
    /* (dialog proc)     (x)  (y)  (w)  (h) (fg)         (bg)     (key)        (f)    (d1)(d2)(dp) */

    { d_shadow_box_proc, 5,   30,  630, 360, MENU_WHITE, MENU_BLACK, 0,         0,      0, 0, NULL,            NULL, NULL },
    { d_textbox_proc,    10,  35,  620, 325, MENU_WHITE, MENU_BLACK, 0,         0,      0, 0, cpu_state_text,  NULL, NULL },
    { d_button_proc,     155, 365, 120, 20,  MENU_WHITE, MENU_BLACK, 0,         D_EXIT, 0, 0, "&Done   (ESC)", NULL, NULL },
    { xstepper_proc,     325, 365, 120, 20,  MENU_WHITE, MENU_BLACK, 0,         D_EXIT, 0, 0, "&Step (ENTER)", NULL, NULL },
    { d_keyboard_proc,   0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 'd',       D_EXIT, 0, 0, done_detail,     NULL, NULL },
    { d_keyboard_proc,   0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, ctrl('m'), D_EXIT, 0, 0, step_detail,     NULL, NULL },
    { d_keyboard_proc,   0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 's',       D_EXIT, 0, 0, step_detail,     NULL, NULL },
    { d_yield_proc,      0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0,         0,      0, 0, NULL,            NULL, NULL },
    { NULL,              0,   0,   0,   0,   0,          0,          0,         0,      0, 0, NULL,            NULL, NULL }
};


DIALOG load_sub_dialog[] =
{
    /* (dialog proc)     (x)  (y)  (w)  (h) (fg)    (bg) (key) (f) (d1)(d2)(dp) */

    { d_shadow_box_proc, 50,  75,  450, 300, MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, NULL,                 NULL, NULL },
    { d_button_proc,     100, 300, 150, 40,  MENU_WHITE, MENU_BLACK, 0, D_EXIT,0, 0, "OK",                 NULL, NULL },
    { d_button_proc,     300, 300, 150, 40,  MENU_WHITE, MENU_BLACK, 0, D_EXIT,0, 0, "Cancel",             NULL, NULL },
    { d_ctext_proc,      250, 100, 400, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "File Load Details.", NULL, NULL },
    { d_text_proc,       100, 150, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Memory start:",      NULL, NULL },
    { d_text_proc,       100, 200, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Memory end:",        NULL, NULL },
    { d_text_proc,       100, 250, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "File offset:",       NULL, NULL },
    { d_edit_proc,       300, 150, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     8, 7, mem_range_start,      NULL, NULL },
    { d_edit_proc,       300, 200, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     8, 8, mem_range_end,        NULL, NULL },
    { d_edit_proc,       300, 250, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     8, 4, mem_range_offset,     NULL, NULL },
    { d_yield_proc,      0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, NULL,                 NULL, NULL },
    { NULL,              0,   0,   0,   0,   0,          0,          0, 0,     0, 0, NULL,                 NULL, NULL }
};

DIALOG save_sub_dialog[] =
{
    /* (dialog proc)     (x)  (y)  (w)  (h) (fg)    (bg) (key) (f) (d1)(d2)(dp) */

    { d_shadow_box_proc, 50,  75,  450, 250, MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, NULL,                 NULL, NULL },
    { d_button_proc,     100, 250, 150, 40,  MENU_WHITE, MENU_BLACK, 0, D_EXIT,0, 0, "OK",                 NULL, NULL },
    { d_button_proc,     300, 250, 150, 40,  MENU_WHITE, MENU_BLACK, 0, D_EXIT,0, 0, "Cancel",             NULL, NULL },
    { d_ctext_proc,      250, 100, 400, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "File Load Details.", NULL, NULL },
    { d_text_proc,       100, 150, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Memory start:",      NULL, NULL },
    { d_text_proc,       100, 200, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Memory end:",        NULL, NULL },
    { d_edit_proc,       300, 150, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     8, 7, mem_range_start,      NULL, NULL },
    { d_edit_proc,       300, 200, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     8, 8, mem_range_end,        NULL, NULL },
    { d_yield_proc,      0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, NULL,                 NULL, NULL },
    { NULL,              0,   0,   0,   0,   0,          0,          0, 0,     0, 0, NULL,                 NULL, NULL }
};


void main_menu_function(void)
{
    UINT_16 pic_width;
    UINT_16 pic_height;

    {
        gen_nosound();

        (menu_list[0]).child = main_getmenu();
        (menu_list[1]).child = beesnd_getmenu();
        (menu_list[2]).child = beescrn_getmenu();
        (menu_list[3]).child = beekey_getmenu();
        (menu_list[4]).child = beepara_getmenu();
        (menu_list[5]).child = beers232_getmenu();
        (menu_list[6]).child = beetape_getmenu();
        (menu_list[7]).child = help_getmenu();

        just_enter   = 1;
        in_menu_mode = 1;

        find_cpu_state(cpu_state_text);

        temp_throttle = do_throttle;
        do_throttle   = 0;

        set_keyboard_rate(700,10);
        clear_keybuf();

        pic_width  = beescrn_get_beescreen_width();
        pic_height = beescrn_get_beescreen_height();

        if ( pic_width  > 640 ) { pic_width  = 640; }
        if ( pic_height > 480 ) { pic_height = 480; }

        if ( !beescrn_is_in_menu_gfx_mode() && !in_step_mode )
        {
            beescrn_menu_gfx_mode();
            set_palette(*((PALETTE *) beescrn_get_beescreen_palette()));
        }

        rectfill(screen,0,0,640-1,480-1,MENU_BLACK);

        set_mouse_sprite(NULL);

        (main_dialog[1]).dp = (BITMAP *) beescrn_get_beescreen_copy();
        (main_dialog[1]).w  = pic_width;
        (main_dialog[1]).h  = pic_height;
        (main_dialog[1]).x  = (640-pic_width)/2;
        (main_dialog[1]).y  = (480-pic_height)/2;

        gui_fg_color = MENU_WHITE;
        gui_bg_color = MENU_BLACK;
        gui_mg_color = MENU_GREY;

        local_bright_ranger   = beescrn_get_bright();
        local_contrast_ranger = beescrn_get_contrast();

        (main_dialog[3]).d2 = local_bright_ranger;
        (main_dialog[5]).d2 = local_contrast_ranger;

        set_mouse_sprite(bee_pointer);

        main_update_menu_marks();
    }

    if ( in_step_mode == 1 )
    {
        in_step_mode = 0;
    }

    do_dialog(main_dialog,-1);

    {
        destroy_bitmap((main_dialog[1]).dp);

        set_keyboard_rate(0,0);
        clear_keybuf();
        do_throttle = temp_throttle;

        if ( !beescrn_is_in_menu_gfx_mode() && !in_step_mode )
        {
            if ( beescrn_revert_gfx_mode() )
            {
                /*
                   Video mode not available, so to prevent trouble go to
                   step mode, which will not require the mode in question.
                */

                in_step_mode = 1;

                beescrn_menu_gfx_mode();
                set_palette(*((PALETTE *) beescrn_get_beescreen_palette()));
            }

            else
            {
                set_palette(*((PALETTE *) beescrn_get_beescreen_palette()));
            }
        }

        if ( !in_step_mode )
        {
            beescrn_blank_physical_screen();
            beescrn_refresh_bee_screen();
        }
    }

    in_menu_mode = 0;

    update_leds();

    c6545_refresh(c6545_base);

    beescrn_draw_on();

    if ( in_step_mode )
    {
        beescrn_draw_off();
    }

    return;
}

int cpu_state_lookup(void)
{
    in_step_mode = 0;

    popup_dialog(cpu_state_dialog,1);

    return D_O_K;
}

int loadit(void)
{
    unsigned long mem_start;
    unsigned long mem_end;
    unsigned long offset;
    UINT_16 i;
    UINT_8 temp;
    FILE *fp;

    if ( file_select_ex("Load File",filename_load,NULL,300,0,0) )
    {
        if ( popup_dialog(load_sub_dialog,1) == 1 )
        {
            sscanf(mem_range_start,"%li",&mem_start);
            sscanf(mem_range_end,"%li",&mem_end);
            sscanf(mem_range_offset,"%li",&offset);

            if ( ( fp = fopen(filename_load,"rb") ) == NULL )
            {
                alert("","Unable to Open File.","","&OK",NULL,'o',0);
            }

            else
            {
                for ( i = 1 ; ( ( i <= offset ) && !feof(fp) ) ; i++ )
                {
                    temp = getc(fp);
                }

                for ( i = mem_start ; ( ( i <= mem_end ) && !feof(fp) ) ; i++ )
                {
                    temp = getc(fp);

                    z80_addr_bus = i;
                    z80_data_bus = temp;

                    z80_wr_mem();
                }

                fclose(fp);
            }
        }
    }

    return D_O_K;
}

int saveit(void)
{
    unsigned long mem_start;
    unsigned long mem_end;
    UINT_16 i;
    FILE *fp;
    FILE *gp;

    if ( file_select_ex("Save File",filename_save,NULL,300,0,0) )
    {
        if ( popup_dialog(save_sub_dialog,1) == 1 )
        {
            sscanf(mem_range_start,"%li",&mem_start);
            sscanf(mem_range_end,"%li",&mem_end);

            if ( ( gp = fopen(filename_save,"rb") ) != NULL )
            {
                fclose(gp);

                switch ( alert("","File exists - overwrite?.","","&Yes","&No",'y','n') )
                {
                    case 1:
                    {
                        break;
                    }

                    default:
                    {
                        goto exit_point;

                        break;
                    }
                }
            }

            if ( ( fp = fopen(filename_save,"wb") ) == NULL )
            {
                alert("","Unable to Open File.","","&OK",NULL,'o',0);
            }

            else
            {
                for ( i = mem_start ; i <= mem_end ; i++ )
                {
                    z80_addr_bus = i;

                    z80_rd_mem();

                    putc(z80_data_bus,fp);
                }

                fclose(fp);
            }
        }
    }

    exit_point:

    return D_O_K;
}

int returner(void)
{
    return D_CLOSE;
}

int step_returner(void)
{
    in_step_mode = 1;

    return D_CLOSE;
}

int quitter(void)
{
    in_step_mode = 1;

    z80_set_power();

    return D_CLOSE;
}

int sel1BASICa(void)
{
    /*
       Change to BASIC a
    */

    rom1_sel = basic_ROM_a;

    setup_mem_ro(0x080,0x09F,rom1_sel);

    rom1_num = 0;

    main_update_menu_marks();

    return D_O_K;
}

int sel2BASICb(void)
{
    /*
       Change to BASIC b
    */

    rom2_sel = basic_ROM_b;

    setup_mem_ro(0x0A0,0x0BF,rom2_sel);

    rom2_num = 0;

    main_update_menu_marks();

    return D_O_K;
}

int sel3WORDBEE(void)
{
    /*
       Change to WORDBEE ROM
    */

    rom3_sel = wordbee_ROM;

    setup_mem_ro(0x0C0,0x0DF,rom3_sel);

    rom3_num = 0;

    main_update_menu_marks();

    return D_O_K;
}

int sel3EDASM(void)
{
    /*
       Change to EDASM ROM
    */

    rom3_sel = edasm_ROM;

    setup_mem_ro(0x0C0,0x0DF,rom3_sel);

    rom3_num = 1;

    main_update_menu_marks();

    return D_O_K;
}

int sel3FORTH(void)
{
    /*
       Change to FORTH ROM
    */

    rom3_sel = forth_ROM;

    setup_mem_ro(0x0C0,0x0DF,rom3_sel);

    rom3_num = 2;

    main_update_menu_marks();

    return D_O_K;
}

int sel4NETWORK(void)
{
    /*
       Change to Network ROM
    */

    rom4_sel = network_ROM;

    setup_mem_ro(0x0E0,0x0EF,rom4_sel);

    rom4_num = 0;

    main_update_menu_marks();

    return D_O_K;
}

int sel5CHARROM(void)
{
    /*
       Change to standard Character ROM
    */

    rom5_sel = CHAR_ROM;

    refresh_charrom();

    if ( romread )
    {
        /* wrindirect used to make it quicker to switch from rom to ram */
        setup_mem_wrindirect_rw(0x0F0,0x0F7,rom5_sel);
    }

    rom5_num = 0;

    main_update_menu_marks();

    return D_O_K;
}

int load1rom(void)
{
    UINT_16 i;
    FILE *fp;

    if ( file_select_ex("Select ROM File",filename_romm,NULL,300,0,0) )
    {
        if ( ( fp = fopen(filename_romm,"rb") ) == NULL )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }

        else
        {
            for ( i = 0 ; i < 0x02000 ; i++ )
            {
                DEBDEREF(rom1_load,i) = getc(fp);
            }

            fclose(fp);

            rom1_sel = rom1_load;

            setup_mem_ro(0x080,0x09F,rom1_sel);
        }
    }

    rom1_num = 1;

    main_update_menu_marks();

    return D_O_K;
}

int load2rom(void)
{
    UINT_16 i;
    FILE *fp;

    if ( file_select_ex("Select ROM File",filename_romm,NULL,300,0,0) )
    {
        if ( ( fp = fopen(filename_romm,"rb") ) == NULL )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }

        else
        {
            for ( i = 0 ; i < 0x02000 ; i++ )
            {
                DEBDEREF(rom2_load,i) = getc(fp);
            }

            fclose(fp);

            rom2_sel = rom2_load;

            setup_mem_ro(0x0A0,0x0BF,rom2_sel);
        }
    }

    rom2_num = 1;

    main_update_menu_marks();

    return D_O_K;
}

int load3rom(void)
{
    UINT_16 i;
    FILE *fp;

    if ( file_select_ex("Select ROM File",filename_romm,NULL,300,0,0) )
    {
        if ( ( fp = fopen(filename_romm,"rb") ) == NULL )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }

        else
        {
            for ( i = 0 ; i < 0x02000 ; i++ )
            {
                DEBDEREF(rom3_load,i) = getc(fp);
            }

            fclose(fp);

            rom3_sel = rom3_load;

            setup_mem_ro(0x0C0,0x0DF,rom3_sel);
        }
    }

    rom3_num = 3;

    main_update_menu_marks();

    return D_O_K;
}

int load4rom(void)
{
    UINT_16 i;
    FILE *fp;

    if ( file_select_ex("Select ROM File",filename_romm,NULL,300,0,0) )
    {
        if ( ( fp = fopen(filename_romm,"rb") ) == NULL )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }

        else
        {
            for ( i = 0 ; i < 0x01000 ; i++ )
            {
                DEBDEREF(rom4_load,i) = getc(fp);
            }

            fclose(fp);

            rom4_sel = rom4_load;

            setup_mem_ro(0x0E0,0x0EF,rom4_sel);
        }
    }

    rom4_num = 1;

    main_update_menu_marks();

    return D_O_K;
}

int load5rom(void)
{
    UINT_16 i;
    FILE *fp;

    if ( file_select_ex("Select ROM File",filename_romm,NULL,300,0,0) )
    {
        if ( ( fp = fopen(filename_romm,"rb") ) == NULL )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }

        else
        {
            for ( i = 0 ; i < 0x00800 ; i++ )
            {
                DEBDEREF(rom5_load,i) = getc(fp);
            }

            fclose(fp);

            rom5_sel = rom5_load;

            refresh_charrom();

            setup_mem_wrindirect_rw(0x0F0,0x0F7,rom5_sel);
        }
    }

    rom5_num = 1;

    main_update_menu_marks();

    return D_O_K;
}

int cpuclk_on(void)
{
    temp_throttle = 1;
    do_throttle   = 1;

    timer_speed_emul_on();

    TIMER_KEYLOOK(key_down);

    update_leds();

    main_update_menu_marks();

    return D_O_K;
}

int cpuclk_off(void)
{
    temp_throttle = 0;
    do_throttle   = 0;

    timer_speed_emul_off();

    TIMER_KEYLOOK(key_down);

    update_leds();

    main_update_menu_marks();

    return D_O_K;
}









void find_cpu_state(char *dest)
{
    UINT_8 local_a,local_f,local_ax,local_fx;
    UINT_8 local_b,local_c,local_bx,local_cx;
    UINT_8 local_d,local_e,local_dx,local_ex;
    UINT_8 local_h,local_l,local_hx,local_lx;

    UINT_16 local_ix;
    UINT_16 local_iy;
    UINT_16 local_sp;
    UINT_16 local_pc;

    UINT_16 local_pref;

    char local_iff1,local_iff2;
    char local_ima ,local_imb;

    UINT_8 local_i;
    UINT_8 local_r;

    UINT_8 local_doff;

    UINT_8 what;

    char temp[8];

    char flagstring[20];

    char pio_ctrl_reg_state0[] = "Normal             ";
    char pio_ctrl_reg_state1[] = "Pend reg ctrl word ";
    char pio_ctrl_reg_state2[] = "Pend mask ctrl word";

    char   pio_a_mode;
    UINT_8 pio_a_intvect;
    char   pio_a_intonoff[] = "OFF";
    UINT_8 pio_a_ioctrl;                /* mode 3 only */
    UINT_8 pio_a_intmask;               /* mode 3 only */
    char   pio_a_intctrl[] = "OR ";     /* mode 3 only */
    char   pio_a_intlevel[] = "LOW ";   /* mode 3 only */

    char  *pio_a_ctrl_regstate = pio_ctrl_reg_state0;
    char   pio_a_int_inhib[] = "NO ";
    UINT_8 pio_a_stat_out;
    UINT_8 pio_a_stat_in;
    UINT_8 pio_a_strbstat;
    UINT_8 pio_a_outbyte;
    UINT_8 pio_a_inbyte;

    char   pio_b_mode;
    UINT_8 pio_b_intvect;
    char   pio_b_intonoff[] = "OFF";
    UINT_8 pio_b_ioctrl;                /* mode 3 only */
    UINT_8 pio_b_intmask;               /* mode 3 only */
    char   pio_b_intctrl[] = "OR ";     /* mode 3 only */
    char   pio_b_intlevel[] = "LOW ";   /* mode 3 only */

    char  *pio_b_ctrl_regstate = pio_ctrl_reg_state0;
    char   pio_b_int_inhib[] = "NO ";
    UINT_8 pio_b_stat_out;
    UINT_8 pio_b_stat_in;
    UINT_8 pio_b_strbstat;
    UINT_8 pio_b_outbyte;
    UINT_8 pio_b_inbyte;

    {
        pio_a_outbyte = z80pio_base->a_reg_output;
        pio_a_inbyte  = z80pio_base->a_reg_input;

        pio_a_mode     = ( ( z80pio_base->a_reg_mode >> 6 ) & 0x03 ) + '0';
        pio_a_intvect  = z80pio_base->a_reg_intvect;
        pio_a_ioctrl   = z80pio_base->a_reg_ioctrl;
        pio_a_intmask  = z80pio_base->a_reg_maskctrl;
        pio_a_stat_out = z80pio_base->a_mode02_state;
        pio_a_stat_in  = z80pio_base->a_mode123_state;
        pio_a_strbstat = z80pio_base->a_strb_prime;

        if ( (z80pio_base->a_regctrl_pending) )
        {
            pio_a_ctrl_regstate = pio_ctrl_reg_state1;
        }

        if ( (z80pio_base->a_maskctrl_pending) )
        {
            pio_a_ctrl_regstate = pio_ctrl_reg_state2;
        }

        if ( (z80pio_base->a_reg_intctrl) & 0x080 )
        {
            pio_a_intonoff[1] = 'N';
            pio_a_intonoff[2] = ' ';
        }

        if ( (z80pio_base->a_reg_intctrl) & 0x040 )
        {
            pio_a_intctrl[0] = 'A';
            pio_a_intctrl[1] = 'N';
            pio_a_intctrl[2] = 'D';
        }

        if ( (z80pio_base->a_reg_intctrl) & 0x020 )
        {
            pio_a_intlevel[0] = 'H';
            pio_a_intlevel[1] = 'I';
            pio_a_intlevel[2] = 'G';
            pio_a_intlevel[3] = 'H';
        }

        if ( (z80pio_base->a_int_inhibit) )
        {
            pio_a_int_inhib[0] = 'Y';
            pio_a_int_inhib[1] = 'E';
            pio_a_int_inhib[2] = 'S';
        }
    }

    {
        pio_b_outbyte = z80pio_base->b_reg_output;
        pio_b_inbyte  = z80pio_base->b_reg_input;

        pio_b_mode     = ( ( (z80pio_base->b_reg_mode) >> 6 ) & 0x03 ) + '0';
        pio_b_intvect  = z80pio_base->b_reg_intvect;
        pio_b_ioctrl   = z80pio_base->b_reg_ioctrl;
        pio_b_intmask  = z80pio_base->b_reg_maskctrl;
        pio_b_stat_out = z80pio_base->b_mode02_state;
        pio_b_stat_in  = z80pio_base->b_mode123_state;
        pio_b_strbstat = z80pio_base->b_strb_prime;

        if ( (z80pio_base->b_regctrl_pending) )
        {
            pio_b_ctrl_regstate = pio_ctrl_reg_state1;
        }

        if ( (z80pio_base->b_maskctrl_pending) )
        {
            pio_b_ctrl_regstate = pio_ctrl_reg_state2;
        }

        if ( (z80pio_base->b_reg_intctrl) & 0x080 )
        {
            pio_b_intonoff[1] = 'N';
            pio_b_intonoff[2] = ' ';
        }

        if ( (z80pio_base->b_reg_intctrl) & 0x040 )
        {
            pio_b_intctrl[0] = 'A';
            pio_b_intctrl[1] = 'N';
            pio_b_intctrl[2] = 'D';
        }

        if ( (z80pio_base->b_reg_intctrl) & 0x020 )
        {
            pio_b_intlevel[0] = 'H';
            pio_b_intlevel[1] = 'I';
            pio_b_intlevel[2] = 'G';
            pio_b_intlevel[3] = 'H';
        }

        if ( (z80pio_base->b_int_inhibit) )
        {
            pio_b_int_inhib[0] = 'Y';
            pio_b_int_inhib[1] = 'E';
            pio_b_int_inhib[2] = 'S';
        }
    }

    z80_get_A();  local_a  = z80_reg_bus;
    z80_get_F();  local_f  = z80_reg_bus;
    z80_get_Ax(); local_ax = z80_reg_bus;
    z80_get_Fx(); local_fx = z80_reg_bus;
    z80_get_B();  local_b  = z80_reg_bus;
    z80_get_C();  local_c  = z80_reg_bus;
    z80_get_Bx(); local_bx = z80_reg_bus;
    z80_get_Cx(); local_cx = z80_reg_bus;
    z80_get_D();  local_d  = z80_reg_bus;
    z80_get_E();  local_e  = z80_reg_bus;
    z80_get_Dx(); local_dx = z80_reg_bus;
    z80_get_Ex(); local_ex = z80_reg_bus;
    z80_get_H();  local_h  = z80_reg_bus;
    z80_get_L();  local_l  = z80_reg_bus;
    z80_get_Hx(); local_hx = z80_reg_bus;
    z80_get_Lx(); local_lx = z80_reg_bus;

    z80_get_IXh(); local_ix = z80_reg_bus; local_ix *= 0x0100; z80_get_IXl(); local_ix += z80_reg_bus;
    z80_get_IYh(); local_iy = z80_reg_bus; local_iy *= 0x0100; z80_get_IYl(); local_iy += z80_reg_bus;
    z80_get_SPh(); local_sp = z80_reg_bus; local_sp *= 0x0100; z80_get_SPl(); local_sp += z80_reg_bus;
    z80_get_PCh(); local_pc = z80_reg_bus; local_pc *= 0x0100; z80_get_PCl(); local_pc += z80_reg_bus;

    z80_get_st1_();

    temp[7] = '0'; if ( z80_reg_bus >= 128 ) { z80_reg_bus -= 128; temp[7] = '1'; }
    temp[6] = '0'; if ( z80_reg_bus >= 64  ) { z80_reg_bus -= 64;  temp[6] = '1'; }
    temp[5] = '0'; if ( z80_reg_bus >= 32  ) { z80_reg_bus -= 32;  temp[5] = '1'; }
    temp[4] = '0'; if ( z80_reg_bus >= 16  ) { z80_reg_bus -= 16;  temp[4] = '1'; }
    temp[3] = '0'; if ( z80_reg_bus >= 8   ) { z80_reg_bus -= 8;   temp[3] = '1'; }
    temp[2] = '0'; if ( z80_reg_bus >= 4   ) { z80_reg_bus -= 4;   temp[2] = '1'; }
    temp[1] = '0'; if ( z80_reg_bus >= 2   ) { z80_reg_bus -= 2;   temp[1] = '1'; }
    temp[0] = '0'; if ( z80_reg_bus >= 1   ) { z80_reg_bus -= 1;   temp[0] = '1'; }

    local_iff1 = temp[1];
    local_iff2 = temp[2];

    local_ima = temp[3];
    local_imb = temp[4];

    if ( temp[7] == '1' )
    {
        if ( ( temp[6] == '1' ) && ( temp[5] == '1' ) )
        {
            local_pref = 0x0ed;
        }

        else
        {
            if ( temp[6] == '1' )
            {
                local_pref = 0x0fdcb;
            }

            else
            {
                if ( temp[5] == '1' )
                {
                    local_pref = 0x0ddcb;
                }

                else
                {
                    local_pref = 0x0cb;
                }
            }
        }
    }

    else
    {
        if ( temp[6] == '1' )
        {
            local_pref = 0x0fd;
        }

        else
        {
            if ( temp[5] == '1' )
            {
                local_pref = 0x0dd;
            }

            else
            {
                local_pref = 0x0;
            }
        }
    }

    z80_get_I();  local_i = z80_reg_bus;
    z80_get_R();  local_r = z80_reg_bus;

    z80_get_doff(); local_doff = z80_reg_bus;

    what = local_f;

    {
        flagstring[1]  = ' ';
        flagstring[3]  = ' ';
        flagstring[5]  = ' ';
        flagstring[7]  = ' ';
        flagstring[9]  = ' ';
        flagstring[10] = ' ';
        flagstring[12] = ' ';
        flagstring[13] = ' ';
        flagstring[15] = ' ';

        if ( what >= 128 ) { flagstring[0]  = '1'; what -= 128; } else { flagstring[0]  = '0'; }
        if ( what >=  64 ) { flagstring[2]  = '1'; what -=  64; } else { flagstring[2]  = '0'; }
        if ( what >=  32 ) { flagstring[4]  = '1'; what -=  32; } else { flagstring[4]  = '0'; }
        if ( what >=  16 ) { flagstring[6]  = '1'; what -=  16; } else { flagstring[6]  = '0'; }
        if ( what >=   8 ) { flagstring[8]  = '1'; what -=   8; } else { flagstring[8]  = '0'; }
        if ( what >=   4 ) { flagstring[11] = '1'; what -=   4; } else { flagstring[11] = '0'; }
        if ( what >=   2 ) { flagstring[14] = '1'; what -=   2; } else { flagstring[14] = '0'; }
        if ( what >=   1 ) { flagstring[16] = '1'; what -=   1; } else { flagstring[16] = '0'; }

        flagstring[17] = '\0';
    }



    sprintf(dest,"          ======  Z80 CPU State Summary ======         "             "|" " === 6545 State === "    "\n"
                 "                                                       "             "|" "                    "    "\n"
                 "+-----+-----+-----+-----+                              "             "|" " Addr Reg: %02x       "  "\n"
                 "| A   | F   | A'  | F'  |     %02x  %02x  %02x  %02x           "     "|" " Stat Reg: %02x       "  "\n"
                 "| B   | C   | B'  | C'  |     %02x  %02x  %02x  %02x           "     "|" " R00: %02x (HTotal-1) "  "\n"
                 "| D   | E   | D'  | E'  |     %02x  %02x  %02x  %02x           "     "|" " R01: %02x (HDisplay) "  "\n"
                 "| H   | L   | H'  | L'  |     %02x  %02x  %02x  %02x           "     "|" " R02: %02x (HSyncPos) "  "\n"
                 "+-----+-----+-----+-----+    +------+------+           "             "|" " R03: %02x (SyncSize) "  "\n"
                 "|    IX     |     %04x       | IFF1 | IFF2 |     %c  %c  "           "|" " R04: %02x (VTotal-1) "  "\n"
                 "|    IY     |     %04x       | IMa  | IMb  |     %c  %c  "           "|" " R05: %02x (VAdjRast) "  "\n"
                 "|    SP     |     %04x       +------+------+           "             "|" " R06: %02x (VDisplay) "  "\n"
                 "|    PC     |     %04x                                 "             "|" " R07: %02x (VSyncPos) "  "\n"
                 "+-----+-----+                     (S Z 5 H 3 P/V N C)  "             "|" " R08: %02x (Mode)     "  "\n"
                 "| I   | R   |     %02x  %02x   Flags:  %s   "                        "|" " R09: %02x (CharHgt-1)"  "\n"
                 "+-----+-----+              Prefix state:  %04x (%02x)    "           "|" " R0A: %02x (CursorBeg)"  "\n"
                 "                                                       "             "|" " R0B: %02x (CursorEnd)"  "\n"
                 "         ======  Z80 PIO State Summary ======          "             "|" " R0C: %02x (DispAdd)h "  "\n"
                 "                                                       "             "|" " R0D: %02x (DispAdd)l "  "\n"
                 " Port A (mode %c) [%02x %d %d]  | Port B (mode %c) [%02x %d %d]  "   "|" " R0E: %02x (CursAdd)h "  "\n"
                 "                           |                           "             "|" " R0F: %02x (CursAdd)l "  "\n"
                 " Interupts:  %s           | Interupts:  %s           "               "|" " R10: %02x (LpenAdd)h "  "\n"
                 " Inhibitted: %s           | Inhibitted: %s           "               "|" " R11: %02x (LpenAdd)l "  "\n"
                 " Vector:     %02x            | Vector:     %02x            "         "|" " R12: %02x (UpdtAdd)h "  "\n"
                 " Int mask:   %02x   (mode 3) | Int mask:   %02x   (mode 3) "         "|" " R13: %02x (UpdtAdd)l "  "\n"
                 " Int logic:  %s  (mode 3) | Int logic:  %s  (mode 3) "               "|" "                    "    "\n"
                 " Int level:  %s (mode 3) | Int level:  %s (mode 3) "                 "|" " Vert blank:    %d   "   "\n"
                 " IO control: %02x   (mode 3) | IO control: %02x   (mode 3) "         "|" " Horiz blank:   %d   "   "\n"
                 "                           |                           "             "|" " Lpen loaded:   %d   "   "\n"
                 " State in/out: %d/%d         | State in/out: %d/%d         "         "|" " Update done:   %d   "   "\n"
                 " Strobe state: %d           | Strobe state: %d           "           "|" " Cursor mode:   %02x  "  "\n"
                 " Ctrl: %s | Ctrl: %s "                                               "|" " Line Length:   %02x  "  "\n"
                 " Output byte: %02x           | Output byte: %02x           "         "|" " row/col mode:  %d   "   "\n"
                 " Input byte:  %02x           | Input byte:  %02x           "         "|" " Trans mem on:  %d   "   "\n"
                 "                                                       "             "|" " RA4 is strb:   %d   "   "\n"
                 "             ======  Emulator state ======             "             "|" " Update interl: %d   "   "\n"
                 "                                                       "             "|" " Display Addr:  %04x"    "\n"
                 "Timer granularity:                 %d nanoseconds "                  "|" " Cursor Addr:   %04x"    "\n"
                 "6545 call granularity (nokey/key): %02x/%02x               "         "|" " Lpen Addr:     %04x"    "\n"
                 "6545 clock division   (nokey/key): %02x/%02x               "         "|" " Update Addr:   %04x"    "\n"


                                                                                                        ,c6545_base->reg_Raddr
                 ,local_a,local_f,local_ax,local_fx                                                     ,((c6545_base->vblank)|(c6545_base->hblank)|(c6545_base->lpen_register_full)|(c6545_base->update_ready))
                 ,local_b,local_c,local_bx,local_cx                                                     ,c6545_base->reg_R0_
                 ,local_d,local_e,local_dx,local_ex                                                     ,c6545_base->reg_R1_
                 ,local_h,local_l,local_hx,local_lx                                                     ,c6545_base->reg_R2_
                                                                                                        ,((c6545_base->reg_R3_h)|(((c6545_base->reg_R3_v)<<4)&0x0f0))
                 ,local_ix,local_iff1,local_iff2                                                        ,c6545_base->reg_R4_
                 ,local_iy,local_ima ,local_imb                                                         ,c6545_base->reg_R5_
                 ,local_sp                                                                              ,c6545_base->reg_R6_
                 ,local_pc                                                                              ,c6545_base->reg_R7_
                                                                                                        ,((c6545_base->reg_R8_)|(c6545_base->reg_R8_adm))
                 ,local_i,local_r,flagstring                                                            ,c6545_base->reg_R9_
                 ,local_pref,local_doff                                                                 ,c6545_base->reg_R10_cs
                                                                                                        ,c6545_base->reg_R11_
                                                                                                        ,c6545_base->reg_R12_ra
                                                                                                        ,c6545_base->reg_R13_ca
                 ,pio_a_mode,(int) *(z80pio_base->a_data),(int) *(z80pio_base->a_rdy),(int) *(z80pio_base->a_strb),pio_b_mode,(int) *(z80pio_base->b_data),(int) *(z80pio_base->b_rdy),(int) *(z80pio_base->b_strb)    ,c6545_base->reg_R14_ra
                                                                                                        ,c6545_base->reg_R15_ca
                 ,pio_a_intonoff,pio_b_intonoff                                                         ,c6545_base->reg_R16_ra
                 ,pio_a_int_inhib,pio_b_int_inhib                                                       ,c6545_base->reg_R17_ca
                 ,pio_a_intvect,pio_b_intvect                                                           ,c6545_base->reg_R18_ra
                 ,pio_a_intmask,pio_b_intmask                                                           ,c6545_base->reg_R19_ca
                 ,pio_a_intctrl,pio_b_intctrl               
                 ,pio_a_intlevel,pio_b_intlevel                                                         ,(c6545_base->vblank == 0x020)?1:0
                 ,pio_a_ioctrl,pio_b_ioctrl                                                             ,(c6545_base->hblank == 0x001)?1:0
                                                                                                        ,(c6545_base->lpen_register_full == 0x040)?1:0
                 ,(int) pio_a_stat_in,(int) pio_a_stat_out,(int) pio_b_stat_in,(int) pio_b_stat_out     ,(c6545_base->update_ready == 0x080)?1:0
                 ,(int) pio_a_strbstat,(int) pio_b_strbstat                                             ,c6545_base->reg_R10_bb
                 ,pio_a_ctrl_regstate,pio_b_ctrl_regstate                                               ,c6545_base->reg_R1_
                 ,pio_a_outbyte,pio_b_outbyte                                                           ,((c6545_base->reg_R8_) & 0x004)?1:0
                 ,pio_a_inbyte,pio_b_inbyte                                                             ,((c6545_base->reg_R8_) & 0x008)?1:0
                                                                                                        ,((c6545_base->reg_R8_) & 0x040)?1:0
                                                                                                        ,((c6545_base->reg_R8_) & 0x080)?1:0
                                                                                                        ,c6545_base->reg_R12_13_
                 ,(int) timer_period_x                                                                  ,c6545_base->reg_R14_15_
                 ,(int) crtc_granularity_no_key, (int) crtc_granularity_is_key                          ,c6545_base->reg_R16_17_
                 ,(int) crtc_clock_division_no_key, (int) crtc_clock_division_is_key                    ,c6545_base->reg_R18_19_);

    return;
}

void screengrab(void)
{
    UINT_32 height;
    UINT_32 width;
    UINT_32 line_increment;
    UINT_32 mem_offset;
    UINT_32 i,j;
    FILE *fp;
    FILE *gp;
    char scrbuff[1800];

    if ( file_select_ex("Grab Screen Text to File",filename_grab,NULL,300,0,0) )
    {
        if ( ( gp = fopen(filename_grab,"rb") ) != NULL )
        {
            fclose(gp);

            switch ( alert("","File exists - overwrite?.","","&Yes","&No",'y','n') )
            {
                case 1:
                {
                    break;
                }

                default:
                {
                    goto exit_point;

                    break;
                }
            }
        }

        if ( ( fp = fopen(filename_grab,"wt") ) == NULL )
        {
            alert("","Unable to Open File.","","&OK",NULL,'o',0);
        }

        else
        {
            height         = c6545_base->reg_R6_;
            width          = c6545_base->reg_R1_; 
            line_increment = ( (c6545_base->reg_R8_) & 0x004 ) ? 0x0100 : (c6545_base->reg_R1_);
            mem_offset     = c6545_base->reg_R12_13_;

            for ( i = 0 ; i < height ; i++ )
            {
                for ( j = 0 ; j < width ; j++ )
                {
                    z80_addr_bus = 0x0f000 + mem_offset + ( i * line_increment ) + j;

                    z80_rd_mem();

                    z80_data_bus &= 0x07F;

                    if ( z80_data_bus < 32  ) { z80_data_bus = 32; }
                    if ( z80_data_bus > 126 ) { z80_data_bus = 32; }

                    scrbuff[j] = z80_data_bus;
                }

                scrbuff[width] = '\0';

                for ( j = width ; j >= 1 ; j-- )
                {
                    if ( scrbuff[j-1] == 32 )
                    {
                        scrbuff[j-1] = '\0';
                    }

                    else
                    {
                        break;
                    }
                }

                fprintf(fp,"%s\n",scrbuff);
            }

            fclose(fp);
        }
    }

    exit_point:

    return;
}

int set_bright(void *dp3, int d2)
{
    local_bright_ranger = d2;

    beescrn_set_bright(local_bright_ranger);

    set_palette(*((PALETTE *) beescrn_get_beescreen_palette()));

    return D_O_K;

    dp3 = NULL;
}

int set_contrast(void *dp3, int d2)
{
    local_contrast_ranger = d2;

    beescrn_set_contrast(local_contrast_ranger);

    set_palette(*((PALETTE *) beescrn_get_beescreen_palette()));

    return D_O_K;

    dp3 = NULL;
}

int done_detail(void)
{
    in_step_mode = 0;

    return D_EXIT;
}

int step_detail(void)
{
    in_step_mode = 2;

    return D_EXIT;
}

int xstepper_entry(int msg, DIALOG *d, int c)
{
    if ( ( in_step_mode == 2 ) && just_enter )
    {
        cpu_state_lookup();
    }

    just_enter = 0;

    if ( in_step_mode == 2 )
    {
        return D_EXIT;
    }

    return D_O_K;

    msg = c;
    d = NULL;
}

int xstepper_proc(int msg, DIALOG *d, int c)
{
    int ret;

    ret = d_button_proc(msg, d, c);

    if ( ret == D_CLOSE )
    {
        in_step_mode = 2;
    }

    return ret;
}

