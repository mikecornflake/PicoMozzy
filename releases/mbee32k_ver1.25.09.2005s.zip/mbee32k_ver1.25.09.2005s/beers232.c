
#include <stdio.h>
#include <stdlib.h>
#include "beers232.h"


/*
   MicroBee serial module
   ======================

*/

#define DEFAULT_OUT_BAUD 300
#define DEFAULT_IN_BAUD  300

UINT_32 beers232_out_baud;
UINT_32 beers232_in_baud;
UINT_8 *beers232_out_bus;
UINT_8 *beers232_in_bus;

int beers232_out_mode;
int beers232_out_state;

int beers232_in_mode;
int beers232_in_state;

UINT_32 beers232_out_counter;
UINT_32 beers232_in_counter;

FILE *beers232_dest_fp;
FILE *beers232_src_fp;

UINT_16 *beers232_cycle_bus;

char beers232_out_menu_optiona[] = "  Output to pc &serial port";
char beers232_out_menu_optionb[] = "  Output to &file";
char beers232_out_menu_optionc[] = "  Output to virtual &modem";
char beers232_out_menu_optiond[] = "  Output to &NULL";
char beers232_out_menu_optione[] = "- Output &Unconnected";

char beers232_in_menu_optiona[] = "  Input from pc s&erial port";
char beers232_in_menu_optionb[] = "  Input from fil&e";
char beers232_in_menu_optionc[] = "  Input from virtual mo&dem";
char beers232_in_menu_optiond[] = "- Input U&nconnected";

MENU beers232_menu[] =
{
    { beers232_out_menu_optiona,      NULL, NULL, D_DISABLED, NULL },
    { beers232_out_menu_optionb,      NULL, NULL, D_DISABLED, NULL },
    { beers232_out_menu_optionc,      NULL, NULL, D_DISABLED, NULL },
    { beers232_out_menu_optiond,      NULL, NULL, D_DISABLED, NULL },
    { beers232_out_menu_optione,      NULL, NULL, D_DISABLED, NULL },
    { "",                             NULL, NULL, 0,          NULL },
    { "Serial port &output settings", NULL, NULL, D_DISABLED, NULL },
    { "",                             NULL, NULL, 0,          NULL },
    { beers232_in_menu_optiona,       NULL, NULL, D_DISABLED, NULL },
    { beers232_in_menu_optionb,       NULL, NULL, D_DISABLED, NULL },
    { beers232_in_menu_optionc,       NULL, NULL, D_DISABLED, NULL },
    { beers232_in_menu_optiond,       NULL, NULL, D_DISABLED, NULL },
    { "",                             NULL, NULL, 0,          NULL },
    { "Serial port &input settings",  NULL, NULL, D_DISABLED, NULL },
    { NULL,                           NULL, NULL, 0,          NULL }
};


void beers232_update_menu_marks(void);


SetupData beers232_setdat[] =
{
   { "", NULL, 0 }
};


SetupData *beers232_setup(void)
{
    beers232_out_baud = DEFAULT_OUT_BAUD;
    beers232_in_baud  = DEFAULT_IN_BAUD;

    return beers232_setdat;
}

int beers232_init(UINT_8 *_beers232_out_bus, UINT_8 *_beers232_in_bus, UINT_16 *_beers232_cycle_bus)
{
    beers232_out_bus = _beers232_out_bus;
    beers232_in_bus  = _beers232_in_bus;

    beers232_out_mode  = 3;
    beers232_out_state = 0;

    beers232_in_mode  = 3;
    beers232_in_state = 0;

    beers232_out_counter = 0;
    beers232_in_counter  = 0;

    beers232_dest_fp = NULL;
    beers232_src_fp  = NULL;

    beers232_cycle_bus = _beers232_cycle_bus;

    return 1;
}

MENU *beers232_getmenu(void)
{
    beers232_update_menu_marks();

    return beers232_menu;
}

void beers232_remove(void)
{
    return;
}

#ifdef DEBUG_SERIAL
FILE *serial_log = NULL;
#endif
int serial_count = 0;

void beers232_serial_out_state_change(void)
{
    #ifdef DEBUG_SERIAL
    if ( serial_log == NULL )
    {
        serial_log = fopen("serial.log","wt");
    }

    fprintf(serial_log,"serial %d: %d at %d cycles\n",serial_count,(int) (*beers232_out_bus),(int) beers232_out_counter);
    fflush(serial_log);
    #endif

    serial_count++;

    beers232_out_counter = 0;

    return;
}

void beers232_cycle(void)
{
    beers232_out_counter += *beers232_cycle_bus;
    beers232_in_counter  += *beers232_cycle_bus;

    return;
}


void beers232_update_menu_marks(void)
{
    return;
}

