
#include "fakealeg.h"
#include "u_dtype.h"
#include "configer.h"

#ifndef _beesnd_h
#define _beesnd_h

#ifndef BUS_PREFIX
#define BUS_PREFIX extern
#endif

/*
   Microbee sound emulation module
   ===============================

   Functions:

   beesnd_cycle()                - take the emulation through some number of
                                   (z80) cycles.
   beesnd_speaker_state_change() - called to indicate that the speaker state
                                   (may have) changed.
   beesnd_toggle_sound()         - toggle sound emulation on/off.
   beesnd_timing_accur_signal()  - this is called to indicate the "real" and
                                   "emulated" time are approximately aligned,
                                   and hence if sound is being emulated via
                                   the pc speaker we can safely change the
                                   tone.
   beesnd_is_snd_on()            - returns nonzero if sound emulation is
                                   on, zero otherwise.

*/

SetupData *beesnd_setup(void);
int beesnd_init(UINT_8 *_beesnd_speaker_state_tmp, UINT_16 *_beesnd_cycle_bus);
MENU *beesnd_getmenu(void);
void beesnd_remove(void);

void beesnd_cycle(void);
void beesnd_speaker_state_change(void);
void beesnd_toggle_sound(void);
void beesnd_timing_accur_signal(void);

int beesnd_is_snd_on(void);


#endif

