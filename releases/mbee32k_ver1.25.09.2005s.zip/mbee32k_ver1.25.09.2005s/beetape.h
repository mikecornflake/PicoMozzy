
#include "fakealeg.h"
#include "u_dtype.h"
#include "configer.h"
#include "z80pio.h"

#ifndef _beetape_h
#define _beetape_h

/*
   MicroBee tape module
   ====================

   Modulation Scheme
   =================

   The microbee uses the "Kansas city standard" (thanks to WorkerBee for
   pointing that out) modulation scheme - that is, 0 is 1200Hz and 1 is
   2400Hz.  This is used to modulate a serial data stream with 8 bits, no
   parity and 2 stop bits.  So, each byte transmitted is:

   0.  boundary bit low
   1.  Data bit 0 (LSB)
   2.  Data bit 1
   3.  Data bit 2
   4.  Data bit 3
   5.  Data bit 4
   6.  Data bit 5
   7.  Data bit 6
   8.  Data bit 7 (MSB)
   9.  stop bit high
   10. stop bit high
   (return to low if end of block)

   When no signal is being sent, the output of the pio is held low.


   300 Baud Modulation Details
   ===========================

   Each high bit is: 2400Hz modulated.
                     starts high, ends low.
                     8 cycles long.
                     characterised by the duty cycle:

                                  - first peak is 840 clocks wide
    +-+ +-+ +-+ +-+ +-+ +-+ +-+   - last 7 peaks are 711 z80 clocks wide
      | | | | | | | | | | | | |
      +-+ +-+ +-+ +-+ +-+ +-+ +-+ - each trough is 684 z80 clocks wide


   Each low bit is: 1200Hz modulated.
                    starts high, ends low.
                    4 cycles long.
                    characterised by the duty cycle:

                              - first peak is 1546->1613 clocks wide
    +--+  +--+  +--+  +--+    - last 3 peaks are 1413 z80 clocks wide
       |  |  |  |  |  |  |
       +--+  +--+  +--+  +--+ - each trough is 1386 z80 clocks wide


   1200 Baud Modulation Details
   ============================

   Each high bit is: 2400Hz modulated.
                     starts high, ends low.
                     2 cycles long.
                     characterised by the duty cycle:

    +-+ +-+   - first peak 840, 2nd peak 711 z80 clocks wide
      | | |
      +-+ +-+ - each trough is 684 z80 clocks wide


   Each low bit is: 1200Hz modulated.
                    starts high, ends low.
                    1 cycle long.
                    characterised by the duty cycle:

    +--+    - peak 1582 z80 clocks wide
       |   
       +--+ - trough 1386 z80 clocks wide


   Higher level details - pipe operations
   ======================================

   When data is piped to the tape port (under basic, this means using
   outl#2, out#3 or similar), the format is thus:

   ff     + 
   ff     | First there are 20 ff's (give or take)
   ...    | 
   ff     + 
   2a     - then 2a, which presumably means something
   ll     - the length byte.  If this is 0, 256 bytes of data follow.
            Otherwise ll bytes follow.
   <ll>   - block: ll bytes of data (or 256 if ll = 0)
   crc    - crc byte
            To calculate this: initialise c = 0
                               for each byte d in <ll>: c := (c XOR d) >> 1
   ff     +
   ff     | Some number of ff's (seems random, but at least 1)
   ...    |
   ff     +

   The entire block is either 300 baud or 1200 baud, including all the
   header stuff and the ff buffers.  Thus by timing the length of the
   1200Hz burst at the start (the boundary bit) one can calculate the
   speed of transfer.  The same logic can be used to detect if this is
   a save operation (which will have 00 as a buffer).  Specifically:

   1. If the transmission starts with 1 cycle at 1200Hz, then goes to 2400Hz
      then the transmission must be a 1200 baud pipe operation
   2. If the transmission starts with 4 cycles at 1200Hz and then goes to
      2400Hz then it must be a 300 baud pipe operation.
   3. If the transmission starts with 36 cycles at 1200Hz, and then goes to
      2400Hz it is a tape save operation (see below), which always starts
      at 300baud for the header.


   Higher level details - tape save operations
   ===========================================

   When data is saved to the tape port, the format is thus:

   *** Transmission will begin at 300baud for (at least) the header. ***
   00     + 
   00     | First there are >=16 00's (NULLs) according to the docs
   ...    | ime, this means that there are 64 of these
   00     +
   01     - SOH (start of header) byte
   xx     +
   xx     |
   xx     | 6 byte filename, padded with NULLs (00's)
   xx     |
   xx     |
   xx     +
   ft     - filetype byte.  Could be anything, but the types recognised by
            basic are: - B for BASIC files
                       - M for MACHINE language files
   ll     \ file size 
   hh     / (LSB first)
   ll     \ load address
   hh     / (LSB first)
   ll     \ autoexec address
   hh     / (LSB first)
   ss     - speed - 00 = 300baud, nonzero (01) = 1200baud
   aa     - autoload control - 00 = no autoexec, FF for autoexec
   nu     - unused (zero) byte
   ck     - checksum byte for header
            To calculate this: 1. sum all bytes in the header (starting at
                                  the first byte after the SOH (not including
                                  SOH) and ending with the unused byte.
                               2. take the 2's complement.
                               3. Then the weird bit - if the solution so
                                  far is xy in hex (eg. 6e means x=6, y=e)
                                  then subtract 1 from x, giving the
                                  checksum (x-1)y so, in the above example,
                                  the checksum would be 5e.
   *** There low cycle here is extended to ~1800 clock cycles.  ***
   *** At this point, if speed == 1200Hz (ss = FF) then the     ***
   *** speed will change from 300baud to 1200baud transmission. ***
   <256>  - byte data block            +
   ck     - checksum for data block    | Not present if filesize <= 256
   ...    - repeat so many times       +
   <n>    - n byte data block, where n = filesize % 0x0100
   crc    - crc for data block

   To calculate the checksum for each data block, and the crc for the final
   data block, the following method is used:

   1. Start block with c = 0
   2. For each data byte in block, do c := CPL(d-c) where CPL is the 1's
      complement (inverse) and d-c is done by two's complementing c.


   Functions provided
   ==================

   beetape_state_change: must be called when the state of *beetapeo_bus
                         is changed.
   beetape_cycle:        must be called regularly to cycle the tape module
                         through the cycles count on *beetape_cycle_bus to
                         control the internal state of the module.  This
                         function will call back to beetapei_strober when
                         the state of the tape input bus *beetapei_bus is
                         changed.

*/


SetupData *beetape_setup(void);
int beetape_init(UINT_8 *_beetapeo_bus, UINT_8 *_beetapei_bus, weird_pointer_jive _beetapei_strober, UINT_16 *_beetape_cycle_bus);
MENU *beetape_getmenu(void);
void beetape_remove(void);

void beetape_state_change(void);
void beetape_cycle(void);

#endif
