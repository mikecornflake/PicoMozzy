
#include "fakealeg.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "z80pio.h"
#include "beetape.h"
#include "u_dtype.h"
#include "beelowpc.h"
#include "configer.h"
#include "debmaloc.h"

#define MENU_WHITE      0x0C1
#define MENU_GREY       0x0C2
#define MENU_BLACK      0x0C3

/*
   Global variables
   ================

   beetapeo_bus:      output bus pointer.
   beetapei_bus:      input bus pointer.
   beetapei_strober:  function called from here when input bus is changed.
   beetape_cycle_bus: function which should be called when the output bus
                      is changed.


   Behavioural constants
   =====================

   BEETAPE_ZCLK_MASK: mask used to stop beetapeo_elapsed_zclk overflowing

   BEETAPE_1200_LOW:  # beetape*_elapsed_zclk cycles "0" for 1200Hz signal
   BEETAPE_1200_HGH:  # beetape*_elapsed_zclk cycles "1" for 1200Hz signal
   BEETAPE_2400_LOW:  # beetape*_elapsed_zclk cycles "0" for 2400Hz signal
   BEETAPE_2400_HGH:  # beetape*_elapsed_zclk cycles "1" for 2400Hz signal

   BEETAPE_1200_LOWER: lower bound of beetape*_elapsed_zclk "1" half-cycle
                       for a 1200Hz signal (when decoding)
   BEETAPE_1200_UPPER: upper bound of beetape*_elapsed_zclk "1" half-cycle
                       for a 1200Hz signal (when decoding)
   BEETAPE_2400_LOWER: lower bound of beetape*_elapsed_zclk "1" half-cycle
                       for a 2400Hz signal (when decoding)
   BEETAPE_2400_UPPER: upper bound of beetape*_elapsed_zclk "1" half-cycle
                       for a 2400Hz signal (when decoding)

   BEETAPE_300_COUNT_LOW:  # cycles @ 1200Hz for a 300 baud tape "0" signal
   BEETAPE_300_COUNT_HGH:  # cycles @ 2400Hz for a 300 baud tape "1" signal
   BEETAPE_1200_COUNT_LOW: # cycles @ 1200Hz for a 1200 baud tape "0" signal
   BEETAPE_1200_COUNT_HGH: # cycles @ 2400Hz for a 1200 baud tape "1" signal

   For convenience, many of the above are combined into some (nominally
   read only) arrays, which allow one refer to a single variable for 
   different frequencies and save speeds.  These are:

   beetape_cycles[2][2] = "correct" # z80 clock cycles a signal should stay
                          either high or low.
                          [0][0] = at 1200Hz LOW
                          [0][1] = at 1200Hz HIGH
                          [1][0] = at 2400Hz LOW
                          [1][1] = at 2400Hz HIGH

   beetape_lower[2] = "minimum" # z80 clock cycles a signal should stay high
                      [0] = at 1200Hz nominal
                      [1] = at 2400Hz nominal
   beetape_upper[2] = "maximum" # z80 clock cycles a signal should stay high
                      [0] = at 1200Hz nominal
                      [1] = at 2400Hz nominal

   beetape_count[2][2] = number of cycles for a given signal
                         [0][0] = 300baud "0" (1200Hz) bit
                         [0][1] = 300baud "1" (2400Hz) bit
                         [1][0] = 1200baud "0" (1200Hz) bit
                         [1][1] = 1200baud "1" (2400Hz) bit
*/


UINT_8  *beetapeo_bus;
UINT_8  *beetapei_bus;
weird_pointer_jive beetapei_strober;
UINT_16 *beetape_cycle_bus;

#define BEETAPE_1200_LOW        1386
#define BEETAPE_1200_HGH        1413
#define BEETAPE_2400_LOW        684
#define BEETAPE_2400_HGH        711

#define BEETAPE_1200_LOWER      1100
#define BEETAPE_1200_UPPER      2200
#define BEETAPE_2400_LOWER      500
#define BEETAPE_2400_UPPER      900

#define BEETAPE_300_COUNT_LOW   4
#define BEETAPE_300_COUNT_HGH   8
#define BEETAPE_1200_COUNT_LOW  1
#define BEETAPE_1200_COUNT_HGH  2

#define BEETAPE_TIMEOUT_POINT   2300
#define BEETAPE_TIMEOUT_PUSH    2000

#define BEETAPE_ZCLK_MASK       0x00fffffff

UINT_32 beetape_cycles[2][2];
UINT_32 beetape_lower[2];
UINT_32 beetape_upper[2];
UINT_32 beetape_count[2][2];

void beetape_update_menu_marks(void);






/*
   Variables and Control - output
   ==============================

   beetapeo_mode:          1  = stream to data file
                           2  = stream to WAVe file
                           3  = stream to NULL
   beetapeo_mode_autosave: 0  = saved data is piped using the pipe mode
                           1  = saved data is saved to a file in the
                                beetapeo_autosave_dir directory.  The
                                filename is worked out using the filename
                                given in the tape header, with extension
                                being the filetype byte.
   beetapeo_autosave_dir:  s  = string giving the current autosave directory.
                                By default, this is "./"
   beetapeo_autosave_name: s  = string giving the current autosave name,
                                which is the combination of the filename and
                                filetype given in the tape header.
   beetapeo_file_tapedest: s  = filename all output data is sent to.  This is
                                used by both the save and pipe operations.
   beetapeo_type:          0  = stream output
                           1  = tape save output
   beetapeo_baud:          0  = 300 baud
                           1  = 1200 baud
   beetapeo_hl_state:      **** If beetapeo_type = 0
                           0  = not doing anything
                           1  = signal detected, ff read
                           2  = 2a read, awaiting length
                           3  = length read, awaiting (or reading) data
                           4  = data finished, awaiting crc
                           **** If beetapeo_type = 1
                           0  = not doing anything
                           1  = signal detected, 00 read, awaiting 01
                           2  = 01 read, awaiting filename byte 1
                           3  =          awaiting filename byte 2
                           4  =          awaiting filename byte 3
                           5  =          awaiting filename byte 4
                           6  =          awaiting filename byte 5
                           7  =          awaiting filename byte 6
                           8  = awaiting filetype byte
                           9  = awaiting lsb of filesize word
                           10 = awaiting msb of filesize word
                           11 = awaiting msb of load addr
                           12 = awaiting msb of load addr
                           13 = awaiting msb of autoexec addr
                           14 = awaiting msb of autoexec addr
                           15 = awaiting speed byte
                           16 = awaiting autoload byte
                           17 = awaiting unused byte
                           18 = awaiting checksum byte
                           19 = awaiting (or reading) data
                           20 = awaiting (or reading) data checksum/crc
   beetapeo_hl_length:     #  = bytes in block still to be read
   beetapeo_hl_overall:    #  = blocks to be read overall, -1
   beetapeo_hl_endit:      #  = bytes in final block
   beetapeo_filename:      s  = file name string
   beetapeo_filetype:      b  = file type byte
   beetapeo_filesize:      #  = file size word
   beetapeo_fileload:      #  = file load address word
   beetapeo_fileexec:      #  = file autoexec address word
   beetapeo_filesped:      b  = file speed byte (0 for 300baud)
   beetapeo_fileauto:      b  = file autoload byte (0 for non-autoexec)
   beetapeo_state_course:  0  = nothing happening, waiting to find stuff
                           1  = first boundary bit
                           2  = data bit 0
                           3  = data bit 1
                           4  = data bit 2
                           5  = data bit 3
                           6  = data bit 4
                           7  = data bit 5
                           8  = data bit 6
                           9  = data bit 7
                           10 = first stop bit
                           11 = second stop bit
   beetapeo_state_fine:    0  = signal level low
                           !0 = signal level high
   beetapeo_tapefreq:      0  = 1200Hz
                           1  = 2400Hz
   beetapeo_byte:          b  = the actual data byte (used in interfn comms)
   beetapeo_crc:           b  = used to calculate the crc
   beetapeo_kansascycle:   #  = elapsed cycles (at 1200 or 2400Hz)
   beetapeo_elapsed_zclk:  #  = elapsed z80 cycles since last edge


   beetapeo_dest_fp:     file pipe operations are sent to
   beetapeo_autosave_fp: file autosave operations are sent to
*/



FILE *beetapeo_dest_fp;
FILE *beetapeo_autosave_fp;

int     beetapeo_mode;
int     beetapeo_mode_autosave;
int     beetapeo_baud;
int     beetapeo_type;
int     beetapeo_state_course;
int     beetapeo_tapefreq;
int     beetapeo_state_fine;
UINT_8  beetapeo_byte;
UINT_8  beetapeo_crc;
UINT_32 beetapeo_kansascycle;
UINT_32 beetapeo_elapsed_zclk;
int     beetapeo_hl_state;
UINT_8  beetapeo_hl_length;
UINT_8  beetapeo_hl_overall;
UINT_8  beetapeo_hl_endit;
char    beetapeo_filename[7];
UINT_8  beetapeo_filetype;
UINT_16 beetapeo_filesize;
UINT_16 beetapeo_fileload;
UINT_16 beetapeo_fileexec;
UINT_8  beetapeo_filesped;
UINT_8  beetapeo_fileauto;

char beetapeo_autosave_dir[1800] = "./";
char beetapeo_autosave_name[1800];
char beetapeo_file_tapedest[1800];

void beetapeo_reset_state_after_block(void);
void beetapeo_reset_state_after_file(void);
void beetapeo_reset_state_after_stream(void);
void beetapeo_reset_state(void);

inline void beetapeo_cycle(void);
void beetapeo_send_byte(void);

void beetapeo_close_output_stream(void);
void beetapeo_close_autosave_file(void);

int beetapeo_set_mode_0(void);
int beetapeo_set_mode_1(char *filename);
int beetapeo_set_mode_2(char *filename);
int beetapeo_set_mode_3(void);
int beetapeo_set_tape_0(void);
int beetapeo_set_tape_1(void);
int beetapeo_set_tape_2(void);
int beetapeo_set_tape_3(void);
int beetape_set_autosave_on(void);
int beetape_set_autosave_off(void);
int beetape_set_savedir(void);

#define BEETAPEO_SET_DEFAULT_MODE beetapeo_set_mode_3()

void beetapeo_reset_state_after_block(void)
{
    beetapeo_byte         = 0;
    beetapeo_baud         = 0;
    beetapeo_type         = 0;
    beetapeo_state_fine   = (*beetapeo_bus);
    beetapeo_state_course = 0;
    beetapeo_tapefreq     = 0;
    beetapeo_crc          = 0;
    beetapeo_kansascycle  = 0;
    beetapeo_elapsed_zclk = 0;
    beetapeo_hl_state     = 0;
    beetapeo_hl_length    = 0;

    return;
}

void beetapeo_reset_state_after_file(void)
{
    beetapeo_reset_state_after_block();

    beetapeo_mode_autosave = 1;

    beetapeo_hl_overall   = 0;
    beetapeo_hl_endit     = 0;

    beetapeo_filename[0] = '\0';
    beetapeo_filename[1] = '\0';
    beetapeo_filename[2] = '\0';
    beetapeo_filename[3] = '\0';
    beetapeo_filename[4] = '\0';
    beetapeo_filename[5] = '\0';
    beetapeo_filename[6] = '\0';

    beetapeo_filetype = 0;
    beetapeo_filesize = 0;
    beetapeo_fileload = 0;
    beetapeo_fileexec = 0;
    beetapeo_filesped = 0;
    beetapeo_fileauto = 0;

    beetapeo_close_autosave_file();

    return;
}

void beetapeo_reset_state_after_stream(void)
{
    beetapeo_reset_state_after_block();

    beetapeo_close_output_stream();

    BEETAPEO_SET_DEFAULT_MODE;

    return;
}

void beetapeo_reset_state(void)
{
    beetapeo_reset_state_after_file();
    beetapeo_reset_state_after_stream();

    return;
}

void beetapeo_send_byte(void)
{
    FILE *beetapeo_mtd_fp;

    if ( !beetapeo_type )
    {
        /*
           This is a byte in a data stream
        */

        switch ( beetapeo_hl_state )
        {
            case 0:
            {
                /*
                   Wait for ff to indicate the start of the header.
                */

                if ( beetapeo_byte == 0x0ff )
                {
                    beetapeo_hl_state = 1;
                }

                break;
            }

            case 1:
            {
                /*
                   This should be followed by a 2a to indicate the start of
                   proceedings.
                */

                if ( beetapeo_byte == 0x02a )
                {
                    beetapeo_hl_state = 2;
                }

                else if ( beetapeo_byte != 0x0ff )
                {
                    beetapeo_reset_state_after_block();
                }

                break;
            }

            case 2:
            {
                /*
                   Next comes the length byte.  If this is 0 then the block
                   will be 256 bytes long.  Otherwise, the block will be 1
                   longer than indicated here.
                */

                beetapeo_hl_state = 3;

                beetapeo_hl_length = beetapeo_byte;

                if ( beetapeo_hl_length == 0 )
                {
                    beetapeo_hl_length = 0x0ff;
                }

                else
                {
                    beetapeo_hl_length--;
                }

                beetapeo_crc = 0x000;

                break;
            }

            case 3:
            {
                /*
                   This is a byte in the data block.
                */

                beetapeo_crc ^= beetapeo_byte;

                if ( beetapeo_crc & 0x001 )
                {
                    beetapeo_crc = ( ( beetapeo_crc >> 0x001 ) & 0x07f ) | 0x080;
                }

                else
                {
                    beetapeo_crc =   ( beetapeo_crc >> 0x001 ) & 0x07f;
                }

                if ( beetapeo_hl_length == 0 )
                {
                    beetapeo_hl_state = 4;
                }

                else
                {
                    beetapeo_hl_length--;
                }

                switch ( beetapeo_mode )
                {
                    case 1:
                    {
                        if ( fputc(beetapeo_byte,beetapeo_dest_fp) != beetapeo_byte )
                        {
                            beetapeo_reset_state_after_stream();
                        }

                        break;
                    }

                    case 2:
                    case 3:
                    {
                        break;
                    }

                    default:
                    {
                        /*
                           State unknown, something badly wrong.
                        */

                        beetapeo_reset_state();

                        break;
                    }
                }

                break;
            }

            case 4:
            {
                beetapeo_hl_state = 0;

                break;
            }

            default:
            {
                /*
                   State unknown, something badly wrong.
                */

                beetapeo_reset_state();

                break;
            }
        }
    }

    else
    {
        /*
           This is a byte in a file being saved
        */

        switch ( beetapeo_hl_state )
        {
            case 0:
            {
                /*
                   Waiting for a 00 to indicate beginning of file.
                */

                if ( beetapeo_byte == 0x000 )
                {
                    beetapeo_hl_state = 1;
                }

                break;
            }

            case 1:
            {
                /*
                   Waiting for SOH (start of header) byte.
                */

                if ( beetapeo_byte == 0x001 )
                {
                    beetapeo_hl_state = 2;

                    beetapeo_crc = 0x000;
                }

                else if ( beetapeo_byte != 0x000 )
                {
                    /*
                       There's some non-zero values in the pre-header, which
                       is not allowed.  Let's assume this was just a false
                       start, so don't do anything too drastic.  Note that
                       the file will not have started at this point in any
                       case, so no need to worry about autosave stuff just
                       yet.
                    */

                    beetapeo_reset_state_after_block();
                }

                break;
            }

            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Record the filename (6 bytes).  While we're at it, it
                   is important to make sure the filename is "OK" for
                   DOS/Windows.  Default overwrite character for unusable
                   chars is "_".

                   FIXME: - IF this is ever ported to linux, this may need
                            to be changed to allow for differences in the
                            linux file name conventions.
                          - Technically, spaces seem to be allowed in the
                            filenames for the microbee tape format (but not
                            the disk format).  However, these are more
                            trouble than they are worth, esp. as dos is a
                            target system for this emulator.  Hence they
                            are dis-allowed here.  This shouldn't matter, as
                            afaik no-one used them on the bee back in the
                            day.
                */

                if ( ( beetapeo_byte >= ' '  ) &&
                     ( beetapeo_byte <= '~'  ) &&
                     ( beetapeo_byte != ' '  ) &&
                     ( beetapeo_byte != '\\' ) &&
                     ( beetapeo_byte != '/'  ) &&
                     ( beetapeo_byte != ':'  ) &&
                     ( beetapeo_byte != '*'  ) &&
                     ( beetapeo_byte != '\?' ) &&
                     ( beetapeo_byte != '\"' ) &&
                     ( beetapeo_byte != '<'  ) &&
                     ( beetapeo_byte != '>'  ) &&
                     ( beetapeo_byte != '|'  )    )
                {
                    beetapeo_filename[beetapeo_hl_state-2] = beetapeo_byte;
                }

                else if ( beetapeo_byte != 0x000 )
                {
                    beetapeo_filename[beetapeo_hl_state-2] = '_';
                }

                else
                {
                    beetapeo_filename[beetapeo_hl_state-2] = '\0';
                }

                beetapeo_filename[6] = '\0';

                beetapeo_hl_state++;

                break;
            }

            case 8:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get filetype character
                */

                beetapeo_filetype = beetapeo_byte;

                beetapeo_hl_state++;

                break;
            }

            case 9:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get LSB of filesize
                */

                beetapeo_filesize = SETLOWER8OF16(beetapeo_filesize,beetapeo_byte);

                beetapeo_hl_state++;

                break;
            }

            case 10:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get MSB of filesize
                */

                beetapeo_filesize = SETUPPER8OF16(beetapeo_filesize,beetapeo_byte);

                beetapeo_hl_state++;

                break;
            }

            case 11:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get LSB of load address
                */

                beetapeo_fileload = SETLOWER8OF16(beetapeo_fileload,beetapeo_byte);

                beetapeo_hl_state++;

                break;
            }

            case 12:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get MSB of load address
                */

                beetapeo_fileload = SETUPPER8OF16(beetapeo_fileload,beetapeo_byte);

                beetapeo_hl_state++;

                break;
            }

            case 13:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get LSB of autoexec address
                */

                beetapeo_fileexec = SETLOWER8OF16(beetapeo_fileexec,beetapeo_byte);

                beetapeo_hl_state++;

                break;
            }

            case 14:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get MSB of autoexec address
                */

                beetapeo_fileexec = SETUPPER8OF16(beetapeo_fileexec,beetapeo_byte);

                beetapeo_hl_state++;

                break;
            }

            case 15:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get filespeed byte.  00 indicates that the data is stored
                   at 300baud, while ff means 1200baud.  For now, I don't
                   bother to check this, which may be a mistake...
                */

                beetapeo_filesped = beetapeo_byte;

                beetapeo_hl_state++;

                break;
            }

            case 16:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   Get autoexec byte.  00 is normal (no autoexec), whilst
                   ff means "jump to autoexec address after loading".
                   Again, we don't check this.
                */

                beetapeo_fileauto = beetapeo_byte;

                beetapeo_hl_state++;

                break;
            }

            case 17:
            {
                beetapeo_crc = MASKEDADD8(beetapeo_crc,beetapeo_byte);

                /*
                   This is a dummy byte, which is ignored.
                */

                beetapeo_hl_state++;

                break;
            }

            case 18:
            {
                /*
                   The checksum for the header is here.  See previously
                   for details.  At present, we don't check to see if this
                   corresponds to the crc generated by the bee... this may
                   be a mistake, but the rationale is that it is better to
                   be generous in the input you accept, and strict in what
                   you produce.  On the other hand, a bad crc here may
                   indicate a problem (well, ok, it does, but anyhow), so
                   stopping might be a better thing to do.
                */

                beetapeo_crc = TAKETWOS(beetapeo_crc);
                beetapeo_crc = ( ( ( beetapeo_crc & 0x0f0 ) - 0x010 ) & 0x0f0 ) | ( beetapeo_crc & 0x00f );

                /*
                   We must set the speed to either 300 or 1200 baud
                   depending on the speed byte, as this is the speed at
                   which any data following this has been recorded.
                */

                if ( beetapeo_filesped ) 
                {
                    beetapeo_baud = 1;
                }

                else
                {
                    beetapeo_baud = 0;
                }

                beetapeo_hl_state++;

                if ( beetapeo_mode_autosave )
                {
                    /*
                       Construct the filename.  This consists of the
                       beetapeo_filename string followed by .M, where
                       M is the beetapeo_filetype character.

                       FIXME: for some reason, the .B file produced is
                              not a true .mwb file - need to write a
                              converter program.
                    */

                    strcpy(beetapeo_autosave_name,beetapeo_filename);

                    if ( (                                  ( beetapeo_filetype < 0x030 ) ) ||
                         ( ( beetapeo_filetype > 0x039 ) && ( beetapeo_filetype < 0x041 ) ) ||
                         ( ( beetapeo_filetype > 0x05a ) && ( beetapeo_filetype < 0x061 ) ) ||
                         ( ( beetapeo_filetype > 0x07a )                                  )    )
                    {
                        beetapeo_filetype = '_';
                    }

                    beetapeo_autosave_name[strlen(beetapeo_autosave_name)+2] = '\0';
                    beetapeo_autosave_name[strlen(beetapeo_autosave_name)+1] = beetapeo_filetype;
                    beetapeo_autosave_name[strlen(beetapeo_autosave_name)]   = '.';

                    /*
                       Save header data in filename beetapeo_autosave_name
                       cat with .mtd (microbee tape data).
                    */

                    strcpy(beetapeo_file_tapedest,beetapeo_autosave_dir);
                    strcat(beetapeo_file_tapedest,beetapeo_filename);
                    strcat(beetapeo_file_tapedest,".mtd");

                    if ( NULL != ( beetapeo_mtd_fp = fopen(beetapeo_file_tapedest,"wt") ) )
                    {
                        fprintf(beetapeo_mtd_fp,"Savename    = %s\n",beetapeo_autosave_name);
                        fprintf(beetapeo_mtd_fp,"Filename    = %s\n",beetapeo_filename);
                        fprintf(beetapeo_mtd_fp,"Filetype    = %c\n",(char) beetapeo_filetype);
                        fprintf(beetapeo_mtd_fp,"Filesize    = %04x\n",(int) beetapeo_filesize);
                        fprintf(beetapeo_mtd_fp,"Load_addr   = %04x\n",(int) beetapeo_fileload);
                        fprintf(beetapeo_mtd_fp,"Exec_addr   = %04x\n",(int) beetapeo_fileexec);
                        fprintf(beetapeo_mtd_fp,"File_speed  = %02x\n",(int) beetapeo_fileauto);
                        fprintf(beetapeo_mtd_fp,"Exec_mode   = %02x\n",(int) beetapeo_fileauto);
                        fprintf(beetapeo_mtd_fp,"Checksum    = %02x\n",(int) beetapeo_byte);
                        fprintf(beetapeo_mtd_fp,"LocChecksum = %02x\n",(int) beetapeo_crc);

                        fclose(beetapeo_mtd_fp);
                    }

                    /*
                       Open file as stream.
                    */

                    strcpy(beetapeo_file_tapedest,beetapeo_autosave_dir);
                    strcat(beetapeo_file_tapedest,beetapeo_autosave_name);

                    if ( NULL == ( beetapeo_autosave_fp = fopen(beetapeo_file_tapedest,"wb") ) )
                    {
                        beetapeo_reset_state_after_file();
                    }
                }

                if ( beetapeo_filesize == 0 )
                {
                    if ( beetapeo_mode_autosave )
                    {
                        beetapeo_reset_state_after_file();
                    }
                }

                else
                {
                    beetapeo_crc = 0;

                    while ( beetapeo_filesize > 0x0ff )
                    {
                        beetapeo_filesize -= 0x0100;
                        beetapeo_hl_overall++;
                    }

                    beetapeo_hl_endit = beetapeo_filesize;

                    if ( beetapeo_hl_overall )
                    {
                        beetapeo_hl_length = 0x0ff;
                    }

                    else
                    {
                        beetapeo_hl_length = beetapeo_hl_endit-1;
                    }
                }

                break;
            }

            case 19:
            {
                /*
                   In the midst of a data block.  In beetapeo_hl_length is
                   zero then this is the last byte in the block, so need to
                   set the state appropriately.
                */

                beetapeo_crc = MASKEDADD8(beetapeo_byte,TAKETWOS(beetapeo_crc)) ^ 0x0ff;

                if ( beetapeo_hl_length == 0 )
                {
                    beetapeo_hl_state = 20;
                }

                else
                {
                    beetapeo_hl_length--;
                }

                if ( beetapeo_mode_autosave )
                {
                    if ( fputc(beetapeo_byte,beetapeo_autosave_fp) != beetapeo_byte )
                    {
                        beetapeo_reset_state_after_file();
                    }
                }

                else
                {
                    switch ( beetapeo_mode )
                    {
                        case 1:
                        {
                            if ( fputc(beetapeo_byte,beetapeo_dest_fp) != beetapeo_byte )
                            {
                                beetapeo_reset_state_after_stream();
                            }

                            break;
                        }

                        case 2:
                        case 3:
                        {
                            break;
                        }

                        default:
                        {
                            /*
                               State unknown, something badly wrong.
                            */

                            beetapeo_reset_state();

                            break;
                        }
                    }
                }

                break;
            }

            case 20:
            {
                /*
                   This is the checksum/crc byte for the most recent block.
                */

                if ( beetapeo_hl_overall )
                {
                    beetapeo_hl_overall--;

                    beetapeo_crc = 0;

                    if ( beetapeo_hl_overall )
                    {
                        beetapeo_hl_length = 0x0ff;
                    }

                    else
                    {
                        beetapeo_hl_length = beetapeo_hl_endit-1;
                    }

                    beetapeo_hl_state = 19;
                }

                else
                {
                    beetapeo_reset_state_after_block();

                    if ( beetapeo_mode_autosave )
                    {
                        beetapeo_reset_state_after_file();
                    }
                }

                break;
            }

            default:
            {
                /*
                   State unknown, something badly wrong.
                */

                beetapeo_reset_state();

                break;
            }
        }
    }

    return;
}

void beetape_state_change(void)
{
    if ( beetapeo_state_fine != (*beetapeo_bus) )
    {
        /*
           The state of the output bit has changed, so action is required.
        */

        beetapeo_state_fine = (*beetapeo_bus);

        switch ( beetapeo_state_course )
        {
            case 0:
            {
                /*
                   Need to detect type and baud rate.  All signals should
                   start with a sequence of either 00's or FF's.  For a
                   data-stream, frequencies will be:

                   1200Hz boundary bit
                   2400Hz data bit    +
                   2400Hz data bit    |
                   2400Hz data bit    |
                   2400Hz data bit    | Data FF
                   2400Hz data bit    |
                   2400Hz data bit    |
                   2400Hz data bit    |
                   2400Hz data bit    +
                   2400Hz stop bit
                   2400Hz stop bit

                   Similarly, for a save operation:

                   1200Hz boundary bit
                   1200Hz data bit    +
                   1200Hz data bit    |
                   1200Hz data bit    |
                   1200Hz data bit    | Data 00
                   1200Hz data bit    |
                   1200Hz data bit    |
                   1200Hz data bit    |
                   1200Hz data bit    +
                   2400Hz stop bit
                   2400Hz stop bit

                   The point is, the number of cycles at 1200Hz at the
                   start of the stream will tell us everything we need to
                   know about the speed and type of the data.  The counts
                   are as follows:

                   4  cycles at 1200Hz => 300  baud data stream
                   1  cycle  at 1200Hz => 1200 baud data stream
                   36 cycles at 1200Hz => save operation (speed unknown)

                   Detect stuff by checking the count on the first 
                   2400Hz cycle.
                */

                if ( beetapeo_state_fine )
                {
                    /*
                       Just had a low->high transition
                    */

                    if ( beetapeo_kansascycle )
                    {
                        if ( ( beetapeo_elapsed_zclk >= beetape_lower[0] ) &&
                             ( beetapeo_elapsed_zclk <= beetape_upper[0] )    )
                        {
                            /*
                               1200Hz cycle detected.

                               NB: The use of "200" in the following is
                                   essentially arbitrary.  Now, the signal
                                   will always start at 1200Hz, then go to
                                   2400Hz (either during data transmission
                                   or when the stop bit is reached), and
                                   then return to 1200Hz at some point.
                                   For the first byte, this will happen
                                   precisely once...
                                   So, beetape_kansascycle counts 1200Hz
                                   cycles starting from 0.  If the count
                                   exceeds 36 then the 1200Hz preamble has
                                   bee impossibly wrong.  Normally, though,
                                   a 2400Hz signal will intervene.  When it
                                   does, beetapeo_kansascycle is incremented
                                   by 200.  When the 2400Hz component finally
                                   ends, we can detect that this is a return
                                   to 1200Hz (and not the initial burst) by
                                   looking to see if beetapeo_kansascycle
                                   is greater than 200.
                            */

                            beetapeo_kansascycle++;

                            if ( beetapeo_kansascycle > 200 )
                            {
                                /*
                                   This is a return to 0, so is (presumably)
                                   the first stop bit of the next byte.  Set
                                   various stuff, and jump straight to the
                                   next state (sorry goto haters, but I can't
                                   be buggered making this "pretty").
                                */

                                if ( beetapeo_type )
                                {
                                    /*
                                       save type
                                    */

                                    beetapeo_state_course = 1;

                                    beetapeo_tapefreq    = 0;
                                    beetapeo_kansascycle = 0;

                                    goto state_1_jumpstart;
                                }

                                else
                                {
                                    /*
                                       stream type
                                    */

                                    beetapeo_state_course = 1;

                                    beetapeo_tapefreq    = 0;
                                    beetapeo_kansascycle = 0;

                                    goto state_1_jumpstart;
                                }
                            }

                            /*
                               Strictly, 36 should be used here.  However,
                               this screws up secondary save operations, so
                               some leeway is required.
                            */

                            else if ( beetapeo_kansascycle > 36 )
                            {
                                /*
                                   1200Hz preamble too long, something is
                                   severely borked.
                                */

                                beetapeo_reset_state();
                            }
                        }

                        else if ( ( beetapeo_elapsed_zclk >= beetape_lower[1] ) &&
                                  ( beetapeo_elapsed_zclk <= beetape_upper[1] )    )
                        {
                            /*
                               2400Hz cycle detected
                            */

                            beetapeo_kansascycle++;

                            if ( beetapeo_kansascycle < 200 )
                            {
                                /*
                                   This is the first 2400Hz cycle, and so the
                                   cycle count should tell us the type and
                                   also baud rate for a stream operation.
                                */

                                beetapeo_kansascycle += 200;

                                if ( beetapeo_kansascycle == (201+beetape_count[1][0]) )
                                {
                                    /*
                                       1200baud stream of data
                                    */

                                    beetapeo_baud = 1;
                                    beetapeo_type = 0;
                                }

                                else if ( beetapeo_kansascycle == (201+beetape_count[0][0]) )
                                {
                                    /*
                                       300baud stream of data
                                    */

                                    beetapeo_baud = 0;
                                    beetapeo_type = 0;
                                }

                                else if ( beetapeo_kansascycle == (201+(9*beetape_count[0][0])) )
                                {
                                    /*
                                       save (speed unknown), but always 
                                       begins with a 300baud header.
                                    */

                                    beetapeo_baud = 0;
                                    beetapeo_type = 1;
                                }

                                else
                                {
                                    /*
                                       Cycle count not recognised, things
                                       rather fucked up.
                                    */

                                    beetapeo_reset_state();
                                }
                            }
                        }

                        else
                        {
                            /*
                               The 1/2 cycle length is outside the acceptable
                               range - things are fucked up.
                            */

                            beetapeo_reset_state();
                        }
                    }

                    else
                    {
                        beetapeo_kansascycle = 1;
                    }
                }

                break;
            }

            case 1:
            {
                /*
                   This is the first boundary bit
                */

                if ( beetapeo_state_fine )
                {
                    state_1_jumpstart:

                    /*
                       Just had a low->high transition
                    */

                    /*
                       Check the frequency - it should be 1200Hz
                    */

                    if ( beetapeo_kansascycle && ( ( beetapeo_elapsed_zclk < beetape_lower[0] ) ||
                                                   ( beetapeo_elapsed_zclk > beetape_upper[0] )    ) )
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }

                    /*
                       The cycle check is here for the 1200baud case, where
                       we need to skip the first one (which will fail this
                       test) as it may lead to confusion.
                    */

                    else if ( ( beetapeo_elapsed_zclk >= beetape_lower[0] ) ||
                              ( beetapeo_elapsed_zclk <= beetape_upper[0] )    )
                    {
                        beetapeo_kansascycle++;

                        if ( beetapeo_kansascycle >= beetape_count[beetapeo_baud][0] )
                        {
                            /*
                               The boundary bit has now finished, so move
                               on to the first data bit.
                            */

                            beetapeo_state_course++;

                            beetapeo_byte         = 0;
                            beetapeo_tapefreq     = 0;
                            beetapeo_kansascycle  = 0;
                        }
                    }
                }

                else
                {
                    /*
                       Just had a high->low transition
                    */

                    /*
                       Check the frequency - it should be 1200Hz
                    */

                    if ( ( beetapeo_elapsed_zclk < beetape_lower[0] ) ||
                         ( beetapeo_elapsed_zclk > beetape_upper[0] )    )
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }
                }

                break;
            }

            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            {
                /*
                   This is a data bit
                */

                if ( beetapeo_state_fine )
                {
                    /*
                       Just had a low->high transition
                    */

                    /*
                       Check the frequency
                    */

                    if ( ( beetapeo_elapsed_zclk < beetape_lower[beetapeo_tapefreq] ) ||
                         ( beetapeo_elapsed_zclk > beetape_upper[beetapeo_tapefreq] )    )
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }

                    else
                    {
                        beetapeo_kansascycle++;

                        if ( beetapeo_kansascycle >= beetape_count[beetapeo_baud][beetapeo_tapefreq] )
                        {
                            /*
                               The bit has finished.

                               1. Record the bit value.
                               2. Increment the state.
                            */

                            if ( beetapeo_tapefreq )
                            {
                                /*
                                   2400Hz is 1, so set relevant bit
                                */

                                beetapeo_byte |= ( 1 << (beetapeo_state_course-2) );
                            }

                            beetapeo_state_course++;

                            beetapeo_tapefreq    = 0;
                            beetapeo_kansascycle = 0;
                        }
                    }
                }

                else if ( beetapeo_kansascycle )
                {
                    /*
                       Just had a high->low transition, but not the first.
                    */

                    if ( ( beetapeo_elapsed_zclk < beetape_lower[beetapeo_tapefreq] ) ||
                         ( beetapeo_elapsed_zclk > beetape_upper[beetapeo_tapefreq] )    )
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }
                }

                else
                {
                    /*
                       The first low cycle just finished.  From this we
                       should be able to calculate the frequency of the
                       signal.
                    */

                    if ( ( beetapeo_elapsed_zclk >= beetape_lower[0] ) &&
                         ( beetapeo_elapsed_zclk <= beetape_upper[0] )    )
                    {
                        beetapeo_tapefreq = 0;
                    }

                    else if ( ( beetapeo_elapsed_zclk >= beetape_lower[1] ) &&
                              ( beetapeo_elapsed_zclk <= beetape_upper[1] )    )
                    {
                        beetapeo_tapefreq = 1;
                    }

                    else
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }
                }

                break;
            }

            case 10:
            case 11:
            {
                /*
                   This is a stop bit
                */

                if ( beetapeo_state_fine )
                {
                    /*
                       Just had a low->high transition
                    */

                    /*
                       Check the frequency - it should be 2400Hz
                    */

                    if ( ( beetapeo_elapsed_zclk < beetape_lower[1] ) ||
                         ( beetapeo_elapsed_zclk > beetape_upper[1] )    )
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }

                    else
                    {
                        beetapeo_kansascycle++;

                        if ( beetapeo_kansascycle >= beetape_count[beetapeo_baud][1] )
                        {
                            /*
                               The stop bit has now finished, so increment
                               the state.
                            */

                            beetapeo_state_course++;

                            beetapeo_tapefreq     = 0;
                            beetapeo_kansascycle  = 0;

                            if ( beetapeo_state_course == 12 )
                            {
                                beetapeo_send_byte();

                                beetapeo_state_course = 1;
                            }
                        }
                    }
                }

                else
                {
                    /*
                       Just had a high->low transition
                    */

                    /*
                       Check the frequency - it should be 2400Hz
                    */

                    if ( ( beetapeo_elapsed_zclk < beetape_lower[1] ) ||
                         ( beetapeo_elapsed_zclk > beetape_upper[1] )    )
                    {
                        /*
                           The 1/2 cycle length is outside the acceptable
                           range - things are fucked up.
                        */

                        beetapeo_reset_state();
                    }
                }

                break;
            }

            default:
            {
                /*
                   State unknown, something badly wrong.
                */

                beetapeo_reset_state();

                break;
            }
        }

        beetapeo_elapsed_zclk = 0;
    }

    return;
}

inline void beetapeo_cycle(void)
{
    /*
       If timeout then reset state
    */

    if ( beetapeo_elapsed_zclk > BEETAPE_TIMEOUT_POINT )
    {
        beetapeo_elapsed_zclk = BEETAPE_TIMEOUT_PUSH;

        beetapeo_reset_state_after_block();

        if ( beetapeo_mode_autosave )
        {
            beetapeo_reset_state_after_file();
        }
    }

    return;
}

int beetapeo_set_mode_1(char *filename)
{
    beetapeo_close_output_stream();

    beetapeo_dest_fp = fopen(filename,"wb");

    if ( beetapeo_dest_fp == NULL )
    {
        BEETAPEO_SET_DEFAULT_MODE;

        return 1;
    }

    beetapeo_mode = 1;

    return 0;
}

int beetapeo_set_mode_2(char *filename)
{
    beetapeo_close_output_stream();

    BEETAPEO_SET_DEFAULT_MODE;

    return 1;

    filename++;
}

int beetapeo_set_mode_3(void)
{
    beetapeo_close_output_stream();

    beetapeo_mode = 3;

    return 0;
}

void beetapeo_close_output_stream(void)
{
    if ( beetapeo_dest_fp != NULL )
    {
        fclose(beetapeo_dest_fp);
    }

    beetapeo_dest_fp = NULL;

    return;
}

void beetapeo_close_autosave_file(void)
{
    if ( beetapeo_autosave_fp != NULL )
    {
        fclose(beetapeo_autosave_fp);
    }

    beetapeo_autosave_fp = NULL;

    return;
}

int beetapeo_set_tape_1(void)
{
    FILE *tempfp;

    if ( file_select_ex("Tape Port Destination File",beetapeo_file_tapedest,NULL,300,0,0) )
    {
        if ( ( tempfp = fopen(beetapeo_file_tapedest,"rt") ) != NULL )
        {
            fclose(tempfp);

            if ( alert("File already exists.","Overwrite anyhow?","","&OK","&Cancel",'o','c') == 2 )
            {
                BEETAPEO_SET_DEFAULT_MODE;

                goto exit_point;
            }
        }

        if ( beetapeo_set_mode_1(beetapeo_file_tapedest) )
        {
            alert("Error:","Couldn't open file.","Reverting to unconnected.","&OK",NULL,'o',0);
        }
    }

    exit_point:

    beetape_update_menu_marks();

    return D_O_K;
}

int beetapeo_set_tape_2(void)
{
    FILE *tempfp;

    if ( file_select_ex("Tape Port Destination WAV File",beetapeo_file_tapedest,NULL,300,0,0) )
    {
        if ( ( tempfp = fopen(beetapeo_file_tapedest,"rt") ) != NULL )
        {
            fclose(tempfp);

            if ( alert("File already exists.","Overwrite anyhow?","","&OK","&Cancel",'o','c') == 2 )
            {
                BEETAPEO_SET_DEFAULT_MODE;

                goto exit_point;
            }
        }

        if ( beetapeo_set_mode_2(beetapeo_file_tapedest) )
        {
            alert("Error:","Couldn't open file.","Reverting to unconnected.","&OK",NULL,'o',0);
        }
    }

    exit_point:

    beetape_update_menu_marks();

    return D_O_K;
}

int beetapeo_set_tape_3(void)
{
    if ( beetapeo_set_mode_3() )
    {
        alert("Error:","WOW - an impossible error!","Let's do that again!","&OK",NULL,'o',0);
    }

    beetape_update_menu_marks();

    return D_O_K;
}

int beetape_set_autosave_on(void)
{
    beetapeo_mode_autosave = 1;

    beetape_update_menu_marks();

    return D_O_K;
}

int beetape_set_autosave_off(void)
{
    beetapeo_mode_autosave = 0;

    beetape_update_menu_marks();

    return D_O_K;
}

int beetape_set_savedir(void)
{
    if ( file_select_ex("Tape Port Destination Directory",beetapeo_autosave_dir,"/d",300,0,0) )
    {
        strcpy(beetapeo_autosave_dir,"./");
    }

    if ( beetapeo_autosave_dir[strlen(beetapeo_autosave_dir)-1] != '/' )
    {
        beetapeo_autosave_dir[strlen(beetapeo_autosave_dir)+1] = '\0';
        beetapeo_autosave_dir[strlen(beetapeo_autosave_dir)]   = '/';
    }

    return D_O_K;
}













/*
   Variables and Control - input
   =============================

   beetapei_type:          0  = nothing happening
                           1  = currently writing from datafile
   beetapei_buffer:        p  = pointer to buffer (dword buffer).
   beetapei_pos_byte:      #  = buffer dword being processed (0 start).
   beetapei_pos_bit:       #  = bit in byte (32 bit mask, not count).
   beetapei_pos_bitcnt:    #  = bit position in buffer
   beetapei_spedchgbitcht: #  = position at which we change from 300 to
                                1200 baud (used by load function).
   beetapei_bufsize:       #  = size of tape buffer (in bits).
   beetapei_tapesped:      0  = 300 baud
                           1  = 1200 baud
   beetapei_state_fine:    0  = signal level low
                           1  = signal level high
   beetapei_bit_fine:      0  = bit is 0 (1200Hz)
                           1  = bit is 1 (2400Hz)
   beetapei_crc:           b  = used to calculate the crc
   beetapei_kansascycle:   #  = elapsed cycles (at 1200 or 2400Hz)
   beetapei_elapsed_zclk:  #  = elapsed z80 cycles since last edge
*/

char beetapei_file_tapedest[1800];

int      beetapei_type;
UINT_32 *beetapei_buffer;
UINT_32  beetapei_pos_byte;
UINT_32  beetapei_pos_bit;
UINT_32  beetapei_pos_bitcnt;
UINT_32  beetapei_spedchgbitcht;
UINT_32  beetapei_bufsize;
int      beetapei_tapesped;
int      beetapei_state_fine;
int      beetapei_bit_fine;
UINT_8   beetapei_crc;
UINT_32  beetapei_kansascycle;
UINT_32  beetapei_elapsed_zclk;

void beetapei_reset_state(void);
int beetapei_pipe_data(void);
int beetapei_pipe_wav(void);
int beetapei_load_data(void);
int beetapei_load_mtd(void);
int beetapei_stopload(void);
void beetapei_convert_to_memload(UINT_8 head_ft, UINT_8 head_fsl, UINT_8 head_fsh, UINT_8 head_lal, UINT_8 head_lah, UINT_8 head_ael, UINT_8 head_aeh, UINT_8 head_sp, UINT_8 head_ac, UINT_8 head_nu, char *yfilename, UINT_32 filesize, FILE *beetapei_src__fp);
void beetapei_putbyteinbuff(UINT_8 what);
inline void beetapei_cycle(void);

void beetapei_reset_state(void)
{
    if ( beetapei_buffer != NULL )
    {
        DEBFREE(beetapei_buffer);
    }

    beetapei_type          = 0;
    beetapei_buffer        = NULL;
    beetapei_pos_byte      = 0;
    beetapei_pos_bit       = 0x000000001;
    beetapei_pos_bitcnt    = 0;
    beetapei_spedchgbitcht = 0x0ffffffff;
    beetapei_bufsize       = 0;
    beetapei_tapesped      = 0;
    beetapei_state_fine    = 0;
    beetapei_bit_fine      = 0;
    beetapei_crc           = 0;
    beetapei_kansascycle   = 0;
    beetapei_elapsed_zclk  = 0;

    beetape_update_menu_marks();

    return;
}

#define BEETAPEI_PUTBITINBUFF(what)                                     \
{                                                                       \
    beetapei_buffer[beetapei_pos_byte] &= ( 0x0ffffffff ^ beetapei_pos_bit ); \
                                                                        \
    if ( what )                                                         \
    {                                                                   \
        beetapei_buffer[beetapei_pos_byte] |= beetapei_pos_bit;         \
    }                                                                   \
                                                                        \
    if ( beetapei_pos_bit != 0x080000000 )                              \
    {                                                                   \
        beetapei_pos_bit <<= 1;                                         \
    }                                                                   \
                                                                        \
    else                                                                \
    {                                                                   \
        beetapei_pos_bit = 0x000000001;                                 \
        beetapei_pos_byte++;                                            \
    }                                                                   \
                                                                        \
    beetapei_pos_bitcnt++;                                              \
}

#define BEETAPEI_GETBITFROMBUFF(what)                                   \
{                                                                       \
    what = 0;                                                           \
                                                                        \
    if ( beetapei_buffer[beetapei_pos_byte] & beetapei_pos_bit )        \
    {                                                                   \
        what = 1;                                                       \
    }                                                                   \
                                                                        \
    if ( beetapei_pos_bit != 0x080000000 )                              \
    {                                                                   \
        beetapei_pos_bit <<= 1;                                         \
    }                                                                   \
                                                                        \
    else                                                                \
    {                                                                   \
        beetapei_pos_bit = 0x000000001;                                 \
        beetapei_pos_byte++;                                            \
    }                                                                   \
                                                                        \
    beetapei_pos_bitcnt++;                                              \
}

void beetapei_putbyteinbuff(UINT_8 what)
{
    BEETAPEI_PUTBITINBUFF(0);
    BEETAPEI_PUTBITINBUFF(what & 0x001);
    BEETAPEI_PUTBITINBUFF(what & 0x002);
    BEETAPEI_PUTBITINBUFF(what & 0x004);
    BEETAPEI_PUTBITINBUFF(what & 0x008);
    BEETAPEI_PUTBITINBUFF(what & 0x010);
    BEETAPEI_PUTBITINBUFF(what & 0x020);
    BEETAPEI_PUTBITINBUFF(what & 0x040);
    BEETAPEI_PUTBITINBUFF(what & 0x080);
    BEETAPEI_PUTBITINBUFF(1);
    BEETAPEI_PUTBITINBUFF(1);

    return;
}

inline void beetapei_cycle(void)
{
    if ( beetapei_type && ( beetapei_elapsed_zclk >= beetape_lower[1] ) )
    {
        if ( beetapei_kansascycle == 0 )
        {
            beetapei_elapsed_zclk = 0;

            /*
               0 is used to signify that the process has just started (this
               is needed to make cycles HL, not LH).  Thus we need to set
               the bit to 1 to get things started.
            */

            (*beetapei_bus) = 1;
            (beetapei_strober)();
            beetapei_state_fine = 1;

            beetapei_kansascycle = 1;

            /*
               Get bit from the bit buffer.
            */

            BEETAPEI_GETBITFROMBUFF(beetapei_bit_fine);
        }

        else
        {
            if ( beetapei_elapsed_zclk >= beetape_cycles[beetapei_bit_fine][beetapei_state_fine] )
            {
                /*
                   OK, current cycle done.
                */

                beetapei_elapsed_zclk -= beetape_cycles[beetapei_bit_fine][beetapei_state_fine];

                /*
                   Invert the state, and update the cycle counter if this
                   was a low->high transition.
                */

                if ( beetapei_state_fine )
                {
                    (*beetapei_bus) = 0;
                    (beetapei_strober)();
                    beetapei_state_fine = 0;
                }

                else
                {
                    (*beetapei_bus) = 1;
                    (beetapei_strober)();
                    beetapei_state_fine = 1;

                    beetapei_kansascycle++;
                }

                if ( beetapei_kansascycle > beetape_count[beetapei_tapesped][beetapei_bit_fine] )
                {
                    /*
                       Current bit is done, get the next one.
                    */

                    BEETAPEI_GETBITFROMBUFF(beetapei_bit_fine);

                    /*
                       Reset the counter (1 start deliberate)
                    */

                    beetapei_kansascycle = 1;

                    /*
                       Change to 1200baud if trigger hit
                    */

                    if ( beetapei_pos_bitcnt == beetapei_spedchgbitcht )
                    {
                        beetapei_tapesped = 1;
                    }
                }
            }
        }

        if ( beetapei_pos_bitcnt >= beetapei_bufsize )
        {
            /*
               This will actually cut the final stop bit off the final
               transmitted byte.  That's why the buffer is always padded
               with a NULL at the end, so only the (unimportant) NULL
               character is affected.
            */

            (*beetapei_bus) = 0;
            (beetapei_strober)();
            beetapei_state_fine = 0;

            beetapei_reset_state();
        }
    }

    return;
}

int beetapei_pipe_data(void)
{
    UINT_32 filesize;
    UINT_32 filesizewithblocks;
    UINT_32 i;
    UINT_32 currblocksize;
    UINT_8 fixblocksize;
    UINT_8 whatbyte;

    FILE *beetapei_src__fp;

    beetapei_reset_state();

    if ( file_select_ex("Source file",beetapei_file_tapedest,NULL,300,0,0) )
    {
        if ( ( beetapei_src__fp = fopen(beetapei_file_tapedest,"rb") ) == NULL )
        {
            alert("Error:","Couldn't open file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        /*
           Count the bytes in the file.
        */

        filesize = 0;

        while ( !feof(beetapei_src__fp) )
        {
            fgetc(beetapei_src__fp);

            filesize++;
        }

        fclose(beetapei_src__fp);

        if ( filesize <= 0 )
        {
            alert("Error:","No data in file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        if ( ( beetapei_src__fp = fopen(beetapei_file_tapedest,"rb") ) == NULL )
        {
            alert("Error:","Couldn't re-open file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        /*
           Add header size to filesize, so that filesize becomes the number
           of characters that will be passed.  42 is the size of the header
           block.
        */

        filesizewithblocks = filesize + (((filesize+0x000ff)/0x0100)*42);

        /*
           Calculate the number of bits required to pipe the file in.  This
           includes 1 boundary bit, 8 data bits and 2 stop bits, giving a
           total of 11 bits per byte to be passed in.

           NB: Include a final NULL, as the final byte will have it's last
               stop bit trimmed, hence want this to affect an irrelevant
               bit, not a relevant bit.
        */

        beetapei_bufsize = (filesizewithblocks+1)*11;

        /*
           Allocate the buffer.  The buffer is kept in blocks of 32 bits, so
           some adjustment is required.
        */

        if ( ( beetapei_buffer = (UINT_32 *) DEBMALLOC(((beetapei_bufsize+0x01f)/0x020)*sizeof(UINT_32)) ) == NULL )
        {
            alert("Error:","Out of memory.","","&OK",NULL,'o',0);

            fclose(beetapei_src__fp);

            return D_O_K;
        }

        /*
           Get pipe speed.
        */

        if ( alert("","Select speed.","","&300 baud","&1200 baud",'3','1') == 1 )
        {
            beetapei_tapesped = 0;
        }

        else
        {
            beetapei_tapesped = 1;
        }

        /*
           Now convert the file into the contents of the file buffer

           Basic block structure: ff   +
                                  ff   | 20 of these
                                  ...  |
                                  ff   +
                                  2a
                                  ll   - length (0 for 256 bytes)
                                  data
                                  crc  - crc byte.  Initialize crc = 0 and
                                         for each byte d in data do:
                                         crc := (crc XOR d) >> 1
                                  ff   +
                                  ff   | 17 of these
                                  ...  |
                                  ff   +
        */

        beetapei_pos_byte   = 0;
        beetapei_pos_bit    = 0x000000001;
        beetapei_pos_bitcnt = 0;

        while ( filesize > 0 )
        {
            beetapei_crc = 0;

            if ( filesize >= 0x00100 )
            {
                currblocksize = 0x0100;
            }

            else
            {
                currblocksize = filesize;
            }

            fixblocksize = ( currblocksize & 0x0ff );
            filesize -= currblocksize;

            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x02a);
            beetapei_putbyteinbuff(fixblocksize);

            for ( i = 1 ; i <= currblocksize ; i++ )
            {
                beetapei_putbyteinbuff(whatbyte = fgetc(beetapei_src__fp));

                beetapei_crc ^= whatbyte;

                if ( beetapei_crc & 0x001 )
                {
                    beetapei_crc = ( ( beetapei_crc >> 0x001 ) & 0x07f ) | 0x080;
                }

                else
                {
                    beetapei_crc =   ( beetapei_crc >> 0x001 ) & 0x07f;
                }
            }

            beetapei_putbyteinbuff(beetapei_crc);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
            beetapei_putbyteinbuff(0x0ff);
        }

        /*
           Put final NULL into the buffer.
        */

        beetapei_putbyteinbuff(0x000);

        /*
           Set control data.
        */

        beetapei_type         = 1;
        beetapei_pos_byte     = 0;
        beetapei_pos_bit      = 0x000000001;
        beetapei_pos_bitcnt   = 0;
        beetapei_state_fine   = 0;
        beetapei_bit_fine     = 0;
        beetapei_crc          = 0;
        beetapei_kansascycle  = 0;
        beetapei_elapsed_zclk = 0;

        fclose(beetapei_src__fp);

        /*
           Put speedchange bit out of bounds
        */

        beetapei_spedchgbitcht = 0x0ffffffff;
    }

    beetape_update_menu_marks();

    return D_O_K;
}

DIALOG beetape_detail_dialog[] =
{
    /* (dialog proc)     (x)  (y)  (w)  (h)  (fg)        (bg)     (key) (f)  (d1)(d2)(dp) */

    { d_shadow_box_proc, 50,  75,  450, 300, MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, NULL,                      NULL, NULL },
    { d_button_proc,     100, 310, 150, 40,  MENU_WHITE, MENU_BLACK, 0, D_EXIT,0, 0, "OK",                      NULL, NULL },
    { d_button_proc,     300, 310, 150, 40,  MENU_WHITE, MENU_BLACK, 0, D_EXIT,0, 0, "Cancel",                  NULL, NULL },
    { d_ctext_proc,      250, 100, 400, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Tape Header Details.",    NULL, NULL },
    { d_text_proc,       100, 130, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Filetag:",                NULL, NULL },
    { d_text_proc,       100, 160, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Filetype:",               NULL, NULL },
    { d_text_proc,       100, 190, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Load address:",           NULL, NULL },
    { d_text_proc,       100, 220, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, "Execute address:",        NULL, NULL },
    { d_edit_proc,       300, 130, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     6, 1, NULL,                      NULL, NULL },
    { d_edit_proc,       300, 160, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     1, 1, NULL,                      NULL, NULL },
    { d_edit_proc,       300, 190, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     7, 1, NULL,                      NULL, NULL },
    { d_edit_proc,       300, 220, 150, 40,  MENU_WHITE, MENU_BLACK, 0, 0,     7, 1, NULL,                      NULL, NULL },
    { d_check_proc,      100, 250, 300, 15,  MENU_WHITE, MENU_BLACK, 0, 0,     1, 0, " Fast load (1200 baud).", NULL, NULL },
    { d_check_proc,      100, 280, 300, 15,  MENU_WHITE, MENU_BLACK, 0, 0,     1, 0, " Autexecute mode.",       NULL, NULL },
    { d_yield_proc,      0,   0,   0,   0,   MENU_WHITE, MENU_BLACK, 0, 0,     0, 0, NULL,                      NULL, NULL },
    { NULL,              0,   0,   0,   0,   0,          0,          0, 0,     0, 0, NULL,                      NULL, NULL }
};

int beetapei_load_data(void)
{
    UINT_32 filesize;
    char *xfilename;
    char *yfilename;
    int hasguessext;

    int head_la;
    int head_ae;
    char str_head_la[16] = "0x00100";
    char str_head_ae[16] = "0x00100";
    char str_head_ft[16] = "M";

    UINT_8 head_ft;
    UINT_8 head_fsl;
    UINT_8 head_fsh;
    UINT_8 head_lal;
    UINT_8 head_lah;
    UINT_8 head_ael;
    UINT_8 head_aeh;
    UINT_8 head_sp;
    UINT_8 head_ac;
    UINT_8 head_nu;

    FILE *beetapei_src__fp;

    beetapei_reset_state();

    if ( file_select_ex("Source file",beetapei_file_tapedest,NULL,300,0,0) )
    {
        if ( ( beetapei_src__fp = fopen(beetapei_file_tapedest,"rb") ) == NULL )
        {
            alert("Error:","Couldn't open file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        /*
           Count the bytes in the file.
        */

        filesize = 0;

        while ( !feof(beetapei_src__fp) )
        {
            fgetc(beetapei_src__fp);

            filesize++;
        }

        fclose(beetapei_src__fp);

        if ( filesize <= 0 )
        {
            alert("Error:","No data in file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        if ( ( beetapei_src__fp = fopen(beetapei_file_tapedest,"rb") ) == NULL )
        {
            alert("Error:","Couldn't re-open file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        /*
           Filename (size characters)
        */

        yfilename = get_filename(beetapei_file_tapedest);

        /*
           Try to guess the type, and relevant header info
        */

        hasguessext = 0;

        xfilename = get_extension(beetapei_file_tapedest);

        if ( strlen(xfilename) == 3 )
        {
            if ( ( ( xfilename[0] == 'm' ) || ( xfilename[0] == 'M' ) ) &&
                 ( ( xfilename[1] == 'w' ) || ( xfilename[1] == 'W' ) ) &&
                 ( ( xfilename[2] == 'b' ) || ( xfilename[2] == 'B' ) )    )
            {
                hasguessext = 1;
            }

            if ( ( ( xfilename[0] == 'c' ) || ( xfilename[0] == 'C' ) ) &&
                 ( ( xfilename[1] == 'o' ) || ( xfilename[1] == 'O' ) ) &&
                 ( ( xfilename[2] == 'm' ) || ( xfilename[2] == 'M' ) )    )
            {
                hasguessext = 2;
            }

            if ( ( ( xfilename[0] == 'c' ) || ( xfilename[0] == 'C' ) ) &&
                 ( ( xfilename[1] == 'p' ) || ( xfilename[1] == 'P' ) ) &&
                 ( ( xfilename[2] == 'm' ) || ( xfilename[2] == 'M' ) )    )
            {
                hasguessext = 2;
            }
        }

        else if ( strlen(xfilename) == 1 )
        {
            if ( ( xfilename[0] == 'B' ) || ( xfilename[0] == 'b' ) )
            {
                hasguessext = 1;
            }

            else if ( ( xfilename[0] == 'M' ) || ( xfilename[0] == 'm' ) )
            {
                hasguessext = 2;
            }
        }

        /*
           Trim the filename.
        */

        if ( strlen(yfilename) > 6 )
        {
            yfilename[6] = '\0';
        }

        switch ( hasguessext )
        {
            case 1:
            {
                /*
                   Use default MWB header
                */

                head_ft  = 'B';
                head_fsl = filesize & 0x0ff;
                head_fsh = ( filesize >> 8 ) & 0x0ff;
                head_lal = 0x0c0;
                head_lah = 0x008;
                head_ael = 0x000;
                head_aeh = 0x000;
                head_sp  = 0x001;
                head_ac  = 0x000;
                head_nu  = 0x000;

                head_la = 0x008c0;
                head_ae = 0x00000;

                if ( alert("File appears to be MWB format.","Use automatic header?","","&Yes","&No",'y','n') == 2 )
                {
                    goto unknown_type;
                }

                /*
                   Get load speed.
                */

                if ( alert("","Select speed.","","&300 baud","&1200 baud",'3','1') == 1 )
                {
                    head_sp = 0;
                }

                else
                {
                    head_sp = 1;
                }

                break;
            }

            case 2:
            {
                /*
                   Use default COM header
                */

                head_ft  = 'M';
                head_fsl = filesize & 0x0ff;
                head_fsh = ( filesize >> 8 ) & 0x0ff;
                head_lal = 0x000;
                head_lah = 0x001;
                head_ael = 0x000;
                head_aeh = 0x001;
                head_sp  = 0x001;
                head_ac  = 0x0ff;
                head_nu  = 0x000;

                head_la = 0x00100;
                head_ae = 0x00100;

                if ( alert("File appears to be COM format.","Use automatic header?","","&Yes","&No",'y','n') == 2 )
                {
                    goto unknown_type;
                }

                /*
                   Get load speed.
                */

                if ( alert("","Select speed.","","&300 baud","&1200 baud",'3','1') == 1 )
                {
                    head_sp = 0;
                }

                else
                {
                    head_sp = 1;
                }

                break;
            }

            default:
            {
                /*
                   Type unknown: By default, treat as a COM file
                */

                head_ft  = 'M';
                head_fsl = filesize & 0x0ff;
                head_fsh = ( filesize >> 8 ) & 0x0ff;
                head_lal = 0x000;
                head_lah = 0x001;
                head_ael = 0x000;
                head_aeh = 0x001;
                head_sp  = 0x001;
                head_ac  = 0x0ff;
                head_nu  = 0x000;

                head_la = 0x00100;
                head_ae = 0x00100;

                unknown_type:

                if ( head_sp )
                {
                    (beetape_detail_dialog[12]).flags = D_SELECTED;
                }

                else
                {
                    (beetape_detail_dialog[12]).flags = 0;
                }

                if ( head_ac )
                {
                    (beetape_detail_dialog[13]).flags = D_SELECTED;
                }

                else
                {
                    (beetape_detail_dialog[13]).flags = 0;
                }

                str_head_la[0] = '0';
                str_head_la[1] = 'x';
                str_head_la[2] = '0';
                str_head_la[3] = ( ( head_la >> 12 ) & 0x00f ) + '0'; if ( str_head_la[3] > '9' ) { str_head_la[3] += ('a'-10-'0'); }
                str_head_la[4] = ( ( head_la >>  8 ) & 0x00f ) + '0'; if ( str_head_la[4] > '9' ) { str_head_la[4] += ('a'-10-'0'); }
                str_head_la[5] = ( ( head_la >>  4 ) & 0x00f ) + '0'; if ( str_head_la[5] > '9' ) { str_head_la[5] += ('a'-10-'0'); }
                str_head_la[6] = (   head_la         & 0x00f ) + '0'; if ( str_head_la[6] > '9' ) { str_head_la[6] += ('a'-10-'0'); }
                str_head_la[7] = '\0';

                str_head_ae[0] = '0';
                str_head_ae[1] = 'x';
                str_head_ae[2] = '0';
                str_head_ae[3] = ( ( head_ae >> 12 ) & 0x00f ) + '0'; if ( str_head_ae[3] > '9' ) { str_head_ae[3] += ('a'-10-'0'); }
                str_head_ae[4] = ( ( head_ae >>  8 ) & 0x00f ) + '0'; if ( str_head_ae[4] > '9' ) { str_head_ae[4] += ('a'-10-'0'); }
                str_head_ae[5] = ( ( head_ae >>  4 ) & 0x00f ) + '0'; if ( str_head_ae[5] > '9' ) { str_head_ae[5] += ('a'-10-'0'); }
                str_head_ae[6] = (   head_ae         & 0x00f ) + '0'; if ( str_head_ae[6] > '9' ) { str_head_ae[6] += ('a'-10-'0'); }
                str_head_ae[7] = '\0';

                str_head_ft[0] = head_ft;
                str_head_ft[1] = '\0';

                (beetape_detail_dialog[8]).dp  = yfilename;
                (beetape_detail_dialog[9]).dp  = str_head_ft;
                (beetape_detail_dialog[10]).dp = str_head_la;
                (beetape_detail_dialog[11]).dp = str_head_ae;

                if ( popup_dialog(beetape_detail_dialog,1) == 1 )
                {
                    sscanf(str_head_la,"%i",&head_la);
                    sscanf(str_head_ae,"%i",&head_ae);

                    head_ft = str_head_ft[0];

                    head_lal = (     head_la                    & 0x000ff );
                    head_lah = ( ( ( head_la & 0x0ff00 ) >> 8 ) & 0x000ff );

                    head_ael = (     head_ae                    & 0x000ff );
                    head_aeh = ( ( ( head_ae & 0x0ff00 ) >> 8 ) & 0x000ff );

                    head_fsl = (     filesize                    & 0x000ff );
                    head_fsh = ( ( ( filesize & 0x0ff00 ) >> 8 ) & 0x000ff );

                    if ( (beetape_detail_dialog[12]).flags & D_SELECTED )
                    {
                        head_sp = 0x001;
                    }

                    else
                    {
                        head_sp = 0x000;
                    }

                    if ( (beetape_detail_dialog[13]).flags & D_SELECTED )
                    {
                        head_ac = 0x0ff;
                    }

                    else
                    {
                        head_ac = 0x000;
                    }

                    head_nu = 0x000;
                }

                else
                {
                    fclose(beetapei_src__fp);

                    return D_O_K;
                }

                break;
            }
        }

        beetapei_convert_to_memload(head_ft,head_fsl,head_fsh,head_lal,head_lah,head_ael,head_aeh,head_sp,head_ac,head_nu,yfilename,filesize,beetapei_src__fp);

        fclose(beetapei_src__fp);
    }

    beetape_update_menu_marks();

    return D_O_K;
}


void beetapei_convert_to_memload(UINT_8 head_ft, UINT_8 head_fsl, UINT_8 head_fsh, UINT_8 head_lal, UINT_8 head_lah, UINT_8 head_ael, UINT_8 head_aeh, UINT_8 head_sp, UINT_8 head_ac, UINT_8 head_nu, char *yfilename, UINT_32 filesize, FILE *beetapei_src__fp)
{
    UINT_8  whatbyte;
    UINT_32 currblocksize;
    UINT_32 i;
    UINT_32 filesizewithblocks;

    /*
       Add header size to filesize, so that filesize becomes the number
       of characters that will be passed.  For loading, there are 82
       bytes in the "header" + 1 crc byte for each data block.
    */

    filesizewithblocks = filesize + 82 + ((filesize+0x000ff)/0x0100);

    /*
       Calculate the number of bits required to pipe the file in.  This
       includes 1 boundary bit, 8 data bits and 2 stop bits, giving a
       total of 11 bits per byte to be passed in.

       NB: Include a final NULL, as the final byte will have it's last
           stop bit trimmed, hence want this to affect an irrelevant
           bit, not a relevant bit.
    */

    beetapei_bufsize = (filesizewithblocks+1)*11;

    /*
       Allocate the buffer.  The buffer is kept in blocks of 32 bits, so
       some adjustment is required.
    */

    if ( ( beetapei_buffer = (UINT_32 *) DEBMALLOC(((beetapei_bufsize+0x01f)/0x020)*sizeof(UINT_32)) ) == NULL )
    {
        alert("Error:","Out of memory.","","&OK",NULL,'o',0);

        fclose(beetapei_src__fp);

        return;
    }

    /*
       Convert the file into the contents of the file buffer.
    */

    beetapei_tapesped   = 0;
    beetapei_pos_byte   = 0;
    beetapei_pos_bit    = 0x000000001;
    beetapei_pos_bitcnt = 0;

    /*
       First dump the header.
    */

    /*
       64 preceeding NULLs
    */

    for ( i = 1 ; i <= 64 ; i++ )
    {
        beetapei_putbyteinbuff(0x000);
    }

    /*
       SOH
    */

    beetapei_putbyteinbuff(0x001);

    beetapei_crc = 0;

    /*
       Dump the filename
    */

    for ( i = 1 ; i <= 6 ; i++ )
    {
        if ( strlen(yfilename) >= i )
        {
            whatbyte = yfilename[i-1];
        }

        else
        {
            whatbyte = 0x000;
        }

        beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
        beetapei_putbyteinbuff(whatbyte);
    }

    /*
       Dump the rest of the header.
    */

    whatbyte = head_ft;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_fsl;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_fsh;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_lal;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_lah;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_ael;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_aeh;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_sp;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_ac;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    whatbyte = head_nu;
    beetapei_crc = MASKEDADD8(beetapei_crc,whatbyte);
    beetapei_putbyteinbuff(whatbyte);

    /*
       checksum: 1. sum the lot from after SOH to nu
                 2. take the 2's complement.
                 3. Then the weird bit - if the solution so far is xy
                    in hex (eg. 6e means x=6, y=e) then subtract 1
                    from x, giving the checksum (x-1)y so, in the
                    above example, the checksum would be 5e.
    */

    beetapei_crc = TAKETWOS(beetapei_crc);
    beetapei_crc = ( ( ( beetapei_crc & 0x0f0 ) - 0x010 ) & 0x0f0 ) | ( beetapei_crc & 0x00f );
    beetapei_putbyteinbuff(beetapei_crc);

    /*
       If 1200baud, set speed change point
    */

    if ( head_sp )
    {
        beetapei_spedchgbitcht = beetapei_pos_bitcnt;
    }

    else
    {
        beetapei_spedchgbitcht = 0x0ffffffff;
    }

    /*
       Translate the body.
    */

    while ( filesize > 0 )
    {
        beetapei_crc = 0;

        if ( filesize >= 0x00100 )
        {
            currblocksize = 0x0100;
        }

        else
        {
            currblocksize = filesize;
        }

        filesize -= currblocksize;

        for ( i = 1 ; i <= currblocksize ; i++ )
        {
            beetapei_putbyteinbuff(whatbyte = fgetc(beetapei_src__fp));

            /*
               For each byte: crc := CPL(d-c)
            */

            beetapei_crc = MASKEDADD8(TAKETWOS(beetapei_crc),whatbyte) ^ 0x0ff;
        }

        beetapei_putbyteinbuff(beetapei_crc);
    }

    /*
       Put final NULL into the buffer.
    */

    beetapei_putbyteinbuff(0x000);

    /*
       Set control data.
    */

    beetapei_type         = 1;
    beetapei_pos_byte     = 0;
    beetapei_pos_bit      = 0x000000001;
    beetapei_pos_bitcnt   = 0;
    beetapei_state_fine   = 0;
    beetapei_bit_fine     = 0;
    beetapei_crc          = 0;
    beetapei_kansascycle  = 0;
    beetapei_elapsed_zclk = 0;

    return;
}

int beetapei_load_mtd(void)
{
    char savename[CONFIG_BUFFER_LEN+1];
    char filetag[CONFIG_BUFFER_LEN+1];
    char buffera[CONFIG_BUFFER_LEN+1];
    char bufferb[CONFIG_BUFFER_LEN+1];
    int k,l;
    char c,d;
    int head_fs = 0;
    int head_la = 0;
    int head_ae = 0;
    UINT_8 head_ft = 0;
    UINT_8 head_fsl = 0;
    UINT_8 head_fsh = 0;
    UINT_8 head_lal = 0;
    UINT_8 head_lah = 0;
    UINT_8 head_ael = 0;
    UINT_8 head_aeh = 0;
    UINT_8 head_sp = 0;
    UINT_8 head_ac = 0;
    UINT_8 head_nu = 0;

    FILE *beetapei_src__fp;

    beetapei_reset_state();

    if ( file_select_ex("Source file",beetapei_file_tapedest,"MTD",300,0,0) )
    {
        if ( ( beetapei_src__fp = fopen(beetapei_file_tapedest,"rt") ) == NULL )
        {
            alert("Error:","Couldn't open MTD file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        while ( !feof(beetapei_src__fp) )
        {
            if ( fgets(buffera,CONFIG_BUFFER_LEN,beetapei_src__fp) == NULL )
            {
                goto next_stage;
            }

            if ( buffera[strlen("Savename")] == ' ' )
            {
                if ( strncmp(buffera,"Savename",strlen("Savename")) == 0 )
                {
                    l = -1;

                    savename[0] = '\0';

                    if ( strlen("Savename")+1 < strlen(buffera) )
                    {
                        for ( k = strlen("Savename")+1 ; k < (int) strlen(buffera) ; k++ )
                        {
                            switch ( l )
                            {
                                case -1:
                                {
                                    if ( buffera[k-1] == '=' )
                                    {
                                        l = 0;
                                    }

                                    break;
                                }

                                case 0:
                                {
                                    if ( ( buffera[k-1] != ' '  ) &&
                                         ( buffera[k-1] != '\t' )    )
                                    {
                                        l = 1;

                                        goto default_proceed;
                                    }

                                    break;
                                }

                                default:
                                {
                                    default_proceed:

                                    if ( l < CONFIG_BUFFER_LEN )
                                    {
                                        savename[l-1] = buffera[k-1];
                                        savename[l]   = '\0';
                                    }

                                    l++;

                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if ( buffera[strlen("Filename")] == ' ' )
            {
                if ( strncmp(buffera,"Filename",strlen("Filename")) == 0 )
                {
                    l = -1;

                    filetag[0] = '\0';

                    if ( strlen("Filename")+1 < strlen(buffera) )
                    {
                        for ( k = strlen("Filename")+1 ; k < (int) strlen(buffera) ; k++ )
                        {
                            switch ( l )
                            {
                                case -1:
                                {
                                    if ( buffera[k-1] == '=' )
                                    {
                                        l = 0;
                                    }

                                    break;
                                }

                                case 0:
                                {
                                    if ( ( buffera[k-1] != ' '  ) &&
                                         ( buffera[k-1] != '\t' )    )
                                    {
                                        l = 1;

                                        goto default_proceed_b;
                                    }

                                    break;
                                }

                                default:
                                {
                                    default_proceed_b:

                                    if ( l < CONFIG_BUFFER_LEN )
                                    {
                                        filetag[l-1] = buffera[k-1];
                                        filetag[l]   = '\0';
                                    }

                                    l++;

                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if ( buffera[strlen("Filetype")] == ' ' )
            {
                if ( strncmp(buffera,"Filetype",strlen("Filetype")) == 0 )
                {
                    sscanf(buffera,"%s %c %c",bufferb,&c,&d);

                    head_ft = d;
                }
            }

            if ( buffera[strlen("Filesize")] == ' ' )
            {
                if ( strncmp(buffera,"Filesize",strlen("Filesize")) == 0 )
                {
                    sscanf(buffera,"%s %c %x",bufferb,&c,&head_fs);
                }
            }

            if ( buffera[strlen("Load_addr")] == ' ' )
            {
                if ( strncmp(buffera,"Load_addr",strlen("Load_addr")) == 0 )
                {
                    sscanf(buffera,"%s %c %x",bufferb,&c,&head_la);
                }
            }

            if ( buffera[strlen("Exec_addr")] == ' ' )
            {
                if ( strncmp(buffera,"Exec_addr",strlen("Exec_addr")) == 0 )
                {
                    sscanf(buffera,"%s %c %x",bufferb,&c,&head_ae);
                }
            }

            if ( buffera[strlen("File_speed")] == ' ' )
            {
                if ( strncmp(buffera,"File_speed",strlen("File_speed")) == 0 )
                {
                    sscanf(buffera,"%s %c %x",bufferb,&c,&k);

                    head_sp = k;
                }
            }

            if ( buffera[strlen("Exec_mode")] == ' ' )
            {
                if ( strncmp(buffera,"Exec_mode",strlen("Exec_mode")) == 0 )
                {
                    sscanf(buffera,"%s %c %x",bufferb,&c,&k);

                    head_ac = k;
                }
            }
        }

        next_stage:

        fclose(beetapei_src__fp);

        replace_filename(bufferb,beetapei_file_tapedest,savename,CONFIG_BUFFER_LEN);

        if ( ( beetapei_src__fp = fopen(bufferb,"rb") ) == NULL )
        {
            alert("Error:","Couldn't open data file.","","&OK",NULL,'o',0);

            return D_O_K;
        }

        head_lal = (     head_la                    & 0x000ff );
        head_lah = ( ( ( head_la & 0x0ff00 ) >> 8 ) & 0x000ff );

        head_ael = (     head_ae                    & 0x000ff );
        head_aeh = ( ( ( head_ae & 0x0ff00 ) >> 8 ) & 0x000ff );

        head_fsl = (     head_fs                    & 0x000ff );
        head_fsh = ( ( ( head_fs & 0x0ff00 ) >> 8 ) & 0x000ff );

        beetapei_convert_to_memload(head_ft,head_fsl,head_fsh,head_lal,head_lah,head_ael,head_aeh,head_sp,head_ac,head_nu,filetag,head_fs,beetapei_src__fp);

        fclose(beetapei_src__fp);
    }

    beetape_update_menu_marks();

    return D_O_K;
}

int beetapei_pipe_wav(void)
{
    beetape_update_menu_marks();

    return D_O_K;
}

int beetapei_stopload(void)
{
    beetapei_reset_state();

    beetape_update_menu_marks();

    return D_O_K;
}









/*
   Menus, initialisation other miscellaneous crap.
*/

char beetape_menu_optionb[] = "  Output to &Data file";
char beetape_menu_optionc[] = "  Output to &Wav file";
char beetape_menu_optiond[] = "- Output &Unconnected";

char beetape_menu_optione[] = "  Autosave off";
char beetape_menu_optionf[] = "- Autosave on";

#define STOP_LOAD_OP_NUM 15

MENU beetape_menu[] =
{
    { beetape_menu_optionb,         beetapeo_set_tape_1,      NULL, 0,          NULL },
    { beetape_menu_optionc,         beetapeo_set_tape_2,      NULL, D_DISABLED, NULL },
    { beetape_menu_optiond,         beetapeo_set_tape_3,      NULL, 0,          NULL },
    { "",                           NULL,                     NULL, 0,          NULL },
    { beetape_menu_optione,         beetape_set_autosave_off, NULL, 0,          NULL },
    { beetape_menu_optionf,         beetape_set_autosave_on,  NULL, 0,          NULL },
    { "",                           NULL,                     NULL, 0,          NULL },
    { "Select AutoSave Directory",  beetape_set_savedir,      NULL, 0,          NULL },
    { "",                           NULL,                     NULL, 0,          NULL },
    { "Pipe input from D&ata file", beetapei_pipe_data,       NULL, 0,          NULL },
    { "Pipe input from Wa&v file",  beetapei_pipe_wav,        NULL, D_DISABLED, NULL },
    { "Load from Da&ta file",       beetapei_load_data,       NULL, 0,          NULL },
    { "Load from &mtd file",        beetapei_load_mtd,        NULL, 0,          NULL },
    { "",                           NULL,                     NULL, 0,          NULL },
    { "Stop load operation",        beetapei_stopload,        NULL, 0,          NULL },
    { NULL,                         NULL,                     NULL, 0,          NULL }
};

SetupData beetape_setdat[] =
{
    { "tape_1200_low",        &(beetape_cycles[0][0]), 2 },
    { "tape_1200_high",       &(beetape_cycles[0][1]), 2 },
    { "tape_2400_low",        &(beetape_cycles[1][0]), 2 },
    { "tape_2400_high",       &(beetape_cycles[1][1]), 2 },
    { "tape_1200_lower",      &(beetape_lower[0]),     2 },
    { "tape_1200_upper",      &(beetape_upper[0]),     2 },
    { "tape_2400_lower",      &(beetape_lower[1]),     2 },
    { "tape_2400_upper",      &(beetape_upper[1]),     2 },
    { "tape_300_count_low",   &(beetape_count[0][0]),  2 },
    { "tape_300_count_high",  &(beetape_count[0][1]),  2 },
    { "tape_1200_count_low",  &(beetape_count[1][0]),  2 },
    { "tape_1200_count_high", &(beetape_count[1][1]),  2 },
    { "tape_autosave",        &beetapeo_mode_autosave, 6 },
    { "", NULL, 0 }
};

SetupData *beetape_setup(void)
{
    beetape_cycles[0][0] = BEETAPE_1200_LOW;
    beetape_cycles[0][1] = BEETAPE_1200_HGH;
    beetape_cycles[1][0] = BEETAPE_2400_LOW;
    beetape_cycles[1][1] = BEETAPE_2400_HGH;

    beetape_lower[0] = BEETAPE_1200_LOWER;
    beetape_upper[0] = BEETAPE_1200_UPPER;
    beetape_lower[1] = BEETAPE_2400_LOWER;
    beetape_upper[1] = BEETAPE_2400_UPPER;

    beetape_count[0][0] = BEETAPE_300_COUNT_LOW;
    beetape_count[0][1] = BEETAPE_300_COUNT_HGH;
    beetape_count[1][0] = BEETAPE_1200_COUNT_LOW;
    beetape_count[1][1] = BEETAPE_1200_COUNT_HGH;

    beetapeo_mode_autosave = 1;

    return beetape_setdat;
}

int beetape_init(UINT_8 *_beetapeo_bus, UINT_8 *_beetapei_bus, weird_pointer_jive _beetapei_strober, UINT_16 *_beetape_cycle_bus)
{
    beetapeo_bus = _beetapeo_bus;
    beetapei_bus = _beetapei_bus;

    beetapei_strober = _beetapei_strober;

    beetape_cycle_bus = _beetape_cycle_bus;

    beetapei_buffer = NULL; /* this is needed to stop the reset function
                               putting in NULLs */

    beetapeo_reset_state();
    beetapei_reset_state();

    beetapeo_dest_fp = NULL;

    BEETAPEO_SET_DEFAULT_MODE;

    return 1;
}

MENU *beetape_getmenu(void)
{
    beetape_update_menu_marks();

    return beetape_menu;
}

void beetape_remove(void)
{
    beetapeo_reset_state();
    beetapei_reset_state();

    return;
}

void beetape_cycle(void)
{
    beetapeo_elapsed_zclk = ( beetapeo_elapsed_zclk + (*beetape_cycle_bus) ) & BEETAPE_ZCLK_MASK;
    beetapei_elapsed_zclk = ( beetapei_elapsed_zclk + (*beetape_cycle_bus) ) & BEETAPE_ZCLK_MASK;

    beetapeo_cycle();
    beetapei_cycle();

    return;
}

void beetape_update_menu_marks(void)
{
    beetape_menu_optionb[0] = ' ';
    beetape_menu_optionc[0] = ' ';
    beetape_menu_optiond[0] = ' ';

    beetape_menu_optione[0] = ' ';
    beetape_menu_optionf[0] = ' ';

    switch ( beetapeo_mode )
    {
        case 1:  { beetape_menu_optionb[0] = '-'; break; }
        case 2:  { beetape_menu_optionc[0] = '-'; break; }
        default: { beetape_menu_optiond[0] = '-'; break; }
    }

    switch ( beetapeo_mode_autosave )
    {
        case 0:  { beetape_menu_optione[0] = '-'; break; }
        default: { beetape_menu_optionf[0] = '-'; break; }
    }

    if ( beetapei_type )
    {
        (beetape_menu[STOP_LOAD_OP_NUM-6]).flags = D_DISABLED;
/*        (beetape_menu[STOP_LOAD_OP_NUM-5]).flags = D_DISABLED;*/
        (beetape_menu[STOP_LOAD_OP_NUM-4]).flags = D_DISABLED;
        (beetape_menu[STOP_LOAD_OP_NUM-3]).flags = D_DISABLED;

        (beetape_menu[STOP_LOAD_OP_NUM-1]).flags = 0;
    }

    else
    {
        (beetape_menu[STOP_LOAD_OP_NUM-6]).flags = 0;
/*        (beetape_menu[STOP_LOAD_OP_NUM-5]).flags = 0;*/
        (beetape_menu[STOP_LOAD_OP_NUM-4]).flags = 0;
        (beetape_menu[STOP_LOAD_OP_NUM-3]).flags = 0;

        (beetape_menu[STOP_LOAD_OP_NUM-1]).flags = D_DISABLED;
    }

    return;
}

