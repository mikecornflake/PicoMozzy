
#include "fakealeg.h"
#include "beesnd.h"
#include "u_dtype.h"
#include "beelowpc.h"
#include "configer.h"
#include "debmaloc.h"


/*
                           Sound Emulation
                           ===============

   Microbee Sound
   ==============

   The Microbee hangs it's speaker off bit 6 of port b of the pio.


   Emulation Method - PC Speaker
   =============================

   Sound emulation is done by estimating the output frequency by finding the
   number of clock cycles between 0->1 changes in the state of the speaker.
   This is done by maintaing the counter:

   UINT_32 beesnd_sound_clock_cycle_countera

   which counts the number of clock cycles done by the CPU.  Then, if an
   appropriate state change for the speaker is found (this occurs when the
   pio calls pio_b_rdy_data_out() with bit 6 of port b high where it was
   low on the previous call), the estimated fequency will be:

                                            10^9
   beesnd_freq = --------------------------------------------------------- Hz
                beesnd_sound_clock_cycle_countera*beesnd_clock_period_snd

   This frequency is stored until the next catchup point and then the tone
   (or otherwise) played by the speaker is set correctly.


   Details
   =======

   I tried a few methods.  Averaging resulted in tones bleeding into one
   another, making frogger sound pretty bad - basically the tone of the
   frog "jump" sound was random.

   In the end, I chose to simply base the tone on a single cycle, which
   surprisingly gave the best results.  So the tone played is calculated
   based on the period of the most recent 0->1 transition.  The only caveat
   here is that if the frequency decreases, then the frequency played will
   still be the higher (older) frequency in the current interval.  This
   prevents the spaces between tones being played rather than the tones
   themselves.

   Finally, it is necessary to insert "clicks" to get the sound right.
   For example, if the space between notes falls in a single catchup
   interval then a "click" is needed to make sure the notes are
   differentiable (see, for example, the fanfare in cbrikout.mwb).

   Also, if the tone decreases during an interval then a click is inserted
   after this tone.

   OK, that was confusing - just see the code (search for the functions
   gen_sound and gen_nosound, and also the variable beesnd_click_here to
   locate the relevant bits of the emulator).


   Data
   ====

   beesnd_do_sound: 0 if sound is off
                    1 if sound is on

   beesnd_sound_sync: when the timer function is called to resync the
                      emulator, this will be set to the value of do_sound.
                      Hence when it is set it indicates that pc time
                      approx. equal to mbee time, so sound emulation can be
                      attempted.

   tone_here:  0 normally, 1 if there is a tone this sound period.
   click_here: 0 normally, 1 if there is a click during this sound period.
   click_next: 0 normally, 1 if there should be a click next sound period.
   click_stop: 0 normally, 1 if a click is happening that must be stopped.

   speaker_state:     state of pio port b bit 6
   speaker_state_old: previous state of pio port b bit 6

   freq:      frequency of tone.
   freq_temp: used to calc the frequency of the latest cycle.

   sound_clock_cycle_countera: number of cycles since last transition
   sound_clock_cycle_counterb: period of last tone.



   mode: 0 none available
         1 PC speaker
         2 soundcard

*/

char beesnd_menu_optiona[] = "- Sound o&ff";
char beesnd_menu_optionb[] = "- Sound o&n";

UINT_16 *beesnd_cycle_bus;

void beesnd_update_menu_marks(void);


int beesnd_turnoff(void);
int beesnd_turnon(void);

#define BEESND_DO_SOUND_DEFAULT                 1
#define BEESND_CLOCK_PERIOD_SND_DEFAULT         298
#define BEESND_MIN_FREQ_DEFAULT                 200
#define BEESND_FREQ_COUNT_ERROR_NUMER_DEFAULT   1
#define BEESND_FREQ_COUNT_ERROR_DENOM_DEFAULT   2
#define BEESND_MAX_CLOCK_CNNT_DEFAULT           0x0dfffffff
#define BEESND_MAX_CLOCK_CNNT_RESET_DEFAULT     0x00dffffff

int     beesnd_do_sound;
volatile int     beesnd_sound_sync;
UINT_32 beesnd_clock_period_snd;
UINT_32 beesnd_min_freq;
UINT_32 beesnd_freq_count_error_numer;
UINT_32 beesnd_freq_count_error_denom;
UINT_64 beesnd_max_clock_cnnt;
UINT_64 beesnd_max_clock_cnnt_reset;

UINT_8 *beesnd_speaker_state_tmp = NULL;

UINT_8 beesnd_tone_here;
UINT_8 beesnd_click_here;
UINT_8 beesnd_click_next;
UINT_8 beesnd_click_stop;

UINT_8 beesnd_speaker_state;
UINT_8 beesnd_speaker_state_old;

UINT_32 beesnd_freq;
UINT_32 beesnd_freq_temp;

UINT_64 beesnd_sound_clock_cycle_countera;
UINT_64 beesnd_sound_clock_cycle_counterb;
UINT_64 beesnd_sound_clock_cycle_counterc;

UINT_64 beesnd_i64;
UINT_64 beesnd_j64;
UINT_64 beesnd_k64;



SetupData beesnd_setdat[] =
{
    { "do_sound",                      &beesnd_do_sound,               6 },
    { "beesnd_clock_period_snd",       &beesnd_clock_period_snd,       2 },
    { "beesnd_min_freq",               &beesnd_min_freq,               2 },
    { "beesnd_freq_count_error_numer", &beesnd_freq_count_error_numer, 2 },
    { "beesnd_freq_count_error_denom", &beesnd_freq_count_error_denom, 2 },
    { "beesnd_max_clock_cnnt",         &beesnd_max_clock_cnnt,         9 },
    { "beesnd_max_clock_cnnt_reset",   &beesnd_max_clock_cnnt_reset,   9 },
    { "",                              NULL,                           0 }
};

MENU beesnd_menu[] =
{
    { beesnd_menu_optiona, beesnd_turnoff, NULL, 0, NULL },
    { beesnd_menu_optionb, beesnd_turnon,  NULL, 0, NULL },
    { NULL,                NULL,           NULL, 0, NULL }
};


void beesnd_update_menu_marks(void)
{
    beesnd_menu_optiona[0] = ' ';
    beesnd_menu_optionb[0] = ' ';

    switch ( beesnd_do_sound )
    {
        case 0:  { beesnd_menu_optiona[0] = '-'; break; }
        default: { beesnd_menu_optionb[0] = '-'; break; }
    }

    return;
}

MENU *beesnd_getmenu(void)
{
    beesnd_update_menu_marks();
    gen_nosound();

    return beesnd_menu;
}

SetupData *beesnd_setup(void)
{
    beesnd_clock_period_snd       = BEESND_CLOCK_PERIOD_SND_DEFAULT;
    beesnd_min_freq               = BEESND_MIN_FREQ_DEFAULT;
    beesnd_freq_count_error_numer = BEESND_FREQ_COUNT_ERROR_NUMER_DEFAULT;
    beesnd_freq_count_error_denom = BEESND_FREQ_COUNT_ERROR_DENOM_DEFAULT;
    beesnd_max_clock_cnnt         = BEESND_MAX_CLOCK_CNNT_DEFAULT;
    beesnd_max_clock_cnnt_reset   = BEESND_MAX_CLOCK_CNNT_RESET_DEFAULT;
    beesnd_do_sound               = BEESND_DO_SOUND_DEFAULT;
    beesnd_sound_sync             = 0;

    return beesnd_setdat;
}

void beesnd_timing_accur_signal(void)
{
    beesnd_sound_sync = beesnd_do_sound;

    return;
}
END_OF_FUNCTION(beesnd_timing_accur_signal)

void beesnd_toggle_sound(void)
{
    if ( beesnd_do_sound )
    {
        beesnd_turnoff();
    }

    else
    {
        beesnd_turnon();
    }

    return;
}
END_OF_FUNCTION(beesnd_toggle_sound)

int beesnd_init(UINT_8 *_beesnd_speaker_state_tmp, UINT_16 *_beesnd_cycle_bus)
{
    LOCK_VARIABLE(beesnd_do_sound);
    LOCK_VARIABLE(beesnd_sound_sync);

    LOCK_FUNCTION(beesnd_timing_accur_signal);
    LOCK_FUNCTION(beesnd_toggle_sound);

    beesnd_cycle_bus = _beesnd_cycle_bus;

    beesnd_speaker_state_tmp = _beesnd_speaker_state_tmp;

    beesnd_sound_clock_cycle_countera = 0;
    beesnd_sound_clock_cycle_counterb = 0;
    beesnd_sound_clock_cycle_counterc = 0;

    beesnd_tone_here  = 0;
    beesnd_click_here = 0;
    beesnd_click_next = 0;
    beesnd_click_stop = 0;

    beesnd_speaker_state     = 0;
    beesnd_speaker_state_old = 0;

    beesnd_freq      = 0;
    beesnd_freq_temp = 0;

    beesnd_update_menu_marks();

    return 1;
}

void beesnd_remove(void)
{
    gen_nosound();

    return;
}

void beesnd_cycle(void)
{
    if ( beesnd_do_sound )
    {
        {
            {
                beesnd_sound_clock_cycle_countera += *beesnd_cycle_bus;

                if ( beesnd_sound_clock_cycle_countera > beesnd_max_clock_cnnt )
                {
                    beesnd_sound_clock_cycle_countera = beesnd_max_clock_cnnt_reset;
                }

                if ( beesnd_sound_sync )
                {
                    /*
                       OK, timing is synced correctly ish.
                    */

                    beesnd_sound_sync = 0;

                    if ( beesnd_tone_here )
                    {
                        beesnd_click_stop = 0;

                        if ( beesnd_freq < beesnd_min_freq )
                        {
                            /*
                               Insert subsonic "click".
                            */

                            gen_soundclick();

                            beesnd_click_here = 0;
                            beesnd_click_next = 0;

                            beesnd_sound_clock_cycle_counterb = 0;

                            beesnd_freq = 0;

                            beesnd_tone_here = 0;

                            beesnd_click_stop = 1;
                        }

                        else
                        {
                            if ( beesnd_click_here )
                            {
                                /*
                                   Restarting the tone will insert an audible
                                   "click" into the tone.  This makes sure
                                   there are no missed pauses (see
                                   cbrikout.mwb, for example).
                                */

                                gen_sound(beesnd_freq);
                            }

                            beesnd_click_here = beesnd_click_next;
                            beesnd_click_next = 0;

                            /*
                               Leave a cycle or two before we cut the tone off.
                            */

                            if ( beesnd_sound_clock_cycle_countera > 2*beesnd_sound_clock_cycle_counterb )
                            {
                                beesnd_tone_here = 0;
                                beesnd_freq      = 0;
                            }
                        }
                    }

                    else
                    {
                        /*
                           Tone has finished, or never was.
                           (can't have clicks here).
                           Turn off if something has ended.
                        */

                        if ( beesnd_sound_clock_cycle_counterb | beesnd_click_stop )
                        {
                            gen_nosound();

                            beesnd_click_here = 0;
                            beesnd_click_next = 0;

                            beesnd_sound_clock_cycle_counterb = 0;

                            beesnd_freq = 0;

                            beesnd_click_stop = 0;
                        }
                    }
                }
            }
        }
    }

    return;
}

void beesnd_speaker_state_change(void)
{
    if ( beesnd_do_sound )
    {
        beesnd_speaker_state_old = beesnd_speaker_state;
        beesnd_speaker_state     = *beesnd_speaker_state_tmp;

        if ( beesnd_sound_clock_cycle_countera && beesnd_speaker_state && !beesnd_speaker_state_old )
        {
            /*
               Calculate the cycle frequency and reset the counter.
            */

            beesnd_freq_temp = 1000000000/(beesnd_sound_clock_cycle_countera*beesnd_clock_period_snd);

            if ( beesnd_freq_temp < beesnd_freq )
            {
                /*
                   Tone has changed, or a click has occured.
                */

                beesnd_click_next = 1;

                beesnd_sound_clock_cycle_countera = beesnd_sound_clock_cycle_counterb;
            }

            else if ( ( beesnd_sound_clock_cycle_countera > ((beesnd_sound_clock_cycle_counterb*(beesnd_freq_count_error_denom+beesnd_freq_count_error_numer))/beesnd_freq_count_error_denom) ) ||
                      ( beesnd_sound_clock_cycle_countera < ((beesnd_sound_clock_cycle_counterb*(beesnd_freq_count_error_denom-beesnd_freq_count_error_numer))/beesnd_freq_count_error_denom) )    )
            {
                /*
                   Tone has started, or a click has occured.
                */

                beesnd_click_here = 1;
            }

            beesnd_freq = beesnd_freq_temp;

            /*
               Reset counters.
            */

            beesnd_sound_clock_cycle_counterb = beesnd_sound_clock_cycle_countera;
            beesnd_sound_clock_cycle_countera = 0;

            /*
               Set the flag to indicate that there is a tone in this interval.
            */

            beesnd_tone_here = 1;
        }
    }

    return;
}



int beesnd_turnoff(void)
{
    beesnd_do_sound   = 0;
    beesnd_sound_sync = 0;

    gen_nosound();

    beesnd_update_menu_marks();

    return D_O_K;
}

int beesnd_turnon(void)
{
    beesnd_do_sound   = 1;
    beesnd_sound_sync = 0;

    beesnd_update_menu_marks();

    return D_O_K;
}


int beesnd_is_snd_on(void)
{
    return beesnd_do_sound;
}

